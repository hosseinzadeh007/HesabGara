using System.IO;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Microsoft.Win32;
using System.Windows.Documents;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public partial class MainWindow : Window
{
    private readonly AccountingService S = new();
    private readonly BackupService Backup = new();
    private readonly AppUser CurrentUser;
    private readonly PrintService Printer = new();
    private List<Invoice> _allInvoices = new();
    private int _calendarOffset = 0;
    private static readonly PersianCalendar PC = new();
    private bool _ready;
    private DateTime _lastAutomaticBackup = DateTime.MinValue;
    private bool _backupRunning;

    public MainWindow(AppUser currentUser)
    {
        CurrentUser = currentUser;
        InitializeComponent();
        Loaded += async (_, _) =>
        {
            BtnDashboard.Focus();
            try { await InitializeAsync(); }
            catch (Exception ex)
            {
                try
                {
                    var logDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara");
                    Directory.CreateDirectory(logDir);
                    File.AppendAllText(
                        Path.Combine(logDir, "startup-error.log"),
                        $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}{Environment.NewLine}{Environment.NewLine}");
                }
                catch { }
                MessageBox.Show(
                    $"راه‌اندازی صفحه اصلی انجام نشد:{Environment.NewLine}{ex.Message}{Environment.NewLine}{Environment.NewLine}گزارش خطا در startup-error.log ذخیره شد.",
                    "خطای راه‌اندازی حساب‌گرا",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        };
        var timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        timer.Tick += async (_, _) => { ClockText.Text = DateTime.Now.ToString("HH:mm:ss"); await AutomaticBackupTickAsync(); };
        timer.Start();
    }

    private async Task InitializeAsync()
    {
        var now = DateTime.Now;
        var py = PC.GetYear(now); var pm = PC.GetMonth(now); var pd = PC.GetDayOfMonth(now);
        ClockText.Text = now.ToString("HH:mm:ss");
        DatabasePathText.Text = AccountingPurchasePro.Data.AppDbContext.DatabasePath;
        await LoadCompanies();

        await RefreshDashboard();
        _ready = true;
    }

    private async Task AutomaticBackupTickAsync()
    {
        if (!_ready || _backupRunning) return;
        try
        {
            var minutesText = await new SettingsService().GetAsync("AutoBackupMinutes");
            if (!int.TryParse(minutesText, out var minutes) || minutes <= 0) return;
            if ((DateTime.Now - _lastAutomaticBackup).TotalMinutes < minutes) return;
            _backupRunning = true;
            var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara", "Backups");
            await Backup.CreateBackupAsync(folder);
            _lastAutomaticBackup = DateTime.Now;
        }
        catch
        {
            // Automatic backup must never interrupt accounting work. Manual backup still reports errors to the user.
        }
        finally { _backupRunning = false; }
    }

    private async Task LoadCompanies()
    {
        var list = await S.GetCompaniesAsync();
        CompanyFilter.ItemsSource = new[] { new Company { Id = 0, Name = "همه" } }.Concat(list).ToList();
        CompanyFilter.DisplayMemberPath = "Name";
        CompanyFilter.SelectedValuePath = "Id";
        CompanyFilter.SelectedIndex = 0;
    }

    private int? SelectedCompanyId => CompanyFilter.SelectedValue is int id && id > 0 ? id : null;

    private async Task RefreshDashboard()
    {
        _allInvoices = await S.GetInvoicesAsync(SelectedCompanyId);
        var companies = await S.GetCompaniesAsync();
        CompaniesCount.Text = companies.Count.ToString("N0");
        ActiveCompanyText.Text = SelectedCompanyId.HasValue ? $"شرکت فعال: {companies.FirstOrDefault(x => x.Id == SelectedCompanyId.Value)?.Name ?? "شرکت انتخاب‌شده"}" : "همه شرکت‌ها";
        DatabaseStatusText.Text = "● پایگاه‌داده آماده";
        BackupStatusText.Text = "پشتیبان‌گیری خودکار فعال";
        InvoicesCount.Text = _allInvoices.Count.ToString("N0");
        TotalInvoices.Text = _allInvoices.Sum(x => x.Amount).ToString("N0");
        TotalPaid.Text = _allInvoices.Sum(x => x.Paid).ToString("N0");
        TotalBalance.Text = _allInvoices.Sum(AccountingService.Balance).ToString("N0");

        LatestInvoices.ItemsSource = _allInvoices.Take(8).Select((x, i) => new
        {
            Row = i + 1,
            Number = x.Number,
            InvoiceDate = PersianDateService.ToPersian(x.InvoiceDate),
            Company = x.Company?.Name ?? "-",
            Amount = x.Amount.ToString("N0"),
            Paid = x.Paid.ToString("N0"),
            Balance = AccountingService.Balance(x).ToString("N0"),
            DueDate = PersianDateService.ToPersian(x.DueDate),
            Status = GetStatus(x)
        }).ToList();

        DueList.Children.Clear();
        var today = DateTime.Today;
        foreach (var x in _allInvoices.Where(x => AccountingService.Balance(x) > 0)
                     .OrderBy(x => x.DueDate).Take(7))
        {
            var days = (x.DueDate.Date - today).Days;
            var color = days < 0 ? "#DC2626" : days <= 7 ? "#EA580C" : "#16A34A";
            var card = new Border { BorderBrush = new SolidColorBrush(Color.FromRgb(231, 235, 241)), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(7), Padding = new Thickness(9), Margin = new Thickness(0, 4, 0, 4) };
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
            var p = new StackPanel();
            p.Children.Add(new TextBlock { Text = x.Company?.Name ?? "فروشنده", FontWeight = FontWeights.SemiBold, HorizontalAlignment = HorizontalAlignment.Right });
            p.Children.Add(new TextBlock { Text = $"سررسید: {PersianDateService.ToPersian(x.DueDate)}", FontSize = 11, Foreground = Brushes.Gray, HorizontalAlignment = HorizontalAlignment.Right });
            Grid.SetColumn(p, 0); g.Children.Add(p);
            var right = new StackPanel { HorizontalAlignment = HorizontalAlignment.Left };
            right.Children.Add(new TextBlock { Text = AccountingService.Balance(x).ToString("N0"), Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color)), FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Left });
            right.Children.Add(new Border { Child = new TextBlock { Text = days < 0 ? "گذشته" : $"{days} روز", Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color)), FontSize = 11, HorizontalAlignment = HorizontalAlignment.Center }, BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color)), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(8), Padding = new Thickness(5, 1, 5, 1), HorizontalAlignment = HorizontalAlignment.Left });
            Grid.SetColumn(right, 1); g.Children.Add(right);
            card.Child = g; DueList.Children.Add(card);
        }
    }

    private static string GetStatus(Invoice x)
    {
        var b = AccountingService.Balance(x);
        if (b <= 0) return "تسویه شده";
        if (x.Paid > 0) return "بخشی پرداخت شده";
        return "پرداخت نشده";
    }

    private void BuildCalendar()
    {
        var now = DateTime.Today;
        var baseDate = now.AddMonths(_calendarOffset);
        var year = PC.GetYear(baseDate); var month = PC.GetMonth(baseDate);
        string[] days = { "شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه" };
        var first = PC.ToDateTime(year, month, 1, 0, 0, 0, 0);
        var offset = ((int)first.DayOfWeek + 1) % 7; // Saturday first
        var daysInMonth = PC.GetDaysInMonth(year, month);
        for (int day = 1; day <= daysInMonth; day++)
        {
            var dt = PC.ToDateTime(year, month, day, 0, 0, 0, 0);
            var b = new Border { Margin = new Thickness(2), CornerRadius = new CornerRadius(5), Padding = new Thickness(2), Background = dt.Date == now ? new SolidColorBrush(Color.FromRgb(220, 235, 255)) : Brushes.Transparent };
            b.Child = new TextBlock { Text = day.ToString("00"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, FontWeight = dt.Date == now ? FontWeights.Bold : FontWeights.Normal };
        }
    }

    private static string GetPersianMonth(int m) => m switch
    {
        1 => "فروردین", 2 => "اردیبهشت", 3 => "خرداد", 4 => "تیر", 5 => "مرداد", 6 => "شهریور",
        7 => "مهر", 8 => "آبان", 9 => "آذر", 10 => "دی", 11 => "بهمن", _ => "اسفند"
    };

    private void CalendarPrev_Click(object sender, RoutedEventArgs e) { _calendarOffset--; BuildCalendar(); }
    private void CalendarNext_Click(object sender, RoutedEventArgs e) { _calendarOffset++; BuildCalendar(); }

    private void Dashboard_Click(object sender, RoutedEventArgs e) { }

    private void Calculator_Click(object sender, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo("calc.exe") { UseShellExecute = true }); }
        catch (Exception ex) { MessageBox.Show("ماشین حساب ویندوز اجرا نشد: " + ex.Message, "ماشین حساب", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void Help_Click(object sender, RoutedEventArgs e)
    {
        var w = new Window { Title = "راهنمای حساب‌گرا", Width = 760, Height = 560, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, FlowDirection = FlowDirection.RightToLeft, Background = new SolidColorBrush(Color.FromRgb(244,247,251)) };
        var box = new TextBox { IsReadOnly = true, TextWrapping = TextWrapping.Wrap, FontSize = 15, Padding = new Thickness(24), BorderThickness = new Thickness(0), Background = Brushes.White, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Text = "راهنمای سریع حساب‌گرا\n\n۱) ابتدا از منوی «شرکت‌ها» اطلاعات شرکت را ثبت کنید.\n۲) در بخش «فاکتورها» شرکت را انتخاب کرده و فاکتورهای همان شرکت را مشاهده یا ثبت کنید.\n۳) از «گزارش‌ها» می‌توانید گزارش هر شرکت را به صورت جداگانه مشاهده و Excel دریافت کنید.\n۴) برای پشتیبان‌گیری از اطلاعات از گزینه «پشتیبان‌گیری» استفاده کنید.\n۵) گزینه «تقویم» تقویم شمسی را نمایش می‌دهد و «ماشین حساب» ماشین حساب ویندوز را اجرا می‌کند.\n\nپشتیبانی: حسین حسین زاده | Hzadeh007@gmail.com" };
        w.Content = new Border { Margin = new Thickness(18), CornerRadius = new CornerRadius(16), BorderBrush = new SolidColorBrush(Color.FromRgb(224,232,240)), BorderThickness = new Thickness(1), Child = box };
        w.ShowDialog();
    }

    private void Calendar_Click(object sender, RoutedEventArgs e)
    {
        var w = new Window { Title = "تقویم شمسی", Width = 520, Height = 470, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, FlowDirection = FlowDirection.RightToLeft, Background = Brushes.White };
        var root = new Grid { Margin = new Thickness(18) }; root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(50) }); root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        var cal = new System.Windows.Controls.Primitives.UniformGrid { Columns = 7, Rows = 7, Margin = new Thickness(10) }; Grid.SetRow(cal,1); root.Children.Add(cal);
        int offset = _calendarOffset; Action render = () => { cal.Children.Clear(); var now = DateTime.Today.AddMonths(offset); int y=PC.GetYear(now), m=PC.GetMonth(now); title.Text=$"{GetPersianMonth(m)} {y}"; foreach(var d in new[]{"شنبه","یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه"}) cal.Children.Add(new TextBlock{Text=d,FontWeight=FontWeights.Bold,HorizontalAlignment=HorizontalAlignment.Center,VerticalAlignment=VerticalAlignment.Center}); var first=PC.ToDateTime(y,m,1,0,0,0,0); int off=((int)first.DayOfWeek+1)%7; for(int i=0;i<off;i++)cal.Children.Add(new TextBlock()); for(int day=1;day<=PC.GetDaysInMonth(y,m);day++){var dt=PC.ToDateTime(y,m,day,0,0,0,0);cal.Children.Add(new Border{Margin=new Thickness(2),Padding=new Thickness(5),CornerRadius=new CornerRadius(6),Background=dt.Date==DateTime.Today?new SolidColorBrush(Color.FromRgb(220,235,255)):Brushes.Transparent,Child=new TextBlock{Text=day.ToString("00"),HorizontalAlignment=HorizontalAlignment.Center,VerticalAlignment=VerticalAlignment.Center}});} }; prev.Click+=(s,e)=>{offset--;render();}; next.Click+=(s,e)=>{offset++;render();}; render(); w.Content=root; w.ShowDialog();
    }

    private void LocalUpdate_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin)
        {
            MessageBox.Show("فقط مدیر سیستم می‌تواند نرم‌افزار را به‌روزرسانی کند.", "به‌روزرسانی محلی", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var dialog = new OpenFileDialog
        {
            Filter = "بسته به‌روزرسانی حساب‌گرا|*.zip",
            Title = "انتخاب بسته به‌روزرسانی محلی حساب‌گرا",
            CheckFileExists = true,
            Multiselect = false
        };
        if (dialog.ShowDialog() != true) return;

        LocalUpdateService.UpdatePackage package;
        try
        {
            package = LocalUpdateService.Inspect(dialog.FileName);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "بسته نامعتبر", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        var current = LocalUpdateService.CurrentVersion;
        var target = AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        var confirm = MessageBox.Show(
            $"نسخه فعلی: {current}\nنسخه بسته: {package.Version}\n\nمحل نصب فعلی:\n{target}\n\nقبل از به‌روزرسانی یک پشتیبان از اطلاعات تهیه می‌شود.\nبرنامه بسته شده و پس از نصب مجدداً اجرا خواهد شد.\n\nآیا ادامه می‌دهید؟",
            "به‌روزرسانی محلی حساب‌گرا",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question);

        if (confirm != MessageBoxResult.Yes)
        {
            try { Directory.Delete(package.ExtractedRoot, true); } catch { }
            return;
        }

        try
        {
            var backupFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara", "Backups");
            Backup.CreateBackupAsync(backupFolder).GetAwaiter().GetResult();
            LocalUpdateService.StartUpdate(package, target);
            MessageBox.Show("به‌روزرسانی آماده اجراست. حساب‌گرا اکنون بسته و پس از نصب نسخه جدید دوباره اجرا می‌شود.", "به‌روزرسانی", MessageBoxButton.OK, MessageBoxImage.Information);
            Application.Current.Shutdown(0);
        }
        catch (Exception ex)
        {
            try { Directory.Delete(package.ExtractedRoot, true); } catch { }
            MessageBox.Show("شروع به‌روزرسانی انجام نشد:\n" + ex.Message, "خطای به‌روزرسانی", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void About_Click(object sender, RoutedEventArgs e)
    {
        var w = new Window { Title = "درباره حساب‌گرا", Width = 620, Height = 430, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, FlowDirection = FlowDirection.RightToLeft, Background = Brushes.White };
        var p = new StackPanel { Margin = new Thickness(36), VerticalAlignment = VerticalAlignment.Center };
        p.Children.Add(new TextBlock { Text = "حساب‌گرا", FontSize = 38, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(8,47,103)), HorizontalAlignment = HorizontalAlignment.Center });
        p.Children.Add(new TextBlock { Text = "نرم‌افزار حسابداری و مدیریت خرید", FontSize = 18, Foreground = new SolidColorBrush(Color.FromRgb(23,105,210)), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0,5,0,24) });
        p.Children.Add(new TextBlock { Text = "نسخه: ۳.۵.۰\nتوسعه‌دهنده: حسین حسین زاده\nایمیل: Hzadeh007@gmail.com\nقابلیت‌ها: مدیریت شرکت‌ها، فاکتورها، پرداخت‌ها، سررسیدها، گزارش‌های تفکیک‌شده و Excel\nپایگاه داده: SQLite / SQL Server\nچارچوب: .NET 8 / WPF", FontSize = 15, Foreground = new SolidColorBrush(Color.FromRgb(52,64,84)), TextAlignment = TextAlignment.Center, TextWrapping = TextWrapping.Wrap, LineHeight = 30 });
        w.Content = p; w.ShowDialog();
    }
    private void Companies_Click(object sender, RoutedEventArgs e) { if (!CurrentUser.IsAdmin && !CurrentUser.CanManageData) { MessageBox.Show("دسترسی مدیریت داده لازم است."); return; }
        var w = new Window { Title = "مدیریت شرکت‌ها", Content = new CompaniesView(S, LoadCompanies), Width = 1250, Height = 780, MinWidth = 1000, MinHeight = 650, FlowDirection = FlowDirection.RightToLeft, WindowStartupLocation = WindowStartupLocation.CenterOwner, Owner = this, Background = new SolidColorBrush(Color.FromRgb(244,247,251)) }; w.ShowDialog(); }
    private void Invoices_Click(object sender, RoutedEventArgs e) { if (!CurrentUser.IsAdmin && !CurrentUser.CanManageData) { MessageBox.Show("دسترسی مدیریت داده لازم است."); return; } var w = new InvoicesView(S, SelectedCompanyId); var host = new Window { Title = "مدیریت فاکتورها", Content = w, Width = 1400, Height = 820, MinWidth = 1100, MinHeight = 650, FlowDirection = FlowDirection.RightToLeft, WindowStartupLocation = WindowStartupLocation.CenterOwner, Owner = this, Background = new SolidColorBrush(Color.FromRgb(244,247,251)) }; host.ShowDialog(); }
    private void Payments_Click(object sender, RoutedEventArgs e) { if (!CurrentUser.IsAdmin && !CurrentUser.CanManageData) { MessageBox.Show("دسترسی مدیریت داده لازم است."); return; } var w = new Window { Title = "پرداخت‌ها", Content = new PaymentsView(S, SelectedCompanyId), Width = 1150, Height = 700, FlowDirection = FlowDirection.RightToLeft, Owner = this }; w.ShowDialog(); }
    private async void Due_Click(object sender, RoutedEventArgs e) { if (!CurrentUser.IsAdmin && !CurrentUser.CanViewReports) { MessageBox.Show("دسترسی گزارش لازم است."); return; } var w = new Window { Title = "سررسیدها", Content = await ReportsView.Create(S, SelectedCompanyId, true), Width = 1200, Height = 750, FlowDirection = FlowDirection.RightToLeft, Owner = this }; w.ShowDialog(); }
    private async void Reports_Click(object sender, RoutedEventArgs e) { if (!CurrentUser.IsAdmin && !CurrentUser.CanViewReports) { MessageBox.Show("دسترسی گزارش لازم است."); return; } var w = new Window { Title = "گزارش‌ها", Content = await ReportsView.Create(S, SelectedCompanyId, false), Width = 1200, Height = 750, FlowDirection = FlowDirection.RightToLeft, Owner = this }; w.ShowDialog(); }
    private async void ImportExcel_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin && !CurrentUser.CanImportExport) { MessageBox.Show("دسترسی Excel لازم است."); return; }
        var d = new OpenFileDialog { Filter = "Excel Workbook|*.xlsx;*.xlsm", Title = "انتخاب فایل Excel برای ورود اطلاعات" };
        if (d.ShowDialog() != true) return;
        try
        {
            var result = await new ExcelService().ImportAsync(d.FileName);
            await LoadCompanies();
            await RefreshDashboard();
            var msg = $"ورود Excel انجام شد.\n\nشرکت‌های جدید: {result.CompaniesAdded:N0}\nشرکت‌های تکراری/ردشده: {result.CompaniesSkipped:N0}\nفاکتورهای جدید: {result.InvoicesAdded:N0}\nفاکتورهای تکراری/ردشده: {result.InvoicesSkipped:N0}\nپرداخت‌های جدید: {result.PaymentsAdded:N0}\nپرداخت‌های تکراری/ردشده: {result.PaymentsSkipped:N0}";
            if (result.Errors.Count > 0) msg += $"\n\nهشدار/خطا: {result.Errors.Count:N0} مورد";
            MessageBox.Show(msg, "نتیجه ورود Excel", MessageBoxButton.OK, result.Errors.Count > 0 ? MessageBoxImage.Warning : MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show("ورود Excel انجام نشد: " + ex.Message, "خطا", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void ExportExcel_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin && !CurrentUser.CanImportExport) { MessageBox.Show("دسترسی Excel لازم است."); return; }
        var d = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx", Title = "ذخیره خروجی Excel", FileName = $"accounting-export-{DateTime.Now:yyyyMMdd-HHmm}.xlsx" };
        if (d.ShowDialog() != true) return;
        try
        {
            await new ExcelService().ExportAsync(d.FileName, SelectedCompanyId);
            MessageBox.Show("خروجی Excel با موفقیت ذخیره شد.", "خروجی Excel", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show("خروجی Excel انجام نشد: " + ex.Message, "خطا", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void Backup_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin && !CurrentUser.CanBackup) { MessageBox.Show("دسترسی پشتیبان‌گیری لازم است."); return; }
        try
        {
            var dlg = new OpenFolderDialog { Title = "پوشه ذخیره پشتیبان", Multiselect = false };
            if (dlg.ShowDialog() != true) return;
            var file = await Backup.CreateBackupAsync(dlg.FolderName);
            MessageBox.Show($"پشتیبان با موفقیت ایجاد شد:\n{file}", "پشتیبان‌گیری", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "پشتیبان‌گیری", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void Users_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin) { MessageBox.Show("فقط مدیر سیستم به مدیریت کاربران دسترسی دارد."); return; }
        var w=new Window{Title="کاربران و دسترسی",Content=new UserManagementView(CurrentUser.Id),Width=1050,Height=650,FlowDirection=FlowDirection.RightToLeft,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner}; w.ShowDialog();
    }

    private void Settings_Click(object sender, RoutedEventArgs e)
    {
        var w=new Window{Title="تنظیمات",Content=new SettingsView(),Width=720,Height=520,FlowDirection=FlowDirection.RightToLeft,Owner=this,WindowStartupLocation=WindowStartupLocation.CenterOwner}; w.ShowDialog();
    }

    private async void Print_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin && !CurrentUser.CanViewReports) { MessageBox.Show("دسترسی چاپ گزارش لازم است."); return; }
        var rows=await S.GetInvoicesAsync(SelectedCompanyId); Printer.PrintInvoices(rows.Take(100));
    }

    private async void Restore_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin && !CurrentUser.CanBackup) { MessageBox.Show("دسترسی بازیابی لازم است."); return; }
        var d=new OpenFileDialog{Filter="SQLite Database|*.db",Title="انتخاب فایل پشتیبان"}; if(d.ShowDialog()!=true)return;
        if(MessageBox.Show("بازیابی پایگاه داده باعث بسته شدن برنامه می‌شود. ادامه می‌دهید؟","تأیید بازیابی",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        try
        {
            var safety = await Backup.RestoreBackupAsync(d.FileName);
            MessageBox.Show(
                $"بازیابی انجام شد. نسخه ایمنی در:\n{safety}\n\nبرنامه را دوباره اجرا کنید.",
                "بازیابی",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            Application.Current.Shutdown();
        }
        catch(Exception ex)
        {
            MessageBox.Show(ex.Message, "بازیابی", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    /* legacy backup handler */
    private void Backup_Click_Legacy(object sender, RoutedEventArgs e)
    {
        var src = AccountingPurchasePro.Data.AppDbContext.DatabasePath;
        if (!System.IO.File.Exists(src)) { MessageBox.Show("هنوز دیتابیسی ایجاد نشده است."); return; }
        var d = new SaveFileDialog { Filter = "SQLite Database|*.db", FileName = $"accounting-backup-{DateTime.Now:yyyyMMdd-HHmm}.db" };
        if (d.ShowDialog() == true) System.IO.File.Copy(src, d.FileName, true);
    }
    private async void CompanyFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready) return;
        await RefreshDashboard();
    }

    private async void Search_Click(object sender, RoutedEventArgs e)
    {
        var company = SelectedCompanyId;
        var search = InvoiceNumberSearch.Text.Trim();
        var rows = await S.GetInvoicesAsync(company, string.IsNullOrWhiteSpace(search) ? null : search);
        var status = (StatusFilter.SelectedItem as ComboBoxItem)?.Content?.ToString();
        if (!string.IsNullOrWhiteSpace(status) && status != "همه") rows = rows.Where(x => GetStatus(x) == status).ToList();
        if (!string.IsNullOrWhiteSpace(InvoiceSearchDate.Text) && InvoiceSearchDate.Text != "انتخاب تاریخ")
        {
            if (!PersianDateService.TryParse(InvoiceSearchDate.Text, out var invoiceDate)) { MessageBox.Show("تاریخ فاکتور معتبر نیست. نمونه: ۱۴۰۵/۰۵/۲۵", "جستجو", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            rows = rows.Where(x => x.InvoiceDate.Date == invoiceDate.Date).ToList();
        }
        if (!string.IsNullOrWhiteSpace(DueSearchDate.Text) && DueSearchDate.Text != "انتخاب تاریخ")
        {
            if (!PersianDateService.TryParse(DueSearchDate.Text, out var dueDate)) { MessageBox.Show("تاریخ سررسید معتبر نیست. نمونه: ۱۴۰۵/۰۶/۲۵", "جستجو", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            rows = rows.Where(x => x.DueDate.Date == dueDate.Date).ToList();
        }
        LatestInvoices.ItemsSource = rows.Take(50).Select((x, i) => new { Row = i + 1, Number = x.Number, InvoiceDate = PersianDateService.ToPersian(x.InvoiceDate), Company = x.Company?.Name ?? "-", Amount = x.Amount.ToString("N0"), Paid = x.Paid.ToString("N0"), Balance = AccountingService.Balance(x).ToString("N0"), DueDate = PersianDateService.ToPersian(x.DueDate), Status = GetStatus(x) }).ToList();
    }
    private async void ClearFilter_Click(object sender, RoutedEventArgs e) { CompanyFilter.SelectedIndex = 0; StatusFilter.SelectedIndex = 0; InvoiceNumberSearch.Clear(); InvoiceSearchDate.Text = "انتخاب تاریخ"; DueSearchDate.Text = "انتخاب تاریخ"; await RefreshDashboard(); }
    private void Exit_Click(object sender, RoutedEventArgs e) => Close();
}
