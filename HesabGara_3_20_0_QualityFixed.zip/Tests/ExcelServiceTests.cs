using AccountingPurchasePro.Data;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace AccountingPurchasePro.Tests;

public class ExcelServiceTests : DatabaseTestBase
{
    static readonly AccountingService S = new();
    static readonly ExcelService Excel = new();

    [Fact]
    public async Task Export_Then_Import_Round_Trips_Companies_Invoices_And_Payments()
    {
        // Seed the source database.
        var company = new Company { Name = "شرکت آزمایشی", Phone = "021-000000" };
        await S.AddCompanyAsync(company);
        var invoice = new Invoice { CompanyId = company.Id, Number = "RT-1", Amount = 1000m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(30) };
        await S.AddInvoiceAsync(invoice);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 250m, PayDate = DateTime.Today, PaymentMethod = "نقد" });

        var xlsxPath = Path.Combine(Path.GetTempPath(), $"HesabGara-tests-export-{Guid.NewGuid():N}.xlsx");
        try
        {
            await Excel.ExportAsync(xlsxPath);

            // Import into a second, empty database.
            var importDbPath = Path.Combine(Path.GetTempPath(), $"HesabGara-tests-import-{Guid.NewGuid():N}.db");
            try
            {
                AppDbContext.TestDatabasePathOverride.Value = importDbPath;
                using (var initDb = new AppDbContext()) initDb.Database.EnsureCreated();

                var result = await Excel.ImportAsync(xlsxPath);
                Assert.Equal(1, result.CompaniesAdded);
                Assert.Equal(1, result.InvoicesAdded);
                Assert.Equal(1, result.PaymentsAdded);
                Assert.Empty(result.Errors);

                var importedInvoices = await S.GetInvoicesAsync();
                var importedInvoice = Assert.Single(importedInvoices);
                Assert.Equal("RT-1", importedInvoice.Number);
                Assert.Equal(1000m, importedInvoice.Amount);
                Assert.Equal(250m, importedInvoice.Paid);

                // Re-importing the same file must not create duplicates.
                var second = await Excel.ImportAsync(xlsxPath);
                Assert.Equal(0, second.CompaniesAdded);
                Assert.Equal(0, second.InvoicesAdded);
                Assert.Equal((await S.GetInvoicesAsync()).Count, importedInvoices.Count);
            }
            finally
            {
                AppDbContext.TestDatabasePathOverride.Value = DatabasePath; // restore this test's own db
                try { if (File.Exists(importDbPath)) File.Delete(importDbPath); } catch { }
            }
        }
        finally
        {
            try { if (File.Exists(xlsxPath)) File.Delete(xlsxPath); } catch { }
        }
    }

    [Fact]
    public async Task Import_Accepts_Single_Sheet_File_And_Auto_Creates_Company()
    {
        // Mirrors what a user would hand-build in a simple spreadsheet: one sheet, no
        // separate "Companies" tab at all, and a company name that doesn't exist yet.
        var xlsxPath = Path.Combine(Path.GetTempPath(), $"HesabGara-tests-simple-{Guid.NewGuid():N}.xlsx");
        try
        {
            using (var wb = new ClosedXML.Excel.XLWorkbook())
            {
                var ws = wb.Worksheets.Add("Sheet1"); // نام دلخواه، نه لزوماً «فاکتورها»
                ws.Cell(1,1).Value="نام شرکت"; ws.Cell(1,2).Value="شماره فاکتور"; ws.Cell(1,3).Value="مبلغ";
                ws.Cell(2,1).Value="شرکت تازه"; ws.Cell(2,2).Value="S-1"; ws.Cell(2,3).Value=500000;
                wb.SaveAs(xlsxPath);
            }

            var result = await Excel.ImportAsync(xlsxPath);
            Assert.Equal(1, result.CompaniesAdded);
            Assert.Equal(1, result.InvoicesAdded);
            Assert.Empty(result.Errors);

            var companies = await S.GetCompaniesAsync();
            Assert.Contains(companies, c => c.Name == "شرکت تازه");
            var invoices = await S.GetInvoicesAsync();
            var invoice = Assert.Single(invoices);
            Assert.Equal("S-1", invoice.Number);
            Assert.Equal(500000m, invoice.Amount);
        }
        finally
        {
            try { if (File.Exists(xlsxPath)) File.Delete(xlsxPath); } catch { }
        }
    }
}
