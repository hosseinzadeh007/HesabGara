using System.Windows.Media;

namespace AccountingPurchasePro.Views;

// C#-side mirror of the palette defined in App.xaml, for the views that build their UI in
// code-behind instead of XAML. Keeping both in sync means every screen in the app - however
// it's built - draws from the same small, deliberate color system instead of scattered
// one-off hex values.
public static class AppTheme
{
    static SolidColorBrush B(string hex) { var b = (SolidColorBrush)new BrushConverter().ConvertFromString(hex)!; b.Freeze(); return b; }

    public static readonly SolidColorBrush Brand900 = B("#0A2647");
    public static readonly SolidColorBrush Brand800 = B("#123A66");
    public static readonly SolidColorBrush Brand700 = B("#1B4E86");
    public static readonly SolidColorBrush Brand600 = B("#1E63A8");
    public static readonly SolidColorBrush Brand500 = B("#3E82C4");
    public static readonly SolidColorBrush Brand100 = B("#E7F1FB");
    public static readonly SolidColorBrush Brand50  = B("#F3F8FD");
    public static readonly SolidColorBrush Accent   = B("#14A9E0");

    public static readonly SolidColorBrush Ink900     = B("#1D2939");
    public static readonly SolidColorBrush Ink700     = B("#344054");
    public static readonly SolidColorBrush Ink500     = B("#66707F");
    public static readonly SolidColorBrush Line300    = B("#D0D9E2");
    public static readonly SolidColorBrush Line200    = B("#E3E8EF");
    public static readonly SolidColorBrush Surface100 = B("#F4F7FA");
    public static readonly SolidColorBrush Surface50  = B("#F8FAFC");

    public static readonly SolidColorBrush Success600 = B("#12946B");
    public static readonly SolidColorBrush Success100 = B("#E3F6EE");
    public static readonly SolidColorBrush Warning600 = B("#C27803");
    public static readonly SolidColorBrush Warning100 = B("#FDF3E0");
    public static readonly SolidColorBrush Danger600  = B("#C4293D");
    public static readonly SolidColorBrush Danger100  = B("#FBE7EA");

    public static readonly System.Windows.Media.Effects.DropShadowEffect CardShadow = MakeShadow();
    static System.Windows.Media.Effects.DropShadowEffect MakeShadow()
    {
        var e = new System.Windows.Media.Effects.DropShadowEffect { Color = Colors.Black, Direction = 270, ShadowDepth = 1.5, BlurRadius = 12, Opacity = 0.09 };
        e.Freeze();
        return e;
    }
}
