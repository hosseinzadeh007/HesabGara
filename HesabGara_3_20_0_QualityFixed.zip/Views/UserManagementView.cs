using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public sealed class UserManagementView : Grid
{
    readonly UserService S = new(); readonly int CurrentUserId; readonly DataGrid G = new();
    readonly TextBox User = new(), Display = new(), Password = new(), SecurityAnswer = new();
    readonly ComboBox SecurityQuestion = new() { IsEditable = true };
    readonly CheckBox Admin = new(), Active = new() { IsChecked = true }, Data = new() { IsChecked = true }, Reports = new() { IsChecked = true }, Excel = new() { IsChecked = true }, Backup = new() { IsChecked = true };

    public UserManagementView(int currentUserId) { CurrentUserId=currentUserId; Build(); Loaded += async (_,_)=>await Load(); }

    void Build()
    {
        FlowDirection = FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});

        var card = new Border
        {
            Background = Brushes.White,
            BorderBrush = AppTheme.Line200,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(14),
            Padding = new Thickness(16),
            Margin = new Thickness(12,12,12,8),
            Effect = AppTheme.CardShadow
        };
        var outer = new StackPanel();

        // Three evenly-sized fields (same "label above box" pattern used across every
        // other tab in the app), instead of the old fixed-width fake-label textboxes
        // whose height never matched the real inputs beside them.
        var fields = new Grid { FlowDirection = FlowDirection.RightToLeft };
        for (int i=0;i<3;i++) fields.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        fields.RowDefinitions.Add(new RowDefinition { Height = new GridLength(62) });
        AddField(fields, "نام کاربری", User, 0);
        AddField(fields, "نام نمایشی", Display, 1);
        AddField(fields, "رمز جدید (اختیاری برای ویرایش)", Password, 2);
        outer.Children.Add(fields);

        // برای این‌که کاربر بتواند بعداً از طریق «فراموشی رمز» خودش را بازیابی کند، باید هر
        // دو مقدار سؤال و پاسخ با هم وارد شوند - فقط برای کاربرانی که مدیر می‌خواهد این
        // قابلیت را برایشان فعال کند؛ خالی گذاشتن هر دو یعنی فعلاً بازیابی خودکار ندارد.
        var recovery = new Grid { FlowDirection = FlowDirection.RightToLeft, Margin = new Thickness(0,10,0,0) };
        for (int i=0;i<2;i++) recovery.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        recovery.RowDefinitions.Add(new RowDefinition { Height = new GridLength(62) });
        SecurityQuestion.ItemsSource = new[] { "نام اولین حیوان خانگی شما چیست؟", "نام شهر محل تولد شما چیست؟", "نام مدرسه‌ی ابتدایی شما چیست؟" };
        AddComboField(recovery, "سؤال امنیتی (برای بازیابی رمز کاربر)", SecurityQuestion, 0);
        AddField(recovery, "پاسخ سؤال امنیتی", SecurityAnswer, 1);
        outer.Children.Add(recovery);

        Admin.Content="مدیر"; Active.Content="فعال"; Data.Content="مدیریت داده"; Reports.Content="گزارش"; Excel.Content="Excel"; Backup.Content="پشتیبان";
        foreach (var cb in new[] { Admin, Active, Data, Reports, Excel, Backup })
        {
            cb.Margin = new Thickness(0,0,18,0);
            cb.VerticalAlignment = VerticalAlignment.Center;
        }
        var permissions = new StackPanel { Orientation=Orientation.Horizontal, FlowDirection=FlowDirection.RightToLeft, Margin=new Thickness(0,14,0,0), Children={Admin,Active,Data,Reports,Excel,Backup} };
        outer.Children.Add(permissions);

        var add=Btn("＋ کاربر جدید"); add.Click+=Add;
        var edit=Btn("ویرایش"); edit.Click+=Edit;
        var off=Btn("غیرفعال‌سازی"); off.Click+=Deactivate;
        var audit=Btn("گزارش فعالیت‌ها");
        audit.Click += (_,_) => { var w=new Window { Title="گزارش فعالیت‌های سیستم", Content=new AuditLogView(), Width=1100, Height=650, Owner=Window.GetWindow(this), FlowDirection=FlowDirection.RightToLeft, WindowStartupLocation=WindowStartupLocation.CenterOwner }; w.ShowDialog(); };
        var buttons = new StackPanel { Orientation=Orientation.Horizontal, FlowDirection=FlowDirection.RightToLeft, Margin=new Thickness(0,14,0,0), Children={add,edit,off,audit} };
        outer.Children.Add(buttons);

        card.Child = outer;
        Grid.SetRow(card,0); Children.Add(card);

        G.AutoGenerateColumns=false; G.IsReadOnly=true; G.CanUserAddRows=false; G.Margin=new Thickness(12,0,12,12);
        G.Columns.Add(new DataGridTextColumn{Header="کاربری",Binding=new System.Windows.Data.Binding("UserName")});
        G.Columns.Add(new DataGridTextColumn{Header="نام",Binding=new System.Windows.Data.Binding("DisplayName")});
        G.Columns.Add(new DataGridCheckBoxColumn{Header="مدیر",Binding=new System.Windows.Data.Binding("IsAdmin")});
        G.Columns.Add(new DataGridCheckBoxColumn{Header="فعال",Binding=new System.Windows.Data.Binding("IsActive")});
        G.Columns.Add(new DataGridCheckBoxColumn{Header="داده",Binding=new System.Windows.Data.Binding("CanManageData")});
        G.Columns.Add(new DataGridCheckBoxColumn{Header="گزارش",Binding=new System.Windows.Data.Binding("CanViewReports")});
        G.Columns.Add(new DataGridCheckBoxColumn{Header="Excel",Binding=new System.Windows.Data.Binding("CanImportExport")});
        G.Columns.Add(new DataGridCheckBoxColumn{Header="Backup",Binding=new System.Windows.Data.Binding("CanBackup")});
        Grid.SetRow(G,1); Children.Add(G);
        G.SelectionChanged += (_,_)=>{if(G.SelectedItem is AppUser u){User.Text=u.UserName;Display.Text=u.DisplayName;Admin.IsChecked=u.IsAdmin;Active.IsChecked=u.IsActive;Data.IsChecked=u.CanManageData;Reports.IsChecked=u.CanViewReports;Excel.IsChecked=u.CanImportExport;Backup.IsChecked=u.CanBackup;Password.Clear();SecurityQuestion.Text=u.SecurityQuestion??"";SecurityAnswer.Clear();}};
    }

    static void AddField(Grid g, string label, TextBox box, int col)
    {
        var p = new StackPanel { Margin = new Thickness(5,0,5,0) };
        p.Children.Add(new TextBlock { Text = label, FontWeight = FontWeights.SemiBold, Foreground = AppTheme.Ink700 });
        box.Height = 40; box.Margin = new Thickness(0,5,0,0);
        p.Children.Add(box);
        Grid.SetColumn(p,col); Grid.SetRow(p,0); g.Children.Add(p);
    }
    static void AddComboField(Grid g, string label, ComboBox box, int col)
    {
        var p = new StackPanel { Margin = new Thickness(5,0,5,0) };
        p.Children.Add(new TextBlock { Text = label, FontWeight = FontWeights.SemiBold, Foreground = AppTheme.Ink700 });
        box.Height = 40; box.Margin = new Thickness(0,5,0,0);
        p.Children.Add(box);
        Grid.SetColumn(p,col); Grid.SetRow(p,0); g.Children.Add(p);
    }
    static Button Btn(string text) => new() { Content = text, Margin = new Thickness(4,4,4,4), Padding = new Thickness(14,8,14,8), Height = 38, FontWeight = FontWeights.SemiBold, Cursor = System.Windows.Input.Cursors.Hand };

    async Task Load(){G.ItemsSource=await S.GetAllAsync();}
    AppUser Input(int id=0)=>new(){Id=id,UserName=User.Text.Trim(),DisplayName=Display.Text.Trim(),IsAdmin=Admin.IsChecked==true,IsActive=Active.IsChecked==true,CanManageData=Data.IsChecked==true,CanViewReports=Reports.IsChecked==true,CanImportExport=Excel.IsChecked==true,CanBackup=Backup.IsChecked==true};
    async void Add(object? s,RoutedEventArgs e){try{await S.CreateAsync(Input(),Password.Text,SecurityQuestion.Text,SecurityAnswer.Text);Password.Clear();SecurityAnswer.Clear();await Load();MessageBox.Show("کاربر ایجاد شد.");}catch(Exception ex){MessageBox.Show(ex.Message,"کاربر",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    async void Edit(object? s,RoutedEventArgs e){if(G.SelectedItem is not AppUser u){MessageBox.Show("یک کاربر را انتخاب کنید.");return;}try{await S.UpdateAsync(Input(u.Id),Password.Text,SecurityQuestion.Text,SecurityAnswer.Text);Password.Clear();SecurityAnswer.Clear();await Load();}catch(Exception ex){MessageBox.Show(ex.Message,"کاربر",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    async void Deactivate(object? s,RoutedEventArgs e){if(G.SelectedItem is not AppUser u)return;if(MessageBox.Show($"کاربر {u.UserName} غیرفعال شود؟","تأیید",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;try{await S.DeactivateAsync(u.Id,CurrentUserId);await Load();}catch(Exception ex){MessageBox.Show(ex.Message,"کاربر",MessageBoxButton.OK,MessageBoxImage.Warning);}}
}
