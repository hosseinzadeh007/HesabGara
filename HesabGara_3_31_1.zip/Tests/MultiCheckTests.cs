﻿using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

/// <summary>ثبت چند چک با مبلغ و سررسید متفاوت برای یک یا چند فاکتور.</summary>
public class MultiCheckTests : DatabaseTestBase
{
    static readonly AccountingService S = new();

    static async Task<Invoice> SeedInvoiceAsync(Company company, string number, decimal amount, int dueInDays)
    {
        var invoice = new Invoice { CompanyId = company.Id, Number = number, Amount = amount, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(dueInDays) };
        await S.AddInvoiceAsync(invoice);
        return invoice;
    }

    static async Task<Company> SeedCompanyAsync()
    {
        var company = new Company { Name = "شرکت چک " + Guid.NewGuid().ToString("N")[..6] };
        await S.AddCompanyAsync(company);
        return company;
    }

    [Fact]
    public async Task One_Invoice_Many_Checks_Each_Becomes_A_Payment()
    {
        var company = await SeedCompanyAsync();
        var inv = await SeedInvoiceAsync(company, "M-1", 1000m, 30);
        var specs = new[]
        {
            new AccountingService.CheckSpec(300m, "111", DateTime.Today.AddDays(30), null),
            new AccountingService.CheckSpec(300m, "222", DateTime.Today.AddDays(60), null),
            new AccountingService.CheckSpec(400m, "333", DateTime.Today.AddDays(90), null),
        };
        var result = await S.AddMultiCheckPaymentAsync(new List<int> { inv.Id }, specs, DateTime.Today, null);
        Assert.Equal(3, result.Count);
        var pays = (await S.GetPaymentsAsync(company.Id)).Where(p => p.InvoiceId == inv.Id).OrderBy(p => p.CheckNumber).ToList();
        Assert.Equal(new[] { "111", "222", "333" }, pays.Select(p => p.CheckNumber).ToArray());
        Assert.Equal(1000m, pays.Sum(p => p.Amount));
    }

    [Fact]
    public async Task Checks_Spill_Over_To_The_Next_Invoice_By_Due_Date()
    {
        var company = await SeedCompanyAsync();
        var a = await SeedInvoiceAsync(company, "A", 500m, 10);
        var b = await SeedInvoiceAsync(company, "B", 500m, 20);
        var specs = new[]
        {
            new AccountingService.CheckSpec(300m, "1", null, null),
            new AccountingService.CheckSpec(400m, "2", null, null),
            new AccountingService.CheckSpec(300m, "3", null, null),
        };
        // چک اول همه روی A؛ چک دوم ۲۰۰ برای تکمیل A و ۲۰۰ روی B؛ چک سوم ۳۰۰ روی B
        var result = await S.AddMultiCheckPaymentAsync(new List<int> { b.Id, a.Id }, specs, DateTime.Today, null);
        Assert.Equal(4, result.Count);
        var pays = await S.GetPaymentsAsync(company.Id);
        Assert.Equal(500m, pays.Where(p => p.InvoiceId == a.Id).Sum(p => p.Amount));
        Assert.Equal(500m, pays.Where(p => p.InvoiceId == b.Id).Sum(p => p.Amount));
    }

    [Fact]
    public async Task Total_More_Than_Balance_Is_Rejected_And_Nothing_Is_Saved()
    {
        var company = await SeedCompanyAsync();
        var inv = await SeedInvoiceAsync(company, "X", 500m, 10);
        var specs = new[]
        {
            new AccountingService.CheckSpec(300m, "1", null, null),
            new AccountingService.CheckSpec(300m, "2", null, null),
        };
        await Assert.ThrowsAsync<InvalidOperationException>(() => S.AddMultiCheckPaymentAsync(new List<int> { inv.Id }, specs, DateTime.Today, null));
        Assert.Empty((await S.GetPaymentsAsync(company.Id)).Where(p => p.InvoiceId == inv.Id));
    }
}
