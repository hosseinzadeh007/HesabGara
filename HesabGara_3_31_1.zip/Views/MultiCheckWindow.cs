using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using HesabGara.Domain;
using HesabGara.Services;

namespace HesabGara.Views;

/// <summary>
/// ثبت چند چک با شماره، سررسید و مبلغ متفاوت برای یک یا چند فاکتور. می‌شود چک‌ها را دستی اضافه کرد
/// یا با «ساخت خودکار» (تعداد، سررسید اولین چک، فاصله‌ی روز) چک‌های مساوی ساخت و بعد ویرایش کرد.
/// </summary>
public sealed class MultiCheckWindow : Window
{
    public sealed record InvoiceInfo(int Id, string Number, decimal Balance);

    sealed class RowUi
    {
        public readonly TextBox Number = new() { Height = 34, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) };
        public readonly PersianDateBox Date = new() { Height = 34, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) };
        public readonly TextBox Amount = new() { Height = 34, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) };
        public readonly CheckImagesPanel Images = new();
        public readonly Button ImgBtn = new() { Content = "📎", Height = 34, Margin = new Thickness(0, 0, 6, 0), ToolTip = "عکس این چک" };
        public readonly Button Remove = new() { Content = "✕", Height = 34, ToolTip = "حذف این چک" };
        public readonly Grid Root = new() { Margin = new Thickness(0, 0, 0, 6) };
    }

    readonly IReadOnlyList<InvoiceInfo> _invoices;
    readonly decimal _totalBalance;
    readonly List<RowUi> _rows = new();
    readonly StackPanel _rowsPanel = new();
    readonly TextBlock _summary = new() { FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 8, 0, 8) };
    readonly TextBox _countBox = new() { Text = "3", Width = 50, Height = 32, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 0, 12, 0) };
    readonly PersianDateBox _firstDateBox = new() { Width = 120, Height = 32, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 0, 12, 0) };
    readonly TextBox _gapBox = new() { Text = "30", Width = 50, Height = 32, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(4, 0, 12, 0) };
    readonly TextBox _noteBox = new() { Height = 34, VerticalContentAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 4, 0, 10) };
    readonly Button _saveBtn;

    public List<AccountingService.SplitPaymentAllocation> Allocations { get; private set; } = new();
    public int CheckCount { get; private set; }

    public MultiCheckWindow(IReadOnlyList<InvoiceInfo> invoices)
    {
        _invoices = invoices;
        _totalBalance = invoices.Sum(x => x.Balance);
        Title = "ثبت چند چک"; Width = 680; Height = 760;
        FlowDirection = FlowDirection.RightToLeft; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = AppTheme.Surface100;

        var form = new StackPanel { Margin = new Thickness(18) };
        form.Children.Add(new TextBlock
        {
            TextWrapping = TextWrapping.Wrap, Foreground = AppTheme.Ink700, Margin = new Thickness(0, 0, 0, 10),
            Text = "فاکتورها (به ترتیب نزدیک‌ترین سررسید پوشش داده می‌شوند):\n" + string.Join("\n", invoices.Select(x => $"• {x.Number} — مانده: {x.Balance:N0} ریال")) + $"\nجمع مانده: {_totalBalance:N0} ریال"
        });

        // ساخت خودکار
        var gen = new WrapPanel { Margin = new Thickness(0, 0, 0, 10) };
        gen.Children.Add(new TextBlock { Text = "ساخت خودکار چک‌های مساوی:  تعداد", VerticalAlignment = VerticalAlignment.Center });
        gen.Children.Add(_countBox);
        gen.Children.Add(new TextBlock { Text = "سررسید اولین چک", VerticalAlignment = VerticalAlignment.Center });
        gen.Children.Add(_firstDateBox);
        gen.Children.Add(new TextBlock { Text = "فاصله (روز)", VerticalAlignment = VerticalAlignment.Center });
        gen.Children.Add(_gapBox);
        var genBtn = MakeButton("ساخت ردیف‌ها", AppTheme.Brand600); genBtn.Foreground = Brushes.White; genBtn.Click += (_, _) => Generate();
        gen.Children.Add(genBtn);
        form.Children.Add(new Border { BorderBrush = AppTheme.Line300, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(8), Padding = new Thickness(10, 8, 10, 4), Margin = new Thickness(0, 0, 0, 12), Child = gen });

        var head = BuildGrid();
        foreach (var (text, col) in new[] { ("شماره چک", 0), ("سررسید چک", 1), ("مبلغ (ریال)", 2), ("عکس", 3) })
        {
            var t = new TextBlock { Text = text, FontWeight = FontWeights.SemiBold, Foreground = AppTheme.Ink700 };
            Grid.SetColumn(t, col); head.Children.Add(t);
        }
        form.Children.Add(head);
        form.Children.Add(_rowsPanel);
        var addBtn = MakeButton("＋ افزودن چک", AppTheme.Surface100); addBtn.Foreground = AppTheme.Ink700;
        addBtn.HorizontalAlignment = HorizontalAlignment.Left;
        addBtn.Click += (_, _) => { AddRow(); UpdateSummary(); };
        form.Children.Add(addBtn);
        form.Children.Add(_summary);
        form.Children.Add(new TextBlock { Text = "توضیحات (اختیاری، برای همه‌ی چک‌ها)", FontWeight = FontWeights.SemiBold, Foreground = AppTheme.Ink700 });
        form.Children.Add(_noteBox);

        _saveBtn = MakeButton("ثبت چک‌ها", AppTheme.Success600); _saveBtn.Foreground = Brushes.White;
        var cancelBtn = MakeButton("انصراف", AppTheme.Surface100); cancelBtn.Foreground = AppTheme.Ink700;
        _saveBtn.Click += (_, _) => Save();
        cancelBtn.Click += (_, _) => Close();
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Left };
        buttons.Children.Add(_saveBtn); buttons.Children.Add(cancelBtn);
        form.Children.Add(buttons);

        Content = new ScrollViewer { Content = form, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        AddRow(); UpdateSummary();
    }

    static Button MakeButton(string text, Brush bg) => new() { Content = text, Background = bg, BorderThickness = new Thickness(0), Padding = new Thickness(13, 8, 13, 8), Margin = new Thickness(4), FontWeight = FontWeights.SemiBold, Cursor = System.Windows.Input.Cursors.Hand };

    static Grid BuildGrid()
    {
        var g = new Grid { Margin = new Thickness(0, 0, 0, 4) };
        AddColumns(g);
        return g;
    }

    static void AddColumns(Grid g)
    {
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.2, GridUnitType.Star) });
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(128) });
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.3, GridUnitType.Star) });
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(52) });
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(34) });
    }

    static decimal ParseMoney(string? text)
    {
        var t = (text ?? "").Replace(",", "").Replace("٬", "").Trim();
        return decimal.TryParse(t, NumberStyles.Number, CultureInfo.InvariantCulture, out var v) ? v : 0m;
    }

    RowUi AddRow()
    {
        var r = new RowUi();
        AddColumns(r.Root);
        void Put(FrameworkElement el, int col) { Grid.SetColumn(el, col); r.Root.Children.Add(el); }
        Put(r.Number, 0); Put(r.Date, 1); Put(r.Amount, 2); Put(r.ImgBtn, 3); Put(r.Remove, 4);
        r.Amount.TextChanged += (_, _) => UpdateSummary();
        r.ImgBtn.Click += (_, _) => EditImages(r);
        r.Remove.Click += (_, _) => { _rows.Remove(r); _rowsPanel.Children.Remove(r.Root); UpdateSummary(); };
        _rows.Add(r); _rowsPanel.Children.Add(r.Root);
        return r;
    }

    void EditImages(RowUi r)
    {
        var holder = new ScrollViewer { Content = r.Images, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Margin = new Thickness(12) };
        var host = new Window { Title = "عکس این چک", Content = holder, Width = 460, Height = 380, Owner = this, FlowDirection = FlowDirection.RightToLeft, WindowStartupLocation = WindowStartupLocation.CenterOwner, Background = AppTheme.Surface100 };
        host.ShowDialog();
        holder.Content = null;   // تا همین پنل بعداً در پنجره‌ی دیگری هم قابل‌نمایش باشد
        var n = r.Images.NewImages.Count;
        r.ImgBtn.Content = n > 0 ? $"📎 {n}" : "📎";
    }

    void Generate()
    {
        if (!int.TryParse(_countBox.Text.Trim(), out var n) || n < 1 || n > 60) { MessageBox.Show("تعداد چک را بین ۱ تا ۶۰ وارد کنید."); return; }
        if (!int.TryParse(_gapBox.Text.Trim(), out var gap) || gap < 0 || gap > 3650) { MessageBox.Show("فاصله‌ی روز را بین ۰ تا ۳۶۵۰ وارد کنید."); return; }
        DateTime? first;
        try { first = _firstDateBox.SelectedDate; }
        catch (ArgumentException ex) { MessageBox.Show(ex.Message); return; }
        if (_rows.Any(r => r.Amount.Text.Trim().Length > 0 || r.Number.Text.Trim().Length > 0)
            && MessageBox.Show("ردیف‌های فعلی با ردیف‌های جدید جایگزین می‌شوند. ادامه می‌دهید؟", "ساخت خودکار", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;

        _rows.Clear(); _rowsPanel.Children.Clear();
        var baseAmount = Math.Floor(_totalBalance / n);
        for (var i = 0; i < n; i++)
        {
            var r = AddRow();
            var amount = i == n - 1 ? _totalBalance - baseAmount * (n - 1) : baseAmount;
            r.Amount.Text = amount.ToString("0.##", CultureInfo.InvariantCulture);
            if (first is DateTime f) r.Date.SelectedDate = f.AddDays(gap * i);
        }
        UpdateSummary();
    }

    void UpdateSummary()
    {
        var sum = _rows.Sum(r => ParseMoney(r.Amount.Text));
        var left = _totalBalance - sum;
        _summary.Text = $"جمع چک‌ها: {sum:N0}   |   مانده‌ی فاکتورها: {_totalBalance:N0}   |   "
            + (left < 0 ? $"{-left:N0} بیشتر از مانده!" : left == 0 ? "برابر با مانده ✓" : $"{left:N0} هنوز بدون چک");
        _summary.Foreground = left < 0 ? Brushes.Firebrick : left == 0 ? AppTheme.Success600 : AppTheme.Ink700;
    }

    async void Save()
    {
        var specs = new List<AccountingService.CheckSpec>();
        try
        {
            foreach (var r in _rows)
            {
                var number = r.Number.Text.Trim();
                var amount = ParseMoney(r.Amount.Text);
                var date = r.Date.SelectedDate;   // اگر تاریخ نامعتبر باشد ArgumentException می‌دهد
                if (number.Length == 0 && date is null && amount == 0 && r.Images.NewImages.Count == 0) continue;   // ردیف خالی
                if (amount <= 0) { MessageBox.Show("مبلغ هر چک را وارد کنید (ردیف اضافه را با ✕ حذف کنید)."); return; }
                specs.Add(new AccountingService.CheckSpec(amount, number.Length == 0 ? null : number, date, PaymentRules.DefaultCheckStatus, r.Images.NewImages));
            }
        }
        catch (ArgumentException ex) { MessageBox.Show(ex.Message, "ثبت چند چک", MessageBoxButton.OK, MessageBoxImage.Warning); return; }

        if (specs.Count == 0) { MessageBox.Show("حداقل یک چک با مبلغ وارد کنید."); return; }
        var total = specs.Sum(s => s.Amount);
        if (total > _totalBalance + 0.01m) { MessageBox.Show($"مجموع چک‌ها ({total:N0}) از مانده‌ی فاکتورها ({_totalBalance:N0}) بیشتر است."); return; }
        var dup = specs.Where(s => s.CheckNumber != null).GroupBy(s => s.CheckNumber).FirstOrDefault(g => g.Count() > 1);
        if (dup != null && MessageBox.Show($"شماره چک «{dup.Key}» بیش از یک بار آمده است. ادامه می‌دهید؟", "شماره تکراری", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;

        _saveBtn.IsEnabled = false;
        try
        {
            Allocations = await new AccountingService().AddMultiCheckPaymentAsync(_invoices.Select(x => x.Id).ToList(), specs, DateTime.Today, _noteBox.Text);
            CheckCount = specs.Count;
            DialogResult = true;
        }
        catch (Exception ex) when (ex is InvalidOperationException or ArgumentException)
        {
            MessageBox.Show(ex.Message, "ثبت چند چک", MessageBoxButton.OK, MessageBoxImage.Warning);
            _saveBtn.IsEnabled = true;
        }
    }
}
