using HesabGara.Data;
using HesabGara.Domain;
using HesabGara.Models;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

public sealed partial class AccountingService
{
    /// <summary>مشخصات یک چک در «ثبت چند چک» (هر چک مبلغ، شماره، سررسید و عکس مخصوص خودش را دارد).</summary>
    public sealed record CheckSpec(decimal Amount, string? CheckNumber, DateTime? CheckDate, string? CheckStatus, IReadOnlyList<byte[]>? Images = null);

    // چند چک (با مبلغ و سررسید متفاوت) برای یک یا چند فاکتور. مبلغ هر چک - به ترتیب نزدیک‌ترین سررسید فاکتور - از مانده‌ی فاکتورها
    // کم می‌شود؛ اگر یک چک از مانده‌ی یک فاکتور بیشتر باشد، بین فاکتور بعدی تقسیم می‌شود (مثل پرداخت مشترک) و برای هر سهم
    // یک رکورد Payment با همان مشخصات چک ثبت می‌شود. همه در یک تراکنش: یا همه‌ی چک‌ها ثبت می‌شوند یا هیچ‌کدام.
    public async Task<List<SplitPaymentAllocation>> AddMultiCheckPaymentAsync(List<int> invoiceIds, IReadOnlyList<CheckSpec> checks, DateTime payDate, string? note, CancellationToken ct = default)
    {
        if (invoiceIds is null || invoiceIds.Count < 1) throw new ArgumentException("حداقل یک فاکتور باید انتخاب شود.");
        if (checks is null || checks.Count < 1) throw new ArgumentException("حداقل یک چک وارد کنید.");
        foreach (var c in checks)
        {
            if (c.Amount <= 0) throw new ArgumentException("مبلغ همه‌ی چک‌ها باید بزرگ‌تر از صفر باشد.");
            ValidateImages(c.Images);
        }

        var results = new List<SplitPaymentAllocation>();
        await using var db = new AppDbContext();
        await InTransactionAsync(db, async () =>
        {
            var ids = invoiceIds.Distinct().ToList();
            var invoices = await db.Invoices.Where(x => ids.Contains(x.Id)).OrderBy(x => x.DueDate).ThenBy(x => x.Id).ToListAsync(ct);
            if (invoices.Count != ids.Count) throw new InvalidOperationException("برخی از فاکتورهای انتخاب‌شده پیدا نشدند.");

            var paid = new Dictionary<int, decimal>();
            foreach (var inv in invoices) paid[inv.Id] = await PaidTotalAsync(db, inv.Id, null, ct);
            var totalBalance = invoices.Sum(i => Math.Max(0m, i.NetAmount - paid[i.Id]));
            var totalChecks = checks.Sum(c => c.Amount);
            if (totalBalance <= 0) throw new InvalidOperationException("فاکتورهای انتخاب‌شده مانده‌ی قابل‌وصول ندارند.");
            if (totalChecks > totalBalance + 0.01m)
                throw new InvalidOperationException($"مجموع مبلغ چک‌ها ({totalChecks:N0}) از مجموع مانده‌ی فاکتورها ({totalBalance:N0}) بیشتر است.");

            var added = new List<(Payment Pay, CheckSpec Spec)>();
            for (var i = 0; i < checks.Count; i++)
            {
                var spec = checks[i];
                var remaining = spec.Amount;
                foreach (var inv in invoices)
                {
                    if (remaining <= 0) break;
                    var balance = Math.Max(0m, inv.NetAmount - paid[inv.Id]);
                    if (balance <= 0) continue;
                    var portion = Math.Min(balance, remaining);
                    var pay = new Payment
                    {
                        InvoiceId = inv.Id, Amount = portion, PayDate = payDate.Date, PaymentMethod = PaymentMethods.Check,
                        CheckNumber = spec.CheckNumber, CheckDate = spec.CheckDate, CheckStatus = spec.CheckStatus,
                        Note = string.IsNullOrWhiteSpace(note) ? $"چک {i + 1} از {checks.Count}" : note.Trim()
                    };
                    PaymentRules.NormalizeCheckFields(pay);
                    db.Payments.Add(pay);
                    added.Add((pay, spec));
                    paid[inv.Id] += portion;
                    inv.Paid = paid[inv.Id];
                    remaining -= portion;
                    results.Add(new SplitPaymentAllocation(inv.Id, inv.Number, portion));
                }
                if (remaining > 0.01m) throw new InvalidOperationException($"چک شماره {i + 1} ({spec.Amount:N0}) از مانده‌ی باقی‌مانده‌ی فاکتورها بیشتر است.");
            }

            await db.SaveChangesAsync(ct);
            foreach (var (pay, spec) in added) AddImagesToContext(db, pay.Id, spec.Images);
            foreach (var a in results)
                await AuditAsync("Create", "Payment(MultiCheck)", a.InvoiceId.ToString(), $"Invoice={a.InvoiceNumber}; Amount={a.Amount}; Checks={checks.Count}", db, ct);
            await db.SaveChangesAsync(ct);
        }, ct);
        return results;
    }
}
