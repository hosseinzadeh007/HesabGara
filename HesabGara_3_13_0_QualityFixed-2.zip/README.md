# حساب‌گرا (HesabGara)

نرم‌افزار حسابداری و مدیریت خرید — WPF / .NET 8، دیتابیس SQLite یا SQL Server.

نسخه‌ی فعلی: به فایل [`VERSION.txt`](./VERSION.txt) مراجعه کنید.

## ساخت پروژه
راهنمای کامل build و انتشار در [`Installer/README_BUILD_FA.md`](./Installer/README_BUILD_FA.md).

## پوشه‌ها
- `Views/` `Services/` `Models/` `Data/` `Domain/` — کد اصلی برنامه
- `Tests/` — تست‌های واحد
- `Installer/` — اسکریپت‌های build و Installer (Inno Setup)
- `docs/changelog/` — یادداشت‌ها و تاریخچه‌ی تغییرات نسخه‌های قبلی
