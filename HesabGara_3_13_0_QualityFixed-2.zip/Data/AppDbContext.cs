using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Data;

public sealed class AppDbContext : DbContext
{
    public DbSet<Company> Companies => Set<Company>();
    public DbSet<Invoice> Invoices => Set<Invoice>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<AppSetting> Settings => Set<AppSetting>();

    // Test-only hook: when set (flows through async/await via AsyncLocal), every
    // AppDbContext created on this call chain uses an isolated SQLite file at this path
    // instead of the real per-user database, and ignores DatabaseConfigurationStore
    // entirely (so a developer's real SQL Server settings are never touched by a test run).
    // Production code must never set this.
    public static readonly AsyncLocal<string?> TestDatabasePathOverride = new();

    public static string DatabaseDirectory => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara");
    public static string DatabasePath =>
        TestDatabasePathOverride.Value ?? Path.Combine(DatabaseDirectory, "accounting.db");

    static string LegacyDatabaseDirectory => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AccountingPurchasePro");
    static string LegacyDatabasePath => Path.Combine(LegacyDatabaseDirectory, "accounting.db");

    public AppDbContext()
    {
        PrepareDatabaseDirectory();
    }

    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
        PrepareDatabaseDirectory();
    }

    static void PrepareDatabaseDirectory()
    {
        if (TestDatabasePathOverride.Value is { } testPath)
        {
            var testDir = Path.GetDirectoryName(testPath);
            if (!string.IsNullOrWhiteSpace(testDir)) Directory.CreateDirectory(testDir);
            return;
        }

        if (string.IsNullOrWhiteSpace(DatabaseDirectory))
            throw new InvalidOperationException("مسیر ذخیره‌سازی اطلاعات حساب‌گرا قابل تشخیص نیست.");

        Directory.CreateDirectory(DatabaseDirectory);

        // Preserve data created by older builds that used the AccountingPurchasePro folder.
        // Copy only when the new database does not exist; never overwrite existing data.
        if (!File.Exists(DatabasePath) && File.Exists(LegacyDatabasePath))
        {
            File.Copy(LegacyDatabasePath, DatabasePath, false);
        }
    }

    protected override void OnConfiguring(DbContextOptionsBuilder options)
    {
        if (TestDatabasePathOverride.Value is { } testPath)
        {
            options.UseSqlite($"Data Source={testPath};Foreign Keys=True");
            return;
        }

        var cfg = DatabaseConfigurationStore.Load();
        if (cfg.Provider == DatabaseProvider.SqlServer && !string.IsNullOrWhiteSpace(cfg.ConnectionString))
            options.UseSqlServer(cfg.ConnectionString, sql => sql.EnableRetryOnFailure(5));
        else
            options.UseSqlite($"Data Source={DatabasePath};Cache=Shared;Foreign Keys=True");
    }

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Company>().HasIndex(x => x.Name).IsUnique();
        b.Entity<Company>().HasIndex(x => x.NationalId).IsUnique();
        b.Entity<Invoice>().HasIndex(x => new { x.CompanyId, x.Number }).IsUnique();
        b.Entity<Invoice>().HasIndex(x => new { x.CompanyId, x.DueDate });
        b.Entity<Payment>().HasIndex(x => new { x.InvoiceId, x.PayDate });
        b.Entity<Payment>().HasIndex(x => x.PaymentMethod);
        b.Entity<AuditLog>().HasIndex(x => x.TimestampUtc);
        b.Entity<AuditLog>().HasIndex(x => x.UserId);
        b.Entity<AuditLog>().HasIndex(x => x.IpAddress);
        b.Entity<AppUser>().HasIndex(x => x.UserName).IsUnique();
        b.Entity<AppSetting>().HasIndex(x => x.Key).IsUnique();
        b.Entity<Invoice>().Property(x => x.Amount).HasPrecision(18, 2);
        b.Entity<Invoice>().Property(x => x.Paid).HasPrecision(18, 2);
        b.Entity<Payment>().Property(x => x.Amount).HasPrecision(18, 2);
        b.Entity<Invoice>().HasOne(x => x.Company).WithMany(x => x.Invoices).HasForeignKey(x => x.CompanyId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Payment>().HasOne(x => x.Invoice).WithMany(x => x.Payments).HasForeignKey(x => x.InvoiceId).OnDelete(DeleteBehavior.Cascade);
    }
}
