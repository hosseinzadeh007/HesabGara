# ساخت نسخه نصب‌شونده

روی Windows، برای هر نیاز یکی از این سه مسیر را انتخاب کنید (فقط یکی کافی است):

## ۱) ساخت سریع فقط فایل EXE (بدون Installer)
برای تست سریع، در ریشه پروژه اجرا کنید:
```
BUILD-HesabGara-3.13.cmd
```
خروجی در `publish\win-x64` قرار می‌گیرد. Inno Setup لازم ندارد.

## ۲) ساخت Installer کامل (توسعه روزمره)
1. .NET 8 SDK و Inno Setup 6 نصب شود.
2. PowerShell را در پوشه پروژه باز کنید و اجرا کنید:
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Installer\test-and-publish.ps1
```
این اسکریپت به‌تنهایی تست‌های واحد را اجرا می‌کند، برنامه را Publish می‌کند و Installer را می‌سازد.
خروجی در `installer-output` قرار می‌گیرد.

## ۳) ساخت نسخه‌ی انتشار رسمی (Production Release)
برای انتشار نهایی که نیاز به شناسه‌ی یکپارچگی فایل‌ها (SHA-256 manifest) و بررسی دقیق‌تر نسخه دارد:
```powershell
.\Installer\Release-Preflight.ps1
.\Installer\Production-Release.ps1
.\Installer\Validate-Release.ps1
```
`Production-Release.ps1` نسخه را همیشه از `VERSION.txt` می‌خواند، تست‌ها را اجرا می‌کند، Publish و Installer را می‌سازد و یک فایل `RELEASE_MANIFEST_SHA256.txt` با هش تک‌تک فایل‌های منتشرشده تولید می‌کند.

---

برنامه به صورت Self-Contained برای win-x64 منتشر می‌شود و روی سیستم مقصد به نصب .NET Runtime، Visual Studio یا SQL Server نیاز ندارد.

اسکریپت‌های قدیمی/جایگزین‌شده (نسخه‌های ۳.۱ تا ۳.۱۱ و برند قدیمی «حساب‌یار») به پوشه‌ی `archive/` منتقل شده‌اند و نباید استفاده شوند.
