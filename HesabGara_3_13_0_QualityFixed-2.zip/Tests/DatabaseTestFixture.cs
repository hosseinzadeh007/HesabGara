using AccountingPurchasePro.Data;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Tests;

/// <summary>
/// Base class giving each individual test method its own throwaway SQLite database file,
/// fully isolated from the real per-user database and from every other test. xUnit creates
/// a fresh instance of the test class for every [Fact]/[Theory], so the constructor here
/// runs (and sets AppDbContext.TestDatabasePathOverride) immediately before each test, and
/// Dispose() runs immediately after — no shared state and no cross-test collisions.
/// </summary>
public abstract class DatabaseTestBase : IDisposable
{
    protected string DatabasePath { get; }

    protected DatabaseTestBase()
    {
        DatabasePath = Path.Combine(Path.GetTempPath(), $"HesabGara-tests-{Guid.NewGuid():N}.db");
        AppDbContext.TestDatabasePathOverride.Value = DatabasePath;
        using var db = new AppDbContext();
        db.Database.EnsureCreated();
    }

    public void Dispose()
    {
        AppDbContext.TestDatabasePathOverride.Value = null;
        try { if (File.Exists(DatabasePath)) File.Delete(DatabasePath); } catch { /* best effort cleanup */ }
    }
}
