using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using AccountingPurchasePro.Models;

namespace AccountingPurchasePro.Services;

public sealed class PrintService
{
    public void PrintInvoices(IEnumerable<Invoice> invoices, string title = "گزارش فاکتورهای حساب‌یار")
    {
        var rows = invoices.ToList();
        if (rows.Count == 0) { MessageBox.Show("برای چاپ، فاکتوری وجود ندارد.", "چاپ", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        var dialog = new PrintDialog();
        if (dialog.ShowDialog() != true) return;
        var total = rows.Sum(x => x.Amount); var paid = rows.Sum(x => x.Paid); var balance = rows.Sum(AccountingService.Balance);
        var doc = new FlowDocument { PagePadding = new Thickness(34), FontFamily = new FontFamily("Tahoma"), FontSize = 10.5, FlowDirection = FlowDirection.RightToLeft, ColumnWidth = double.PositiveInfinity };

        var header = new Table { CellSpacing = 0 };
        header.Columns.Add(new TableColumn { Width = new GridLength(1, GridUnitType.Star) });
        var hr = new TableRow();
        var hc = new TableCell(new Paragraph(new Run("حساب‌یار"))) { Background = new SolidColorBrush(Color.FromRgb(11,58,122)), Foreground = Brushes.White, Padding = new Thickness(14), FontSize = 22, FontWeight = FontWeights.Bold, TextAlignment = TextAlignment.Right };
        hr.Cells.Add(hc); var hg = new TableRowGroup(); hg.Rows.Add(hr); header.RowGroups.Add(hg); doc.Blocks.Add(header);
        doc.Blocks.Add(new Paragraph(new Run(title)) { FontSize = 17, FontWeight = FontWeights.Bold, TextAlignment = TextAlignment.Center, Margin = new Thickness(0,12,0,4) });
        doc.Blocks.Add(new Paragraph(new Run($"تاریخ چاپ: {PersianDateService.ToPersian(DateTime.Now)}   |   تعداد فاکتورها: {rows.Count:N0}")) { TextAlignment = TextAlignment.Center, Foreground = Brushes.Gray, Margin = new Thickness(0,0,0,12) });

        var summary = new Table { CellSpacing = 4 };
        for(int i=0;i<3;i++) summary.Columns.Add(new TableColumn());
        var sr = new TableRow();
        foreach(var item in new[]{($"جمع فاکتورها\n{total:N0} ریال", "#EAF3FF"),($"جمع پرداختی\n{paid:N0} ریال", "#EAF9F0"),($"مانده\n{balance:N0} ریال", "#FFF0F1")})
        {
            var c=new TableCell(new Paragraph(new Run(item.Item1))){Background=(Brush)new BrushConverter().ConvertFromString(item.Item2)!,Padding=new Thickness(10),FontWeight=FontWeights.Bold,TextAlignment=TextAlignment.Center};sr.Cells.Add(c);
        }
        var sg=new TableRowGroup();sg.Rows.Add(sr);summary.RowGroups.Add(sg);doc.Blocks.Add(summary);doc.Blocks.Add(new Paragraph(new Run(" ")));

        var table = new Table { CellSpacing = 0 };
        foreach(var _ in Enumerable.Range(0,7)) table.Columns.Add(new TableColumn());
        var group = new TableRowGroup(); var headerRow=new TableRow();
        foreach(var h in new[]{"شماره فاکتور","شرکت","تاریخ","سررسید","مبلغ (ریال)","پرداختی","مانده"}) headerRow.Cells.Add(new TableCell(new Paragraph(new Run(h))){Background=new SolidColorBrush(Color.FromRgb(11,58,122)),Foreground=Brushes.White,FontWeight=FontWeights.Bold,Padding=new Thickness(7),TextAlignment=TextAlignment.Center});
        group.Rows.Add(headerRow);
        foreach(var x in rows)
        {
            var r=new TableRow(); var vals=new[]{x.Number,x.Company?.Name??"-",PersianDateService.ToPersian(x.InvoiceDate),PersianDateService.ToPersian(x.DueDate),x.Amount.ToString("N0"),x.Paid.ToString("N0"),AccountingService.Balance(x).ToString("N0")};
            for(int i=0;i<vals.Length;i++) r.Cells.Add(new TableCell(new Paragraph(new Run(vals[i]))){Padding=new Thickness(6),TextAlignment=TextAlignment.Center,Background=i%2==0?new SolidColorBrush(Color.FromRgb(249,251,253)):Brushes.White});
            group.Rows.Add(r);
        }
        table.RowGroups.Add(group); doc.Blocks.Add(table);
        var version = typeof(PrintService).Assembly.GetName().Version?.ToString(3) ?? LocalUpdateService.CurrentVersion;
        doc.Blocks.Add(new Paragraph(new Run($"توسعه‌دهنده: حسین حسین زاده  |  نسخه {version}  |  Hzadeh007@gmail.com")){FontSize=9,Foreground=Brushes.Gray,TextAlignment=TextAlignment.Center,Margin=new Thickness(0,16,0,0)});
        dialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, title);
    }
}