using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace AccountingPurchasePro.Services;

public enum DatabaseProvider { Sqlite, SqlServer }

/// <summary>
/// In-memory configuration. ConnectionString here is always the plain (usable) value;
/// encryption only happens at the storage boundary (see DatabaseConfigurationStore).
/// </summary>
public sealed class DatabaseConfiguration
{
    public DatabaseProvider Provider { get; set; } = DatabaseProvider.Sqlite;
    public string ConnectionString { get; set; } = "";
    public bool IsNetworkMode => Provider == DatabaseProvider.SqlServer;
}

public static class DatabaseConfigurationStore
{
    // Adds a fixed, non-secret "purpose" tag to the DPAPI call. This is not a secret key;
    // it just scopes the protected blob so it cannot be silently reused for unrelated data.
    static readonly byte[] Entropy = Encoding.UTF8.GetBytes("HesabGara.DatabaseConfiguration.v1");

    public static string DirectoryPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara");
    public static string FilePath => Path.Combine(DirectoryPath, "database.json");
    static string LegacyDirectoryPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabYar");
    static string LegacyFilePath => Path.Combine(LegacyDirectoryPath, "database.json");

    // On-disk shape. The connection string (which may contain a SQL Server password) is
    // stored DPAPI-encrypted for the current Windows user, never as plain text.
    sealed class StoredConfiguration
    {
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public DatabaseProvider Provider { get; set; } = DatabaseProvider.Sqlite;
        public string? EncryptedConnectionString { get; set; }
    }

    // Shape used by builds prior to 3.13.1, which stored the connection string as plain text
    // under the "ConnectionString" property. Kept only so existing installs migrate cleanly.
    sealed class LegacyPlainConfiguration
    {
        public DatabaseProvider Provider { get; set; } = DatabaseProvider.Sqlite;
        public string ConnectionString { get; set; } = "";
    }

    public static DatabaseConfiguration Load()
    {
        try
        {
            var path = File.Exists(FilePath) ? FilePath :
                       File.Exists(LegacyFilePath) ? LegacyFilePath : null;
            if (path is null) return new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite };

            var json = File.ReadAllText(path);

            var cfg = TryLoadEncrypted(json) ?? TryLoadLegacyPlainText(json);
            if (cfg is null) return new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite };

            // Never allow an incomplete/invalid saved configuration to break startup.
            if (cfg.Provider == DatabaseProvider.SqlServer && string.IsNullOrWhiteSpace(cfg.ConnectionString))
                return new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite };

            return cfg;
        }
        catch
        {
            // A damaged configuration must not prevent the application from starting.
            return new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite };
        }
    }

    static DatabaseConfiguration? TryLoadEncrypted(string json)
    {
        var stored = JsonSerializer.Deserialize<StoredConfiguration>(json);
        if (stored is null || string.IsNullOrWhiteSpace(stored.EncryptedConnectionString))
        {
            // Sqlite-only configs never had a connection string; still a valid "encrypted" shape.
            if (stored is not null && stored.Provider == DatabaseProvider.Sqlite)
                return new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite };
            return null;
        }

        var plain = Decrypt(stored.EncryptedConnectionString);
        if (plain is null) return null; // could not decrypt (e.g. different Windows user) -> fall through
        return new DatabaseConfiguration { Provider = stored.Provider, ConnectionString = plain };
    }

    static DatabaseConfiguration? TryLoadLegacyPlainText(string json)
    {
        try
        {
            var legacy = JsonSerializer.Deserialize<LegacyPlainConfiguration>(json);
            if (legacy is null) return null;
            return new DatabaseConfiguration { Provider = legacy.Provider, ConnectionString = legacy.ConnectionString ?? "" };
        }
        catch { return null; }
    }

    public static void Save(DatabaseConfiguration config)
    {
        Directory.CreateDirectory(DirectoryPath);
        var stored = new StoredConfiguration
        {
            Provider = config.Provider,
            EncryptedConnectionString = string.IsNullOrEmpty(config.ConnectionString) ? null : Encrypt(config.ConnectionString)
        };
        var json = JsonSerializer.Serialize(stored, new JsonSerializerOptions { WriteIndented = true });
        var temp = FilePath + ".tmp";
        File.WriteAllText(temp, json);
        File.Move(temp, FilePath, true);
    }

    static string Encrypt(string plain)
    {
        var bytes = Encoding.UTF8.GetBytes(plain);
        var protectedBytes = ProtectedData.Protect(bytes, Entropy, DataProtectionScope.CurrentUser);
        return Convert.ToBase64String(protectedBytes);
    }

    static string? Decrypt(string encoded)
    {
        try
        {
            var protectedBytes = Convert.FromBase64String(encoded);
            var bytes = ProtectedData.Unprotect(protectedBytes, Entropy, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(bytes);
        }
        catch
        {
            // Cannot decrypt: wrong Windows user/profile, or the value predates encryption
            // and is still plain text. Try using it as-is; SQL Server will simply reject a
            // garbled connection string, which is safer than silently losing the setting.
            return encoded;
        }
    }
}
