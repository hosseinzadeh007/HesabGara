using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;
using Xunit;

namespace AccountingPurchasePro.Tests;

public class AccountingServiceTests : DatabaseTestBase
{
    static readonly AccountingService S = new();

    static async Task<Company> SeedCompanyAsync(string name)
    {
        var company = new Company { Name = name };
        await S.AddCompanyAsync(company);
        return company;
    }

    static async Task<Invoice> SeedInvoiceAsync(int companyId, string number, decimal amount, int dueInDays = 30)
    {
        var invoice = new Invoice
        {
            CompanyId = companyId,
            Number = number,
            Amount = amount,
            InvoiceDate = DateTime.Today,
            DueDate = DateTime.Today.AddDays(dueInDays)
        };
        await S.AddInvoiceAsync(invoice);
        return invoice;
    }

    [Fact]
    public async Task AddPayment_Reduces_Invoice_Balance()
    {
        var company = await SeedCompanyAsync("شرکت الف");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 1000m);

        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 400m, PayDate = DateTime.Today, PaymentMethod = "نقد" });

        var stored = (await S.GetInvoicesAsync(company.Id)).Single();
        Assert.Equal(400m, stored.Paid);
        Assert.Equal(600m, AccountingService.Balance(stored));
    }

    [Fact]
    public async Task AddPayment_Rejects_Amount_Greater_Than_Balance()
    {
        var company = await SeedCompanyAsync("شرکت ب");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 500m);

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 600m, PayDate = DateTime.Today, PaymentMethod = "نقد" }));
    }

    [Fact]
    public async Task AddPayment_Rejects_Invalid_Payment_Method()
    {
        var company = await SeedCompanyAsync("شرکت ج");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 500m);

        await Assert.ThrowsAsync<ArgumentException>(() =>
            S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 100m, PayDate = DateTime.Today, PaymentMethod = "بیت‌کوین" }));
    }

    [Fact]
    public async Task AddPayment_On_Fully_Settled_Invoice_Throws()
    {
        var company = await SeedCompanyAsync("شرکت د");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 300m);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 300m, PayDate = DateTime.Today, PaymentMethod = "نقد" });

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 1m, PayDate = DateTime.Today, PaymentMethod = "نقد" }));
    }

    [Fact]
    public async Task DeletePayment_Restores_Invoice_Balance()
    {
        var company = await SeedCompanyAsync("شرکت ه");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 1000m);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 700m, PayDate = DateTime.Today, PaymentMethod = "نقد" });
        var payment = (await S.GetPaymentsAsync(company.Id)).Single();

        await S.DeletePaymentAsync(payment.Id);

        var stored = (await S.GetInvoicesAsync(company.Id)).Single();
        Assert.Equal(0m, stored.Paid);
        Assert.Equal(1000m, AccountingService.Balance(stored));
    }

    [Fact]
    public async Task AddInvoice_Rejects_Duplicate_Number_For_Same_Company()
    {
        var company = await SeedCompanyAsync("شرکت و");
        await SeedInvoiceAsync(company.Id, "DUP-1", 100m);

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            S.AddInvoiceAsync(new Invoice { CompanyId = company.Id, Number = "DUP-1", Amount = 200m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(10) }));
    }

    [Fact]
    public async Task AddInvoice_Rejects_DueDate_Before_InvoiceDate()
    {
        var company = await SeedCompanyAsync("شرکت ز");

        await Assert.ThrowsAsync<ArgumentException>(() =>
            S.AddInvoiceAsync(new Invoice
            {
                CompanyId = company.Id,
                Number = "INV-X",
                Amount = 100m,
                InvoiceDate = DateTime.Today,
                DueDate = DateTime.Today.AddDays(-1)
            }));
    }

    [Fact]
    public async Task UpdateInvoice_Rejects_Amount_Below_Already_Paid()
    {
        var company = await SeedCompanyAsync("شرکت ح");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 1000m);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 800m, PayDate = DateTime.Today, PaymentMethod = "نقد" });

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            S.UpdateInvoiceAsync(new Invoice { Id = invoice.Id, CompanyId = company.Id, Number = "INV-1", Amount = 500m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(30) }));
    }

    [Fact]
    public async Task DeleteInvoice_With_Payments_Is_Rejected()
    {
        var company = await SeedCompanyAsync("شرکت ط");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 500m);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 100m, PayDate = DateTime.Today, PaymentMethod = "نقد" });

        await Assert.ThrowsAsync<InvalidOperationException>(() => S.DeleteInvoiceAsync(invoice.Id));
    }

    [Fact]
    public async Task DeleteCompany_With_Invoices_Is_Rejected()
    {
        var company = await SeedCompanyAsync("شرکت ی");
        await SeedInvoiceAsync(company.Id, "INV-1", 500m);

        await Assert.ThrowsAsync<InvalidOperationException>(() => S.DeleteCompanyAsync(company.Id));
    }

    [Fact]
    public async Task Payment_Is_Still_Visible_After_Reselecting_Same_Invoice()
    {
        // Mirrors the exact InvoicesView flow: add a payment for invoice A, select a
        // different invoice B (which reloads the payments panel for B), then reselect A -
        // the same GetPaymentsForInvoiceAsync call InvoicesView.LoadPaymentsForSelected()
        // makes on every selection change - and confirm A's payment is still there.
        var company = await SeedCompanyAsync("شرکت پ");
        var invoiceA = await SeedInvoiceAsync(company.Id, "INV-A", 1000m);
        var invoiceB = await SeedInvoiceAsync(company.Id, "INV-B", 500m);

        await S.AddPaymentAsync(new Payment { InvoiceId = invoiceA.Id, Amount = 300m, PayDate = DateTime.Today, PaymentMethod = "نقد" });

        // Simulate switching to invoice B - just a read, like selecting a grid row does.
        var paymentsForB = await S.GetPaymentsForInvoiceAsync(invoiceB.Id);
        Assert.Empty(paymentsForB);

        // Simulate switching back to invoice A.
        var paymentsForA = await S.GetPaymentsForInvoiceAsync(invoiceA.Id);
        var payment = Assert.Single(paymentsForA);
        Assert.Equal(300m, payment.Amount);
        Assert.Equal("نقد", payment.PaymentMethod);

        // And the invoice's own Paid/Balance must reflect it too.
        var storedA = (await S.GetInvoicesAsync(company.Id)).Single(x => x.Id == invoiceA.Id);
        Assert.Equal(300m, storedA.Paid);
        Assert.Equal(700m, AccountingService.Balance(storedA));
    }

    [Fact]
    public async Task Check_Payment_Defaults_Status_To_Pending_When_Not_Provided()
    {
        var company = await SeedCompanyAsync("شرکت ک");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 500m);

        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 200m, PayDate = DateTime.Today, PaymentMethod = "چک", CheckNumber = "123456" });

        var payment = (await S.GetPaymentsAsync(company.Id)).Single();
        Assert.Equal("در انتظار وصول", payment.CheckStatus);
    }

    [Fact]
    public async Task UpdatePayment_Changes_Amount_And_Invoice_Balance()
    {
        var company = await SeedCompanyAsync("شرکت ل");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 1000m);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 300m, PayDate = DateTime.Today, PaymentMethod = "نقد" });
        var payment = (await S.GetPaymentsForInvoiceAsync(invoice.Id)).Single();

        await S.UpdatePaymentAsync(new Payment { Id = payment.Id, Amount = 450m, PayDate = DateTime.Today, PaymentMethod = "نقد" });

        var updated = (await S.GetPaymentsForInvoiceAsync(invoice.Id)).Single();
        Assert.Equal(450m, updated.Amount);
        var storedInvoice = (await S.GetInvoicesAsync(company.Id)).Single();
        Assert.Equal(450m, storedInvoice.Paid);
        Assert.Equal(550m, AccountingService.Balance(storedInvoice));
    }

    [Fact]
    public async Task UpdatePayment_Allows_Raising_To_Full_Remaining_Balance()
    {
        // Exact scenario the "full settlement" checkbox relies on: editing a payment up to
        // (balance + its own current amount) must succeed, not be rejected as over-balance.
        var company = await SeedCompanyAsync("شرکت م");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 1000m);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 200m, PayDate = DateTime.Today, PaymentMethod = "نقد" });
        var payment = (await S.GetPaymentsForInvoiceAsync(invoice.Id)).Single();

        await S.UpdatePaymentAsync(new Payment { Id = payment.Id, Amount = 1000m, PayDate = DateTime.Today, PaymentMethod = "نقد" });

        var storedInvoice = (await S.GetInvoicesAsync(company.Id)).Single();
        Assert.Equal(1000m, storedInvoice.Paid);
        Assert.Equal(0m, AccountingService.Balance(storedInvoice));
    }

    [Fact]
    public async Task UpdatePayment_Rejects_Amount_Beyond_Invoice_Total()
    {
        var company = await SeedCompanyAsync("شرکت ن");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 500m);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 200m, PayDate = DateTime.Today, PaymentMethod = "نقد" });
        var payment = (await S.GetPaymentsForInvoiceAsync(invoice.Id)).Single();

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            S.UpdatePaymentAsync(new Payment { Id = payment.Id, Amount = 600m, PayDate = DateTime.Today, PaymentMethod = "نقد" }));
    }

    [Fact]
    public async Task GetPaymentById_Returns_Correct_Payment_For_Report_Edit_Dialog()
    {
        var company = await SeedCompanyAsync("شرکت س");
        var invoice = await SeedInvoiceAsync(company.Id, "INV-1", 800m);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 300m, PayDate = DateTime.Today, PaymentMethod = "چک", CheckNumber = "999" });
        var payment = (await S.GetPaymentsForInvoiceAsync(invoice.Id)).Single();

        var found = await S.GetPaymentByIdAsync(payment.Id);

        Assert.NotNull(found);
        Assert.Equal(300m, found!.Amount);
        Assert.Equal("999", found.CheckNumber);
    }

    [Fact]
    public async Task SplitPayment_Allocates_Exact_Total_Across_Two_Invoices_Oldest_Due_First()
    {
        var company = await SeedCompanyAsync("شرکت ع");
        var invoiceA = await SeedInvoiceAsync(company.Id, "INV-A", 1000m, dueInDays: 10);
        var invoiceB = await SeedInvoiceAsync(company.Id, "INV-B", 2000m, dueInDays: 30);

        var result = await S.AddSplitPaymentAsync(
            new List<int> { invoiceB.Id, invoiceA.Id }, 3000m, DateTime.Today, "چک",
            "12345", DateTime.Today, "در انتظار وصول", null);

        Assert.Equal(2, result.Allocations.Count);
        // نزدیک‌ترین سررسید (A) باید اول تخصیص بگیرد.
        Assert.Equal(invoiceA.Id, result.Allocations[0].InvoiceId);
        Assert.Equal(1000m, result.Allocations[0].Amount);
        Assert.Equal(invoiceB.Id, result.Allocations[1].InvoiceId);
        Assert.Equal(2000m, result.Allocations[1].Amount);

        var invoices = await S.GetInvoicesAsync(company.Id);
        Assert.All(invoices, x => Assert.Equal(0m, AccountingService.Balance(x)));
    }

    [Fact]
    public async Task SplitPayment_Allocates_Partial_Total_To_Earliest_Due_Invoice_First()
    {
        var company = await SeedCompanyAsync("شرکت ف");
        var invoiceA = await SeedInvoiceAsync(company.Id, "INV-A", 1000m, dueInDays: 10);
        var invoiceB = await SeedInvoiceAsync(company.Id, "INV-B", 2000m, dueInDays: 30);

        // فقط ۱۲۰۰ ریال پرداخت می‌شود: باید کل فاکتور A (۱۰۰۰) و بخشی از B (۲۰۰) را بپوشاند.
        var result = await S.AddSplitPaymentAsync(new List<int> { invoiceA.Id, invoiceB.Id }, 1200m, DateTime.Today, "نقد", null, null, null, null);

        Assert.Equal(2, result.Allocations.Count);
        Assert.Equal(1000m, result.Allocations.Single(a => a.InvoiceId == invoiceA.Id).Amount);
        Assert.Equal(200m, result.Allocations.Single(a => a.InvoiceId == invoiceB.Id).Amount);

        var storedB = (await S.GetInvoicesAsync(company.Id)).Single(x => x.Id == invoiceB.Id);
        Assert.Equal(1800m, AccountingService.Balance(storedB));
    }

    [Fact]
    public async Task SplitPayment_Rejects_Amount_Beyond_Combined_Balance()
    {
        var company = await SeedCompanyAsync("شرکت ق");
        var invoiceA = await SeedInvoiceAsync(company.Id, "INV-A", 500m);
        var invoiceB = await SeedInvoiceAsync(company.Id, "INV-B", 500m);

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            S.AddSplitPaymentAsync(new List<int> { invoiceA.Id, invoiceB.Id }, 1500m, DateTime.Today, "نقد", null, null, null, null));
    }

    [Fact]
    public async Task SplitPayment_Rejects_Fewer_Than_Two_Invoices()
    {
        var company = await SeedCompanyAsync("شرکت ک2");
        var invoiceA = await SeedInvoiceAsync(company.Id, "INV-A", 500m);

        await Assert.ThrowsAsync<ArgumentException>(() =>
            S.AddSplitPaymentAsync(new List<int> { invoiceA.Id }, 300m, DateTime.Today, "نقد", null, null, null, null));
    }
}
