﻿using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public class PaymentsView : Grid
{
    readonly AccountingService S;
    readonly int? CompanyId;
    readonly ComboBox InvoiceBox = new();
    readonly TextBox Amount = new();
    readonly ComboBox MethodBox = new();
    readonly TextBox CheckNumberBox = new();
    readonly DatePicker CheckDateBox = new();
    readonly ComboBox CheckStatusBox = new();
    readonly TextBox NoteBox = new();
    readonly DataGrid G = new();

    public PaymentsView(AccountingService s, int? companyId = null)
    {
        S = s;
        CompanyId = companyId;
        Build();
        Loaded += async (_, _) => await Load();
    }

    void Build()
    {
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(145) });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        var form = new Grid { Margin = new Thickness(10) };
        for (int i = 0; i < 2; i++) form.RowDefinitions.Add(new RowDefinition { Height = new GridLength(58) });
        for (int i = 0; i < 6; i++) form.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(i == 0 ? 2 : 1, GridUnitType.Star) });

        InvoiceBox.Margin = new Thickness(4);
        Amount.Margin = new Thickness(4);
        Amount.Width = 150;
        MethodBox.Margin = new Thickness(4);
        MethodBox.ItemsSource = new[] { "نقد", "کارت‌به‌کارت", "چک", "ترکیبی" };
        MethodBox.SelectedIndex = 0;
        MethodBox.SelectionChanged += (_, _) => UpdateCheckFields();

        CheckNumberBox.Margin = new Thickness(4);
        CheckNumberBox.ToolTip = "اختیاری؛ می‌توانید شماره چک را بعداً تکمیل کنید.";
        CheckDateBox.Margin = new Thickness(4);
        CheckDateBox.SelectedDateFormat = DatePickerFormat.Short;
        CheckStatusBox.Margin = new Thickness(4);
        CheckStatusBox.ItemsSource = new[] { "در انتظار وصول", "وصول‌شده", "برگشتی", "لغوشده" };
        CheckStatusBox.SelectedIndex = 0;
        NoteBox.Margin = new Thickness(4);

        AddLabeled(form, "فاکتور", InvoiceBox, 0, 0);
        AddLabeled(form, "مبلغ", Amount, 0, 1);
        AddLabeled(form, "روش وصول", MethodBox, 0, 2);
        AddLabeled(form, "شماره چک (اختیاری)", CheckNumberBox, 0, 3);
        AddLabeled(form, "تاریخ چک (اختیاری)", CheckDateBox, 0, 4);
        AddLabeled(form, "وضعیت چک", CheckStatusBox, 0, 5);

        AddLabeled(form, "توضیحات", NoteBox, 1, 0);
        Grid.SetColumnSpan(NoteBox, 2);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Left };
        var add = new Button { Content = "＋ ثبت وصول", Margin = new Thickness(4), Padding = new Thickness(14, 7, 14, 7) };
        add.Click += Add;
        var del = new Button { Content = "حذف وصول", Margin = new Thickness(4), Padding = new Thickness(14, 7, 14, 7) };
        del.Click += Delete;
        buttons.Children.Add(add);
        buttons.Children.Add(del);
        Grid.SetColumn(buttons, 2);
        Grid.SetColumnSpan(buttons, 4);
        Grid.SetRow(buttons, 1);
        form.Children.Add(buttons);

        Children.Add(form);

        G.AutoGenerateColumns = false;
        G.IsReadOnly = true;
        G.CanUserAddRows = false;
        G.SelectionMode = DataGridSelectionMode.Single;
        G.Columns.Add(new DataGridTextColumn { Header = "شناسه", Binding = new Binding("Id") });
        G.Columns.Add(new DataGridTextColumn { Header = "فاکتور", Binding = new Binding("Invoice.Number") });
        G.Columns.Add(new DataGridTextColumn { Header = "شرکت", Binding = new Binding("Invoice.Company.Name") });
        G.Columns.Add(new DataGridTextColumn { Header = "مبلغ", Binding = new Binding("Amount") { StringFormat = "{0:N0}" } });
        G.Columns.Add(new DataGridTextColumn { Header = "تاریخ وصول", Binding = new Binding("PayDate") });
        G.Columns.Add(new DataGridTextColumn { Header = "روش وصول", Binding = new Binding("PaymentMethod") });
        G.Columns.Add(new DataGridTextColumn { Header = "شماره چک", Binding = new Binding("CheckNumber") });
        G.Columns.Add(new DataGridTextColumn { Header = "تاریخ چک", Binding = new Binding("CheckDate") });
        G.Columns.Add(new DataGridTextColumn { Header = "وضعیت چک", Binding = new Binding("CheckStatus") });
        G.Columns.Add(new DataGridTextColumn { Header = "توضیحات", Binding = new Binding("Note") });
        Grid.SetRow(G, 1);
        Children.Add(G);

        UpdateCheckFields();
    }

    static void AddLabeled(Grid grid, string label, Control control, int row, int col)
    {
        var panel = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        panel.Children.Add(new TextBlock { Text = label + ":", VerticalAlignment = VerticalAlignment.Center, Width = 120, FontWeight = FontWeights.SemiBold });
        panel.Children.Add(control);
        Grid.SetRow(panel, row);
        Grid.SetColumn(panel, col);
        grid.Children.Add(panel);
    }

    void UpdateCheckFields()
    {
        var isCheck = string.Equals(MethodBox.SelectedItem?.ToString(), "چک", StringComparison.Ordinal);
        CheckNumberBox.IsEnabled = isCheck;
        CheckDateBox.IsEnabled = isCheck;
        CheckStatusBox.IsEnabled = isCheck;
        if (!isCheck)
        {
            CheckNumberBox.Clear();
            CheckDateBox.SelectedDate = null;
            CheckStatusBox.SelectedIndex = 0;
        }
    }

    async Task Load()
    {
        var invoices = await S.GetInvoicesAsync(CompanyId);
        InvoiceBox.ItemsSource = invoices.Where(x => AccountingService.Balance(x) > 0).ToList();
        InvoiceBox.DisplayMemberPath = "Number";
        InvoiceBox.SelectedValuePath = "Id";

        var payments = await S.GetPaymentsAsync(CompanyId);
        G.ItemsSource = payments.Select(p => new PaymentRow(p)).ToList();
    }

    async void Add(object? sender, RoutedEventArgs e)
    {
        if (InvoiceBox.SelectedValue is not int id ||
            !decimal.TryParse(Amount.Text.Replace(",", "").Replace("٬", "").Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var a) || a <= 0)
        {
            MessageBox.Show("فاکتور و مبلغ معتبر را انتخاب کنید.");
            return;
        }

        var method = MethodBox.SelectedItem?.ToString() ?? "نقد";
        try
        {
            await S.AddPaymentAsync(new Payment
            {
                InvoiceId = id,
                Amount = a,
                PayDate = DateTime.Today,
                PaymentMethod = method,
                CheckNumber = method == "چک" ? NullIfWhite(CheckNumberBox.Text) : null,
                CheckDate = method == "چک" ? CheckDateBox.SelectedDate?.Date : null,
                CheckStatus = method == "چک" ? CheckStatusBox.SelectedItem?.ToString() : null,
                Note = NullIfWhite(NoteBox.Text)
            });

            Amount.Clear();
            CheckNumberBox.Clear();
            CheckDateBox.SelectedDate = null;
            NoteBox.Clear();
            MethodBox.SelectedIndex = 0;
            await Load();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "ثبت وصول", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    async void Delete(object? sender, RoutedEventArgs e)
    {
        if (G.SelectedItem is not PaymentRow row)
        {
            MessageBox.Show("یک وصول را انتخاب کنید.");
            return;
        }

        var p = row.Payment;
        if (MessageBox.Show($"وصول {p.Amount:N0} حذف شود؟", "تأیید حذف", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        try
        {
            await S.DeletePaymentAsync(p.Id);
            await Load();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "حذف وصول", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    static string? NullIfWhite(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    sealed class PaymentRow
    {
        public Payment Payment { get; }
        public int Id => Payment.Id;
        public Invoice? Invoice => Payment.Invoice;
        public decimal Amount => Payment.Amount;
        public string PayDate => PersianDateService.ToPersian(Payment.PayDate);
        public string PaymentMethod => Payment.PaymentMethod;
        public string CheckNumber => Payment.CheckNumber ?? "—";
        public string CheckDate => Payment.CheckDate.HasValue ? PersianDateService.ToPersian(Payment.CheckDate.Value) : "—";
        public string CheckStatus => Payment.CheckStatus ?? "—";
        public string Note => Payment.Note ?? "";

        public PaymentRow(Payment payment) => Payment = payment;
    }
}
