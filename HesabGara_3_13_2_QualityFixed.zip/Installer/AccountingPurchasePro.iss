﻿#define MyAppName "حساب‌گرا"
#define MyAppVersion "3.13.1"
#define MyAppPublisher "حسین حسین زاده"
#define MyAppExeName "HesabGara.exe"
[Setup]
AppId={{B7C3C2A4-0B0E-4A2A-A1D1-8F0C5B4D9F20}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\HesabGara
DefaultGroupName={#MyAppName}
OutputDir=..\installer-output
OutputBaseFilename=HesabGara_Setup_{#MyAppVersion}_win-x64
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
VersionInfoVersion=3.13.1.0
VersionInfoProductVersion=3.13.1
Uninstallable=yes
CreateUninstallRegKey=yes
SetupIconFile=HesabGara.ico
PrivilegesRequired=admin
DisableProgramGroupPage=yes
UninstallDisplayIcon={app}\{#MyAppExeName}
[Files]
Source: "..\publish\win-x64\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[Tasks]
Name: "desktopicon"; Description: "ایجاد میانبر روی دسکتاپ"; GroupDescription: "میانبرها:"; Flags: unchecked

[Icons]
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "اجرای حساب‌گرا"; Flags: nowait postinstall skipifsilent
