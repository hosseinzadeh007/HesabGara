﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$Root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$required = @(
  'AccountingPurchasePro.csproj','VERSION.txt','Installer\AccountingPurchasePro.iss',
  'Installer\publish-win-x64.ps1','Installer\build-installer.ps1',
  'Installer\Validate-Release-3.12.ps1','HesabGara.sln'
)
foreach ($item in $required) {
  $path = Join-Path $Root $item
  if (-not (Test-Path $path)) { throw "Missing release artifact: $item" }
}
$version = (Get-Content (Join-Path $Root 'VERSION.txt') -Raw).Trim()
if ($version -ne '3.13.1') { throw "VERSION.txt mismatch: $version" }
$csproj = Get-Content (Join-Path $Root 'AccountingPurchasePro.csproj') -Raw
if ($csproj -notmatch '<Version>3\.11\.0</Version>' -or $csproj -notmatch '<AssemblyVersion>3\.11\.0\.0</AssemblyVersion>' -or $csproj -notmatch '<FileVersion>3\.11\.0\.0</FileVersion>') { throw 'Project version metadata mismatch.' }
$iss = Get-Content (Join-Path $Root 'Installer\AccountingPurchasePro.iss') -Raw
if ($iss -notmatch '#define MyAppVersion "3\.11\.0"' -or $iss -notmatch 'VersionInfoVersion=3\.11\.0\.0') { throw 'Installer version metadata mismatch.' }
$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { Write-Warning 'dotnet SDK not available: static preflight passed, compile validation remains pending on Windows.' }
else {
  $sdks = & $dotnet.Source --list-sdks 2>$null
  if ($LASTEXITCODE -ne 0 -or -not ($sdks -match '^8\.')) { throw 'A .NET 8 SDK is required for this release.' }
}
Write-Host 'HesabGara 3.13.1 release preflight PASSED.' -ForegroundColor Green
