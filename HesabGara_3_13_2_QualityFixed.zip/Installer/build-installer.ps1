﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$ProjectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$Publish = Join-Path $ProjectRoot 'publish\win-x64'
$Iss = Join-Path $PSScriptRoot 'AccountingPurchasePro.iss'
$Output = Join-Path $ProjectRoot 'installer-output'
$PublishScript = Join-Path $PSScriptRoot 'publish-win-x64.ps1'

if (-not (Test-Path $Iss)) {
    throw "Inno Setup script not found: $Iss"
}

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) {
    throw "dotnet was not found. Install the .NET 8 SDK, then close and reopen PowerShell."
}
$sdks = & $dotnet.Source --list-sdks 2>$null
if ($LASTEXITCODE -ne 0 -or -not $sdks) {
    throw "No .NET SDK was found. Install the .NET 8 SDK (not only the Runtime), then reopen PowerShell."
}

$exe = Join-Path $Publish 'HesabGara.exe'
if (-not (Test-Path $exe)) {
    Write-Host "Publish output not found. Publishing now..." -ForegroundColor Yellow
    & $PublishScript
    if ($LASTEXITCODE -ne 0) { throw "Publish script failed. Exit code: $LASTEXITCODE" }
}

if (-not (Test-Path $exe)) {
    throw "HesabGara.exe was not produced: $exe"
}

$info = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($exe)
if ($info.FileVersion -notlike "3.13.1.*") {
    throw "Stale publish detected. Expected HesabGara.exe 3.11.0.x, found: $($info.FileVersion). Run publish-win-x64.ps1 first."
}

if (-not (Test-Path $Output)) {
    New-Item -ItemType Directory $Output | Out-Null
}

$paths = @(
    "$env:ProgramFiles(x86)\Inno Setup 7\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 7\ISCC.exe",
    "$env:ProgramFiles(x86)\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)
$iscc = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $iscc) {
    throw "Inno Setup 7/6 was not found. Install Inno Setup, then run this script again."
}

Write-Host "Compiling installer with: $iscc" -ForegroundColor Cyan
& $iscc $Iss
if ($LASTEXITCODE -ne 0) {
    throw "Inno Setup compilation failed. Exit code: $LASTEXITCODE"
}

$setup = Join-Path $Output 'HesabGara_Setup_3.13.1_win-x64.exe'
if (-not (Test-Path $setup)) {
    throw "Inno Setup reported success but installer was not found: $setup"
}

Write-Host "Installer created successfully: $setup" -ForegroundColor Green
