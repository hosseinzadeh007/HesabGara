# تاریخچه تغییرات حساب‌گرا

> این فایل از ادغام یادداشت‌های پراکنده‌ی نسخه‌های قبلی ساخته شده است.


## 3.26.0 — نظم‌دهی ساختار و رفع دوگانگی مبلغ پرداخت‌شده

- **مالی:** مبلغ پرداخت‌شده‌ی هر فاکتور فقط از جمع رکوردهای Payment می‌آید. مبالغ «پرداخت‌شده‌ی» قدیمی که رکورد Payment نداشتند (و همگام‌سازی شروع برنامه آن‌ها را صفر می‌کرد) یک‌بار به Payment تبدیل می‌شوند (`Data/LegacyPaidMigration.cs`). ثبت فاکتور و ورود اکسل هم مبلغ اولیه را به‌صورت Payment ثبت می‌کنند.
- **ساختار:** `AccountingService` به سه فایل موضوعی (`Services/Accounting/`) شکسته شد؛ روش‌های وصول و قواعد چک در `Domain/PaymentRules.cs` یکپارچه شدند؛ لیست ستون‌های افزایشی دیتابیس یک جدول واحد شد؛ کلاس `Row` از `InvoicesView` جدا شد.
- **نام‌گذاری:** namespace و پروژه از `AccountingPurchasePro` به `HesabGara` تغییر کرد (پوشه‌ی داده‌ی قدیمی همچنان برای انتقال خودکار شناسایی می‌شود).
- **مخزن:** ۵۰ فایل changelog در همین فایل ادغام شد؛ پوشه‌های archive، اسکریپت‌های تکراری ریشه و آیکون‌های تکراری حذف شدند.
- **انتشار:** اسکریپت‌های Preflight/Validate/build-installer نسخه را از `VERSION.txt` می‌خوانند (قبلاً نسخه‌های متناقض ۳.۱۱/۳.۱۰/۳.۱۳ در آن‌ها ثابت بود و هرگز پاس نمی‌شدند).
- **تاریخ شمسی در وصول‌ها:** تاریخ چک (که با DatePicker میلادی نشان داده می‌شد) در همه‌ی فرم‌ها به کادر تاریخ شمسی (`Views/PersianDateBox.cs`) تبدیل شد؛ فرم وصول فیلد «تاریخ وصول» گرفت و ویرایش وصول دیگر تاریخ آن را به امروز برنمی‌گرداند؛ زمان لاگ ممیزی هم شمسی نمایش داده می‌شود.
- **اکسل:** برگه‌ی «پرداخت ها» حالا روش وصول، شماره چک، تاریخ چک و وضعیت چک را هم صادر و وارد می‌کند (فایل‌های قدیمی بدون این ستون‌ها همچنان وارد می‌شوند و نقد ثبت می‌شوند).
- **بازیابی از پشتیبان (رفع باگ جدی):** چون دیتابیس در حالت WAL کار می‌کند، بازیابی قبلی فایل اصلی را بازنویسی می‌کرد ولی `-wal` قدیمی می‌ماند؛ نتیجه این بود که داده‌ی فعلی برنمی‌گشت به پشتیبان و «نسخه‌ی ایمنی» هم می‌توانست خالی باشد. حالا نسخه‌ی ایمنی با `VACUUM INTO` گرفته می‌شود، اتصال‌ها بسته می‌شوند، `-wal`/`-shm` قدیمی پاک می‌شوند و فایل با جایگزینی اتمی عوض می‌شود. فایل‌هایی که پشتیبان حساب‌گرا نیستند (یا خودِ دیتابیس فعلی) رد می‌شوند.
- **حالت شبکه‌ای (SQL Server):** ثبت، ویرایش و حذف وصول/فاکتور با تنظیم `EnableRetryOnFailure` سازگار نبود (تراکنش دستی خارج از execution strategy) و در حالت شبکه‌ای خطا می‌داد؛ همه‌ی تراکنش‌ها از یک helper (`InTransactionAsync`) عبور می‌کنند و Serializable هستند تا دو کاربر همزمان یک فاکتور را بیش‌ازحد وصول نکنند. مهاجرت مبلغ پرداخت‌شده‌ی قدیمی زیر قفل `sp_getapplock` اجرا می‌شود تا با بالا آمدن همزمان چند کلاینت تکراری ثبت نشود، و جدول Settings در دیتابیس‌های قدیمی SQL Server ساخته می‌شود. رمز SQL در صفحه‌ی تنظیمات دیگر به‌صورت متن آشکار نمایش داده نمی‌شود.
- **امنیت و ورود:** پس از ۵ تلاش ناموفق برای یک نام کاربری، ورود و بازیابی رمز با سؤال امنیتی ۱۰ دقیقه مسدود می‌شود (شمارش از لاگ ممیزی، مشترک بین سیستم‌ها)؛ آخرین مدیر فعال از فرم ویرایش هم دیگر قابل غیرفعال‌سازی نیست؛ اگر برنامه در حالت SQL Server به سرور وصل نشود، پیشنهاد بازنشانی تنظیمات اتصال داده می‌شود (به‌جای گیر کردن کاربر).
- **حذف پشتیبان‌های قدیمی:** پشتیبان خودکار قبلاً هرگز پاک نمی‌شد و پوشه‌ی `Backups` بی‌نهایت بزرگ می‌شد. حالا فقط N پشتیبان خودکار آخر نگه داشته می‌شود (تنظیم در «تنظیمات»، پیش‌فرض ۳۰، صفر = همه). فقط فایل‌هایی با نام دقیق `HesabGara_yyyyMMdd_HHmmss.db/.bak` در پوشه‌ی پشتیبان خودکار حذف می‌شوند؛ پشتیبان‌های دستی و هر فایل دیگری دست‌نخورده می‌ماند. نسخه‌های ایمنی `before-restore` هم به ۵ عدد آخر محدود شدند.
- **موبایل:** «تنظیمات ← ساخت فایل برای موبایل» یک فایل JSON فقط‌خواندنی می‌سازد (`Services/MobileExportService.cs`) که در صفحه‌ی موبایل (`mobile/hesabgara-mobile.html`) باز می‌شود: خلاصه‌ی مانده، فاکتورها با فیلتر و جستجو، شرکت‌ها، چک‌ها و جزئیات هر فاکتور با تاریخ شمسی.
- **تست:** `Tests/MobileExportTests.cs`،  `Tests/BackupRetentionTests.cs`،  `Tests/SecurityTests.cs`،  `Tests/PaidConsistencyTests.cs`، `Tests/ExcelCheckRoundTripTests.cs` و `Tests/BackupRestoreTests.cs` اضافه شد.

---

## BRANDING_FA

حساب‌یار
نرم‌افزار حسابداری حرفه‌ای

توسعه‌دهنده: حسین حسین زاده
ایمیل: Hzadeh007@gmail.com
نسخه: 3.0 RC

این بسته نسخه Release Candidate سورس پروژه است.
برای اجرای نهایی روی Windows باید روی یک سیستم دارای .NET 8 SDK و ابزارهای Build ویندوز Publish شود.


---

## BUILD-FIX-2026-08-13

HesabYar 3.0 - Build Fix 2026-08-13

اصلاحات:
- افزودن using System.IO صریح به فایل‌هایی که از File/Directory/Path استفاده می‌کنند.
- اصلاح BackupService برای جلوگیری از EF1002 با پارامتری‌کردن VACUUM INTO.
- اصلاح DatabaseInitializer برای پارامتری‌کردن خواندن pragma_table_info و اعتبارسنجی شناسه‌های SQL.
- تست‌ها در پروژه جداگانه باقی مانده‌اند و در پروژه WPF اصلی Compile نمی‌شوند.
- Installer به‌صورت مستقیم AccountingPurchasePro.csproj را Publish می‌کند.

ترتیب اجرا در ویندوز:
1) cd "C:\Users\pc9\Desktop\HesabYar"
2) dotnet restore ".\AccountingPurchasePro.csproj" --runtime win-x64
3) powershell.exe -ExecutionPolicy Bypass -File ".\Installer\build-app.ps1"
4) powershell.exe -ExecutionPolicy Bypass -File ".\Installer\build-installer.ps1"

اگر مرحله 3 موفق شد، سپس مرحله 4 را اجرا کنید.


---

## BUILD-HESABGARA-3.13-README_FA

نسخه کامل پروژه حساب‌گرا 3.13.0

این ZIP سورس کامل پروژه پایه 3.12.0 است که به 3.13.0 ارتقا داده شده.
قابلیت وصول نقد، کارت‌به‌کارت، چک و ترکیبی اضافه شده و شماره/تاریخ چک اختیاری است.

برای ساخت EXE:
1) ZIP را کامل Extract کنید.
2) فایل BUILD-HesabGara-3.13.cmd را اجرا کنید.
3) خروجی در publish\win-x64 ساخته می‌شود.

این نسخه مسیر دیتابیس قبلی را حفظ می‌کند تا اطلاعات نسخه قبلی از بین نرود.


---

## BUILD-INSTRUCTIONS

HesabYar 3.0 - Build/Installer اصلاح‌شده

1) این ZIP را استخراج کنید، طوری که فایل AccountingPurchasePro.csproj در ریشه پوشه HesabYar باشد.
2) PowerShell:
   cd "C:\Users\pc9\Desktop\HesabYar"
   dotnet build
3) ساخت Installer:
   powershell.exe -ExecutionPolicy Bypass -File ".\Installer\build-installer.ps1"

نکات:
- پروژه اصلی دیگر فایل‌های Tests را کامپایل نمی‌کند.
- تداخل WPF و Windows Forms حذف شده است.
- پوشه انتخاب پشتیبان از OpenFolderDialog خود WPF استفاده می‌کند.
- اسکریپت Installer، Inno Setup 7 و 6 را پیدا می‌کند.
- مسیر publish داخل خود پروژه است: .\publish\win-x64


---

## BUILD-INSTRUCTIONS_FA

ساخت نسخه قابل اجرا در Windows

1) .NET 8 SDK را نصب کنید.
2) Visual Studio 2022+ با workload «.NET Desktop Development» یا dotnet SDK را داشته باشید.
3) در PowerShell داخل پوشه پروژه اجرا کنید:
   dotnet restore
   dotnet build -c Release
4) برای نسخه مستقل win-x64:
   dotnet publish -c Release -r win-x64 --self-contained true

خروجی در bin/Release/net8.0-windows/win-x64/publish قرار می‌گیرد.


خروجی نهایی: HesabYar_Setup_3.4.0_win-x64.exe
نام محصول: حساب‌یار
توسعه‌دهنده: حسین حسین زاده
ایمیل: Hzadeh007@gmail.com
برای ساخت یک‌کلیکی، Installer\Build-HesabYar.cmd را اجرا کنید.


---

## BUILD_FINAL_3.1

نسخه نهایی HesabYar 3.2.0

تغییرات این نسخه:
1. صفحه ورود تمام‌صفحه و مطابق طرح جدید.
2. منوی سمت راست با لوگو و نام حساب‌یار و نوشته‌های سفید.
3. بازطراحی حرفه‌ای پنجره مدیریت شرکت‌ها و مشخص بودن محل ورود مشخصات شرکت.
4. بازطراحی حرفه‌ای پنجره فاکتورها و فیلتر زنده بر اساس شرکت.
5. گزارش‌ها دارای انتخاب شرکت و گزارش مستقل هر شرکت هستند.
6. چاپ فاکتورها با سربرگ، خلاصه مالی و جدول حرفه‌ای‌تر.
7. ماشین حساب، راهنما، تقویم، تنظیمات و درباره نرم‌افزار فعال شدند.
8. نسخه به 3.2.0 به‌روزرسانی شد و مشخصات توسعه‌دهنده در نرم‌افزار درج شد.

ساخت:
PowerShell را در ریشه پروژه باز کنید و اجرا کنید:
  .\Installer\Build-Final-3.1.ps1

خروجی:
  publish\win-x64\HesabYar.exe


---

## BUILD_FIXES_3.1.0

اصلاحات این بسته:
- UniformGrid در MainWindow و DashboardView به WPF UniformGrid با namespace صریح تغییر داده شد.
- اسکریپت Build به Clean Build تغییر داده شد تا bin/obj قدیمی باعث خطای Assets file نشوند.
- Restore و Publish با runtime win-x64 و self-contained انجام می‌شود.
- خروجی در publish\win-x64 قرار می‌گیرد.


---

## BUILD_FIX_NOTES_v3

HesabYar 3.0 - Build fixes v3
1. CompaniesView: renamed field Name to CompanyNameBox to avoid hiding FrameworkElement.Name.
2. UserManagementView: made Thickness constructor explicit WPF four-sided.
3. DashboardView: added System.Windows.Controls.Primitives for UniformGrid.
4. DashboardView: replaced invalid DataGrid.RowProperty usage with Grid.SetRow.
5. ExcelService: null-forgiving navigation used for EF Include/ThenInclude to satisfy nullable analysis.


---

## CHANGELOG_v2.0_PRO_FA

# v2.0 Professional Core

## هسته مالی
- انتقال قواعد محاسبه به Domain/FinanceRules
- decimal برای مبالغ
- جلوگیری از مانده منفی
- میانگین وزنی سررسید بر اساس مانده واقعی
- کنترل پرداخت بیش از مانده
- کنترل سررسید قبل از تاریخ فاکتور

## دیتابیس
- Indexهای ترکیبی برای فاکتور و پرداخت
- Foreign Key و Restrict برای شرکت/فاکتور
- WAL و Foreign Keys برای SQLite
- AuditLog
- Reconcile پرداخت‌ها در شروع برنامه

## کیفیت
- Validation سرویس‌ها
- تراکنش ثبت پرداخت
- تست واحد محاسبات مالی
- TreatWarningsAsErrors
- اسکریپت یکپارچه Test + Publish

## حذف کالا
مدل و بخش کالا/خدمات از هسته برنامه حذف شد.


---

## CHANGELOG_v2.1_PRO_FA

# AccountingPurchasePro v2.1 Professional

## مرحله دوم ارتقا
- ورود امن با Login Window
- ایجاد مدیر اولیه در اولین اجرا؛ رمز عبور حداقل ۸ کاراکتر
- هش رمز عبور با PBKDF2-SHA256 و salt تصادفی
- ثبت Login در AuditLog
- کنترل اولیه دسترسی برای عملیات مدیریتی
- Backup با checkpoint کامل WAL و ایجاد نام زمان‌دار
- قبل از Restore یک کپی ایمنی از دیتابیس فعلی ایجاد می‌شود
- مدل کاربر به EF Core اضافه شد
- گزینه «کالاها و خدمات» همچنان حذف است
- ساختار Self-Contained/Installer حفظ شده است

## نکته انتشار
برای تولید Setup.exe واقعی باید روی Windows دارای .NET 8 SDK و Inno Setup اجرا شود. این محیط امکان Build واقعی WPF ویندوز را ندارد.


---

## CHANGELOG_v2.2_PRO_FA

# AccountingPurchasePro v2.2 Professional

این نسخه مرحله «کنترل داده و عملیات» را تکمیل می‌کند:

- ویرایش و حذف شرکت با محافظت از سوابق مالی
- ویرایش فاکتور با جلوگیری از کاهش مبلغ کمتر از پرداخت‌های ثبت‌شده
- حذف فاکتور فقط در صورت نداشتن پرداخت
- حذف پرداخت با بازمحاسبه امن مبلغ Paid فاکتور
- تراکنش دیتابیس برای عملیات حساس
- ثبت Audit Log برای عملیات Create/Update/Delete
- گزارش سررسید و گزارش کلی با جمع، پرداختی، مانده و میانگین وزنی سررسید
- خروجی Excel از گزارش جاری
- انتخاب شرکت همچنان فاکتورها و پرداخت‌های همان شرکت را محدود می‌کند
- محاسبات مالی با decimal باقی مانده‌اند
- کالا و خدمات در مدل و UI وجود ندارد

## توجه به انتشار

برای ساخت نسخه نهایی ویندوز از Installer/publish-win-x64.ps1 استفاده کنید. این پروژه Self-Contained win-x64 است.


---

## CHANGELOG_v2.3_PRO_FA

# AccountingPurchasePro Professional v2.3

این مرحله مجموعه چند ارتقای پیوسته برای نزدیک شدن به نسخه تجاری است.

## مدیریت کاربران و سطح دسترسی
- مدیریت کامل کاربران از داخل نرم‌افزار
- ایجاد، ویرایش و غیرفعال‌سازی کاربر
- نقش مدیر
- مجوز مدیریت داده‌ها
- مجوز گزارش‌ها و چاپ
- مجوز ورود/خروج Excel
- مجوز پشتیبان‌گیری و بازیابی
- جلوگیری از حذف/غیرفعال‌سازی آخرین مدیر فعال

## پشتیبان‌گیری
- Backup داخلی SQLite با checkpoint برای WAL
- Restore از فایل `.db`
- ایجاد نسخه ایمنی قبل از Restore
- بستن نرم‌افزار پس از Restore برای جلوگیری از استفاده از دیتابیس قدیمی

## چاپ
- چاپ گزارش فاکتورها با PrintDialog ویندوز
- راست‌چین و مناسب چاپ فارسی

## تنظیمات
- نام مجموعه
- تلفن
- فاصله پشتیبان‌گیری خودکار به‌عنوان تنظیم ذخیره‌شده برای مرحله Scheduler

## دیتابیس
- ارتقای خودکار ستون‌های جدید کاربران برای دیتابیس‌های ساخته‌شده با نسخه‌های قبلی
- جدول Settings و Unique Index
- Foreign Keys، WAL و Indexهای مالی حفظ شده‌اند.

## امنیت و حسابداری
- PBKDF2-SHA256 + Salt برای رمز عبور
- Audit Log
- decimal برای مبالغ
- تراکنش ثبت/حذف پرداخت
- جلوگیری از پرداخت بیشتر از مانده
- میانگین وزنی سررسید بر اساس مانده واقعی
- تفکیک کامل اطلاعات با فیلتر شرکت

## Excel
- Import با تشخیص تکراری
- Export شرکت انتخاب‌شده
- عدم ثبت مجدد پرداخت تکراری


---

## DEPLOYMENT_WIZARD_3.6_FA

# حساب‌یار 3.6.0 — راه‌اندازی حرفه‌ای Server / Client

در اولین اجرای برنامه، Wizard راه‌اندازی نمایش داده می‌شود و کاربر بدون ویرایش فایل تنظیمات می‌تواند حالت استقرار را انتخاب کند:

- محلی — SQLite
- شبکه‌ای — SQL Server

در حالت شبکه‌ای امکان ورود IP/نام سرور، پورت اختیاری، نام دیتابیس و Windows Authentication یا SQL Authentication وجود دارد.

## سناریوی Server

1. SQL Server را روی سیستم سرور آماده کنید.
2. دیتابیس موردنظر را بسازید یا نام دیتابیس جدید را وارد کنید.
3. در Wizard، IP سرور و نام دیتابیس را وارد کنید.
4. اتصال را تست کنید.
5. حساب‌یار را ادامه دهید؛ ساخت/به‌روزرسانی ساختار جداول توسط برنامه انجام می‌شود.

## سناریوی Client

روی هر کلاینت همان برنامه نصب می‌شود. در اولین اجرا:

- حالت «شبکه‌ای — SQL Server» را انتخاب کنید.
- IP یا نام DNS سرور را وارد کنید.
- همان نام دیتابیس را انتخاب کنید.
- روش احراز هویت را تعیین کنید.
- اتصال را تست کنید.

> برای شبکه‌های خارج از LAN، SQL Server را مستقیماً روی اینترنت باز نکنید؛ از VPN یا شبکه امن استفاده کنید.


---

## FINAL_FIX_REPORT_FA

حساب‌یار 3.2.0 - اصلاح نهایی Build
================================

اصلاح فوری این نسخه:
- رفع خطاهای CS1039/CS1003/CS1010/CS1026/CS1002 در MainWindow.xaml.cs
- اصلاح رشته‌های چندخطی در ثبت خطای startup
- نگه‌داشتن اسکریپت Build بدون نیاز به تغییر ExecutionPolicy
- Clean + Restore + Publish با runtime win-x64
- خروجی انتشار در publish\win-x64

دستور پیشنهادی:
Installer\Build-HesabYar-Clean.cmd

توجه: اجرای Build نهایی باید روی Windows دارای .NET 8 SDK انجام شود.


---

## FINAL_RELEASE_CHECKLIST_3.11_FA

# چک‌لیست Release 3.11.0

- [ ] dotnet restore
- [ ] dotnet test
- [ ] dotnet publish win-x64 self-contained
- [ ] بررسی FileVersion EXE
- [ ] بررسی SHA-256 manifest
- [ ] ساخت Inno Setup
- [ ] نصب تمیز روی Windows 10/11 x64
- [ ] اجرای Login
- [ ] تست SQLite
- [ ] تست SQL Server Client/Server
- [ ] تست Backup/Restore
- [ ] تست Local Update و Rollback
- [ ] تست Uninstall
- [ ] تست اجرای مجدد بعد از Restart


---

## FINAL_RELEASE_README_FA

# حسابداری خرید حرفه‌ای — نسخه 3.0 Release Candidate

این بسته، نسخه حرفه‌ای آماده انتشار پروژه C# / WPF است.

## ویژگی‌های اصلی
- C# / .NET 8 / WPF / Entity Framework Core / SQLite
- رابط فارسی و راست‌چین
- مدیریت شرکت‌ها، فاکتورها و پرداخت‌ها
- تفکیک کامل اطلاعات بر اساس شرکت
- انتخاب فاکتورها با CheckBox و محاسبه زنده جمع، پرداختی، مانده و میانگین وزنی سررسید
- میانگین وزنی بر مبنای مانده واقعی
- Import / Export Excel و تشخیص تکراری‌ها
- کاربران، ورود امن و سطح دسترسی
- Audit Log
- Backup و Restore اعتبارسنجی‌شده
- Backup خودکار قابل تنظیم
- بررسی سلامت دیتابیس
- گزارش و چاپ
- حذف کامل بخش کالاها و خدمات
- Self-contained win-x64
- Installer با Inno Setup

## انتشار روی Windows
1. Windows 10/11 x64 داشته باشید.
2. .NET 8 SDK و Inno Setup را روی ماشین Build نصب کنید.
3. PowerShell را با دسترسی مناسب باز کنید.
4. `Installer/test-and-publish.ps1` را اجرا کنید.
5. خروجی Setup در `installer-output` ساخته می‌شود.

## نکته داده‌ها
دیتابیس در `%LOCALAPPDATA%\AccountingPurchasePro\accounting.db` نگهداری می‌شود و حذف برنامه نباید اطلاعات را حذف کند.
قبل از Restore، نسخه ایمنی با پسوند `.before-restore-*` ساخته می‌شود.

## وضعیت تست
این محیط اجرای فعلی Linux است و Windows/.NET SDK در آن موجود نیست؛ بنابراین EXE/Setup در این محیط Build و اجرای واقعی نشده است. اسکریپت انتشار برای Build واقعی Windows آماده شده است.


---

## FIX_NOTES_2026-08-13

رفع خطای کامپایل MainWindow.xaml.cs
خطای CS1039/CS1026/CS1002 ناشی از رشته چندخطی در Restore_Click بود.
رشته به یک interpolated string معتبر با \n تبدیل شد و ساختار try/catch نیز مرتب شد.


---

## FIX_STARTUP_DATABASE_3.13.1_FA

# اصلاح نهایی خطای راه‌اندازی پایگاه داده حساب‌گرا – 3.13.1

این نسخه علاوه بر مدیریت خطای NullReference، ناسازگاری مسیر دیتابیس نسخه‌های قدیمی را نیز برطرف می‌کند.

اصلاحات اصلی:
- مسیر اصلی SQLite به `%LOCALAPPDATA%\HesabGara\accounting.db` منتقل شد.
- اگر دیتابیس قدیمی در `%LOCALAPPDATA%\AccountingPurchasePro\accounting.db` وجود داشته باشد و دیتابیس جدید وجود نداشته باشد، یک‌بار بدون overwrite کپی می‌شود.
- مراحل Startup در لاگ ثبت می‌شوند تا محل دقیق خطا مشخص باشد.
- پیام خطا مسیر کامل فایل لاگ را نمایش می‌دهد.
- `CanConnect()` بعد از `EnsureCreated()` اجرا می‌شود تا خرابی اتصال همان ابتدا مشخص شود.
- چرخش لاگ‌ها با نام جدید HesabGara انجام می‌شود.
- پیام‌های Setup Wizard از حساب‌یار به حساب‌گرا اصلاح شدند.


---

## FIX_UI_3.13.0_V4_FA

# اصلاح رابط کاربری حساب‌گرا 3.13.0 – V4

- قالب دکمه‌های منوی سمت راست با ControlTemplate اختصاصی جایگزین شد تا سایه/Chrome پیش‌فرض WPF نمایش داده نشود.
- حالت انتخاب‌شده داشبورد به‌صورت آبی مشخص است و حالت Hover نیز کنترل‌شده است.
- لوگوی موقت قبلی (دایره + فلش) با یک نشان برداری «حگ» هماهنگ با برند حساب‌گرا جایگزین شد.
- شماره نسخه نمایش‌داده‌شده در پایین منو از 3.3.0 به 3.13.0 اصلاح شد.

نکته: فایل پروژه فعلی شامل فایل تصویری لوگوی منتخب قبلی نیست؛ بنابراین برای جلوگیری از حدس‌زدن، لوگوی فعلی به‌صورت برداری داخل XAML ساخته شده است.


---

## HEADER_FIX_3.13.0_FA

اصلاح هدر نسخه 3.13.0
- عنوان حساب‌گرا با رنگ سفید، اندازه بزرگ و وزن ExtraBold
- زیرعنوان با رنگ آبی روشن و خوانایی بیشتر
- هدر راست‌چین و داخل کارت مستقل برای جلوگیری از محو شدن/هم‌پوشانی
- کنترل‌های پنجره در سمت چپ با زمینه مشخص
- لوگو و آیکون‌های قبلی بدون تغییر باقی مانده‌اند


---

## ICON_APPLIED_FA

حساب‌گرا - اعمال آیکون نهایی

آیکون اصلی نرم‌افزار از طرح مربع سفیدِ پایین سمت راست تصویر ارسالی استخراج و آماده شد.

فایل‌های ایجادشده:
- Assets/HesabGaraIcon.ico
- Assets/HesabGaraIcon.png

کاربرد:
- آیکون EXE
- آیکون پنجره WPF
- میانبر دسکتاپ در صورت استفاده از Installer

لوگوی هدر و لوگوی منوی نرم‌افزار جدا از آیکون باقی می‌مانند.


---

## LOCAL_UPDATE_GUIDE_FA

به‌روزرسانی محلی حساب‌یار

1) در نسخه جدید برنامه، از منوی «به‌روزرسانی محلی» فایل ZIP انتشار را انتخاب کنید.
2) بسته باید خروجی Publish ویندوز x64 باشد و شامل HesabYar.exe و VERSION.txt باشد.
3) فقط مدیر سیستم اجازه به‌روزرسانی دارد.
4) قبل از نصب، برنامه به‌صورت خودکار از پایگاه داده پشتیبان می‌گیرد.
5) برنامه بسته می‌شود، فایل‌های نسخه جدید جایگزین می‌شوند و حساب‌یار دوباره اجرا می‌شود.
6) فایل‌های دیتابیس (*.db) و فایل‌های WAL/SHM در زمان به‌روزرسانی دست‌نخورده باقی می‌مانند.
7) اگر برنامه در Program Files نصب شده باشد، ویندوز ممکن است برای جایگزینی فایل‌ها درخواست دسترسی مدیر سیستم نمایش دهد.

سازنده بسته:
حسین حسین زاده
Hzadeh007@gmail.com


---

## NETWORK_RELEASE_3.4_FA

# حساب‌یار 3.4.0 — شبکه واقعی با SQL Server

## هدف
نسخه 3.4 مسیر رسمی استفاده چند کامپیوتر از یک پایگاه‌داده مرکزی را اضافه می‌کند.

### معماری
- سیستم سرور: SQL Server + دیتابیس HesabYar
- سیستم‌های کلاینت: برنامه HesabYar + اتصال TCP به SQL Server از طریق IP/نام سرور
- حالت محلی قبلی SQLite همچنان حفظ شده است.

### تنظیم
از «تنظیمات ← اتصال شبکه‌ای» حالت «شبکه‌ای (SQL Server)» را انتخاب کنید.
1. نام سرور/IP را وارد کنید؛ نمونه: `192.168.1.10` یا `SERVER01\\SQLEXPRESS`
2. نام دیتابیس را وارد کنید؛ نمونه: `HesabYar`
3. احراز هویت Windows یا SQL Login را انتخاب کنید.
4. «بررسی اتصال SQL Server» را اجرا کنید.
5. تنظیمات را ذخیره و برنامه را مجدداً اجرا کنید.

### نکات امنیتی
- پورت SQL Server باید فقط در شبکه مورد اعتماد باز باشد.
- برای دسترسی اینترنتی مستقیم به SQL Server توصیه نمی‌شود؛ VPN یا شبکه امن استفاده شود.
- برای SQL Login از حساب اختصاصی با حداقل دسترسی استفاده کنید.
- Backup پایگاه‌داده مرکزی باید روی خود سرور زمان‌بندی شود.


---

## NETWORK_ROADMAP_3.3_FA

# مسیر اتصال شبکه‌ای حساب‌یار

نسخه فعلی از SQLite محلی استفاده می‌کند و برای استفاده همزمان چند سیستم از طریق IP ثابت نباید فایل SQLite را روی Share شبکه قرار داد.

مسیر حرفه‌ای برای نسخه شبکه‌ای:
1. SQL Server روی سیستم سرور
2. Connection String امن و قابل تنظیم
3. احراز هویت کاربران و سطح دسترسی
4. اتصال کلاینت‌ها از طریق IP ثابت یا DNS داخلی
5. Backup سمت سرور
6. Migration کنترل‌شده SQLite به SQL Server

این مسیر عمداً در این مرحله فعال نشده تا اتصال شبکه‌ای به شکل واقعی و قابل اعتماد پیاده‌سازی شود، نه صرفاً با یک گزینه نمایشی.


---

## ONE_CLICK_BUILD

HesabYar 3.4.0 - ساخت سریع
1) روی Installer\Build-HesabYar.cmd دوبار کلیک کنید.
2) Restore و Publish به صورت self-contained win-x64 انجام می‌شود.
3) خروجی در publish\win-x64 قرار می‌گیرد.
اگر خطایی رخ دهد، پنجره متوقف می‌شود و متن خطا نمایش داده می‌شود.


---

## PRODUCTION_RELEASE_CHECKLIST_3.12_FA

# چک‌لیست Release تولیدی 3.12.0

- [ ] نصب .NET 8 SDK
- [ ] اجرای Unit Tests با نتیجه PASS
- [ ] Restore با runtime win-x64
- [ ] Publish self-contained
- [ ] کنترل FileVersion فایل HesabYar.exe
- [ ] تولید SHA-256 manifest
- [ ] ساخت Installer با Inno Setup
- [ ] نصب Clean روی Windows
- [ ] اجرای Login و ساخت کاربر مدیر
- [ ] تست SQLite
- [ ] تست SQL Server
- [ ] تست Backup / Restore
- [ ] تست Update / Rollback
- [ ] تست حذف نرم‌افزار
- [ ] تست Client/Server و قطع/وصل شبکه
- [ ] بررسی Audit Log
- [ ] تأیید نهایی Release


---

## PROFESSIONAL_UPGRADE_3.2_FA

# حساب‌یار 3.2.0 — ارتقای حرفه‌ای

این نسخه با تمرکز روی تجربه کاربری فاکتورها آماده شده است.

## اصلاحات اصلی
- نمایش فوری جمع فاکتورهای انتخاب‌شده، پرداختی و مانده.
- نمایش **سررسید وزنی** و تعداد روز وزنی برای فاکتورهای انتخاب‌شده.
- محاسبه سررسید وزنی بر اساس **مانده واقعی** هر فاکتور، نه مبلغ اسمی.
- نمایش تاریخ فاکتور و سررسید به‌صورت شمسی در جدول.
- نمایش تاریخ پرداخت‌ها به‌صورت شمسی.
- جلوگیری از Refresh غیرضروری هنگام تغییر Checkbox.
- افزایش نسخه محصول به 3.2.0.

## نکته انتشار
این بسته در محیط فعلی به دلیل نبود Windows/.NET SDK قابل Build و اجرای نهایی نیست؛ بنابراین این فایل، **سورس ارتقایافته** است و ادعای تست EXE نهایی نشده است. برای Release روی Windows باید اسکریپت Build اجرا و خروجی Setup تست شود.


---

## PROFESSIONAL_UPGRADE_3.3_FA

# حساب‌یار 3.3.0 — Professional Release Hardening

## ارتقاهای این مرحله
- داشبورد با نمایش شرکت فعال و وضعیت پایگاه‌داده/پشتیبان‌گیری
- اصلاح رنگ‌بندی سررسیدهای نزدیک و نمایش مانده واقعی به‌جای مبلغ اولیه
- جستجوی واقعی بر اساس تاریخ فاکتور و تاریخ سررسید به صورت شمسی
- پاک‌سازی کامل فیلترها
- ارتقای نسخه به 3.3.0
- جلوگیری از نصب بسته Update هم‌نسخه یا قدیمی

## نکته انتشار
این نسخه هنوز باید روی Windows با .NET 8 SDK، Build و Publish و سپس Installer آن تست شود.


---

## QA_3.9.0_REPORT_FA

# گزارش QA نسخه 3.9.0 — حساب‌یار

## نتیجه کلی
**وضعیت: Release Candidate مشروط (Conditional RC)**

در این محیط Linux قرار داریم و .NET SDK / Windows / WPF runtime در دسترس نیست؛ بنابراین Build و اجرای واقعی Windows قابل تأیید نیست. با این حال، سورس نسخه 3.8.0 به‌صورت ایستا بررسی شد و چند ایراد مهم قبل از Release شناسایی و اصلاح شد.

## یافته‌های مهم و اصلاحات

| مورد | وضعیت | توضیح |
|---|---|---|
| نسخه پروژه | اصلاح شد | از 3.8.0 به 3.9.0 ارتقا یافت |
| Installer version | اصلاح شد | Installer قبلاً روی 3.7.0 مانده بود؛ اکنون 3.9.0 است |
| SQL Server schema | اصلاح شد | ستون‌های Permission در دیتابیس‌های موجود قبلاً Migration نمی‌شدند |
| SQLite schema | قابل قبول | EnsureCreated + ستون‌های افزوده بررسی شدند |
| Backup | قابل قبول | مسیرهای SQLite/SQL Server جدا هستند |
| Local Update | قابل قبول با تست Windows | نسخه از Assembly خوانده می‌شود |
| Password hashing | قابل قبول | PBKDF2-SHA256 + salt + fixed-time comparison |
| Audit Log | قابل قبول | Login/Failure و IP ثبت می‌شود |
| Network | نیازمند تست واقعی | SQL Server connection باید روی Windows/شبکه واقعی تست شود |
| Installer build | نیازمند تست واقعی | Inno Setup و publish واقعی باید روی Windows اجرا شوند |

## تست‌های انجام‌شده در محیط فعلی

- باز کردن ZIP و استخراج کامل: **PASS**
- شمارش و بررسی ساختار پروژه: **PASS**
- بررسی Target Framework: **PASS — net8.0-windows**
- بررسی Self-contained / win-x64: **PASS — تنظیم شده**
- بررسی TreatWarningsAsErrors: **PASS — فعال است**
- بررسی نسخه‌ها: **FAIL اولیه → FIXED در 3.9.0**
- بررسی SQL Server additive schema: **FAIL اولیه → FIXED در 3.9.0**
- بررسی وجود تست‌های FinanceRules: **PASS**
- اجرای dotnet build: **BLOCKED** چون dotnet SDK در محیط فعلی نصب نیست
- اجرای WPF: **BLOCKED** چون محیط Windows در دسترس نیست
- اجرای Installer: **BLOCKED** چون Inno Setup/Windows در دسترس نیست

## مواردی که قبل از Release نهایی باید روی Windows تست شوند

1. `dotnet restore`
2. `dotnet build -c Release`
3. اجرای تست‌های xUnit
4. `dotnet publish -c Release -r win-x64 --self-contained true`
5. اجرای EXE روی Windows 10/11 x64
6. نصب و حذف کامل Installer
7. First Run Wizard
8. SQLite: ایجاد مدیر، ورود، فاکتور، پرداخت، Backup/Restore
9. SQL Server: ایجاد/اتصال دیتابیس و Migration افزایشی
10. اتصال دو Client همزمان به یک Server
11. قطع شبکه هنگام ذخیره و بازیابی اتصال
12. Excel Import/Export و Duplicate Detection
13. Local Update و Rollback
14. بررسی نمایش کامل تاریخ‌های شمسی در تمام صفحات و چاپ

## هشدارهای Release

- برای SQL Server موجود، Migrationهای آینده بهتر است به سیستم Migration رسمی EF Core منتقل شوند؛ `EnsureCreated` برای چرخه تکامل طولانی‌مدت دیتابیس راهکار ایده‌آل نیست.
- برای محصول شبکه‌ای، Backup باید روی خود Server SQL و با مسیر قابل دسترس سرویس SQL انجام شود.
- قبل از عرضه عمومی، Rate limiting / lockout برای Login ناموفق و سیاست پیچیدگی رمز عبور می‌تواند تقویت شود.

## حکم QA

**3.9.0 برای مرحله Release Candidate آماده است، اما هنوز «نسخه نهایی تأییدشده» نیست.**
تأیید نهایی فقط بعد از Build، Install و تست عملی روی Windows امکان‌پذیر است.


---

## RBAC_AUDIT_RELEASE_3.5_FA

# حساب‌یار 3.5.0 — RBAC + Audit Pro

## تغییرات
- نشست کاربر مرکزی با UserSession
- سطح دسترسی متمرکز: مدیریت داده، گزارش، Excel و پشتیبان‌گیری
- ثبت کاربر و IP در AuditLog
- ثبت Login موفق و LoginFailed
- گزارش فعالیت‌های سیستم برای مدیر
- ثبت تغییرات مدیریت کاربران با کاربر و IP
- ارتقای schema برای SQLite و SQL Server
- حفظ PBKDF2-SHA256 برای رمز عبور
- نسخه 3.5.0

## نکته امنیتی
IP ثبت‌شده، IP محلی سیستم اجراکننده حساب‌یار است. در حالت SQL Server برای ثبت IP کلاینت‌ها، برنامه باید روی هر کلاینت اجرا شود و AuditLog از همان کلاینت ثبت شود؛ سرور نباید به اینترنت عمومی باز شود. برای دسترسی خارج از شبکه، VPN پیشنهاد می‌شود.


---

## README_FINAL_ROADMAP_FA

# نقشه راه نسخه نهایی

این پروژه اکنون در مسیر نسخه تجاری قرار دارد. مراحل اصلی تکمیل‌شده تا v2.3:

1. انتقال به C# / WPF / .NET 8
2. هسته مالی و decimal
3. EF Core + SQLite داخلی
4. فاکتور، پرداخت، سررسید و میانگین وزنی
5. انتخاب زنده فاکتورها با CheckBox
6. فیلتر شرکت و تفکیک فاکتورها/پرداخت‌ها
7. Excel Import/Export
8. Backup/Restore
9. Login و رمزنگاری PBKDF2
10. Audit Log
11. کاربران و سطح دسترسی
12. تنظیمات
13. چاپ گزارش
14. آماده‌سازی Self-Contained + Installer

## مراحل باقی‌مانده برای انتشار تجاری
- اجرای Build واقعی روی Windows
- اجرای Unit/Integration Tests
- تست مهاجرت دیتابیس نسخه‌های قبلی
- تست Excel با فایل‌های واقعی
- تست UI و DPI/Font
- تست Restore و Backup روی چند سیستم
- تکمیل Scheduler پشتیبان‌گیری خودکار
- تکمیل گزارش‌ساز و چاپ‌های تخصصی
- تولید Setup.exe نهایی و تست نصب/حذف/ارتقا


---

## README_PROFESSIONAL_FA

# AccountingPurchasePro — نسخه حرفه‌ای C# / WPF

این نسخه با هدف نزدیک شدن به محصول تجاری ساخته شده است.

## معماری
- C# / .NET 8 / WPF
- منطق مالی مستقل در `Domain/FinanceRules.cs`
- سرویس‌های کاربردی در `Services/`
- EF Core + SQLite داخلی و بدون نیاز به SQL Server روی سیستم مقصد
- تراکنش برای ثبت پرداخت
- Audit Log برای عملیات اصلی
- Indexهای مالی و رابطه‌ای
- Validation ورودی‌ها
- تست واحد برای محاسبات مالی

## الزامات مالی
- تمام مبالغ `decimal` هستند.
- مانده هیچ‌وقت منفی نمی‌شود.
- پرداخت بیشتر از مانده فاکتور رد می‌شود.
- میانگین وزنی سررسید فقط بر اساس مانده واقعی محاسبه می‌شود.
- انتخاب/لغو انتخاب فاکتورها باید UI را بدون Refresh به‌روزرسانی کند.

## Excel
Import/Export نسخه قبلی حفظ شده است؛ Import رکوردهای تکراری را رد می‌کند و پرداخت‌ها را با فاکتور مرتبط می‌کند.

## اجرای نسخه نهایی
روی سیستم Build:
1. .NET 8 SDK نصب باشد.
2. Inno Setup 6 نصب باشد.
3. `Installer/build-installer.ps1` را با PowerShell اجرا کنید.

خروجی Self-Contained برای `win-x64` است و روی سیستم مقصد به .NET Runtime یا Visual Studio نیاز ندارد.

> این محیط ChatGPT امکان اجرای واقعی WPF/Windows و Build نهایی Setup.exe را ندارد؛ بنابراین قبل از انتشار تجاری، پروژه باید روی Windows Build و تست شود.


---

## RELEASE_3.10_CHECKLIST_FA

# چک‌لیست Release 3.10.0

- [ ] نصب .NET 8 SDK روی Windows
- [ ] اجرای Preflight بدون FAIL
- [ ] dotnet restore موفق
- [ ] dotnet build -c Release موفق
- [ ] dotnet publish win-x64 self-contained موفق
- [ ] اجرای HesabYar.exe
- [ ] تست Login و RBAC
- [ ] تست Companies / Invoices / Payments
- [ ] تست تاریخ شمسی و Weighted Due Date
- [ ] تست Excel Import/Export
- [ ] تست SQLite Backup/Restore
- [ ] تست SQL Server Backup/Restore
- [ ] تست Client/Server و قطع/وصل شبکه
- [ ] تست Local Update و Rollback
- [ ] ساخت Setup با Inno Setup
- [ ] نصب روی Windows تمیز
- [ ] اجرای بعد از نصب
- [ ] Uninstall موفق
- [ ] بررسی نسخه 3.10.0 در فایل‌ها و Installer


---

## RELEASE_3.10_WINDOWS_VALIDATION_FA

# حساب‌یار 3.10.0 — Windows Release Validation

این نسخه مرحله آماده‌سازی برای Build و تست واقعی Windows است.

## هدف
- یکسان‌سازی نسخه پروژه، Installer و VERSION.txt روی 3.10.0
- بررسی Self-contained / win-x64
- جلوگیری از اعلام PASS جعلی وقتی Windows/.NET SDK در دسترس نیست
- ایجاد اسکریپت Preflight برای بررسی محیط واقعی قبل از Build

## دستور پیشنهادی روی Windows
1. .NET 8 SDK را نصب کنید.
2. PowerShell را باز کنید.
3. داخل پوشه پروژه اجرا کنید:
   `powershell -ExecutionPolicy Bypass -File .\Installer\Validate-Release-3.10.ps1`
4. سپس:
   `powershell -ExecutionPolicy Bypass -File .\Installer\publish-win-x64.ps1`
5. پس از ایجاد `publish\win-x64\HesabYar.exe`، Installer را با Inno Setup بسازید.

## معیارهای پذیرش
- Build با exit code صفر
- `HesabYar.exe` ایجاد شود
- اجرای EXE بدون نصب .NET Runtime اضافی
- نصب و حذف Installer موفق باشد
- Login، SQLite، SQL Server، Backup/Restore، Update و Audit تست شوند
- نسخه EXE و Installer هر دو 3.10.0 باشند

## محدودیت این محیط
Build واقعی WPF/Windows و اجرای Installer در محیط فعلی انجام نشده است؛ بنابراین این مرحله فقط آمادگی و کنترل‌های قابل اجرای خارج از Windows را فراهم می‌کند و نتیجه Build واقعی باید روی Windows ثبت شود.


---

## RELEASE_3.11_FINAL_ENGINEERING_FA

# حساب‌یار 3.11.0 — Final Release Engineering

## تغییرات این مرحله

- رفع باگ مهم نام فایل Setup در اسکریپت build که هنوز 3.7.0 را جستجو می‌کرد.
- جلوگیری از استفاده تصادفی از Publish قدیمی با بررسی FileVersion واقعی EXE.
- هماهنگ‌سازی نسخه 3.11.0 در پروژه، Installer و VERSION.txt.
- اضافه شدن Release Preflight برای کنترل فایل‌ها، نسخه‌ها و SDK.
- تولید فایل SHA-256 برای تمام فایل‌های Publish جهت کنترل یکپارچگی Release.
- تست خودکار با شکست صریح در صورت خطا.

## وضعیت

این نسخه از نظر مهندسی Release آماده بررسی روی Windows است؛ Build واقعی، اجرای WPF، SQL Server و نصب Inno Setup باید روی Windows انجام شود و تا آن زمان PASS نهایی ادعا نمی‌شود.


---

## RELEASE_3.12_PRODUCTION_FA

# حساب‌یار 3.12.0 — Production Release Engineering

## هدف
این نسخه مسیر تحویل تولیدی را یکپارچه می‌کند: تست واحد، Restore، Publish خود-contained win-x64، کنترل نسخه EXE، ساخت SHA-256 manifest و ساخت Installer.

## اسکریپت اصلی
`Installer/Production-Release-3.12.ps1`

این اسکریپت در صورت نبود .NET 8 SDK یا Inno Setup، یا شکست تست/Publish/Installer، با خطا متوقف می‌شود و Release ناقص را موفق اعلام نمی‌کند.

## کنترل‌های نسخه
- Project: 3.12.0
- AssemblyVersion: 3.12.0.0
- FileVersion: 3.12.0.0
- Runtime: win-x64
- SelfContained: true

## وضعیت
این بسته، Release Engineering را آماده می‌کند. Build واقعی Windows و اجرای Installer باید روی Windows انجام شود؛ این محیط آن را ادعا نمی‌کند.


---

## RELEASE_3.13_HESABGARA_FA

# حساب‌گرا 3.13.0 — تغییرات این نسخه

- تغییر نام محصول از حساب‌یار به حساب‌گرا.
- تغییر AssemblyName به HesabGara.
- افزودن روش وصول: نقد، کارت‌به‌کارت، چک، ترکیبی.
- شماره چک اختیاری است و در صورت انتخاب چک فعال می‌شود.
- تاریخ چک اختیاری است.
- وضعیت چک: در انتظار وصول، وصول‌شده، برگشتی، لغوشده.
- امکان تکمیل اطلاعات چک در آینده.
- نمایش روش وصول و اطلاعات چک در جدول پرداخت‌ها.
- سازگاری با دیتابیس‌های SQLite و SQL Server موجود با افزودن ستون‌های جدید در اولین اجرا.
- مسیر دیتابیس قبلی عمداً حفظ شده تا ارتقا باعث از دست رفتن اطلاعات نشود.
- اسکریپت Publish برای پیدا کردن dotnet.exe در مسیرهای استاندارد اصلاح شد.


---

## RELEASE_3.6_PRO

# HesabYar 3.6.0 — Professional Deployment Release

## تغییرات
- اضافه شدن First-Run Setup Wizard
- انتخاب Local SQLite یا Network SQL Server بدون ویرایش فایل config
- تست اتصال SQL Server از Wizard
- پشتیبانی Windows Authentication و SQL Authentication
- پشتیبانی پورت اختیاری SQL Server
- جلوگیری از اجرای DatabaseInitializer قبل از انتخاب مسیر دیتابیس در اولین اجرا
- ارتقای نسخه به 3.6.0

## توجه
این بسته سورس پروژه است. Build نهایی Self-Contained Win-x64 و Installer باید روی Windows با .NET 8 SDK ساخته و روی Windows واقعی تست شود.


---

## RELEASE_3.7_PRO

# حساب‌یار 3.7.0 — Installer Pro

## این نسخه
- Installer به‌روز شده برای نسخه 3.7.0
- حداقل Windows 10 1809
- Self-contained win-x64
- انتخاب اختیاری میانبر دسکتاپ در Installer
- اطلاعات نسخه و Uninstaller استاندارد
- Wizard راه‌اندازی شبکه با اعتبارسنجی پورت و نام دیتابیس
- امکان آماده‌سازی خودکار دیتابیس SQL Server از طریق دسترسی master
- قبل از ذخیره تنظیمات شبکه، آماده بودن دیتابیس بررسی می‌شود

## نکته
این بسته سورس/اسکریپت انتشار است. برای تولید Setup نهایی باید روی Windows با .NET 8 SDK و Inno Setup اجرا شود.


---

## RELEASE_3.8_HARDENING_FA

# حساب‌یار 3.8.0 — Release Hardening

## تغییرات اصلی

### 1) سلامت پایگاه داده
- بررسی SQLite با `integrity_check` و `foreign_key_check`
- بررسی وضعیت ONLINE دیتابیس در SQL Server
- گزارش تعداد شرکت‌ها، فاکتورها و پرداخت‌ها
- خطاهای Health Check به جای متوقف کردن برنامه گزارش می‌شوند.

### 2) Backup حرفه‌ای
- SQLite: پشتیبان سازگار با WAL و اعتبارسنجی Integrity
- SQL Server: `BACKUP DATABASE` با `CHECKSUM` و `COMPRESSION`
- SQL Server Backup با `RESTORE VERIFYONLY` اعتبارسنجی می‌شود.
- Restore SQL Server با حالت SINGLE_USER و بازگشت به MULTI_USER انجام می‌شود.
- نکته: مسیر `.bak` در SQL Server باید روی خود سرور SQL قابل دسترسی باشد.

### 3) لاگ فنی
- ثبت خطاهای راه‌اندازی و خطاهای UI
- فایل‌های لاگ روزانه در:
  `%LOCALAPPDATA%\HesabYar\Logs`
- نگهداری حداکثر 14 فایل قدیمی
- Logger نباید خودش باعث Crash برنامه شود.

### 4) پایداری
- خطاهای غیرمنتظره دیگر فقط به MessageBox محدود نیستند و در فایل لاگ هم ذخیره می‌شوند.
- منطق شبکه و SQLite از هم تفکیک شده‌اند.

## محدودیت مهم
این بسته سورس/پروژه Release است. ساخت EXE و Installer نهایی باید روی Windows با .NET 8 SDK و ابزار Installer پروژه انجام و سپس تست شود.


---

## RELEASE_PACKAGE_FA

حساب‌یار — بسته آماده انتشار 3.4.0

توسعه‌دهنده: حسین حسین زاده
ایمیل: Hzadeh007@gmail.com

این بسته برای ساخت نسخه نصب‌شونده Self-Contained ویندوز آماده شده است.
برای ساخت Setup روی Windows:
1) .NET 8 SDK را نصب کنید.
2) Inno Setup 6 را نصب کنید.
3) فایل Installer\Build-HesabYar.cmd را با دسترسی معمولی اجرا کنید.
4) خروجی در installer-output\HesabYar_Setup_3.4.0_win-x64.exe قرار می‌گیرد.

پس از ساخت Setup، کامپیوتر مقصد به .NET Runtime یا Visual Studio نیاز ندارد، چون برنامه به صورت Self-Contained منتشر می‌شود.


---

## RTL_LAYOUT_FIX_3.13.0_FA

اصلاح راست‌چین کامل رابط کاربری حساب‌گرا – نسخه 3.13.0

- چیدمان اصلی به صورت قطعی LTR برای جلوگیری از جابه‌جایی فیزیکی ستون‌ها تنظیم شد.
- منوی اصلی به ستون سمت راست منتقل و FlowDirection آن RTL شد.
- محتوای اصلی، هدر، نوار ابزار و نوار وضعیت RTL شدند.
- متن دکمه‌های منوی سمت راست Right-aligned شد.
- ترتیب و جایگاه منوی سمت راست مستقل از RTL بودن محتوای داخلی شد.
- هدر برند در سمت راست بخش اصلی باقی می‌ماند و کنترل‌های پنجره در سمت چپ قرار می‌گیرند.


---

## UI_BRAND_UPDATE_3.13.0_FA

حساب‌گرا 3.13.0 - به‌روزرسانی هویت بصری
- لوگوی اصلی حساب‌گرا برای Sidebar و Login اعمال شد.
- آیکون EXE/Shortcut در Assets/HesabGara.ico قرار گرفت.
- داشبورد به عنوان گزینه فعال منوی راست با استایل آبی نمایش داده می‌شود.
- رنگ‌بندی منوی راست به سرمه‌ای/آبی/طلایی هماهنگ شد.
- نسخه نمایش داده‌شده در Login به 3.13.0 اصلاح شد.


---

## UI_V7_CHANGES_FA

حساب‌گرا - UI V7

اعمال‌شده:
- متن منوی سمت راست سفید و پرکنتراست.
- RTL پنجره اصلی حفظ/تقویت شد.
- حذف میانبر تقویم از داشبورد در XAML در صورت وجود.
- پس‌زمینه محتوای اصلی دست‌نخورده و سفید باقی می‌ماند.

مرحله بعدی پیشنهادی:
- انتقال عملیات پرداخت به داخل فاکتورها.
- حذف تب مستقل پرداخت‌ها پس از تست عملیات جدید.
- ادغام سررسیدها با گزارش‌ها.
- بهینه‌سازی تب کاربران و نقش‌ها.

منطق دیتابیس و عملیات مالی در این مرحله تغییر داده نشده تا نسخه اجرایی سالم حفظ شود.
