using HesabGara.Models;

namespace HesabGara.Domain;

/// <summary>
/// یک چک واقعی. وقتی یک چک برای چند فاکتور صادر می‌شود، برنامه برای هر فاکتور یک رکورد وصول می‌سازد؛
/// این کلاس آن رکوردها (هم‌شرکت، هم‌شماره و هم‌تاریخ) را دوباره یک چک حساب می‌کند.
/// </summary>
public sealed class CheckGroup
{
    public IReadOnlyList<Payment> Payments { get; }
    public CheckGroup(IReadOnlyList<Payment> payments) => Payments = payments;

    Payment First => Payments[0];
    public int Id => Payments.Min(p => p.Id);
    public string? CheckNumber => First.CheckNumber;
    public DateTime? CheckDate => First.CheckDate;
    public decimal Amount => Payments.Sum(p => p.Amount);
    public int CompanyId => First.Invoice?.CompanyId ?? 0;
    public string CompanyName => First.Invoice?.Company?.Name ?? "-";

    /// <summary>اگر وضعیت رکوردها فرق کند: برگشتی مهم‌تر از در انتظار وصول و آن مهم‌تر از بقیه است.</summary>
    public string Status
    {
        get
        {
            var all = Payments.Select(p => p.CheckStatus ?? "").ToList();
            if (all.Contains("برگشتی")) return "برگشتی";
            if (all.Contains(PaymentRules.DefaultCheckStatus)) return PaymentRules.DefaultCheckStatus;
            return all.FirstOrDefault(x => x.Length > 0) ?? "";
        }
    }

    /// <summary>فاکتورهایی که این چک برایشان صادر شده، با سهم هر کدام از مبلغ چک.</summary>
    public IReadOnlyList<(string Number, decimal Amount)> Invoices =>
        Payments.GroupBy(p => p.InvoiceId)
            .Select(g => (Number: g.First().Invoice?.Number ?? "-", Amount: g.Sum(p => p.Amount)))
            .OrderBy(x => x.Number, StringComparer.OrdinalIgnoreCase)
            .ToList();

    /// <summary>برای یک فاکتور فقط شماره‌اش؛ برای چند فاکتور «شماره (سهم)، شماره (سهم)».</summary>
    public string InvoiceText
    {
        get
        {
            var list = Invoices;
            return list.Count == 1 ? list[0].Number : string.Join("، ", list.Select(i => $"{i.Number} ({i.Amount:N0})"));
        }
    }
}

public static class CheckGrouping
{
    /// <summary>چک‌ها (رکوردهای وصول با روش «چک») را به «یک ردیف برای هر چک» تبدیل می‌کند؛ نزدیک‌ترین سررسید اول.</summary>
    public static List<CheckGroup> Group(IEnumerable<Payment> checkPayments)
    {
        var keyed = new Dictionary<(int Company, string Number, DateTime? Date), List<Payment>>();
        var groups = new List<CheckGroup>();
        foreach (var p in checkPayments)
        {
            var number = (p.CheckNumber ?? "").Trim();
            if (number.Length == 0) { groups.Add(new CheckGroup(new[] { p })); continue; }   // بدون شماره نمی‌شود تشخیص داد
            var key = (p.Invoice?.CompanyId ?? 0, number.ToUpperInvariant(), p.CheckDate?.Date);
            if (!keyed.TryGetValue(key, out var list)) keyed[key] = list = new List<Payment>();
            list.Add(p);
        }
        groups.AddRange(keyed.Values.Select(l => new CheckGroup(l)));
        return groups.OrderBy(g => g.CheckDate ?? DateTime.MaxValue).ThenBy(g => g.Id).ToList();
    }
}
