using HesabGara.Models;

namespace HesabGara.Domain;

/// <summary>یک ردیف گردش حساب (بدهکار = افزایش بدهی مشتری، بستانکار = کاهش آن).</summary>
public sealed record StatementEntry(DateTime Date, int Order, string Description, string Reference, decimal Debit, decimal Credit);

public sealed record StatementLine(DateTime Date, string Description, string Reference, decimal Debit, decimal Credit, decimal Balance);

public sealed record StatementResult(decimal Opening, IReadOnlyList<StatementLine> Lines, decimal TotalDebit, decimal TotalCredit, decimal Closing);

/// <summary>
/// صورت‌حساب شرکت: فاکتورها (بدهکار به مبلغ کل)، مرجوعی (بستانکار)، وصول‌ها (بستانکار).
/// چکی که برای چند فاکتور صادر شده یک ردیف است. مانده‌ی نهایی همیشه با مجموع مانده‌ی فاکتورها برابر است.
/// </summary>
public static class CompanyStatement
{
    public static List<StatementEntry> Entries(IEnumerable<Invoice> invoices, IEnumerable<Payment> payments)
    {
        var list = new List<StatementEntry>();
        foreach (var i in invoices)
        {
            list.Add(new StatementEntry(i.InvoiceDate.Date, 0, $"فاکتور {i.Number}", i.Number, i.Amount, 0m));
            if (i.ReturnedAmount > 0)
                list.Add(new StatementEntry(i.InvoiceDate.Date, 1, $"مرجوعی فاکتور {i.Number}", i.Number, 0m, i.ReturnedAmount));
        }

        var pays = payments.ToList();
        foreach (var g in CheckGrouping.Group(pays.Where(p => p.PaymentMethod == PaymentMethods.Check)))
        {
            var number = string.IsNullOrWhiteSpace(g.CheckNumber) ? "بدون شماره" : g.CheckNumber!.Trim();
            var status = g.Status.Length > 0 ? " — " + g.Status : "";
            list.Add(new StatementEntry(g.Payments.Min(p => p.PayDate).Date, 2, $"وصول چک {number}{status}", g.InvoiceText, 0m, g.Amount));
        }
        foreach (var p in pays.Where(p => p.PaymentMethod != PaymentMethods.Check))
        {
            var note = string.IsNullOrWhiteSpace(p.Note) ? "" : " — " + p.Note.Trim();
            list.Add(new StatementEntry(p.PayDate.Date, 2, $"وصول {p.PaymentMethod}{note}", p.Invoice?.Number ?? "-", 0m, p.Amount));
        }
        return list.OrderBy(e => e.Date).ThenBy(e => e.Order).ThenBy(e => e.Description, StringComparer.Ordinal).ToList();
    }

    /// <summary>اگر <paramref name="from"/> داده شود، گردش‌های قبل از آن به‌صورت «مانده‌ی از قبل» جمع می‌شود.</summary>
    public static StatementResult Build(IEnumerable<Invoice> invoices, IEnumerable<Payment> payments, DateTime? from, DateTime? to)
    {
        var all = Entries(invoices, payments);
        var opening = from.HasValue ? all.Where(e => e.Date < from.Value.Date).Sum(e => e.Debit - e.Credit) : 0m;
        var lines = new List<StatementLine>();
        var running = opening;
        decimal totalDebit = 0m, totalCredit = 0m;
        foreach (var e in all.Where(e => (!from.HasValue || e.Date >= from.Value.Date) && (!to.HasValue || e.Date <= to.Value.Date)))
        {
            running += e.Debit - e.Credit;
            totalDebit += e.Debit;
            totalCredit += e.Credit;
            lines.Add(new StatementLine(e.Date, e.Description, e.Reference, e.Debit, e.Credit, running));
        }
        return new StatementResult(opening, lines, totalDebit, totalCredit, running);
    }
}
