using System.Data;
using HesabGara.Data;
using HesabGara.Domain;
using HesabGara.Models;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

public sealed record SelectionSummary(decimal TotalAmount, decimal TotalPaid, decimal TotalBalance, decimal WeightedDueDays, DateTime? WeightedDueDate);

/// <summary>
/// منطق حسابداری، تقسیم‌شده بر اساس موضوع:
/// Companies (شرکت‌ها)، Invoices (فاکتورها)، Payments (وصول‌ها).
///
/// قاعده‌ی مالی: «مبلغ پرداخت‌شده‌ی» هر فاکتور فقط از جمع رکوردهای Payment می‌آید.
/// ستون Invoice.Paid فقط یک کَش همگام‌شده است و هیچ‌جا مستقل از Payment مقداردهی نمی‌شود.
/// </summary>
public sealed partial class AccountingService
{
    public static decimal Balance(Invoice x) => FinanceRules.Balance(x.Amount, x.Paid);

    public static decimal WeightedDueDays(IEnumerable<Invoice> rows, DateTime? reference = null)
        => FinanceRules.Summarize(rows.Select(x => (x.Amount, x.Paid, x.DueDate)), reference).WeightedDays;

    public static SelectionSummary Summarize(IEnumerable<Invoice> rows)
    {
        var result = FinanceRules.Summarize(rows.Select(x => (x.Amount, x.Paid, x.DueDate)));
        return new(result.Total, result.Paid, result.Balance, result.WeightedDays, result.WeightedDate);
    }

    // تراکنش دستی + SQL Server: چون AppDbContext با EnableRetryOnFailure تنظیم شده، EF تراکنش دستی را
    // فقط داخل execution strategy می‌پذیرد (وگرنه در حالت شبکه‌ای هر ثبت/ویرایش/حذف وصول خطا می‌داد).
    // Serializable باعث می‌شود دو کاربر همزمان روی یک فاکتور نتوانند هر دو از مانده‌ی قدیمی عبور کنند؛
    // deadlock احتمالی را strategy خودکار تکرار می‌کند و کاربر دوم پیام «مانده کافی نیست» می‌گیرد.
    static Task InTransactionAsync(AppDbContext db, Func<Task> work, CancellationToken ct)
    {
        var strategy = db.Database.CreateExecutionStrategy();
        return strategy.ExecuteAsync(async () =>
        {
            db.ChangeTracker.Clear(); // هر تلاش مجدد باید از وضعیت تمیز شروع شود
            await using var tx = await db.Database.BeginTransactionAsync(IsolationLevel.Serializable, ct);
            await work();
            await tx.CommitAsync(ct);
        });
    }

    // جمع وصول‌های یک فاکتور (SQLite از SUM روی decimal پشتیبانی نمی‌کند؛ جمع سمت کلاینت انجام می‌شود).
    // excludePaymentId برای ویرایش یک وصول است تا مبلغ فعلی خودش حساب نشود.
    static async Task<decimal> PaidTotalAsync(AppDbContext db, int invoiceId, int? excludePaymentId, CancellationToken ct)
    {
        var q = db.Payments.Where(x => x.InvoiceId == invoiceId);
        if (excludePaymentId.HasValue) { var id = excludePaymentId.Value; q = q.Where(x => x.Id != id); }
        return (await q.Select(x => x.Amount).ToListAsync(ct)).Sum();
    }

    static Task AuditAsync(string action, string entity, string id, string? details, AppDbContext db, CancellationToken ct)
        => db.AuditLogs.AddAsync(new AuditLog { TimestampUtc = DateTime.UtcNow, Action = action, Entity = entity, EntityId = id, Details = details }, ct).AsTask();
}
