﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using HesabGara.Models;
using HesabGara.Views;

namespace HesabGara.Services;

/// <summary>یک جدول قابل چاپ: عنوان، سرستون‌ها، ردیف‌ها (متن آماده)، توضیح پایین جدول و وزن نسبی ستون‌ها.</summary>
public sealed record PrintTable(string Heading, IReadOnlyList<string> Headers, IReadOnlyList<string[]> Rows, string? Footer = null, double[]? Widths = null);

public sealed class PrintService
{
    // خروجی چاپ الان دو مرحله‌ای است: اول یک پیش‌نمای واقعی از سند نمایش داده می‌شود، و فقط
    // با تأیید کاربر روی دکمه‌ی «چاپ» در همان پنجره، دیالوگ چاپ ویندوز باز می‌شود.
    public async Task PrintInvoicesAsync(IEnumerable<Invoice> invoices, string title = "گزارش فاکتورها")
    {
        var rows = invoices.ToList();
        if (rows.Count == 0) { MessageBox.Show("برای چاپ، فاکتوری وجود ندارد.", "چاپ", MessageBoxButton.OK, MessageBoxImage.Information); return; }

        var companyName = await new SettingsService().GetAsync("CompanyName");
        var doc = BuildDocument(rows, title, string.IsNullOrWhiteSpace(companyName) ? "حساب‌گرا" : companyName!);
        ShowPreview(doc, title);
    }

    void ShowPreview(FlowDocument doc, string title)
    {
        var viewer = new FlowDocumentScrollViewer { Document = doc, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Padding = new Thickness(10) };
        var printBtn = new Button { Content = "چاپ", Width = 110, Height = 36, Margin = new Thickness(6), Background = AppTheme.Brand600, Foreground = Brushes.White, BorderThickness = new Thickness(0) };
        var closeBtn = new Button { Content = "بستن", Width = 110, Height = 36, Margin = new Thickness(6), Background = AppTheme.Surface100, Foreground = AppTheme.Ink700, BorderThickness = new Thickness(0) };
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(14) };
        buttons.Children.Add(printBtn); buttons.Children.Add(closeBtn);

        var root = new Grid { Background = AppTheme.Surface100 };
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        Grid.SetRow(viewer, 0); Grid.SetRow(buttons, 1);
        root.Children.Add(viewer); root.Children.Add(buttons);

        var win = new Window
        {
            Title = "پیش‌نمای چاپ — " + title, Content = root, Width = 900, Height = 760,
            FlowDirection = FlowDirection.RightToLeft, WindowStartupLocation = WindowStartupLocation.CenterScreen,
            Background = AppTheme.Surface100
        };
        closeBtn.Click += (_, _) => win.Close();
        printBtn.Click += (_, _) =>
        {
            var dialog = new PrintDialog();
            if (dialog.ShowDialog() != true) return;
            dialog.PrintDocument(((IDocumentPaginatorSource)doc).DocumentPaginator, title);
            win.Close();
        };
        win.ShowDialog();
    }

    FlowDocument BuildDocument(List<Invoice> rows, string title, string companyName)
    {
        var total = rows.Sum(x => x.Amount); var paid = rows.Sum(x => x.Paid); var balance = rows.Sum(AccountingService.Balance);
        var doc = new FlowDocument { PagePadding = new Thickness(34), FontFamily = new FontFamily("Tahoma"), FontSize = 10.5, FlowDirection = FlowDirection.RightToLeft, ColumnWidth = double.PositiveInfinity };

        AddBrandHeader(doc, companyName);

        doc.Blocks.Add(new Paragraph(new Run(title)) { FontSize = 17, FontWeight = FontWeights.Bold, TextAlignment = TextAlignment.Center, Margin = new Thickness(0,12,0,4) });
        doc.Blocks.Add(new Paragraph(new Run($"تاریخ چاپ: {PersianDateService.ToPersian(DateTime.Now)}   |   تعداد فاکتورها: {rows.Count:N0}")) { TextAlignment = TextAlignment.Center, Foreground = new SolidColorBrush(Color.FromRgb(102,112,127)), Margin = new Thickness(0,0,0,12) });

        var summary = new Table { CellSpacing = 4 };
        for(int i=0;i<3;i++) summary.Columns.Add(new TableColumn());
        var sr = new TableRow();
        foreach(var item in new[]{($"جمع فاکتورها\n{total:N0} ریال", "#E7F1FB"),($"جمع پرداختی\n{paid:N0} ریال", "#E3F6EE"),($"مانده\n{balance:N0} ریال", "#FBE7EA")})
        {
            var c=new TableCell(new Paragraph(new Run(item.Item1))){Background=(Brush)new BrushConverter().ConvertFromString(item.Item2)!,Padding=new Thickness(10),FontWeight=FontWeights.Bold,TextAlignment=TextAlignment.Center};sr.Cells.Add(c);
        }
        var sg=new TableRowGroup();sg.Rows.Add(sr);summary.RowGroups.Add(sg);doc.Blocks.Add(summary);doc.Blocks.Add(new Paragraph(new Run(" ")));

        var table = new Table { CellSpacing = 0 };
        foreach(var _ in Enumerable.Range(0,7)) table.Columns.Add(new TableColumn());
        var group = new TableRowGroup(); var headerRow=new TableRow();
        foreach(var h in new[]{"شماره فاکتور","شرکت","تاریخ","سررسید","مبلغ (ریال)","پرداختی","مانده"}) headerRow.Cells.Add(new TableCell(new Paragraph(new Run(h))){Background=new SolidColorBrush(Color.FromRgb(10,38,71)),Foreground=Brushes.White,FontWeight=FontWeights.Bold,Padding=new Thickness(7),TextAlignment=TextAlignment.Center});
        group.Rows.Add(headerRow);
        foreach(var x in rows)
        {
            var r=new TableRow(); var vals=new[]{x.Number,x.Company?.Name??"-",PersianDateService.ToPersian(x.InvoiceDate),PersianDateService.ToPersian(x.DueDate),x.Amount.ToString("N0"),x.Paid.ToString("N0"),AccountingService.Balance(x).ToString("N0")};
            for(int i=0;i<vals.Length;i++) r.Cells.Add(new TableCell(new Paragraph(new Run(vals[i]))){Padding=new Thickness(6),TextAlignment=TextAlignment.Center,Background=i%2==0?new SolidColorBrush(Color.FromRgb(248,250,252)):Brushes.White});
            group.Rows.Add(r);
        }
        table.RowGroups.Add(group); doc.Blocks.Add(table);
        AddFooter(doc);
        return doc;
    }

    static FlowDocument NewDocument() => new FlowDocument { PagePadding = new Thickness(34), FontFamily = new FontFamily("Tahoma"), FontSize = 10.5, FlowDirection = FlowDirection.RightToLeft, ColumnWidth = double.PositiveInfinity };

    static void AddBrandHeader(FlowDocument doc, string companyName)
    {
        // هدر چاپ: فقط لوگوی نرم‌افزار (بدون متن «حساب‌گرا») + نام مجموعه‌ی کاربر به‌جای نام نرم‌افزار.
        var header = new Table { CellSpacing = 0 };
        header.Columns.Add(new TableColumn { Width = new GridLength(70) });
        header.Columns.Add(new TableColumn { Width = new GridLength(1, GridUnitType.Star) });
        var hr = new TableRow();
        var logoCell = new TableCell { Background = new SolidColorBrush(Color.FromRgb(10,38,71)), Padding = new Thickness(10), TextAlignment = TextAlignment.Center };
        try
        {
            var logo = new Image { Source = new BitmapImage(new Uri("pack://application:,,,/Assets/HesabGara_SidebarIcon.png")), Width = 46, Height = 46, Stretch = Stretch.Uniform };
            logoCell.Blocks.Add(new BlockUIContainer(logo));
        }
        catch { /* اگر تصویر در دسترس نبود، هدر بدون لوگو ادامه پیدا می‌کند */ }
        var nameCell = new TableCell(new Paragraph(new Run(companyName))) { Background = new SolidColorBrush(Color.FromRgb(10,38,71)), Foreground = Brushes.White, Padding = new Thickness(14), FontSize = 20, FontWeight = FontWeights.Bold, TextAlignment = TextAlignment.Right };
        hr.Cells.Add(nameCell); hr.Cells.Add(logoCell);
        var hg = new TableRowGroup(); hg.Rows.Add(hr); header.RowGroups.Add(hg); doc.Blocks.Add(header);
    }

    static void AddFooter(FlowDocument doc)
    {
        var version = typeof(PrintService).Assembly.GetName().Version?.ToString(3) ?? LocalUpdateService.CurrentVersion;
        doc.Blocks.Add(new Paragraph(new Run($"توسعه‌دهنده: حسین حسین زاده  |  نسخه {version}  |  Hzadeh007@gmail.com")){FontSize=9,Foreground=new SolidColorBrush(Color.FromRgb(102,112,127)),TextAlignment=TextAlignment.Center,Margin=new Thickness(0,16,0,0)});
    }

    /// <summary>چاپ یک گزارش عمومی (یک یا چند جدول) با همان هدر و پیش‌نمای چاپ فاکتورها.</summary>
    public async Task PrintReportAsync(string title, string subtitle, IReadOnlyList<PrintTable> tables)
    {
        if (tables.All(t => t.Rows.Count == 0)) { MessageBox.Show("برای چاپ، داده‌ای وجود ندارد.", "چاپ", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        var companyName = await new SettingsService().GetAsync("CompanyName");
        var doc = BuildReportDocument(title, subtitle, tables, string.IsNullOrWhiteSpace(companyName) ? "حساب‌گرا" : companyName!);
        ShowPreview(doc, title);
    }

    static FlowDocument BuildReportDocument(string title, string subtitle, IReadOnlyList<PrintTable> tables, string companyName)
    {
        var doc = NewDocument();
        AddBrandHeader(doc, companyName);
        var gray = new SolidColorBrush(Color.FromRgb(102, 112, 127));
        doc.Blocks.Add(new Paragraph(new Run(title)) { FontSize = 17, FontWeight = FontWeights.Bold, TextAlignment = TextAlignment.Center, Margin = new Thickness(0, 12, 0, 4) });
        doc.Blocks.Add(new Paragraph(new Run($"تاریخ چاپ: {PersianDateService.ToPersian(DateTime.Now)}")) { TextAlignment = TextAlignment.Center, Foreground = gray, Margin = new Thickness(0, 0, 0, 4) });
        if (!string.IsNullOrWhiteSpace(subtitle))
            doc.Blocks.Add(new Paragraph(new Run(subtitle)) { TextAlignment = TextAlignment.Center, Foreground = gray, FontSize = 10, Margin = new Thickness(0, 0, 0, 12) });

        foreach (var t in tables)
        {
            if (!string.IsNullOrWhiteSpace(t.Heading))
                doc.Blocks.Add(new Paragraph(new Run(t.Heading)) { FontSize = 13, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 14, 0, 4) });
            if (t.Rows.Count == 0) { doc.Blocks.Add(new Paragraph(new Run("موردی وجود ندارد.")) { Foreground = gray }); continue; }

            var table = new Table { CellSpacing = 0 };
            for (var i = 0; i < t.Headers.Count; i++)
                table.Columns.Add(new TableColumn { Width = new GridLength(t.Widths != null && i < t.Widths.Length ? t.Widths[i] : 1, GridUnitType.Star) });
            var group = new TableRowGroup();
            var headerRow = new TableRow();
            foreach (var h in t.Headers)
                headerRow.Cells.Add(new TableCell(new Paragraph(new Run(h))) { Background = new SolidColorBrush(Color.FromRgb(10, 38, 71)), Foreground = Brushes.White, FontWeight = FontWeights.Bold, Padding = new Thickness(5), TextAlignment = TextAlignment.Center });
            group.Rows.Add(headerRow);
            for (var r = 0; r < t.Rows.Count; r++)
            {
                var row = new TableRow();
                foreach (var cell in t.Rows[r])
                    row.Cells.Add(new TableCell(new Paragraph(new Run(cell))) { Padding = new Thickness(5), TextAlignment = TextAlignment.Center, Background = r % 2 == 0 ? new SolidColorBrush(Color.FromRgb(248, 250, 252)) : Brushes.White });
                group.Rows.Add(row);
            }
            table.RowGroups.Add(group);
            doc.Blocks.Add(table);
            if (!string.IsNullOrWhiteSpace(t.Footer))
                doc.Blocks.Add(new Paragraph(new Run(t.Footer)) { FontWeight = FontWeights.Bold, Margin = new Thickness(0, 4, 0, 0) });
        }
        AddFooter(doc);
        return doc;
    }
}
