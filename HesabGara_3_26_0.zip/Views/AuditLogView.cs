using System.Windows;
using System.Windows.Controls;
using HesabGara.Data;
using HesabGara.Services;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Views;

public sealed class AuditLogView : Grid
{
    readonly DataGrid G = new() { AutoGenerateColumns = false, IsReadOnly = true, CanUserAddRows = false, Margin = new Thickness(12) };
    readonly TextBox Search = new() { Width = 260, Height = 32, Margin = new Thickness(4) };

    public AuditLogView()
    {
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(55) });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        var top = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(12, 8, 12, 0), FlowDirection = FlowDirection.RightToLeft };
        top.Children.Add(new TextBlock { Text = "جستجوی کاربر / عملیات / IP:", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4) });
        top.Children.Add(Search);
        var btn = new Button { Content = "جستجو", Padding = new Thickness(14, 5, 14, 5), Margin = new Thickness(4) };
        btn.Click += async (_, _) => await LoadAsync();
        top.Children.Add(btn);
        Grid.SetRow(top, 0); Children.Add(top);

        G.Columns.Add(new DataGridTextColumn { Header = "زمان", Binding = new System.Windows.Data.Binding("Timestamp") });
        G.Columns.Add(new DataGridTextColumn { Header = "کاربر", Binding = new System.Windows.Data.Binding("UserName") });
        G.Columns.Add(new DataGridTextColumn { Header = "IP", Binding = new System.Windows.Data.Binding("IpAddress") });
        G.Columns.Add(new DataGridTextColumn { Header = "عملیات", Binding = new System.Windows.Data.Binding("Action") });
        G.Columns.Add(new DataGridTextColumn { Header = "بخش", Binding = new System.Windows.Data.Binding("Entity") });
        G.Columns.Add(new DataGridTextColumn { Header = "جزئیات", Binding = new System.Windows.Data.Binding("Details") });
        Grid.SetRow(G, 1); Children.Add(G);
        Loaded += async (_, _) => await LoadAsync();
    }

    async Task LoadAsync()
    {
        await using var db = new AppDbContext();
        var q = db.AuditLogs.AsNoTracking().AsQueryable();

        var s = Search.Text.Trim();
        if (!string.IsNullOrWhiteSpace(s))
        {
            // Filter in the database BEFORE limiting row count, so matches older than the
            // most recent 1000 entries are still found instead of silently being excluded.
            q = q.Where(x =>
                (x.UserName != null && EF.Functions.Like(x.UserName, $"%{s}%")) ||
                (x.IpAddress != null && EF.Functions.Like(x.IpAddress, $"%{s}%")) ||
                EF.Functions.Like(x.Action, $"%{s}%") ||
                (x.Details != null && EF.Functions.Like(x.Details, $"%{s}%")));
        }

        var rows = await q.OrderByDescending(x => x.TimestampUtc).Take(1000).Select(x => new
        {
            Timestamp = PersianDateService.ToPersian(x.TimestampUtc.ToLocalTime()) + " " + x.TimestampUtc.ToLocalTime().ToString("HH:mm:ss"),
            UserName = x.UserName ?? "-",
            IpAddress = x.IpAddress ?? "-",
            Action = x.Action,
            Entity = x.Entity,
            Details = x.Details ?? ""
        }).ToListAsync();
        G.ItemsSource = rows;
    }
}
