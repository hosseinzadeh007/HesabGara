using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using HesabGara.Models;
using HesabGara.Services;

namespace HesabGara.Views;

public partial class InvoicesView : Grid
{
    readonly AccountingService S; readonly int? InitialCompanyId; readonly DataGrid G=new(); readonly TextBlock Summary=new();
    ComboBox CompanyBox=new(); TextBox NumberBox=new(), AmountBox=new(), DateBox=new(), DueBox=new(), NoteBox=new();
    readonly ObservableCollection<Row> Rows=new(); bool loading; bool suppressCompanyChange;
    readonly CheckBox DueOnlyBox = new(){ Content="فقط سررسیدهای باز" };

    // --- Payments / check-collection panel for the currently selected invoice ---
    int? SelectedInvoiceId;
    int? EditingPaymentId; decimal? EditingOriginalAmount;
    readonly TextBlock PaySubtitle=new();
    readonly TextBox PayAmount=new(), PayCheckNumberBox=new(), PayNoteBox=new();
    readonly ComboBox PayMethodBox=new(), PayCheckStatusBox=new();
    readonly PersianDateBox PayCheckDateBox=new(), PayDateBox=new();
    readonly CheckBox PayFullSettleBox=new(){ Content="تسویه کامل (کل مانده)" };
    readonly DataGrid PayGrid=new();
    Button PayAddButton=new(), PayDeleteButton=new(), PayCancelEditButton=new();

    public InvoicesView(AccountingService s,int? companyId){S=s;InitialCompanyId=companyId;Margin=new Thickness(18);Background=AppTheme.Surface100;Build();Loaded+=async(_,_)=>{await InitCompanies();await Load();};}

    void Build()
    {
        FlowDirection = FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(66) });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        var card = new Border
        {
            Background = Brushes.White,
            BorderBrush = AppTheme.Line200,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(14),
            Padding = new Thickness(16),
            Margin = new Thickness(0,0,0,10),
            Effect = AppTheme.CardShadow
        };

        var g = new Grid { FlowDirection = FlowDirection.RightToLeft };
        for (int i=0;i<4;i++) g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var title = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        title.Children.Add(new TextBlock { Text="مشخصات فاکتور", FontSize=17, FontWeight=FontWeights.Bold,
            Foreground=AppTheme.Brand900 });
        title.Children.Add(new TextBlock { Text="  ثبت و ویرایش اطلاعات فاکتور", Foreground=AppTheme.Ink500,
            FontSize=12.5, VerticalAlignment=VerticalAlignment.Center, Margin=new Thickness(8,0,0,0) });
        Grid.SetColumnSpan(title,4); Grid.SetRow(title,0); g.Children.Add(title);

        AddField(g,"شماره فاکتور *",NumberBox,0,1);
        AddCombo(g,"شرکت *",CompanyBox,1,1);
        AddField(g,"تاریخ فاکتور",DateBox,2,1);
        AddField(g,"سررسید",DueBox,3,1);

        AddField(g,"مبلغ (ریال) *",AmountBox,0,2);
        Grid.SetColumnSpan(NoteBox,1);
        AddField(g,"توضیحات",NoteBox,1,2);

        var buttons = new StackPanel { Orientation=Orientation.Horizontal, HorizontalAlignment=HorizontalAlignment.Left,
            VerticalAlignment=VerticalAlignment.Center, FlowDirection=FlowDirection.RightToLeft };
        var save=Btn("＋ ثبت / ذخیره",AppTheme.Success600); save.Click+=AddInvoice;
        var clear=Btn("پاک کردن",AppTheme.Surface100); clear.Foreground=AppTheme.Ink900; clear.Click+=(_,_)=>ClearForm();
        var del=Btn("حذف",AppTheme.Danger100); del.Foreground=AppTheme.Danger600; del.Click+=DeleteInvoice;
        buttons.Children.Add(save); buttons.Children.Add(clear); buttons.Children.Add(del);
        Grid.SetColumn(buttons,2); Grid.SetColumnSpan(buttons,2); Grid.SetRow(buttons,2); g.Children.Add(buttons);

        card.Child=g; Grid.SetRow(card,0); Children.Add(card);

        var sumCard = new Border
        {
            Background=AppTheme.Brand100,
            CornerRadius=new CornerRadius(11), Padding=new Thickness(10,8,10,8),
            Margin=new Thickness(0,0,0,8),
            BorderBrush=AppTheme.Line300, BorderThickness=new Thickness(1)
        };
        var sp=new DockPanel { LastChildFill=true, FlowDirection=FlowDirection.RightToLeft };
        Summary.FontSize=13; Summary.FontWeight=FontWeights.SemiBold; Summary.Foreground=AppTheme.Ink900;
        Summary.Text="هیچ فاکتوری انتخاب نشده است"; Summary.TextWrapping=TextWrapping.Wrap; Summary.VerticalAlignment=VerticalAlignment.Center;
        sp.Children.Add(Summary);
        var btns=new StackPanel { Orientation=Orientation.Horizontal, HorizontalAlignment=HorizontalAlignment.Left, FlowDirection=FlowDirection.RightToLeft };
        DueOnlyBox.VerticalAlignment=VerticalAlignment.Center; DueOnlyBox.Margin=new Thickness(0,0,14,0); DueOnlyBox.Foreground=AppTheme.Ink700; DueOnlyBox.FontWeight=FontWeights.SemiBold;
        DueOnlyBox.Checked+=async(_,_)=>await Load(); DueOnlyBox.Unchecked+=async(_,_)=>await Load();
        btns.Children.Add(DueOnlyBox);
        var all=Btn("انتخاب همه",Brushes.White); all.Foreground=AppTheme.Brand700; all.Click+=(_,_)=>{foreach(var r in Rows)r.Selected=true;UpdateSummary();};
        var none=Btn("لغو انتخاب",Brushes.White); none.Foreground=AppTheme.Brand700; none.Click+=(_,_)=>{foreach(var r in Rows)r.Selected=false;UpdateSummary();};
        var splitPay=Btn("ثبت پرداخت مشترک برای انتخاب‌شده‌ها",AppTheme.Success600); splitPay.Foreground=Brushes.White; splitPay.Click+=RegisterSplitPayment;
        btns.Children.Add(all); btns.Children.Add(none); btns.Children.Add(splitPay); DockPanel.SetDock(btns,Dock.Left); sp.Children.Add(btns);
        sumCard.Child=sp; Grid.SetRow(sumCard,1); Children.Add(sumCard);

        G.FlowDirection=FlowDirection.RightToLeft; G.AutoGenerateColumns=false; G.CanUserAddRows=false; G.IsReadOnly=false;
        G.SelectionUnit=DataGridSelectionUnit.FullRow; G.RowHeight=40; G.ColumnHeaderHeight=38; G.FontSize=12.5;
        G.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; G.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        G.Columns.Add(new DataGridCheckBoxColumn{Header="انتخاب",Binding=new System.Windows.Data.Binding(nameof(Row.Selected)){Mode=System.Windows.Data.BindingMode.TwoWay,UpdateSourceTrigger=System.Windows.Data.UpdateSourceTrigger.PropertyChanged},Width=55});
        G.Columns.Add(new DataGridTextColumn{Header="شماره",Binding=new System.Windows.Data.Binding(nameof(Row.Number)),IsReadOnly=true,Width=85});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new System.Windows.Data.Binding("Company.Name"),IsReadOnly=true,Width=new DataGridLength(1.3,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="تاریخ",Binding=new System.Windows.Data.Binding(nameof(Row.InvoiceDatePersian)),IsReadOnly=true,Width=95});
        G.Columns.Add(new DataGridTextColumn{Header="سررسید",Binding=new System.Windows.Data.Binding(nameof(Row.DueDatePersian)),IsReadOnly=true,Width=95});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new System.Windows.Data.Binding(nameof(Row.Amount)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=95});
        G.Columns.Add(new DataGridTextColumn{Header="پرداختی",Binding=new System.Windows.Data.Binding(nameof(Row.Paid)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=95});
        G.Columns.Add(new DataGridTextColumn{Header="مانده",Binding=new System.Windows.Data.Binding(nameof(Row.Balance)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=95});
        G.Columns.Add(new DataGridTextColumn{Header="توضیحات",Binding=new System.Windows.Data.Binding(nameof(Row.Note)),IsReadOnly=true,Width=new DataGridLength(1.3,DataGridLengthUnitType.Star),MinWidth=90});
        CompanyBox.SelectionChanged+=async(_,_)=>{if(!loading&&!suppressCompanyChange)await Load();};
        G.SelectionChanged+=async(_,_)=>{if(G.SelectedItem is Row r){Populate(r);SelectedInvoiceId=r.Id;await LoadPaymentsForSelected();}else{SelectedInvoiceId=null;await LoadPaymentsForSelected();}};
        G.CurrentCellChanged+=(_,_)=>Dispatcher.BeginInvoke(UpdateSummary);
        G.CellEditEnding+=(_,_)=>Dispatcher.BeginInvoke(UpdateSummary); G.MouseLeftButtonUp+=(_,_)=>Dispatcher.BeginInvoke(UpdateSummary);

        // Row 2 is split: invoices grid on the wider side, payments/check-collection panel
        // for the selected invoice on the other side - so collecting a payment or updating
        // a check never requires leaving the Invoices screen.
        var split = new Grid { FlowDirection = FlowDirection.RightToLeft };
        split.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2.2, GridUnitType.Star) });
        split.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        Grid.SetColumn(G,0); split.Children.Add(G);
        var payPanel = BuildPaymentsPanel();
        Grid.SetColumn(payPanel,1); split.Children.Add(payPanel);
        Grid.SetRow(split,2); Children.Add(split);
    }

    Border BuildPaymentsPanel()
    {
        var card = new Border
        {
            Background = Brushes.White,
            BorderBrush = AppTheme.Line200,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(14),
            Padding = new Thickness(14),
            Margin = new Thickness(10,0,0,0),
            Effect = AppTheme.CardShadow
        };

        // Everything (header, form, buttons, history) lives in one scrollable stack instead
        // of a fixed set of Auto/Star grid rows. That earlier approach silently compressed
        // and clipped content - most visibly the submit button, since it sat at the very
        // bottom of the form - whenever the panel didn't have enough vertical room. A
        // ScrollViewer guarantees every control stays reachable no matter the window size.
        var outer = new StackPanel();

        var header = new StackPanel { Margin = new Thickness(0,0,0,10) };
        header.Children.Add(new TextBlock { Text="پرداخت‌ها و وصول چک", FontSize=16, FontWeight=FontWeights.Bold, Foreground=AppTheme.Brand900 });
        PaySubtitle.Text = "یک فاکتور را از جدول کنار انتخاب کنید"; PaySubtitle.Foreground=AppTheme.Ink500; PaySubtitle.FontSize=12; PaySubtitle.Margin=new Thickness(0,3,0,0); PaySubtitle.TextWrapping=TextWrapping.Wrap;
        header.Children.Add(PaySubtitle);
        outer.Children.Add(header);

        var form = new StackPanel();
        PayDateBox.SelectedDate=DateTime.Today; PayMethodBox.ItemsSource=new[]{"نقد","کارت‌به‌کارت","چک","ترکیبی"}; PayMethodBox.SelectedIndex=0; PayMethodBox.SelectionChanged+=(_,_)=>UpdateCheckFieldsEnabled();
        PayCheckStatusBox.ItemsSource=new[]{"در انتظار وصول","وصول‌شده","برگشتی","لغوشده"}; PayCheckStatusBox.SelectedIndex=0;
        PayCheckNumberBox.ToolTip="اختیاری؛ می‌توانید شماره چک را بعداً تکمیل کنید.";
        AddStackedField(form,"تاریخ وصول",PayDateBox);
        AddStackedField(form,"مبلغ وصول (ریال)",PayAmount);
        PayFullSettleBox.Foreground=AppTheme.Ink700; PayFullSettleBox.Margin=new Thickness(0,-4,0,10); PayFullSettleBox.FontSize=12.5;
        PayFullSettleBox.Checked+=(_,_)=>ApplyFullSettleAmount(); PayFullSettleBox.Unchecked+=(_,_)=>{ PayAmount.IsReadOnly=false; };
        form.Children.Add(PayFullSettleBox);
        AddStackedField(form,"روش وصول",PayMethodBox);
        AddStackedField(form,"شماره چک (اختیاری)",PayCheckNumberBox);
        AddStackedField(form,"تاریخ چک (اختیاری)",PayCheckDateBox);
        AddStackedField(form,"وضعیت چک",PayCheckStatusBox);
        AddStackedField(form,"توضیحات",PayNoteBox);

        var payButtons = new StackPanel { Orientation=Orientation.Horizontal, Margin=new Thickness(0,4,0,10) };
        PayAddButton = Btn("＋ ثبت وصول",AppTheme.Success600); PayAddButton.Foreground=Brushes.White; PayAddButton.Click+=SubmitPayment;
        PayDeleteButton = Btn("حذف وصول انتخاب‌شده",AppTheme.Danger100); PayDeleteButton.Foreground=AppTheme.Danger600; PayDeleteButton.Click+=DeletePayment;
        PayCancelEditButton = Btn("انصراف از ویرایش",AppTheme.Surface100); PayCancelEditButton.Foreground=AppTheme.Ink700; PayCancelEditButton.Click+=(_,_)=>CancelPaymentEdit(); PayCancelEditButton.Visibility=Visibility.Collapsed;
        payButtons.Children.Add(PayAddButton); payButtons.Children.Add(PayDeleteButton); payButtons.Children.Add(PayCancelEditButton);
        form.Children.Add(payButtons);
        outer.Children.Add(form);

        var historyLabel = new TextBlock { Text="سوابق وصول این فاکتور (برای ویرایش، یک ردیف را انتخاب کنید)", FontWeight=FontWeights.SemiBold, FontSize=13, Foreground=AppTheme.Ink700, Margin=new Thickness(0,0,0,6), TextWrapping=TextWrapping.Wrap };
        outer.Children.Add(historyLabel);

        PayGrid.FlowDirection=FlowDirection.RightToLeft; PayGrid.AutoGenerateColumns=false; PayGrid.IsReadOnly=true; PayGrid.CanUserAddRows=false;
        PayGrid.SelectionMode=DataGridSelectionMode.Single; PayGrid.RowHeight=36; PayGrid.ColumnHeaderHeight=34; PayGrid.FontSize=12;
        PayGrid.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; PayGrid.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        PayGrid.MinHeight=180; PayGrid.MaxHeight=340;
        PayGrid.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new System.Windows.Data.Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=90});
        PayGrid.Columns.Add(new DataGridTextColumn{Header="تاریخ",Binding=new System.Windows.Data.Binding("PayDate"),Width=90});
        PayGrid.Columns.Add(new DataGridTextColumn{Header="روش",Binding=new System.Windows.Data.Binding("PaymentMethod"),Width=90});
        PayGrid.Columns.Add(new DataGridTextColumn{Header="وضعیت چک",Binding=new System.Windows.Data.Binding("CheckStatus"),Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=100});
        PayGrid.SelectionChanged += (_,_) => { if (PayGrid.SelectedItem is PaymentRow pr) PopulateForEdit(pr); };
        outer.Children.Add(PayGrid);

        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Content = outer };
        card.Child = scroll;
        UpdateCheckFieldsEnabled();
        SetPaymentsPanelEnabled(false);
        return card;
    }

    static void AddStackedField(StackPanel panel, string label, Control control)
    {
        var p = new StackPanel { Margin = new Thickness(0,0,0,8) };
        p.Children.Add(new TextBlock { Text=label, FontWeight=FontWeights.SemiBold, FontSize=12.5, Foreground=AppTheme.Ink700, Margin=new Thickness(0,0,0,3) });
        control.Height = 34;
        p.Children.Add(control);
        panel.Children.Add(p);
    }

    void UpdateCheckFieldsEnabled()
    {
        var isCheck = string.Equals(PayMethodBox.SelectedItem?.ToString(), "چک", StringComparison.Ordinal);
        PayCheckNumberBox.IsEnabled = isCheck; PayCheckDateBox.IsEnabled = isCheck; PayCheckStatusBox.IsEnabled = isCheck;
        if (!isCheck) { PayCheckNumberBox.Clear(); PayCheckDateBox.SelectedDate=null; PayCheckStatusBox.SelectedIndex=0; }
    }

    void SetPaymentsPanelEnabled(bool enabled)
    {
        // Adding a NEW payment only makes sense while there's a remaining balance, so these
        // stay gated by "enabled" (which callers pass as balance > 0). Deleting an EXISTING
        // payment must stay possible even on a fully-settled invoice - that's exactly how a
        // mistaken entry that caused it to look settled would get corrected - so it's gated
        // separately, by whether an invoice is selected at all, not by its balance.
        PayAmount.IsEnabled=enabled; PayMethodBox.IsEnabled=enabled; PayNoteBox.IsEnabled=enabled; PayAddButton.IsEnabled=enabled; PayFullSettleBox.IsEnabled=enabled;
        PayDeleteButton.IsEnabled = SelectedInvoiceId.HasValue;
        if (enabled) UpdateCheckFieldsEnabled();
        else { PayCheckNumberBox.IsEnabled=false; PayCheckDateBox.IsEnabled=false; PayCheckStatusBox.IsEnabled=false; }
    }

    // With the checkbox ticked, the amount field always fills with the invoice's remaining
    // balance - if a payment is currently being edited, its own old amount is added back in
    // first, since that amount is being freed up for reassignment as part of the edit.
    void ApplyFullSettleAmount()
    {
        if (SelectedInvoiceId is not int id) { PayFullSettleBox.IsChecked=false; return; }
        var row = Rows.FirstOrDefault(x => x.Id == id);
        if (row is null) { PayFullSettleBox.IsChecked=false; return; }
        var available = row.Balance + (EditingPaymentId.HasValue ? EditingOriginalAmount ?? 0 : 0);
        PayAmount.Text = available.ToString("0.##");
        PayAmount.IsReadOnly = true;
    }

    void PopulateForEdit(PaymentRow pr)
    {
        EditingPaymentId = pr.Payment.Id;
        EditingOriginalAmount = pr.Payment.Amount;
        PayFullSettleBox.IsChecked = false; PayAmount.IsReadOnly = false;
        PayDateBox.SelectedDate = pr.Payment.PayDate;
        PayAmount.Text = pr.Payment.Amount.ToString("0.##");
        PayMethodBox.SelectedItem = pr.Payment.PaymentMethod;
        PayCheckNumberBox.Text = pr.Payment.CheckNumber ?? "";
        PayCheckDateBox.SelectedDate = pr.Payment.CheckDate;
        PayCheckStatusBox.SelectedItem = pr.Payment.CheckStatus;
        PayNoteBox.Text = pr.Payment.Note ?? "";
        PayAddButton.Content = "ذخیره ویرایش وصول";
        PayAddButton.Background = AppTheme.Brand600;
        PayCancelEditButton.Visibility = Visibility.Visible;
    }

    void CancelPaymentEdit()
    {
        EditingPaymentId = null; EditingOriginalAmount = null;
        PayAmount.Clear(); PayDateBox.SelectedDate=DateTime.Today; PayCheckNumberBox.Clear(); PayCheckDateBox.SelectedDate=null; PayNoteBox.Clear(); PayMethodBox.SelectedIndex=0;
        PayFullSettleBox.IsChecked = false; PayAmount.IsReadOnly = false;
        PayAddButton.Content = "＋ ثبت وصول";
        PayAddButton.Background = AppTheme.Success600;
        PayCancelEditButton.Visibility = Visibility.Collapsed;
        PayGrid.SelectedItem = null;
    }

    int _paymentsRequestToken;

    async Task LoadPaymentsForSelected()
    {
        var myToken = ++_paymentsRequestToken;
        PayAmount.Clear(); PayDateBox.SelectedDate=DateTime.Today; PayCheckNumberBox.Clear(); PayCheckDateBox.SelectedDate=null; PayNoteBox.Clear(); PayMethodBox.SelectedIndex=0;
        EditingPaymentId=null; EditingOriginalAmount=null; PayFullSettleBox.IsChecked=false; PayAmount.IsReadOnly=false;
        PayAddButton.Content="＋ ثبت وصول"; PayAddButton.Background=AppTheme.Success600; PayCancelEditButton.Visibility=Visibility.Collapsed;
        if (SelectedInvoiceId is not int id)
        {
            if (myToken != _paymentsRequestToken) return; // a newer selection has already started
            PaySubtitle.Text = "یک فاکتور را از جدول کنار انتخاب کنید";
            PayGrid.ItemsSource = null;
            SetPaymentsPanelEnabled(false);
            return;
        }
        var row = Rows.FirstOrDefault(x => x.Id == id);
        var balance = row?.Balance ?? 0;
        var payments = await S.GetPaymentsForInvoiceAsync(id);
        // If the user selected a different invoice while this fetch was in flight, this
        // result is stale - applying it now would show the wrong invoice's payment history.
        if (myToken != _paymentsRequestToken) return;
        PaySubtitle.Text = row is null ? "" : (balance > 0
            ? $"فاکتور {row.Number} — مانده قابل وصول: {balance:N0} ریال"
            : $"فاکتور {row.Number} — تسویه شده است");
        SetPaymentsPanelEnabled(balance > 0);
        PayGrid.ItemsSource = payments.Select(p => new PaymentRow(p)).ToList();
    }

    async void SubmitPayment(object? sender, RoutedEventArgs e)
    {
        if (SelectedInvoiceId is not int id) { MessageBox.Show("یک فاکتور را انتخاب کنید."); return; }
        if (!decimal.TryParse(PayAmount.Text.Replace(",","").Replace("٬","").Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var amount) || amount <= 0)
        {
            MessageBox.Show("مبلغ وصول را به‌درستی وارد کنید.");
            return;
        }
        var method = PayMethodBox.SelectedItem?.ToString() ?? "نقد";
        var editingId = EditingPaymentId;
        try
        {
            if (editingId is int payId)
            {
                await S.UpdatePaymentAsync(new Payment
                {
                    Id = payId,
                    Amount = amount,
                    PayDate = PayDateBox.SelectedDate ?? DateTime.Today,
                    PaymentMethod = method,
                    CheckNumber = method=="چک" ? NullIfWhite(PayCheckNumberBox.Text) : null,
                    CheckDate = method=="چک" ? PayCheckDateBox.SelectedDate?.Date : null,
                    CheckStatus = method=="چک" ? PayCheckStatusBox.SelectedItem?.ToString() : null,
                    Note = NullIfWhite(PayNoteBox.Text)
                });
                await ReloadKeepingSelection(id);
                MessageBox.Show("وصول با موفقیت ویرایش شد.", "ویرایش وصول", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                await S.AddPaymentAsync(new Payment
                {
                    InvoiceId = id,
                    Amount = amount,
                    PayDate = PayDateBox.SelectedDate ?? DateTime.Today,
                    PaymentMethod = method,
                    CheckNumber = method=="چک" ? NullIfWhite(PayCheckNumberBox.Text) : null,
                    CheckDate = method=="چک" ? PayCheckDateBox.SelectedDate?.Date : null,
                    CheckStatus = method=="چک" ? PayCheckStatusBox.SelectedItem?.ToString() : null,
                    Note = NullIfWhite(PayNoteBox.Text)
                });
                await ReloadKeepingSelection(id);
                MessageBox.Show("وصول با موفقیت ثبت و ذخیره شد.", "ثبت وصول", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, editingId.HasValue ? "ویرایش وصول" : "ثبت وصول", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    async void DeletePayment(object? sender, RoutedEventArgs e)
    {
        if (PayGrid.SelectedItem is not PaymentRow row) { MessageBox.Show("یک وصول را از جدول سوابق انتخاب کنید."); return; }
        if (MessageBox.Show($"وصول {row.Amount:N0} حذف شود؟","تأیید حذف",MessageBoxButton.YesNo,MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        try
        {
            var invoiceId = SelectedInvoiceId;
            await S.DeletePaymentAsync(row.Id);
            if (invoiceId is int id) await ReloadKeepingSelection(id);
            MessageBox.Show("وصول با موفقیت حذف شد.", "حذف وصول", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message,"حذف وصول",MessageBoxButton.OK,MessageBoxImage.Warning); }
    }

    // Reloads the invoices grid (so Paid/Balance reflect the new payment) while keeping the
    // same invoice selected and its payments panel refreshed.
    async Task ReloadKeepingSelection(int invoiceId)
    {
        await Load();
        var row = Rows.FirstOrDefault(x => x.Id == invoiceId);
        if (row != null) { G.SelectedItem = row; Populate(row); }
        SelectedInvoiceId = invoiceId;
        await LoadPaymentsForSelected();
    }

    static string? NullIfWhite(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    static Button Btn(string text,Brush bg){return new Button{Content=text,Background=bg,BorderThickness=new Thickness(0),Padding=new Thickness(13,8,13,8),Margin=new Thickness(4),FontWeight=FontWeights.SemiBold,Cursor=System.Windows.Input.Cursors.Hand};}
    static void AddField(Grid g,string label,TextBox box,int c,int r){var p=new StackPanel{Margin=new Thickness(5,0,5,8),MinWidth=90};p.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink700});box.Height=40;box.Margin=new Thickness(0,4,0,0);p.Children.Add(box);Grid.SetColumn(p,c);Grid.SetRow(p,r);g.Children.Add(p);}
    static void AddCombo(Grid g,string label,ComboBox box,int c,int r){var p=new StackPanel{Margin=new Thickness(5,0,5,8),MinWidth=90};p.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink700});box.Height=40;box.Margin=new Thickness(0,4,0,0);p.Children.Add(box);Grid.SetColumn(p,c);Grid.SetRow(p,r);g.Children.Add(p);}
    async Task InitCompanies(){loading=true;var list=await S.GetCompaniesAsync();var all=new List<Company>{new Company{Id=0,Name="همه شرکت‌ها"}};all.AddRange(list);CompanyBox.ItemsSource=all;CompanyBox.DisplayMemberPath="Name";CompanyBox.SelectedValuePath="Id";CompanyBox.SelectedValue=InitialCompanyId??0;DateBox.Text=PersianDateService.ToPersian(DateTime.Today);DueBox.Text=PersianDateService.ToPersian(DateTime.Today.AddDays(30));loading=false;}
    int? FilterCompanyId=>CompanyBox.SelectedValue is int id&&id>0?id:null;
    void Populate(Row r){suppressCompanyChange=true;NumberBox.Text=r.Number;CompanyBox.SelectedValue=r.Company?.Id??0;suppressCompanyChange=false;DateBox.Text=r.InvoiceDatePersian;DueBox.Text=r.DueDatePersian;AmountBox.Text=r.Amount.ToString("0.##");NoteBox.Text=r.Note??"";}
    async Task Load(){Rows.Clear();var list=await S.GetInvoicesAsync(FilterCompanyId);if(DueOnlyBox.IsChecked==true)list=list.Where(x=>AccountingService.Balance(x)>0).OrderBy(x=>x.DueDate).ToList();foreach(var x in list){var row=new Row(x);row.PropertyChanged+=(s,e)=>{if(e.PropertyName==nameof(Row.Selected))Dispatcher.BeginInvoke(UpdateSummary);};Rows.Add(row);}G.ItemsSource=Rows;UpdateSummary();}
    void UpdateSummary(){
        var selected=Rows.Where(x=>x.Selected).ToList();
        if(selected.Count==0){Summary.Text="هیچ فاکتوری انتخاب نشده است";return;}
        var summary=HesabGara.Domain.FinanceRules.Summarize(selected.Select(x=>(x.Amount,x.Paid,x.DueDateValue)));
        var weighted=summary.WeightedDate.HasValue ? PersianDateService.ToPersian(summary.WeightedDate.Value) : "—";
        var days=summary.WeightedDate.HasValue ? $"{summary.WeightedDays:N1} روز" : "—";
        Summary.Text=$"انتخاب: {selected.Count:N0} فاکتور   |   جمع: {summary.Total:N0} ریال   |   پرداختی: {summary.Paid:N0} ریال   |   مانده: {summary.Balance:N0} ریال   |   سررسید وزنی: {weighted} ({days})";
    }
    async void AddInvoice(object? s,RoutedEventArgs e){try{if(CompanyBox.SelectedValue is not int cid||cid<=0)throw new ArgumentException("شرکت را انتخاب کنید.");var inv=new Invoice{CompanyId=cid,Number=NumberBox.Text.Trim(),InvoiceDate=ParseDate(DateBox.Text),DueDate=ParseDate(DueBox.Text),Amount=decimal.Parse(AmountBox.Text.Replace(",","")),Note=NoteBox.Text};if(G.SelectedItem is Row r)inv.Id=r.Id; if(inv.Id>0)await S.UpdateInvoiceAsync(inv);else await S.AddInvoiceAsync(inv);ClearForm();await Load();}catch(Exception ex){MessageBox.Show(ex.Message,"ثبت فاکتور",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    static DateTime ParseDate(string text){if(PersianDateService.TryParse(text,out var d))return d;throw new ArgumentException("تاریخ را به صورت ۱۴۰۵/۰۵/۲۳ وارد کنید.");}
    async void DeleteInvoice(object? s,RoutedEventArgs e){if(G.SelectedItem is not Row r){MessageBox.Show("یک فاکتور را انتخاب کنید.");return;}if(MessageBox.Show($"فاکتور «{r.Number}» حذف شود؟","تأیید حذف",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;try{await S.DeleteInvoiceAsync(r.Id);ClearForm();SelectedInvoiceId=null;await Load();await LoadPaymentsForSelected();}catch(Exception ex){MessageBox.Show(ex.Message,"حذف فاکتور",MessageBoxButton.OK,MessageBoxImage.Warning);}}

    // برای حالتی که یک چک/پرداخت واحد، مجموع چند فاکتور را پوشش می‌دهد: فاکتورهای انتخاب‌شده
    // (تیک‌خورده در ستون «انتخاب») را می‌گیرد، یک فرم پرداخت مشترک نشان می‌دهد و مبلغ کل را
    // بین آن‌ها (نزدیک‌ترین سررسید اول) تقسیم می‌کند.
    async void RegisterSplitPayment(object? sender, RoutedEventArgs e)
    {
        var selected = Rows.Where(x=>x.Selected).ToList();
        if (selected.Count < 2) { MessageBox.Show("برای پرداخت مشترک، حداقل دو فاکتور را از ستون «انتخاب» تیک بزنید."); return; }
        var totalBalance = selected.Sum(x=>x.Balance);
        if (totalBalance <= 0) { MessageBox.Show("فاکتورهای انتخاب‌شده مانده‌ی قابل‌وصولی ندارند."); return; }

        var listText = new TextBlock { TextWrapping = TextWrapping.Wrap, Foreground = AppTheme.Ink700, Margin = new Thickness(0,0,0,12),
            Text = "فاکتورهای انتخاب‌شده:\n" + string.Join("\n", selected.Select(x => $"• {x.Number} — مانده: {x.Balance:N0} ریال")) };
        var amountBox = new TextBox { Text = totalBalance.ToString("0.##"), Height = 36, Margin = new Thickness(0,4,0,10) };
        var methodBox = new ComboBox { ItemsSource = new[]{"نقد","کارت‌به‌کارت","چک","ترکیبی"}, SelectedIndex = 2, Height = 36, Margin = new Thickness(0,4,0,10) };
        var checkNumberBox = new TextBox { Height = 36, Margin = new Thickness(0,4,0,10) };
        var checkDateBox = new PersianDateBox { Height = 36, Margin = new Thickness(0,4,0,10) };
        var checkStatusBox = new ComboBox { ItemsSource = new[]{"در انتظار وصول","وصول‌شده","برگشتی","لغوشده"}, SelectedIndex = 0, Height = 36, Margin = new Thickness(0,4,0,10) };
        var noteBox = new TextBox { Height = 36, Margin = new Thickness(0,4,0,10) };

        var form = new StackPanel { Margin = new Thickness(18) };
        void AddRow(string label, FrameworkElement box) { form.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink700}); form.Children.Add(box); }
        form.Children.Add(listText);
        AddRow("مبلغ کل پرداخت (ریال)", amountBox);
        AddRow("روش پرداخت", methodBox);
        AddRow("شماره چک (اختیاری)", checkNumberBox);
        AddRow("تاریخ چک (اختیاری)", checkDateBox);
        AddRow("وضعیت چک", checkStatusBox);
        AddRow("توضیحات", noteBox);

        var saveBtn = Btn("ثبت پرداخت مشترک", AppTheme.Success600); saveBtn.Foreground = Brushes.White;
        var cancelBtn = Btn("انصراف", AppTheme.Surface100); cancelBtn.Foreground = AppTheme.Ink700;
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0,8,0,0) };
        buttons.Children.Add(saveBtn); buttons.Children.Add(cancelBtn);
        form.Children.Add(buttons);

        var win = new Window
        {
            Title = "ثبت پرداخت مشترک", Content = new ScrollViewer{Content=form,VerticalScrollBarVisibility=ScrollBarVisibility.Auto}, Width = 400, Height = 620,
            FlowDirection = FlowDirection.RightToLeft, WindowStartupLocation = WindowStartupLocation.CenterOwner, Owner = Window.GetWindow(this),
            Background = AppTheme.Surface100
        };
        cancelBtn.Click += (_,_) => win.Close();
        saveBtn.Click += async (_,_) =>
        {
            if (!decimal.TryParse(amountBox.Text.Replace(",","").Replace("٬","").Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var amount) || amount <= 0)
            { MessageBox.Show("مبلغ کل را به‌درستی وارد کنید."); return; }
            var method = methodBox.SelectedItem?.ToString() ?? "چک";
            try
            {
                var result = await S.AddSplitPaymentAsync(
                    selected.Select(x=>x.Id).ToList(), amount, DateTime.Today, method,
                    method=="چک" ? checkNumberBox.Text : null,
                    method=="چک" ? checkDateBox.SelectedDate : null,
                    method=="چک" ? checkStatusBox.SelectedItem?.ToString() : null,
                    noteBox.Text);
                win.Close();
                await Load(); await LoadPaymentsForSelected();
                var detail = string.Join("\n", result.Allocations.Select(a => $"• {a.InvoiceNumber}: {a.Amount:N0} ریال"));
                MessageBox.Show($"پرداخت مشترک با موفقیت ثبت شد و بین {result.Allocations.Count:N0} فاکتور تقسیم شد:\n\n{detail}", "پرداخت مشترک", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message,"پرداخت مشترک",MessageBoxButton.OK,MessageBoxImage.Warning); }
        };
        win.ShowDialog();
    }
    void ClearForm(){NumberBox.Clear();AmountBox.Clear();NoteBox.Clear();DateBox.Text=PersianDateService.ToPersian(DateTime.Today);DueBox.Text=PersianDateService.ToPersian(DateTime.Today.AddDays(30));G.UnselectAll();}


    sealed class PaymentRow
    {
        public Payment Payment { get; }
        public int Id => Payment.Id;
        public decimal Amount => Payment.Amount;
        public string PayDate => PersianDateService.ToPersian(Payment.PayDate);
        public string PaymentMethod => Payment.PaymentMethod;
        public string CheckStatus => Payment.PaymentMethod=="چک" ? (Payment.CheckStatus ?? "—") : "—";
        public PaymentRow(Payment payment) => Payment = payment;
    }
}
