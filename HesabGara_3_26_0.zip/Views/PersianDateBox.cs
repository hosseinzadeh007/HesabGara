using System.Windows.Controls;
using HesabGara.Services;

namespace HesabGara.Views;

/// <summary>
/// کادر ورود تاریخ شمسی (جایگزین DatePicker که تقویم میلادی نشان می‌دهد).
/// SelectedDate مثل DatePicker یک DateTime? میلادی است تا ذخیره در دیتابیس تغییری نکند؛
/// اگر متن نامعتبر باشد خطای قابل نمایش می‌دهد.
/// </summary>
public class PersianDateBox : TextBox
{
    public const string Example = "1405/06/25";

    public PersianDateBox()
    {
        ToolTip = "تاریخ شمسی، مثال: " + Example;
        MaxLength = 10;
    }

    public DateTime? SelectedDate
    {
        get
        {
            var text = Text?.Trim();
            if (string.IsNullOrEmpty(text)) return null;
            if (PersianDateService.TryParse(text, out var date)) return date.Date;
            throw new ArgumentException("تاریخ را به صورت شمسی وارد کنید. نمونه: " + Example);
        }
        set => Text = value.HasValue ? PersianDateService.ToPersian(value.Value) : "";
    }
}
