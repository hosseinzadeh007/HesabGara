﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using Microsoft.Win32;
using ClosedXML.Excel;
using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;

namespace HesabGara.Views;

// Reports module: three reports sharing one filter bar (company / date range / search):
// company-wide combined report, invoice grouping, and issued checks (filtered by check due date).
public class ReportsView : Grid
{
    readonly AccountingService S; readonly int? InitialCompanyId;
    readonly DataGrid G=new(); readonly TextBlock Summary=new(); readonly TextBlock TitleText=new();
    readonly ComboBox CompanyBox=new(), StatusBox=new(), PresetBox=new();
    readonly TextBox FromDateBox=new(), ToDateBox=new(), SearchBox=new();
    readonly Button TabCombined, TabGrouping, TabChecks;
    readonly TextBlock ReportInfo=new();
    StackPanel? FromField, ToField, StatusField, SearchField;
    bool _ready, _suppress; // فیلترها بعد از اولین بارگذاری بلافاصله اعمال می‌شوند
    // گروه‌بندی فاکتورها
    readonly TextBox GroupNameBox=new(); readonly TextBlock SelectionSummary=new(), GroupTotalsText=new(), GroupDetailText=new();
    Button? AddGroupBtn;
    readonly CheckBox HideGroupedBox=new(){Content="فاکتورهای گروه‌بندی‌شده نمایش داده نشوند",IsChecked=true,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,8,0)};
    // داده‌ی آخرین گزارش برای چاپ
    List<Payment> _checkList=new(); List<Invoice> _cInv=new(); List<Payment> _cPay=new(), _cChk=new();
    readonly ScrollViewer CombinedScroll=new(); readonly DataGrid CInvoices=new(), CPayments=new(), CChecks=new();
    readonly TextBlock CInvoicesHeader=new(), CPaymentsHeader=new(), CChecksHeader=new();
    readonly Grid GroupingPanel=new(); readonly DataGrid GroupPickerGrid=new(), GroupResultsGrid=new();
    readonly ObservableCollection<GroupRow> GroupPickerRows=new();
    readonly List<InvoiceGroupResult> Groups=new();
    ReportTab _tab = ReportTab.Combined;
    enum ReportTab { Combined, Grouping, Checks }
    const string AllStatuses = "همه وضعیت‌ها";
    static readonly string[] CheckStatusItems = new[]{AllStatuses}.Concat(PaymentRules.CheckStatuses).ToArray();

    public ReportsView(AccountingService s,int? c)
    {
        S=s; InitialCompanyId=c; Margin=new Thickness(18); Background=AppTheme.Surface100;
        TabCombined=TabButton("گزارش جامع شرکت"); TabGrouping=TabButton("گروه‌بندی فاکتورها"); TabChecks=TabButton("چک‌های در جریان");
        TabCombined.Click+=async(_,_)=>{_tab=ReportTab.Combined;UpdateTabs();await Load();};
        TabGrouping.Click+=async(_,_)=>{_tab=ReportTab.Grouping;UpdateTabs();await Load();};
        TabChecks.Click+=async(_,_)=>{_tab=ReportTab.Checks;UpdateTabs();await Load();};
        Build();
    }
    public static async Task<ReportsView>Create(AccountingService s,int? c){var v=new ReportsView(s,c);await v.LoadCompanies();await v.Load();v._ready=true;return v;}

    void Build()
    {
        FlowDirection=FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});   // header + tabs
        RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});   // filter bar
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(58)}); // summary
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)}); // grid

        // --- Header + tabs ---
        var headerCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(14),Effect=AppTheme.CardShadow};
        var headerStack=new StackPanel();
        TitleText.Text="گزارش‌ها"; TitleText.FontSize=17; TitleText.FontWeight=FontWeights.Bold; TitleText.Foreground=AppTheme.Brand900;
        headerStack.Children.Add(TitleText);
        var tabsRow=new StackPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(0,10,0,0)};
        tabsRow.Children.Add(TabCombined); tabsRow.Children.Add(TabGrouping); tabsRow.Children.Add(TabChecks);
        headerStack.Children.Add(tabsRow);
        ReportInfo.Margin=new Thickness(2,10,2,0); ReportInfo.FontSize=12; ReportInfo.Foreground=AppTheme.Ink500; ReportInfo.TextWrapping=TextWrapping.Wrap;
        headerStack.Children.Add(ReportInfo);
        headerCard.Child=headerStack; Grid.SetRow(headerCard,0); Children.Add(headerCard);
        UpdateTabs();

        // --- Filter bar ---
        var filterCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(14),Margin=new Thickness(0,8,0,0),Effect=AppTheme.CardShadow};
        var filters=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft};

        filters.Children.Add(LabeledField("شرکت", CompanyBox, 210));
        CompanyBox.Height=38;
        CompanyBox.SelectionChanged+=async(_,_)=>{ if(_ready&&!_suppress) await Load(); };

        SearchField=LabeledField("جستجو (شماره چک/فاکتور/شرکت)", SearchBox, 200);
        SearchBox.ToolTip="با Enter جستجو می‌شود";
        SearchBox.KeyUp+=async(_,e)=>{ if(e.Key==System.Windows.Input.Key.Enter) await Load(); };
        filters.Children.Add(SearchField);

        PresetBox.ItemsSource=new[]{"همه","امروز","۷ روز اخیر","این ماه (شمسی)","سه‌ماه اخیر","امسال (شمسی)","۷ روز آینده","۳۰ روز آینده","بازه‌ی دلخواه"};
        PresetBox.SelectedIndex=0;
        PresetBox.SelectionChanged+=async(_,_)=>{ ApplyPreset(); if(_ready&&!_suppress&&(PresetBox.SelectedItem as string)!="بازه‌ی دلخواه") await Load(); };
        filters.Children.Add(LabeledField("بازه‌ی زمانی", PresetBox, 160));

        FromDateBox.ToolTip="مثال: 1405/01/01"; ToDateBox.ToolTip="مثال: 1405/06/25";
        FromDateBox.KeyUp+=async(_,e)=>{ if(e.Key==System.Windows.Input.Key.Enter) await Load(); };
        ToDateBox.KeyUp+=async(_,e)=>{ if(e.Key==System.Windows.Input.Key.Enter) await Load(); };
        FromField=LabeledField("از تاریخ", FromDateBox, 120); ToField=LabeledField("تا تاریخ", ToDateBox, 120);
        filters.Children.Add(FromField); filters.Children.Add(ToField);

        StatusBox.SelectionChanged+=async(_,_)=>{ if(_ready&&!_suppress&&StatusBox.SelectedItem!=null) await Load(); };
        StatusField=LabeledField("وضعیت چک", StatusBox, 150);
        filters.Children.Add(StatusField);

        var showBtn=Btn("نمایش گزارش",AppTheme.Success600); showBtn.Foreground=Brushes.White; showBtn.VerticalAlignment=VerticalAlignment.Bottom; showBtn.Margin=new Thickness(4,0,4,4);
        showBtn.Click+=async(_,_)=>await Load();
        filters.Children.Add(showBtn);

        var expBtn=Btn("خروجی Excel",AppTheme.Brand600); expBtn.Foreground=Brushes.White; expBtn.VerticalAlignment=VerticalAlignment.Bottom; expBtn.Margin=new Thickness(4,0,4,4);
        expBtn.Click+=Export;
        filters.Children.Add(expBtn);

        var printBtn=Btn("چاپ",AppTheme.Brand700); printBtn.Foreground=Brushes.White; printBtn.VerticalAlignment=VerticalAlignment.Bottom; printBtn.Margin=new Thickness(4,0,4,4);
        printBtn.Click+=Print;
        filters.Children.Add(printBtn);

        filterCard.Child=filters; Grid.SetRow(filterCard,1); Children.Add(filterCard);
        UpdateTabs();

        // --- Summary ---
        var sumCard=new Border{Background=AppTheme.Brand100,CornerRadius=new CornerRadius(11),Padding=new Thickness(12),Margin=new Thickness(0,8,0,8)};
        Summary.FontSize=12.5; Summary.FontWeight=FontWeights.SemiBold; Summary.Foreground=AppTheme.Ink900;
        Summary.TextWrapping=TextWrapping.Wrap; Summary.VerticalAlignment=VerticalAlignment.Center;
        sumCard.Child=Summary; Grid.SetRow(sumCard,2); Children.Add(sumCard);

        // --- Grid (tabs 1-4) ---
        G.FlowDirection=FlowDirection.RightToLeft; G.AutoGenerateColumns=false; G.IsReadOnly=true; G.CanUserAddRows=false;
        G.SelectionMode=DataGridSelectionMode.Single; G.SelectionUnit=DataGridSelectionUnit.FullRow;
        G.RowHeight=40; G.ColumnHeaderHeight=38; G.FontSize=12.5; G.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; G.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        G.LoadingRow += G_LoadingRow;

        Grid.SetRow(G,3); Children.Add(G);

        // --- Combined report (tab 5): سه بخش پشت سر هم در یک قاب، بدون نیاز به جابه‌جایی تب ---
        var combinedStack=new StackPanel();
        combinedStack.Children.Add(BuildCombinedSection(CInvoicesHeader,"فاکتورهای خریداری‌شده", CInvoices,
            "شماره","شرکت","تاریخ فاکتور","سررسید","مبلغ","پرداختی","مانده","وضعیت"));
        combinedStack.Children.Add(BuildCombinedSection(CPaymentsHeader,"پرداخت‌ها", CPayments,
            "تاریخ وصول","فاکتور","مبلغ","روش","شماره چک","وضعیت چک"));
        combinedStack.Children.Add(BuildCombinedSection(CChecksHeader,"چک‌های داده‌شده (بر اساس سررسید چک)", CChecks,
            "تاریخ چک","شماره چک","فاکتور","مبلغ","وضعیت چک"));
        CombinedScroll.Content=combinedStack; CombinedScroll.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        CombinedScroll.Visibility=Visibility.Collapsed;
        Grid.SetRow(CombinedScroll,3); Children.Add(CombinedScroll);

        // --- گروه‌بندی فاکتورها: دو ستون کنار هم با جداکننده‌ی قابل‌کشیدن.
        // راست: ۱) انتخاب فاکتورها (جمع زنده + نام گروه + «افزودن»)   چپ: ۲) گروه‌های ساخته‌شده (جزئیات + جمع کل).
        // گروه‌ها فقط در همین جلسه‌ی مشاهده می‌مانند.
        GroupingPanel.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1.6,GridUnitType.Star),MinWidth=380});
        GroupingPanel.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});
        GroupingPanel.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star),MinWidth=300});
        GroupingPanel.Visibility=Visibility.Collapsed;

        // ---- ستون ۱: انتخاب فاکتورها ----
        var pickCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(12),Padding=new Thickness(12),Margin=new Thickness(0,0,0,0),Effect=AppTheme.CardShadow};
        var pickLayout=new Grid();
        pickLayout.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        pickLayout.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});
        pickLayout.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});

        var pickHeader=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft,Margin=new Thickness(0,0,0,8)};
        pickHeader.Children.Add(new TextBlock{Text="۱) فاکتورها را انتخاب کنید",FontWeight=FontWeights.Bold,FontSize=14,Foreground=AppTheme.Brand900,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,12,0)});
        var selAllBtn=Btn("انتخاب همه",AppTheme.Surface100); selAllBtn.Foreground=AppTheme.Ink700;
        selAllBtn.Click+=(_,_)=>{ foreach (var r in GroupPickerRows) r.Selected=true; };
        var selNoneBtn=Btn("هیچ‌کدام",AppTheme.Surface100); selNoneBtn.Foreground=AppTheme.Ink700;
        selNoneBtn.Click+=(_,_)=>{ foreach (var r in GroupPickerRows) r.Selected=false; };
        HideGroupedBox.Content="مخفی‌کردن فاکتورهای گروه‌بندی‌شده";
        HideGroupedBox.Checked+=async(_,_)=>{ if(_ready) await Load(); }; HideGroupedBox.Unchecked+=async(_,_)=>{ if(_ready) await Load(); };
        pickHeader.Children.Add(selAllBtn); pickHeader.Children.Add(selNoneBtn); pickHeader.Children.Add(HideGroupedBox);
        Grid.SetRow(pickHeader,0); pickLayout.Children.Add(pickHeader);

        GroupPickerGrid.FlowDirection=FlowDirection.RightToLeft; GroupPickerGrid.AutoGenerateColumns=false; GroupPickerGrid.CanUserAddRows=false;
        GroupPickerGrid.SelectionMode=DataGridSelectionMode.Single; GroupPickerGrid.SelectionUnit=DataGridSelectionUnit.FullRow;
        GroupPickerGrid.RowHeight=36; GroupPickerGrid.ColumnHeaderHeight=34; GroupPickerGrid.FontSize=12;
        GroupPickerGrid.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; GroupPickerGrid.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        // کادر انتخاب با «یک» کلیک تغییر می‌کند (ستون چک‌باکس پیش‌فرض DataGrid دو کلیک می‌خواهد).
        var cbFactory=new FrameworkElementFactory(typeof(CheckBox));
        cbFactory.SetBinding(CheckBox.IsCheckedProperty,new Binding(nameof(GroupRow.Selected)){Mode=BindingMode.TwoWay,UpdateSourceTrigger=UpdateSourceTrigger.PropertyChanged});
        cbFactory.SetValue(FrameworkElement.HorizontalAlignmentProperty,HorizontalAlignment.Center);
        cbFactory.SetValue(FrameworkElement.VerticalAlignmentProperty,VerticalAlignment.Center);
        GroupPickerGrid.Columns.Add(new DataGridTemplateColumn{Header="انتخاب",CellTemplate=new DataTemplate{VisualTree=cbFactory},Width=62});
        GroupPickerGrid.Columns.Add(new DataGridTextColumn{Header="شماره",Binding=new Binding(nameof(GroupRow.Number)),IsReadOnly=true,Width=95});
        GroupPickerGrid.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding(nameof(GroupRow.CompanyName)),IsReadOnly=true,Width=new DataGridLength(1.3,DataGridLengthUnitType.Star),MinWidth=120});
        GroupPickerGrid.Columns.Add(new DataGridTextColumn{Header="تاریخ فاکتور",Binding=new Binding(nameof(GroupRow.InvoiceDatePersian)),IsReadOnly=true,Width=100});
        GroupPickerGrid.Columns.Add(new DataGridTextColumn{Header="سررسید",Binding=new Binding(nameof(GroupRow.DueDatePersian)),IsReadOnly=true,Width=100});
        GroupPickerGrid.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding(nameof(GroupRow.Amount)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=100});
        GroupPickerGrid.Columns.Add(new DataGridTextColumn{Header="مانده",Binding=new Binding(nameof(GroupRow.Balance)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=100});
        GroupPickerGrid.Columns.Add(new DataGridTextColumn{Header="گروه",Binding=new Binding(nameof(GroupRow.GroupLabel)),IsReadOnly=true,Width=80});
        GroupPickerGrid.ItemsSource=GroupPickerRows;
        // کلیک روی هر جای ردیف (به‌جز خود کادر) انتخاب را برعکس می‌کند.
        GroupPickerGrid.PreviewMouseLeftButtonUp+=(_,e)=>
        {
            var d=e.OriginalSource as DependencyObject;
            while (d!=null && d is not DataGridRow && d is not CheckBox) d=ParentOf(d);
            if (d is DataGridRow row && row.Item is GroupRow gr) gr.Selected=!gr.Selected;
        };
        Grid.SetRow(GroupPickerGrid,1); pickLayout.Children.Add(GroupPickerGrid);

        var pickFooter=new StackPanel{Margin=new Thickness(0,10,0,0)};
        SelectionSummary.FontWeight=FontWeights.SemiBold; SelectionSummary.FontSize=13; SelectionSummary.Foreground=AppTheme.Brand700; SelectionSummary.TextWrapping=TextWrapping.Wrap; SelectionSummary.Margin=new Thickness(2,0,2,8);
        pickFooter.Children.Add(SelectionSummary);
        var addRow=new DockPanel{LastChildFill=true,FlowDirection=FlowDirection.RightToLeft};
        AddGroupBtn=Btn("＋ افزودن گروه",AppTheme.Success600); AddGroupBtn.Foreground=Brushes.White; AddGroupBtn.FontSize=14; AddGroupBtn.Padding=new Thickness(18,9,18,9); AddGroupBtn.IsEnabled=false;
        AddGroupBtn.Click+=AddInvoiceGroup;
        DockPanel.SetDock(AddGroupBtn,Dock.Left);
        GroupNameBox.Height=38; GroupNameBox.Padding=new Thickness(8,6,8,6); GroupNameBox.VerticalContentAlignment=VerticalAlignment.Center; GroupNameBox.Margin=new Thickness(4,4,4,4);
        GroupNameBox.ToolTip="نام گروه (اختیاری)، مثلاً «چک‌های مهر». با Enter گروه ساخته می‌شود.";
        GroupNameBox.KeyUp+=(_,e)=>{ if(e.Key==System.Windows.Input.Key.Enter && AddGroupBtn?.IsEnabled==true) AddInvoiceGroup(null,new RoutedEventArgs()); };
        var nameLabel=new TextBlock{Text="نام گروه (اختیاری):",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(4,0,6,0),Foreground=AppTheme.Ink700};
        DockPanel.SetDock(nameLabel,Dock.Right);
        addRow.Children.Add(AddGroupBtn); addRow.Children.Add(nameLabel); addRow.Children.Add(GroupNameBox);
        pickFooter.Children.Add(addRow);
        Grid.SetRow(pickFooter,2); pickLayout.Children.Add(pickFooter);
        pickCard.Child=pickLayout;
        Grid.SetColumn(pickCard,0); GroupingPanel.Children.Add(pickCard);

        var splitter=new GridSplitter{Width=10,HorizontalAlignment=HorizontalAlignment.Stretch,VerticalAlignment=VerticalAlignment.Stretch,ResizeBehavior=GridResizeBehavior.PreviousAndNext,Background=Brushes.Transparent,Cursor=System.Windows.Input.Cursors.SizeWE,ToolTip="برای تغییر عرض بکشید"};
        Grid.SetColumn(splitter,1); GroupingPanel.Children.Add(splitter);

        // ---- ستون ۲: گروه‌های ساخته‌شده ----
        var resultsCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(12),Padding=new Thickness(12),Effect=AppTheme.CardShadow};
        var resLayout=new Grid();
        resLayout.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        resLayout.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});
        resLayout.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        resLayout.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});

        var resHeader=new TextBlock{Text="۲) گروه‌های ساخته‌شده",FontWeight=FontWeights.Bold,FontSize=14,Foreground=AppTheme.Brand900,Margin=new Thickness(0,0,0,8)};
        Grid.SetRow(resHeader,0); resLayout.Children.Add(resHeader);

        GroupResultsGrid.FlowDirection=FlowDirection.RightToLeft; GroupResultsGrid.AutoGenerateColumns=false; GroupResultsGrid.IsReadOnly=true; GroupResultsGrid.CanUserAddRows=false;
        GroupResultsGrid.SelectionMode=DataGridSelectionMode.Single; GroupResultsGrid.SelectionUnit=DataGridSelectionUnit.FullRow;
        GroupResultsGrid.RowHeight=36; GroupResultsGrid.ColumnHeaderHeight=34; GroupResultsGrid.FontSize=12;
        GroupResultsGrid.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; GroupResultsGrid.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        GroupResultsGrid.Columns.Add(new DataGridTextColumn{Header="#",Binding=new Binding(nameof(InvoiceGroupResult.GroupNumber)),Width=38});
        GroupResultsGrid.Columns.Add(new DataGridTextColumn{Header="نام گروه",Binding=new Binding(nameof(InvoiceGroupResult.Name)),Width=new DataGridLength(1.1,DataGridLengthUnitType.Star),MinWidth=90});
        // این دو ستون در جدول مخفی‌اند (جزئیات پایین جدول نشان داده می‌شود) ولی در خروجی Excel می‌آیند.
        GroupResultsGrid.Columns.Add(new DataGridTextColumn{Header="شماره فاکتورها",Binding=new Binding(nameof(InvoiceGroupResult.InvoiceNumbers)),Visibility=Visibility.Collapsed});
        GroupResultsGrid.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding(nameof(InvoiceGroupResult.CompanyNames)),Visibility=Visibility.Collapsed});
        GroupResultsGrid.Columns.Add(new DataGridTextColumn{Header="تعداد",Binding=new Binding(nameof(InvoiceGroupResult.Count)),Width=52});
        GroupResultsGrid.Columns.Add(new DataGridTextColumn{Header="جمع کل",Binding=new Binding(nameof(InvoiceGroupResult.TotalAmount)){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=95});
        GroupResultsGrid.Columns.Add(new DataGridTextColumn{Header="مانده",Binding=new Binding(nameof(InvoiceGroupResult.Balance)){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=95});
        GroupResultsGrid.Columns.Add(new DataGridTextColumn{Header="میانگین سررسید",Binding=new Binding(nameof(InvoiceGroupResult.AvgDueDate)),Width=105});
        GroupResultsGrid.ItemsSource=Groups;
        GroupResultsGrid.SelectionChanged+=(_,_)=>UpdateGroupDetail();
        Grid.SetRow(GroupResultsGrid,1); resLayout.Children.Add(GroupResultsGrid);

        GroupDetailText.TextWrapping=TextWrapping.Wrap; GroupDetailText.FontSize=12; GroupDetailText.Foreground=AppTheme.Ink700; GroupDetailText.Margin=new Thickness(2);
        var detailBox=new Border{Background=AppTheme.Surface100,CornerRadius=new CornerRadius(8),Padding=new Thickness(8),Margin=new Thickness(0,8,0,0),
            Child=new ScrollViewer{MaxHeight=96,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=GroupDetailText}};
        Grid.SetRow(detailBox,2); resLayout.Children.Add(detailBox);

        var resFooter=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft,Margin=new Thickness(0,8,0,0)};
        var removeGroupBtn=Btn("حذف گروه انتخاب‌شده",AppTheme.Danger100); removeGroupBtn.Foreground=AppTheme.Danger600; removeGroupBtn.Click+=RemoveSelectedGroup;
        var clearGroupsBtn=Btn("پاک کردن همه",AppTheme.Surface100); clearGroupsBtn.Foreground=AppTheme.Ink700;
        clearGroupsBtn.Click+=async(_,_)=>{ if(Groups.Count==0) return; Groups.Clear(); RefreshGroups(); var (f,t)=ReadDateRange(); await LoadGroupingPicker(f,t); };
        GroupTotalsText.VerticalAlignment=VerticalAlignment.Center; GroupTotalsText.Margin=new Thickness(8,0,0,0); GroupTotalsText.FontWeight=FontWeights.SemiBold; GroupTotalsText.Foreground=AppTheme.Ink700; GroupTotalsText.TextWrapping=TextWrapping.Wrap;
        resFooter.Children.Add(removeGroupBtn); resFooter.Children.Add(clearGroupsBtn);
        var totalsHost=new Border{Margin=new Thickness(0,6,0,0),Child=GroupTotalsText};
        var footerStack=new StackPanel(); footerStack.Children.Add(resFooter); footerStack.Children.Add(totalsHost);
        Grid.SetRow(footerStack,3); resLayout.Children.Add(footerStack);
        resultsCard.Child=resLayout;
        Grid.SetColumn(resultsCard,2); GroupingPanel.Children.Add(resultsCard);
        RefreshGroups();

        Grid.SetRow(GroupingPanel,3); Children.Add(GroupingPanel);
    }

    Border BuildCombinedSection(TextBlock header, string title, DataGrid grid, params string[] columnHeaders)
    {
        var card=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(12),Padding=new Thickness(12),Margin=new Thickness(0,0,0,10),Effect=AppTheme.CardShadow};
        var stack=new StackPanel();
        var titleRow=new StackPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(0,0,0,6)};
        titleRow.Children.Add(new TextBlock{Text=title,FontWeight=FontWeights.Bold,FontSize=13.5,Foreground=AppTheme.Brand900});
        header.FontSize=11.5; header.Foreground=AppTheme.Ink500; header.Margin=new Thickness(10,2,0,0); header.VerticalAlignment=VerticalAlignment.Center;
        titleRow.Children.Add(header);
        stack.Children.Add(titleRow);

        grid.FlowDirection=FlowDirection.RightToLeft; grid.AutoGenerateColumns=false; grid.IsReadOnly=true; grid.CanUserAddRows=false;
        grid.RowHeight=32; grid.ColumnHeaderHeight=32; grid.FontSize=11.5; grid.MaxHeight=220; grid.MinHeight=70;
        grid.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; grid.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        foreach (var h in columnHeaders) grid.Columns.Add(new DataGridTextColumn{Header=h,Binding=new Binding(SafeProp(h)),Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=80});
        stack.Children.Add(grid);
        card.Child=stack;
        return card;
    }
    // ستون‌های این سه‌گانه از رکوردهای موجود (Invoices row type / PayRow / CheckRow) استفاده می‌کنند؛
    // این متد فقط عنوان فارسی هر ستون را به نام Property مربوطه نگاشت می‌دهد.
    static string SafeProp(string header) => header switch
    {
        "شماره"=>"Number", "شرکت"=>"Company.Name", "تاریخ فاکتور"=>"InvoiceDate", "سررسید"=>"Due",
        "مبلغ"=>"Amount", "پرداختی"=>"Paid", "مانده"=>"Balance", "وضعیت"=>"Status",
        "تاریخ وصول"=>"PayDate", "فاکتور"=>"InvoiceNumber", "روش"=>"PaymentMethod",
        "شماره چک"=>"CheckNumber", "وضعیت چک"=>"CheckStatus", "تاریخ چک"=>"CheckDate",
        _=>header
    };

    static StackPanel LabeledField(string label, Control box, double width)
    {
        var p=new StackPanel{Margin=new Thickness(4,0,4,4)};
        p.Children.Add(new TextBlock{Text=label,FontSize=11,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink500,Margin=new Thickness(2,0,2,3)});
        box.Width=width; box.Height=36;
        if (box is TextBox tb){tb.Padding=new Thickness(8,6,8,6);tb.VerticalContentAlignment=VerticalAlignment.Center;}
        p.Children.Add(box);
        return p;
    }
    static Button TabButton(string text)=>new Button{Content=text,Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,0,8,0),BorderThickness=new Thickness(0),FontWeight=FontWeights.SemiBold,Cursor=System.Windows.Input.Cursors.Hand};
    void UpdateTabs()
    {
        _suppress=true;
        SetTabState(TabCombined,_tab==ReportTab.Combined); SetTabState(TabGrouping,_tab==ReportTab.Grouping); SetTabState(TabChecks,_tab==ReportTab.Checks);
        G.Visibility = _tab==ReportTab.Checks ? Visibility.Visible : Visibility.Collapsed;
        CombinedScroll.Visibility = _tab==ReportTab.Combined ? Visibility.Visible : Visibility.Collapsed;
        GroupingPanel.Visibility = _tab==ReportTab.Grouping ? Visibility.Visible : Visibility.Collapsed;
        if (StatusField!=null) StatusField.Visibility = _tab==ReportTab.Checks ? Visibility.Visible : Visibility.Collapsed;
        if (SearchField!=null) SearchField.Visibility = _tab==ReportTab.Combined ? Visibility.Collapsed : Visibility.Visible;
        StatusBox.ItemsSource = CheckStatusItems; StatusBox.SelectedIndex = 0;
        SetLabel(FromField, _tab==ReportTab.Checks ? "سررسید چک — از" : "از تاریخ");
        SetLabel(ToField, _tab==ReportTab.Checks ? "سررسید چک — تا" : "تا تاریخ");
        ReportInfo.Text = _tab switch
        {
            ReportTab.Combined => "فاکتورها، وصول‌ها و چک‌های یک شرکت در یک صفحه. فاکتورها بر اساس تاریخ فاکتور، وصول‌ها بر اساس تاریخ وصول و چک‌ها بر اساس سررسید چک فیلتر می‌شوند.",
            ReportTab.Grouping => "فاکتورهای مانده‌دار را تیک بزنید و گروه بسازید تا جمع و میانگین سررسید هر گروه را ببینید. فیلتر تاریخ بر اساس تاریخ فاکتور است.",
            _ => "چک‌های صادرشده برای شرکت انتخاب‌شده، بر اساس سررسید چک. بازه‌ی زمانی را عوض کنید (مثلاً «۳۰ روز آینده») تا ببینید در آن بازه چه چک‌هایی سررسید دارند."
        };
        _suppress=false;
    }
    static void SetLabel(StackPanel? field, string text) { if (field?.Children[0] is TextBlock tb) tb.Text = text; }
    static string Norm(string? s) => (s ?? "").Replace('ي','ی').Replace('ك','ک').Trim();
    static bool Has(string? s, string q) => Norm(s).Contains(Norm(q), StringComparison.OrdinalIgnoreCase);
    static void SetTabState(Button b, bool active)
    {
        b.Background = active ? AppTheme.Brand600 : AppTheme.Surface100;
        b.Foreground = active ? Brushes.White : AppTheme.Ink700;
    }
    static Button Btn(string t,Brush bg)=>new Button{Content=t,Background=bg,BorderThickness=new Thickness(0),Padding=new Thickness(13,8,13,8),Margin=new Thickness(4),FontWeight=FontWeights.SemiBold};

    async Task LoadCompanies(){var list=await S.GetCompaniesAsync();var all=new List<Company>{new Company{Id=0,Name="همه شرکت‌ها"}};all.AddRange(list);CompanyBox.ItemsSource=all;CompanyBox.DisplayMemberPath="Name";CompanyBox.SelectedValuePath="Id";CompanyBox.SelectedValue=InitialCompanyId??0;}
    int? CompanyId=>CompanyBox.SelectedValue is int id&&id>0?id:null;

    void ApplyPreset()
    {
        var preset = PresetBox.SelectedItem as string;
        if (preset=="بازه‌ی دلخواه" || preset is null) return;
        var pc = new PersianCalendar(); var today = DateTime.Today;
        (DateTime from, DateTime to) range = preset switch
        {
            "امروز" => (today, today),
            "۷ روز اخیر" => (today.AddDays(-6), today),
            "این ماه (شمسی)" => MonthRange(pc, today),
            "سه‌ماه اخیر" => (today.AddDays(-90), today),
            "امسال (شمسی)" => (pc.ToDateTime(pc.GetYear(today),1,1,0,0,0,0), today),
            "۷ روز آینده" => (today, today.AddDays(7)),
            "۳۰ روز آینده" => (today, today.AddDays(30)),
            _ => (DateTime.MinValue, DateTime.MaxValue) // "همه"
        };
        FromDateBox.Text = range.from==DateTime.MinValue ? "" : PersianDateService.ToPersian(range.from);
        ToDateBox.Text = range.to==DateTime.MaxValue ? "" : PersianDateService.ToPersian(range.to);
    }
    static (DateTime,DateTime) MonthRange(PersianCalendar pc, DateTime today)
    {
        int y=pc.GetYear(today), m=pc.GetMonth(today);
        var from = pc.ToDateTime(y,m,1,0,0,0,0);
        var to = pc.ToDateTime(y,m,pc.GetDaysInMonth(y,m),0,0,0,0);
        return (from,to);
    }
    (DateTime? from, DateTime? to) ReadDateRange()
    {
        DateTime? from=null, to=null;
        if (!string.IsNullOrWhiteSpace(FromDateBox.Text)) { if (PersianDateService.TryParse(FromDateBox.Text, out var f)) from=f.Date; else MessageBox.Show("تاریخ «از» معتبر نیست. نمونه: 1405/01/01","فیلتر تاریخ",MessageBoxButton.OK,MessageBoxImage.Warning); }
        if (!string.IsNullOrWhiteSpace(ToDateBox.Text)) { if (PersianDateService.TryParse(ToDateBox.Text, out var t)) to=t.Date; else MessageBox.Show("تاریخ «تا» معتبر نیست. نمونه: 1405/06/25","فیلتر تاریخ",MessageBoxButton.OK,MessageBoxImage.Warning); }
        return (from,to);
    }
    static string StatusOf(Invoice x)
    {
        var balance = AccountingService.Balance(x);
        return balance<=0 ? "تسویه شده" : x.Paid>0 ? "بخشی پرداخت شده" : "پرداخت نشده";
    }

    async Task Load()
    {
        var (from,to) = ReadDateRange();
        switch (_tab)
        {
            case ReportTab.Combined: await LoadCombined(from,to); break;
            case ReportTab.Grouping: await LoadGroupingPicker(from,to); break;
            default: G.Columns.Clear(); await LoadChecks(from,to); break;
        }
    }

    async Task LoadGroupingPicker(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — گروه‌بندی فاکتورها";
        var rows = await S.GetInvoicesAsync(CompanyId);
        if (from.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();
        rows = rows.Where(x=>AccountingService.Balance(x)>0).OrderBy(x=>x.DueDate).ToList();
        var gq = SearchBox.Text.Trim();
        if (gq.Length>0) rows = rows.Where(x=>Has(x.Number,gq) || Has(x.Company?.Name,gq)).ToList();

        // هر فاکتور در کدام گروه ثبت‌شده است؟
        var groupOf = new Dictionary<int,int>();
        foreach (var g in Groups) foreach (var id in g.InvoiceIds) groupOf[id] = g.GroupNumber;
        var hideGrouped = HideGroupedBox.IsChecked==true;
        if (hideGrouped) rows = rows.Where(x=>!groupOf.ContainsKey(x.Id)).ToList();

        Summary.Text = $"شرکت: {(CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها"}   |   فاکتور قابل انتخاب: {rows.Count:N0}   |   مانده‌ی آن‌ها: {rows.Sum(AccountingService.Balance):N0}   |   گروه‌های ثبت‌شده: {Groups.Count:N0}";

        GroupPickerRows.Clear();
        foreach (var x in rows)
        {
            var row = new GroupRow(x, groupOf.TryGetValue(x.Id, out var gn) ? $"گروه {gn}" : "");
            row.PropertyChanged += (_,e) => { if (e.PropertyName==nameof(GroupRow.Selected)) UpdateSelectionSummary(); };
            GroupPickerRows.Add(row);
        }
        UpdateSelectionSummary();
    }

    void UpdateSelectionSummary()
    {
        var sel = GroupPickerRows.Where(x=>x.Selected).Select(x=>x.Invoice).ToList();
        if (AddGroupBtn!=null) AddGroupBtn.IsEnabled = sel.Count>0;
        if (sel.Count==0) { SelectionSummary.Text="هیچ فاکتوری انتخاب نشده — روی ردیف فاکتور (یا کادر انتخاب) بزنید."; return; }
        var sum = AccountingService.Summarize(sel);
        SelectionSummary.Text = $"انتخاب‌شده: {sel.Count:N0} فاکتور   |   جمع: {sum.TotalAmount:N0}   |   مانده: {sum.TotalBalance:N0}   |   میانگین سررسید: {(sum.WeightedDueDate.HasValue?PersianDateService.ToPersian(sum.WeightedDueDate.Value):"—")}";
    }

    void RefreshGroups()
    {
        GroupResultsGrid.Items.Refresh();
        GroupTotalsText.Text = Groups.Count==0 ? "هنوز گروهی ثبت نشده است."
            : $"{Groups.Count:N0} گروه   |   جمع کل: {Groups.Sum(g=>g.TotalAmount):N0}   |   مانده‌ی کل: {Groups.Sum(g=>g.Balance):N0}";
        UpdateGroupDetail();
    }

    void UpdateGroupDetail()
    {
        GroupDetailText.Text = GroupResultsGrid.SelectedItem is InvoiceGroupResult g
            ? $"{g.Name} — {g.Count:N0} فاکتور\nفاکتورها: {g.InvoiceNumbers}\nشرکت‌ها: {g.CompanyNames}"
            : "برای دیدن فاکتورها و شرکت‌های هر گروه، روی آن بزنید.";
    }

    static DependencyObject? ParentOf(DependencyObject d) =>
        d is System.Windows.Media.Visual || d is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);

    async void AddInvoiceGroup(object? sender, RoutedEventArgs e)
    {
        var selected = GroupPickerRows.Where(x=>x.Selected).ToList();
        if (selected.Count == 0) { MessageBox.Show("حداقل یک فاکتور را انتخاب کنید (روی ردیف بزنید)."); return; }

        var already = selected.Count(x=>x.GroupLabel.Length>0);
        if (already>0 && MessageBox.Show($"{already:N0} فاکتور از انتخاب‌شده‌ها قبلاً در یک گروه دیگر هستند. باز هم در این گروه هم بیایند؟","گروه‌بندی",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes) return;

        var invoices = selected.Select(x=>x.Invoice).ToList();
        var sum = AccountingService.Summarize(invoices);
        var number = Groups.Count + 1;
        var group = new InvoiceGroupResult
        {
            GroupNumber = number,
            Name = string.IsNullOrWhiteSpace(GroupNameBox.Text) ? $"گروه {number}" : GroupNameBox.Text.Trim(),
            InvoiceNumbers = string.Join("، ", invoices.Select(x=>x.Number)),
            CompanyNames = string.Join("، ", invoices.Select(x=>x.Company?.Name ?? "-").Distinct()),
            Count = invoices.Count,
            TotalAmount = sum.TotalAmount,
            Balance = sum.TotalBalance,
            AvgDueDate = sum.WeightedDueDate.HasValue ? PersianDateService.ToPersian(sum.WeightedDueDate.Value) : "—",
            InvoiceIds = invoices.Select(x=>x.Id).ToList()
        };
        Groups.Add(group);
        GroupNameBox.Clear();
        RefreshGroups();

        var (from,to) = ReadDateRange();
        await LoadGroupingPicker(from,to);
    }

    async void RemoveSelectedGroup(object? sender, RoutedEventArgs e)
    {
        if (GroupResultsGrid.SelectedItem is not InvoiceGroupResult g) { MessageBox.Show("یک گروه را از جدول پایین انتخاب کنید."); return; }
        Groups.Remove(g);
        for (int i=0;i<Groups.Count;i++) { Groups[i].GroupNumber = i+1; if (Groups[i].Name.StartsWith("گروه ")) Groups[i].Name = $"گروه {i+1}"; }
        RefreshGroups();
        var (from,to) = ReadDateRange();
        await LoadGroupingPicker(from,to);
    }

    // چک‌های صادرشده (همه‌ی وضعیت‌ها یا یک وضعیت مشخص). فیلتر تاریخ همیشه روی «سررسید چک» است.
    // چک بدون تاریخ سررسید فقط وقتی فیلتر تاریخی نباشد نمایش داده می‌شود و در غیر این صورت در خلاصه گزارش می‌شود.
    async Task LoadChecks(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — چک‌های در جریان";
        var companyName = (CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها";
        var payments = await S.GetPaymentsAsync(CompanyId);
        var all = payments.Where(p=>p.PaymentMethod=="چک").ToList();

        var hasRange = from.HasValue || to.HasValue;
        var undated = all.Count(p=>!p.CheckDate.HasValue);
        var checks = all.Where(p=>!hasRange || p.CheckDate.HasValue).ToList();
        if (from.HasValue) checks = checks.Where(p=>p.CheckDate!.Value.Date>=from.Value).ToList();
        if (to.HasValue) checks = checks.Where(p=>p.CheckDate!.Value.Date<=to.Value).ToList();

        var statusFilter = StatusBox.SelectedItem as string;
        if (!string.IsNullOrEmpty(statusFilter) && statusFilter!=AllStatuses) checks = checks.Where(p=>(p.CheckStatus ?? "")==statusFilter).ToList();

        var q = SearchBox.Text.Trim();
        if (q.Length>0) checks = checks.Where(p=>Has(p.CheckNumber,q) || Has(p.Invoice?.Number,q) || Has(p.Invoice?.Company?.Name,q)).ToList();

        // نزدیک‌ترین سررسید اول
        checks = checks.OrderBy(p=>p.CheckDate ?? DateTime.MaxValue).ThenBy(p=>p.Id).ToList();
        _checkList = checks;

        string Part(string status)
        {
            var part = checks.Where(p=>p.CheckStatus==status).ToList();
            return $"{status}: {part.Count:N0} ({part.Sum(p=>p.Amount):N0})";
        }
        var rangeText = hasRange
            ? $"سررسید از {(from.HasValue?PersianDateService.ToPersian(from.Value):"…")} تا {(to.HasValue?PersianDateService.ToPersian(to.Value):"…")}"
            : "همه‌ی سررسیدها";
        Summary.Text = $"شرکت: {companyName}   |   {rangeText}   |   تعداد چک: {checks.Count:N0}   |   جمع: {checks.Sum(p=>p.Amount):N0} ریال   |   {Part(PaymentRules.DefaultCheckStatus)}   |   {Part(PaymentRules.CheckStatuses[2])}   |   {Part(PaymentRules.CheckStatuses[1])}"
            + (hasRange && undated>0 ? $"   |   ({undated:N0} چک بدون تاریخ سررسید در این فیلتر نیامد)" : "");

        G.Columns.Add(new DataGridTextColumn{Header="سررسید چک",Binding=new Binding("CheckDate"),Width=105});
        G.Columns.Add(new DataGridTextColumn{Header="تا سررسید",Binding=new Binding("DueInfo"),Width=105});
        G.Columns.Add(new DataGridTextColumn{Header="شماره چک",Binding=new Binding("CheckNumber"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شماره فاکتور",Binding=new Binding("InvoiceNumber"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("CompanyName"),Width=new DataGridLength(1.4,DataGridLengthUnitType.Star),MinWidth=140});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="وضعیت",Binding=new Binding("CheckStatus"),Width=110});
        var today = DateTime.Today;
        G.ItemsSource = checks.Select(p => new CheckRow(
            p.CheckDate.HasValue?PersianDateService.ToPersian(p.CheckDate.Value):"—", p.CheckNumber ?? "—",
            p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-", p.Amount, p.CheckStatus ?? "—", DueInfo(p, today)
        )).ToList();
    }

    // «۳ روز دیگر / امروز / ۲ روز گذشته» فقط برای چک‌های در انتظار وصول.
    static string DueInfo(Payment p, DateTime today)
    {
        if (p.CheckStatus != PaymentRules.DefaultCheckStatus || !p.CheckDate.HasValue) return "—";
        var d = (p.CheckDate.Value.Date - today.Date).Days;
        return d>0 ? $"{d:N0} روز دیگر" : d==0 ? "امروز" : $"{-d:N0} روز گذشته";
    }

    async Task LoadCombined(DateTime? from, DateTime? to)
    {
        var companyName = (CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها";
        TitleText.Text = $"گزارش جامع — {companyName}";

        var invoices = await S.GetInvoicesAsync(CompanyId);
        if (from.HasValue) invoices = invoices.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) invoices = invoices.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();
        invoices = invoices.OrderByDescending(x=>x.InvoiceDate).ToList();

        var allPayments = await S.GetPaymentsAsync(CompanyId);
        // وصول‌ها بر اساس «تاریخ وصول» فیلتر می‌شوند، ولی چک‌ها بر اساس «سررسید چک».
        var payments = allPayments.ToList();
        if (from.HasValue) payments = payments.Where(p=>p.PayDate.Date>=from.Value).ToList();
        if (to.HasValue) payments = payments.Where(p=>p.PayDate.Date<=to.Value).ToList();
        payments = payments.OrderByDescending(p=>p.PayDate).ToList();

        var hasRange = from.HasValue || to.HasValue;
        var checks = allPayments.Where(p=>p.PaymentMethod=="چک" && (!hasRange || p.CheckDate.HasValue)).ToList();
        if (from.HasValue) checks = checks.Where(p=>p.CheckDate!.Value.Date>=from.Value).ToList();
        if (to.HasValue) checks = checks.Where(p=>p.CheckDate!.Value.Date<=to.Value).ToList();
        checks = checks.OrderBy(p=>p.CheckDate ?? DateTime.MaxValue).ToList();
        _cInv = invoices; _cPay = payments; _cChk = checks;

        var sum = AccountingService.Summarize(invoices);
        Summary.Text = $"شرکت: {companyName}   |   فاکتور: {invoices.Count:N0} ({sum.TotalAmount:N0} ریال)   |   پرداخت: {payments.Count:N0} ({payments.Sum(p=>p.Amount):N0} ریال)   |   چک: {checks.Count:N0} ({checks.Sum(p=>p.Amount):N0} ریال)   |   مانده‌ی کل: {sum.TotalBalance:N0}";

        CInvoicesHeader.Text = $"{invoices.Count:N0} فاکتور   |   جمع {invoices.Sum(x=>x.Amount):N0} ریال   |   مانده {invoices.Sum(AccountingService.Balance):N0} ریال";
        CInvoices.ItemsSource = invoices.Select(x => new
        {
            x.Number, x.Company,
            InvoiceDate = PersianDateService.ToPersian(x.InvoiceDate),
            Due = PersianDateService.ToPersian(x.DueDate),
            x.Amount, x.Paid, Balance = AccountingService.Balance(x),
            Status = StatusOf(x)
        }).ToList();

        CPaymentsHeader.Text = $"{payments.Count:N0} پرداخت   |   جمع {payments.Sum(p=>p.Amount):N0} ریال";
        CPayments.ItemsSource = payments.Select(p => new PayRow(
            p.Id, PersianDateService.ToPersian(p.PayDate), p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-",
            p.Amount, p.PaymentMethod, p.CheckNumber ?? "—", p.CheckStatus ?? "—", string.IsNullOrWhiteSpace(p.Note)?"—":p.Note
        )).ToList();

        CChecksHeader.Text = $"{checks.Count:N0} چک   |   جمع {checks.Sum(p=>p.Amount):N0} ریال   |   برگشتی: {checks.Count(p=>p.CheckStatus=="برگشتی"):N0}";
        CChecks.ItemsSource = checks.Select(p => new CheckRow(
            p.CheckDate.HasValue?PersianDateService.ToPersian(p.CheckDate.Value):"—", p.CheckNumber ?? "—",
            p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-", p.Amount, p.CheckStatus ?? "—"
        )).ToList();
    }

    void G_LoadingRow(object? sender, DataGridRowEventArgs e)
    {
        if (_tab != ReportTab.Checks || e.Row.Item is not CheckRow cr) { e.Row.Background = Brushes.White; return; }
        e.Row.Background = cr.CheckStatus switch
        {
            "برگشتی" => AppTheme.Danger100,
            "در انتظار وصول" => AppTheme.Warning100,
            _ => Brushes.White
        };
    }

    void Export(object? sender,RoutedEventArgs e)
    {
        if (_tab == ReportTab.Grouping && Groups.Count == 0) { MessageBox.Show("هنوز گروهی ثبت نشده است. ابتدا چند فاکتور را تیک بزنید و «افزودن گروه» را بزنید.", "خروجی", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        var d=new SaveFileDialog{Filter="Excel Workbook|*.xlsx",FileName=$"گزارش-{DateTime.Now:yyyyMMdd-HHmm}.xlsx"};
        if(d.ShowDialog()!=true)return;
        try
        {
            using var wb = new XLWorkbook();
            if (_tab == ReportTab.Combined)
            {
                AddSheetFromGrid(wb, CInvoices, "فاکتورهای خریداری‌شده");
                AddSheetFromGrid(wb, CPayments, "پرداخت‌ها");
                AddSheetFromGrid(wb, CChecks, "چک‌های داده‌شده");
            }
            else if (_tab == ReportTab.Grouping)
            {
                AddSheetFromGrid(wb, GroupResultsGrid, "گروه‌بندی فاکتورها");
            }
            else
            {
                AddSheetFromGrid(wb, G, "چک‌های در جریان");
            }
            wb.SaveAs(d.FileName);
            MessageBox.Show("خروجی Excel دقیقاً مطابق اطلاعات همین گزارش ذخیره شد.","خروجی Excel",MessageBoxButton.OK,MessageBoxImage.Information);
        }
        catch(Exception ex){MessageBox.Show(ex.Message,"خروجی",MessageBoxButton.OK,MessageBoxImage.Error);}
    }

    // ---------- چاپ (هر سه گزارش) ----------
    async void Print(object? sender, RoutedEventArgs e)
    {
        try
        {
            var ps = new PrintService();
            var today = DateTime.Today;
            switch (_tab)
            {
                case ReportTab.Checks:
                    await ps.PrintReportAsync("گزارش چک‌های در جریان", Summary.Text, new[]{ CheckTable("", _checkList, today) });
                    break;
                case ReportTab.Combined:
                {
                    var company = (CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها";
                    var invTable = new PrintTable("فاکتورها",
                        new[]{"شماره","شرکت","تاریخ فاکتور","سررسید","مبلغ","پرداختی","مانده","وضعیت"},
                        _cInv.Select(x=>new[]{x.Number,x.Company?.Name ?? "-",PersianDateService.ToPersian(x.InvoiceDate),PersianDateService.ToPersian(x.DueDate),x.Amount.ToString("N0"),x.Paid.ToString("N0"),AccountingService.Balance(x).ToString("N0"),StatusOf(x)}).ToList(),
                        $"جمع: {_cInv.Sum(x=>x.Amount):N0}   |   پرداختی: {_cInv.Sum(x=>x.Paid):N0}   |   مانده: {_cInv.Sum(AccountingService.Balance):N0} ریال");
                    var payTable = new PrintTable("وصول‌ها",
                        new[]{"تاریخ وصول","فاکتور","مبلغ","روش","شماره چک","وضعیت چک"},
                        _cPay.Select(p=>new[]{PersianDateService.ToPersian(p.PayDate),p.Invoice?.Number ?? "-",p.Amount.ToString("N0"),p.PaymentMethod,p.CheckNumber ?? "—",p.CheckStatus ?? "—"}).ToList(),
                        $"جمع وصول‌ها: {_cPay.Sum(p=>p.Amount):N0} ریال");
                    await ps.PrintReportAsync($"گزارش جامع — {company}", Summary.Text, new[]{ invTable, payTable, CheckTable("چک‌ها (بر اساس سررسید چک)", _cChk, today) });
                    break;
                }
                default:
                {
                    if (Groups.Count==0) { MessageBox.Show("هنوز گروهی ثبت نشده است. ابتدا چند فاکتور را انتخاب کنید و «افزودن گروه» را بزنید.","چاپ",MessageBoxButton.OK,MessageBoxImage.Information); return; }
                    var table = new PrintTable("گروه‌های فاکتور",
                        new[]{"#","نام گروه","شماره فاکتورها","شرکت","تعداد","جمع کل","مانده","میانگین سررسید"},
                        Groups.Select(g=>new[]{g.GroupNumber.ToString(),g.Name,g.InvoiceNumbers,g.CompanyNames,g.Count.ToString("N0"),g.TotalAmount.ToString("N0"),g.Balance.ToString("N0"),g.AvgDueDate}).ToList(),
                        GroupTotalsText.Text,
                        new[]{0.4,1,2.2,1.4,0.6,1.2,1.2,1.1});
                    await ps.PrintReportAsync("گروه‌بندی فاکتورها", "", new[]{ table });
                    break;
                }
            }
        }
        catch (Exception ex) { MessageBox.Show(ex.Message,"چاپ",MessageBoxButton.OK,MessageBoxImage.Warning); }
    }

    static PrintTable CheckTable(string heading, IReadOnlyList<Payment> checks, DateTime today) => new(heading,
        new[]{"سررسید چک","تا سررسید","شماره چک","فاکتور","شرکت","مبلغ","وضعیت"},
        checks.Select(p=>new[]{p.CheckDate.HasValue?PersianDateService.ToPersian(p.CheckDate.Value):"—",DueInfo(p,today),p.CheckNumber ?? "—",p.Invoice?.Number ?? "-",p.Invoice?.Company?.Name ?? "-",p.Amount.ToString("N0"),p.CheckStatus ?? "—"}).ToList(),
        $"تعداد: {checks.Count:N0}   |   جمع مبلغ: {checks.Sum(p=>p.Amount):N0} ریال");

    // خروجی Excel دقیقاً همان ستون‌ها و ردیف‌هایی را می‌نویسد که همین لحظه در جدول دیده می‌شود -
    // نه یک خروجی ثابت و جدا از فیلترها/تبی که کاربر واقعاً باز کرده.
    static void AddSheetFromGrid(XLWorkbook wb, DataGrid grid, string sheetName)
    {
        var ws = wb.Worksheets.Add(SafeSheetName(sheetName));
        var columns = grid.Columns.OfType<DataGridBoundColumn>().ToList();
        for (int c = 0; c < columns.Count; c++)
            ws.Cell(1, c + 1).Value = columns[c].Header?.ToString() ?? "";

        var items = grid.ItemsSource?.Cast<object>().ToList() ?? new List<object>();
        for (int r = 0; r < items.Count; r++)
            for (int c = 0; c < columns.Count; c++)
            {
                var path = (columns[c].Binding as Binding)?.Path?.Path;
                var val = path != null ? GetPropertyValue(items[r], path) : null;
                ws.Cell(r + 2, c + 1).Value = val?.ToString() ?? "";
            }

        ws.RightToLeft = true;
        ws.Row(1).Style.Font.Bold = true;
        ws.Row(1).Style.Fill.BackgroundColor = XLColor.LightBlue;
        ws.SheetView.FreezeRows(1);
        if (items.Count > 0) ws.Columns().AdjustToContents();
    }
    static string SafeSheetName(string s) => s.Length > 31 ? s.Substring(0, 31) : s; // محدودیت اکسل روی طول نام شیت

    static object? GetPropertyValue(object obj, string path)
    {
        object? current = obj;
        foreach (var part in path.Split('.'))
        {
            if (current is null) return null;
            var prop = current.GetType().GetProperty(part);
            if (prop is null) return null;
            current = prop.GetValue(current);
        }
        return current;
    }

}

sealed record PayRow(int Id, string PayDate, string InvoiceNumber, string CompanyName, decimal Amount, string PaymentMethod, string CheckNumber, string CheckStatus, string Note);
sealed record CheckRow(string CheckDate, string CheckNumber, string InvoiceNumber, string CompanyName, decimal Amount, string CheckStatus, string DueInfo = "—");

public sealed class GroupRow : INotifyPropertyChanged
{
    public Invoice Invoice { get; }
    public GroupRow(Invoice invoice, string groupLabel = "") { Invoice = invoice; GroupLabel = groupLabel; }
    public string Number => Invoice.Number;
    public string CompanyName => Invoice.Company?.Name ?? "-";
    public string InvoiceDatePersian => PersianDateService.ToPersian(Invoice.InvoiceDate);
    public string DueDatePersian => PersianDateService.ToPersian(Invoice.DueDate);
    public decimal Amount => Invoice.Amount;
    public decimal Balance => AccountingService.Balance(Invoice);
    public string GroupLabel { get; }
    bool _selected;
    public bool Selected
    {
        get => _selected;
        set { if (_selected==value) return; _selected = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Selected))); }
    }
    public event PropertyChangedEventHandler? PropertyChanged;
}

public sealed class InvoiceGroupResult
{
    public int GroupNumber { get; set; }
    public string Name { get; set; } = "";
    public string InvoiceNumbers { get; set; } = "";
    public string CompanyNames { get; set; } = "";
    public int Count { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal Balance { get; set; }
    public string AvgDueDate { get; set; } = "";
    public List<int> InvoiceIds { get; set; } = new();
}
