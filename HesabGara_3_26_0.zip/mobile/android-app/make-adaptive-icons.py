"""ساخت آیکون تطبیقی اندروید از لوگوی برنامه، به‌طوری که روی گوشی شبیه آیکون اصلی دیده شود.

ورودی : assets/icon-only.png (لوگوی اصلی؛ گوشه‌های شفاف یا تمام‌صفحه هر دو قابل قبول است)
خروجی : assets/icon-foreground.png و assets/icon-background.png  (برای capacitor-assets)
لوگو حدود ۷۰٪ بوم را پر می‌کند (اندازه‌ی پنجره‌ی نمایشی لانچر)، و پس‌زمینه از رنگ‌های حاشیه‌ی خود لوگو
ساخته می‌شود تا ماسک گرد/گردگوشه‌ی لانچر لبه‌ی اضافه نشان ندهد.
"""
import statistics
import sys
from PIL import Image

src = sys.argv[1] if len(sys.argv) > 1 else "assets/icon-only.png"
out = sys.argv[2] if len(sys.argv) > 2 else "assets"
CANVAS, SCALE = 1024, 0.70

im = Image.open(src).convert("RGBA")
mask = im.getchannel("A").point(lambda a: 255 if a > 20 else 0)
c = im.crop(mask.getbbox() or (0, 0, *im.size))
side = max(c.size)
sq = Image.new("RGBA", (side, side), (0, 0, 0, 0))
sq.paste(c, ((side - c.width) // 2, (side - c.height) // 2))
size = round(CANVAS * SCALE)
sq = sq.resize((size, size), Image.LANCZOS)
off = (CANVAS - size) // 2

fg = Image.new("RGBA", (CANVAS, CANVAS), (0, 0, 0, 0))
fg.paste(sq, (off, off), sq)
fg.save(f"{out}/icon-foreground.png")


def rim(y0, y1):
    px = []
    for y in range(int(size * y0), int(size * y1)):
        for x in range(int(size * 0.3), int(size * 0.7), 4):
            r, g, b, a = sq.getpixel((x, y))
            if a > 200:
                px.append((r, g, b))
    return tuple(int(statistics.median(ch)) for ch in zip(*px)) if px else (4, 24, 91)


top, bot = rim(0.03, 0.055), rim(0.945, 0.97)
col = Image.new("RGB", (1, CANVAS))
for y in range(CANVAS):
    t = min(1.0, max(0.0, (y - off) / size))
    col.putpixel((0, y), tuple(round(top[i] * (1 - t) + bot[i] * t) for i in range(3)))
col.resize((CANVAS, CANVAS)).save(f"{out}/icon-background.png")
print("adaptive icons written:", f"{out}/icon-foreground.png", f"{out}/icon-background.png", "top", top, "bottom", bot)
