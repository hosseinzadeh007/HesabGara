# ساخت اپ اندروید حساب‌گرا (APK)

روی کامپیوتر ویندوز، بعد از نصب Node.js 18+ و Android Studio (یک بار باز شود تا SDK دانلود شود):

```
cd mobile\android-app
.\Build-Android.ps1
```
خروجی: `mobile\HesabGara-mobile.apk` ← به گوشی بفرستید و نصب کنید (اجازه‌ی «نصب از منبع ناشناس» لازم است).
این پروژه روی این سیستم build و روی گوشی تست نشده؛ اگر اسکریپت خطا داد متن خطا را بفرستید.

- آیکون از لوگوی حساب‌گرا ساخته می‌شود (`assets/icon-only.png`؛ منبع حداکثر ۲۵۶ پیکسل است، با فایل ۱۰۲۴×۱۰۲۴ اصلی شفاف‌تر می‌شود).
- برای به‌روزرسانی ظاهر: `www/index.html` را عوض کنید و دوباره `Build-Android.ps1` را اجرا کنید.
- نسخه‌ی debug برای استفاده‌ی شخصی کافی است؛ برای فروشگاه، امضای release لازم است.
- بدون نیاز به ساخت APK، نسخه‌ی نصبی وب در `mobile/pwa` است.

## ساخت آنلاین (بدون نصب چیزی روی کامپیوتر)
**روش الف: GitHub Actions (APK کامل با لوگو)**
1. در github.com یک مخزن **خصوصی (Private)** بسازید.
2. فقط محتوای همین پوشه (`android-app`) را در آن آپلود کنید، نه کل پروژه‌ی حساب‌گرا.
3. تب Actions ← «Build Android APK» ← «Run workflow». بعد از چند دقیقه، فایل `HesabGara-apk` را از پایین صفحه‌ی اجرا دانلود کنید (داخلش `app-debug.apk` است).

**روش ب: PWABuilder (بدون GitHub)**
1. پوشه‌ی `mobile/pwa` را روی یک آدرس HTTPS بگذارید (مثلاً Netlify Drop).
2. در pwabuilder.com آدرس را وارد کنید ← Package for stores ← Android ← دانلود.

## نسخه‌ی ساده برای GitHub (فقط سه فایل)
پوشه‌ی `standalone` را ببینید: `hesabgara-app.html` و `hesabgara-icon.png` را در ریشه‌ی مخزن بگذارید و `build-android.yml` را در `.github/workflows/` بسازید. پروژه‌ی اندروید داخل خود Actions ساخته می‌شود و نیازی به آپلود پوشه نیست.
