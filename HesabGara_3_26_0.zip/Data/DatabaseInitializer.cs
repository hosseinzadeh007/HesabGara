using System.Text.RegularExpressions;
using HesabGara.Services;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Data;

public static class DatabaseInitializer
{
    public static void Initialize()
    {
        var cfg = DatabaseConfigurationStore.Load();
        if (cfg is null)
            throw new InvalidOperationException("تنظیمات پایگاه داده قابل بارگذاری نیست.");

        if (cfg.Provider == DatabaseProvider.SqlServer && string.IsNullOrWhiteSpace(cfg.ConnectionString))
            throw new InvalidOperationException("تنظیمات SQL Server ناقص است. برنامه را دوباره اجرا کنید تا حالت محلی انتخاب شود.");

        using var db = new AppDbContext();
        try
        {
            db.Database.EnsureCreated();
            if (!db.Database.CanConnect())
                throw new InvalidOperationException("پایگاه داده ایجاد شد اما اتصال به آن برقرار نشد.");
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"ایجاد/باز کردن پایگاه داده ناموفق بود. نوع پایگاه داده: {cfg.Provider}. مسیر SQLite: {AppDbContext.DatabasePath}", ex);
        }
        if (cfg.Provider == DatabaseProvider.Sqlite)
        {
            db.Database.ExecuteSqlRaw("PRAGMA foreign_keys = ON;");
            db.Database.ExecuteSqlRaw("PRAGMA journal_mode = WAL;");
            db.Database.ExecuteSqlRaw("PRAGMA synchronous = NORMAL;");
            foreach (var c in AdditiveColumns) EnsureColumn(db, c.Table, c.Column, c.Sqlite);
            db.Database.ExecuteSqlRaw("CREATE TABLE IF NOT EXISTS Settings (Id INTEGER NOT NULL CONSTRAINT PK_Settings PRIMARY KEY AUTOINCREMENT, Key TEXT NOT NULL, Value TEXT NOT NULL DEFAULT '')");
            db.Database.ExecuteSqlRaw("CREATE UNIQUE INDEX IF NOT EXISTS IX_Settings_Key ON Settings(Key)");
        }
        else if (cfg.Provider == DatabaseProvider.SqlServer)
        {
            // EnsureCreated() دیتابیس موجود را ارتقا نمی‌دهد؛ ستون‌های جدید به‌صورت افزایشی اضافه می‌شوند.
            foreach (var c in AdditiveColumns) EnsureSqlServerColumn(db, c.Table, c.Column, c.SqlServer);
            db.Database.ExecuteSqlRaw("""
                IF OBJECT_ID(N'[dbo].[Settings]', N'U') IS NULL
                BEGIN
                    CREATE TABLE [dbo].[Settings] ([Id] int IDENTITY(1,1) NOT NULL CONSTRAINT [PK_Settings] PRIMARY KEY, [Key] nvarchar(450) NOT NULL, [Value] nvarchar(max) NOT NULL);
                    CREATE UNIQUE INDEX [IX_Settings_Key] ON [dbo].[Settings]([Key]);
                END
                """);
        }

        // مهاجرت داده (پس از ساختار، قبل از هر همگام‌سازی Paid).
        LegacyPaidMigration.Run(db);
    }

    // همه‌ی تغییرات افزایشی ساختار در یک جدول: برای ستون جدید فقط یک ردیف اینجا اضافه کنید.
    sealed record ColumnSpec(string Table, string Column, string Sqlite, string SqlServer);

    static readonly ColumnSpec[] AdditiveColumns =
    {
        new("Users", "CanManageData", "INTEGER NOT NULL DEFAULT 1", "bit NOT NULL CONSTRAINT DF_Users_CanManageData DEFAULT 1"),
        new("Users", "CanViewReports", "INTEGER NOT NULL DEFAULT 1", "bit NOT NULL CONSTRAINT DF_Users_CanViewReports DEFAULT 1"),
        new("Users", "CanImportExport", "INTEGER NOT NULL DEFAULT 1", "bit NOT NULL CONSTRAINT DF_Users_CanImportExport DEFAULT 1"),
        new("Users", "CanBackup", "INTEGER NOT NULL DEFAULT 1", "bit NOT NULL CONSTRAINT DF_Users_CanBackup DEFAULT 1"),
        new("Users", "SecurityQuestion", "TEXT NULL", "nvarchar(256) NULL"),
        new("Users", "SecurityAnswerHash", "TEXT NULL", "nvarchar(256) NULL"),
        new("AuditLogs", "UserId", "INTEGER NULL", "int NULL"),
        new("AuditLogs", "UserName", "TEXT NULL", "nvarchar(256) NULL"),
        new("AuditLogs", "IpAddress", "TEXT NULL", "nvarchar(64) NULL"),
        new("Payments", "PaymentMethod", "TEXT NOT NULL DEFAULT 'نقد'", "nvarchar(32) NOT NULL CONSTRAINT DF_Payments_PaymentMethod DEFAULT N'نقد'"),
        new("Payments", "CheckNumber", "TEXT NULL", "nvarchar(128) NULL"),
        new("Payments", "CheckDate", "TEXT NULL", "datetime2 NULL"),
        new("Payments", "CheckStatus", "TEXT NULL", "nvarchar(32) NULL"),
    };

    static void EnsureSqlServerColumn(AppDbContext db, string table, string column, string definition)
    {
        var exists = db.Database.SqlQueryRaw<int>("SELECT COUNT(*) AS Value FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = {0} AND COLUMN_NAME = {1}", new object[] { table, column }).AsEnumerable().FirstOrDefault() > 0;
        if (!exists) db.Database.ExecuteSqlRaw("ALTER TABLE [" + table + "] ADD [" + column + "] " + definition);
    }

    static void EnsureColumn(AppDbContext db, string table, string column, string definition)
    {
        if (!IsSafeIdentifier(table) || !IsSafeIdentifier(column)) throw new ArgumentException("نام جدول یا ستون پایگاه‌داده معتبر نیست.");
        var exists = db.Database.SqlQueryRaw<int>("SELECT COUNT(*) AS Value FROM pragma_table_info({0}) WHERE name = {1}", new object[] { table, column }).AsEnumerable().FirstOrDefault() > 0;
        if (!exists) db.Database.ExecuteSqlRaw("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
        static bool IsSafeIdentifier(string value) => !string.IsNullOrWhiteSpace(value) && Regex.IsMatch(value, @"^[A-Za-z_][A-Za-z0-9_]*$");
    }
}
