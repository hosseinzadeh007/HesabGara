using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

public class CompanyStatementTests : DatabaseTestBase
{
    static readonly Company Co = new() { Id = 1, Name = "شرکت نمونه", NationalId = "1234567890" };

    static Invoice Inv(int id, string number, decimal amount, decimal returned, DateTime date) =>
        new() { Id = id, Number = number, CompanyId = 1, Company = Co, Amount = amount, ReturnedAmount = returned, InvoiceDate = date, DueDate = date.AddDays(30) };

    static Payment Pay(int id, Invoice inv, decimal amount, DateTime date, string method = "نقد", string? checkNo = null, string? note = null) =>
        new() { Id = id, InvoiceId = inv.Id, Invoice = inv, Amount = amount, PayDate = date, PaymentMethod = method, CheckNumber = checkNo, CheckDate = checkNo is null ? null : date.AddDays(20), CheckStatus = checkNo is null ? null : "در انتظار وصول", Note = note };

    static (List<Invoice>, List<Payment>) Sample()
    {
        var a = Inv(1, "A-1", 1000m, 200m, new DateTime(2026, 1, 1));
        var b = Inv(2, "A-2", 500m, 0m, new DateTime(2026, 1, 10));
        var pays = new List<Payment>
        {
            Pay(1, a, 300m, new DateTime(2026, 1, 5)),
            Pay(2, a, 200m, new DateTime(2026, 1, 12), "چک", "777"),   // یک چک برای دو فاکتور
            Pay(3, b, 100m, new DateTime(2026, 1, 12), "چک", "777")
        };
        return (new List<Invoice> { a, b }, pays);
    }

    [Fact]
    public void Running_Balance_Totals_And_Order_Are_Correct()
    {
        var (invoices, payments) = Sample();
        var r = CompanyStatement.Build(invoices, payments, null, null);

        Assert.Equal(5, r.Lines.Count);                                   // فاکتور، مرجوعی، وصول نقد، فاکتور دوم، «یک» چک
        Assert.Equal("فاکتور A-1", r.Lines[0].Description);               // در یک روز: فاکتور قبل از مرجوعی
        Assert.Equal("مرجوعی فاکتور A-1", r.Lines[1].Description);
        Assert.Equal(new[] { 1000m, 800m, 500m, 1000m, 700m }, r.Lines.Select(l => l.Balance));
        Assert.Equal(1500m, r.TotalDebit);
        Assert.Equal(800m, r.TotalCredit);
        Assert.Equal(700m, r.Closing);
        Assert.Equal(0m, r.Opening);
    }

    [Fact]
    public void A_Check_For_Several_Invoices_Is_One_Row_Naming_Both_Invoices()
    {
        var (invoices, payments) = Sample();
        var r = CompanyStatement.Build(invoices, payments, null, null);
        var check = Assert.Single(r.Lines, l => l.Description.StartsWith("وصول چک"));
        Assert.Equal(300m, check.Credit);
        Assert.Contains("A-1 (200)", check.Reference);
        Assert.Contains("A-2 (100)", check.Reference);
    }

    [Fact]
    public void From_Date_Turns_Earlier_Movements_Into_An_Opening_Balance()
    {
        var (invoices, payments) = Sample();
        var r = CompanyStatement.Build(invoices, payments, new DateTime(2026, 1, 10), null);
        Assert.Equal(500m, r.Opening);                                     // 1000 - 200 - 300
        Assert.Equal(2, r.Lines.Count);
        Assert.Equal(new[] { 1000m, 700m }, r.Lines.Select(l => l.Balance));
        Assert.Equal(500m, r.TotalDebit);
        Assert.Equal(300m, r.TotalCredit);
        Assert.Equal(700m, r.Closing);
    }

    [Fact]
    public void To_Date_Cuts_Later_Movements()
    {
        var (invoices, payments) = Sample();
        var r = CompanyStatement.Build(invoices, payments, null, new DateTime(2026, 1, 5));
        Assert.Equal(3, r.Lines.Count);
        Assert.Equal(500m, r.Closing);
    }

    [Fact]
    public async Task Closing_Balance_Equals_The_Sum_Of_Invoice_Balances_In_A_Real_Database()
    {
        var s = new AccountingService();
        var company = new Company { Name = "شرکت صورت‌حساب" };
        await s.AddCompanyAsync(company);
        var i1 = new Invoice { CompanyId = company.Id, Number = "D-1", Amount = 1000m, ReturnedAmount = 150m, InvoiceDate = DateTime.Today.AddDays(-20), DueDate = DateTime.Today.AddDays(10) };
        var i2 = new Invoice { CompanyId = company.Id, Number = "D-2", Amount = 600m, InvoiceDate = DateTime.Today.AddDays(-10), DueDate = DateTime.Today.AddDays(20) };
        await s.AddInvoiceAsync(i1); await s.AddInvoiceAsync(i2);
        await s.AddPaymentAsync(new Payment { InvoiceId = i1.Id, Amount = 250m, PayDate = DateTime.Today.AddDays(-15), PaymentMethod = "نقد" });
        await s.AddSplitPaymentAsync(new List<int> { i1.Id, i2.Id }, 700m, DateTime.Today.AddDays(-5), "چک", "9001", DateTime.Today.AddDays(30), "در انتظار وصول", null);

        var invoices = await s.GetInvoicesAsync(company.Id);
        var payments = await s.GetPaymentsAsync(company.Id);
        var r = CompanyStatement.Build(invoices, payments, null, null);

        Assert.Equal(invoices.Sum(AccountingService.Balance), r.Closing);
        Assert.Equal(1, r.Lines.Count(l => l.Description.StartsWith("وصول چک")));   // چک مشترک فقط یک ردیف
    }
}
