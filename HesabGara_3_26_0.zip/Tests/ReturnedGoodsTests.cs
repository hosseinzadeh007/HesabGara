using HesabGara.Data;
using HesabGara.Models;
using HesabGara.Services;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace HesabGara.Tests;

/// <summary>مرجوعی: مبلغ خالص = مبلغ کل − مرجوعی، و مانده و وصول همیشه بر اساس خالص‌اند.</summary>
public class ReturnedGoodsTests : DatabaseTestBase
{
    static readonly AccountingService S = new();

    static async Task<Invoice> SeedAsync(decimal amount, decimal returned = 0m, decimal paid = 0m)
    {
        var company = new Company { Name = "شرکت مرجوعی " + Guid.NewGuid().ToString("N")[..6] };
        await S.AddCompanyAsync(company);
        var invoice = new Invoice { CompanyId = company.Id, Number = "M-1", Amount = amount, ReturnedAmount = returned, Paid = paid, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(30) };
        await S.AddInvoiceAsync(invoice);
        return invoice;
    }

    static async Task<Invoice> ReloadAsync(int id) => (await S.GetInvoicesAsync()).Single(x => x.Id == id);

    [Fact]
    public async Task Net_Amount_And_Balance_Subtract_The_Returned_Goods()
    {
        var inv = await SeedAsync(1000m, returned: 200m, paid: 300m);
        var stored = await ReloadAsync(inv.Id);
        Assert.Equal(200m, stored.ReturnedAmount);
        Assert.Equal(800m, stored.NetAmount);
        Assert.Equal(500m, AccountingService.Balance(stored));      // 1000 - 200 - 300
    }

    [Theory]
    [InlineData(-1)]
    [InlineData(1001)]
    public async Task Returned_Amount_Must_Be_Between_Zero_And_The_Total(double returned)
    {
        var company = new Company { Name = "ک" };
        await S.AddCompanyAsync(company);
        var bad = new Invoice { CompanyId = company.Id, Number = "X", Amount = 1000m, ReturnedAmount = (decimal)returned, InvoiceDate = DateTime.Today, DueDate = DateTime.Today };
        await Assert.ThrowsAsync<ArgumentException>(() => S.AddInvoiceAsync(bad));
    }

    [Fact]
    public async Task Payments_Are_Limited_To_The_Net_Balance()
    {
        var inv = await SeedAsync(1000m, returned: 400m);
        await Assert.ThrowsAsync<InvalidOperationException>(() => S.AddPaymentAsync(new Payment { InvoiceId = inv.Id, Amount = 700m, PayDate = DateTime.Today }));

        await S.AddPaymentAsync(new Payment { InvoiceId = inv.Id, Amount = 600m, PayDate = DateTime.Today });
        Assert.Equal(0m, AccountingService.Balance(await ReloadAsync(inv.Id)));
    }

    [Fact]
    public async Task Editing_The_Returned_Amount_Updates_The_Balance()
    {
        var inv = await SeedAsync(1000m, paid: 300m);
        var edit = new Invoice { Id = inv.Id, CompanyId = inv.CompanyId, Number = inv.Number, Amount = 1000m, ReturnedAmount = 150m, InvoiceDate = inv.InvoiceDate, DueDate = inv.DueDate };
        await S.UpdateInvoiceAsync(edit);

        var stored = await ReloadAsync(inv.Id);
        Assert.Equal(150m, stored.ReturnedAmount);
        Assert.Equal(550m, AccountingService.Balance(stored));      // 1000 - 150 - 300
    }

    [Fact]
    public async Task Net_Amount_Cannot_Drop_Below_What_Was_Already_Paid()
    {
        var inv = await SeedAsync(1000m, paid: 700m);
        var edit = new Invoice { Id = inv.Id, CompanyId = inv.CompanyId, Number = inv.Number, Amount = 1000m, ReturnedAmount = 400m, InvoiceDate = inv.InvoiceDate, DueDate = inv.DueDate };
        await Assert.ThrowsAsync<InvalidOperationException>(() => S.UpdateInvoiceAsync(edit));    // خالص 600 < پرداختی 700
    }

    [Fact]
    public async Task Summary_And_Weighted_Due_Date_Use_The_Net_Amount()
    {
        var inv = await SeedAsync(1000m, returned: 400m);
        var summary = AccountingService.Summarize(new[] { await ReloadAsync(inv.Id) });
        Assert.Equal(600m, summary.TotalAmount);
        Assert.Equal(600m, summary.TotalBalance);
    }

    [Fact]
    public async Task Reconcile_Keeps_Returned_Amount_And_Caps_Paid_To_The_Net()
    {
        var inv = await SeedAsync(1000m, returned: 100m);
        await using (var db = new AppDbContext())
        {
            var e = await db.Invoices.SingleAsync(x => x.Id == inv.Id);
            e.Paid = 5000m;                    // شبیه‌سازی کَش خراب
            await db.SaveChangesAsync();
        }
        await S.ReconcilePaidAmountsAsync();
        var stored = await ReloadAsync(inv.Id);
        Assert.Equal(100m, stored.ReturnedAmount);
        Assert.Equal(0m, stored.Paid);         // بدون رکورد وصول
    }

    [Fact]
    public async Task Mobile_Export_Sends_Net_Amount_With_Gross_And_Returned()
    {
        var inv = await SeedAsync(1000m, returned: 150m);
        using var doc = System.Text.Json.JsonDocument.Parse(await new MobileExportService().BuildJsonAsync());
        var i = doc.RootElement.GetProperty("invoices")[0];
        Assert.Equal(850m, i.GetProperty("amount").GetDecimal());
        Assert.Equal(1000m, i.GetProperty("gross").GetDecimal());
        Assert.Equal(150m, i.GetProperty("returned").GetDecimal());
    }
}
