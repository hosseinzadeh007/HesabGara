using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

public class SecurityTests : DatabaseTestBase
{
    static readonly SecurityService Security = new();
    static readonly UserService Users = new();

    static async Task<AppUser> SeedAdminAsync() =>
        await Security.CreateFirstAdminAsync("admin", "مدیر", "StrongPass1", "نام اولین مدرسه؟", "Alborz");

    [Fact]
    public async Task Login_Is_Locked_After_Too_Many_Failures_Even_With_Correct_Password()
    {
        await SeedAdminAsync();
        for (var i = 0; i < SecurityService.MaxFailedAttempts; i++)
            Assert.Null(await Security.LoginAsync("admin", "wrong-password"));

        await Assert.ThrowsAsync<InvalidOperationException>(() => Security.LoginAsync("admin", "StrongPass1"));
    }

    [Fact]
    public async Task Correct_Password_Logs_In_Before_The_Limit()
    {
        await SeedAdminAsync();
        Assert.Null(await Security.LoginAsync("admin", "wrong-password"));
        Assert.NotNull(await Security.LoginAsync("admin", "StrongPass1"));
    }

    [Fact]
    public async Task Security_Answer_Guessing_Is_Locked_After_Too_Many_Failures()
    {
        await SeedAdminAsync();
        for (var i = 0; i < SecurityService.MaxFailedAttempts; i++)
            await Assert.ThrowsAsync<InvalidOperationException>(() => Security.ResetPasswordViaSecurityAnswerAsync("admin", "guess" + i, "NewStrongPass1"));

        // حتی پاسخ درست هم دیگر پذیرفته نمی‌شود.
        var ex = await Assert.ThrowsAsync<InvalidOperationException>(() => Security.ResetPasswordViaSecurityAnswerAsync("admin", "Alborz", "NewStrongPass1"));
        Assert.Contains("تلاش ناموفق", ex.Message);
    }

    [Fact]
    public async Task Last_Active_Admin_Cannot_Be_Deactivated_Through_Edit()
    {
        var admin = await SeedAdminAsync();
        var edit = new AppUser { Id = admin.Id, UserName = admin.UserName, DisplayName = admin.DisplayName, IsAdmin = true, IsActive = false, CanManageData = true, CanViewReports = true, CanImportExport = true, CanBackup = true };
        await Assert.ThrowsAsync<InvalidOperationException>(() => Users.UpdateAsync(edit, null));
    }
}
