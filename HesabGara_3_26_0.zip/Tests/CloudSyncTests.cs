using System.Net;
using System.Text;
using System.Text.Json;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

public class CloudCryptoTests
{
    // این بردار با WebCrypto مرورگر ساخته شده؛ یعنی قالب C# و گوشی دقیقاً هم‌خوان است.
    const string WebCryptoVector = """{"v":1,"kdf":"pbkdf2-sha256","iter":250000,"salt":"AQIDBAUGBwgJCgsMDQ4PEA==","iv":"ZWZnaGlqa2xtbm9w","ct":"uKbqo+kT2u4QU/F2wXtDXtzign/OJ+3v3MIEBvGEliLzZDAZsvCF0wA+cXE2UHDzWeY="}""";
    const string VectorPassword = "رمز-آزمایشی-123";

    [Fact]
    public void Roundtrip_With_Persian_Password_And_Text()
    {
        var plain = "{\"app\":\"HesabGara\",\"name\":\"شرکت آزمایشی\"}";
        var envelope = CloudCrypto.Encrypt(plain, "گذرواژه‌ی-قوی-۱۲۳");
        Assert.DoesNotContain("آزمایشی", envelope);
        Assert.Equal(plain, CloudCrypto.Decrypt(envelope, "گذرواژه‌ی-قوی-۱۲۳"));
    }

    [Fact]
    public void Wrong_Password_Is_Rejected()
    {
        var envelope = CloudCrypto.Encrypt("secret", "correct-password");
        var ex = Assert.Throws<InvalidOperationException>(() => CloudCrypto.Decrypt(envelope, "wrong-password"));
        Assert.Contains("رمز اشتباه", ex.Message);
    }

    [Fact]
    public void Tampered_Ciphertext_Is_Rejected()
    {
        using var doc = JsonDocument.Parse(CloudCrypto.Encrypt("secret", "correct-password"));
        var ct = Convert.FromBase64String(doc.RootElement.GetProperty("ct").GetString()!);
        ct[0] ^= 0x01;
        var json = $"{{\"v\":1,\"kdf\":\"pbkdf2-sha256\",\"iter\":{CloudCrypto.Iterations},\"salt\":\"{doc.RootElement.GetProperty("salt").GetString()}\",\"iv\":\"{doc.RootElement.GetProperty("iv").GetString()}\",\"ct\":\"{Convert.ToBase64String(ct)}\"}}";
        Assert.Throws<InvalidOperationException>(() => CloudCrypto.Decrypt(json, "correct-password"));
    }

    [Fact]
    public void Decrypts_Vector_Produced_By_WebCrypto()
        => Assert.Equal("{\"app\":\"HesabGara\",\"x\":\"سلام\"}", CloudCrypto.Decrypt(WebCryptoVector, VectorPassword));

    [Theory]
    [InlineData("not json")]
    [InlineData("{\"v\":2,\"kdf\":\"pbkdf2-sha256\",\"iter\":250000,\"salt\":\"AA==\",\"iv\":\"AA==\",\"ct\":\"AA==\"}")]
    [InlineData("{\"v\":1}")]
    public void Malformed_Envelopes_Fail_Cleanly(string envelope)
        => Assert.Throws<InvalidOperationException>(() => CloudCrypto.Decrypt(envelope, "any-password"));
}

public class CloudSyncServiceTests : DatabaseTestBase
{
    sealed class FakeHandler : HttpMessageHandler
    {
        public HttpRequestMessage? Request;
        public string? Body;
        public HttpStatusCode Status = HttpStatusCode.OK;

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
        {
            Request = request;
            Body = request.Content is null ? null : await request.Content.ReadAsStringAsync(ct);
            return new HttpResponseMessage(Status) { Content = new StringContent("{}", Encoding.UTF8, "application/json") };
        }
    }

    static CloudSyncSettings Settings(string password = "long-enough-password") =>
        new("https://sync.example.test", CloudSyncService.NewChannelId(), "api-key-123", password, false);

    [Fact]
    public void Pairing_Code_Roundtrips_And_Contains_No_Secrets()
    {
        var id = CloudSyncService.NewChannelId();
        Assert.Equal(32, id.Length);
        var code = CloudSyncService.BuildPairingCode("https://sync.example.test/", id);
        Assert.True(CloudSyncService.TryParsePairingCode(code, out var url, out var parsedId));
        Assert.Equal("https://sync.example.test", url);
        Assert.Equal(id, parsedId);
        Assert.False(CloudSyncService.TryParsePairingCode("HG1.garbage", out _, out _));
        Assert.False(CloudSyncService.TryParsePairingCode(CloudSyncService.BuildPairingCode("http://evil.test", id), out _, out _));
    }

    [Theory]
    [InlineData("http://example.com")]
    [InlineData("ftp://example.com")]
    [InlineData("not a url")]
    public void ServerUrl_Must_Be_Https(string url)
        => Assert.Throws<ArgumentException>(() => CloudSyncService.NormalizeServerUrl(url));

    [Fact]
    public async Task Push_Sends_Encrypted_Envelope_With_Bearer_Key()
    {
        await new AccountingService().AddCompanyAsync(new HesabGara.Models.Company { Name = "شرکت ابری" });
        var handler = new FakeHandler();
        var s = Settings();

        var bytes = await new CloudSyncService(new HttpClient(handler)).PushAsync(s);

        Assert.True(bytes > 0);
        Assert.Equal(HttpMethod.Put, handler.Request!.Method);
        Assert.Equal(CloudSyncService.BlobUrl(s.ServerUrl, s.ChannelId), handler.Request.RequestUri!.ToString());
        Assert.Equal("Bearer", handler.Request.Headers.Authorization!.Scheme);
        Assert.Equal("api-key-123", handler.Request.Headers.Authorization.Parameter);
        Assert.DoesNotContain("شرکت ابری", handler.Body!);
        using var doc = JsonDocument.Parse(CloudCrypto.Decrypt(handler.Body!, s.Password));
        Assert.Equal("HesabGara", doc.RootElement.GetProperty("app").GetString());
        Assert.Equal("شرکت ابری", doc.RootElement.GetProperty("companies")[0].GetProperty("name").GetString());
    }

    [Fact]
    public async Task Push_Maps_Unauthorized_To_Readable_Message()
    {
        var ex = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            new CloudSyncService(new HttpClient(new FakeHandler { Status = HttpStatusCode.Unauthorized })).PushAsync(Settings()));
        Assert.Contains("کلید ارسال", ex.Message);
    }

    [Fact]
    public async Task Push_Rejects_Short_Password_Without_Calling_The_Network()
    {
        var handler = new FakeHandler();
        await Assert.ThrowsAsync<InvalidOperationException>(() => new CloudSyncService(new HttpClient(handler)).PushAsync(Settings("short")));
        Assert.Null(handler.Request);
    }
}
