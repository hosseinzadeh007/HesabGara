using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

public class BackupRetentionTests
{
    static string NewTempDir()
    {
        var dir = Path.Combine(Path.GetTempPath(), $"HesabGara-tests-retention-{Guid.NewGuid():N}");
        Directory.CreateDirectory(dir);
        return dir;
    }

    static void Touch(string dir, string name) => File.WriteAllText(Path.Combine(dir, name), "x");

    [Fact]
    public void Prune_Keeps_Newest_And_Never_Touches_Foreign_Files()
    {
        var dir = NewTempDir();
        try
        {
            foreach (var n in new[] { "HesabGara_20260101_000000.db", "HesabGara_20260102_000000.db", "HesabGara_20260103_000000.db", "HesabGara_20260104_000000.bak", "HesabGara_20260105_000000.db" })
                Touch(dir, n);
            Touch(dir, "notes.txt");
            Touch(dir, "HesabGara_manual-copy.db");   // نام دستی کاربر: الگوی پشتیبان خودکار نیست
            Touch(dir, "accounting.db");

            var deleted = BackupService.PruneOldBackups(dir, 2);

            Assert.Equal(3, deleted);
            Assert.True(File.Exists(Path.Combine(dir, "HesabGara_20260105_000000.db")));
            Assert.True(File.Exists(Path.Combine(dir, "HesabGara_20260104_000000.bak")));
            Assert.False(File.Exists(Path.Combine(dir, "HesabGara_20260103_000000.db")));
            Assert.False(File.Exists(Path.Combine(dir, "HesabGara_20260101_000000.db")));
            Assert.True(File.Exists(Path.Combine(dir, "notes.txt")));
            Assert.True(File.Exists(Path.Combine(dir, "HesabGara_manual-copy.db")));
            Assert.True(File.Exists(Path.Combine(dir, "accounting.db")));
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void Prune_With_Zero_Or_Negative_Keep_Deletes_Nothing(int keep)
    {
        var dir = NewTempDir();
        try
        {
            Touch(dir, "HesabGara_20260101_000000.db");
            Touch(dir, "HesabGara_20260102_000000.db");
            Assert.Equal(0, BackupService.PruneOldBackups(dir, keep));
            Assert.Equal(2, Directory.GetFiles(dir).Length);
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    [Fact]
    public void Prune_On_Missing_Folder_Is_A_Noop()
        => Assert.Equal(0, BackupService.PruneOldBackups(Path.Combine(Path.GetTempPath(), "HesabGara-does-not-exist-" + Guid.NewGuid().ToString("N")), 5));

    [Fact]
    public void Restore_Safety_Copies_Are_Limited_To_The_Newest_Ones()
    {
        var dir = NewTempDir();
        try
        {
            var db = Path.Combine(dir, "accounting.db");
            Touch(dir, "accounting.db");
            for (var i = 1; i <= 4; i++) Touch(dir, $"accounting.db.before-restore-2026010{i}_000000");

            Assert.Equal(2, BackupService.PruneRestoreSafetyCopies(db, 2));
            Assert.True(File.Exists(db));
            Assert.True(File.Exists(Path.Combine(dir, "accounting.db.before-restore-20260104_000000")));
            Assert.True(File.Exists(Path.Combine(dir, "accounting.db.before-restore-20260103_000000")));
            Assert.False(File.Exists(Path.Combine(dir, "accounting.db.before-restore-20260101_000000")));
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }
}
