using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

public class CheckGroupingTests : DatabaseTestBase
{
    static Payment Check(int id, int invoiceId, string invoiceNumber, int companyId, decimal amount, string? number, DateTime? date, string? status = "در انتظار وصول") =>
        new()
        {
            Id = id, InvoiceId = invoiceId, Amount = amount, PaymentMethod = "چک", CheckNumber = number, CheckDate = date, CheckStatus = status,
            Invoice = new Invoice { Id = invoiceId, Number = invoiceNumber, CompanyId = companyId, Company = new Company { Id = companyId, Name = "شرکت " + companyId } }
        };

    [Fact]
    public void One_Check_Issued_For_Several_Invoices_Becomes_One_Row_With_All_Its_Invoices()
    {
        var date = new DateTime(2026, 11, 1);
        var groups = CheckGrouping.Group(new[]
        {
            Check(1, 10, "A-1", 1, 300m, "777", date),
            Check(2, 11, "A-2", 1, 200m, "777", date),
            Check(3, 12, "B-1", 2, 150m, "555", date)
        });

        Assert.Equal(2, groups.Count);
        var multi = groups.Single(g => g.CheckNumber == "777");
        Assert.Equal(500m, multi.Amount);
        Assert.Equal(2, multi.Invoices.Count);
        Assert.Contains("A-1 (300)", multi.InvoiceText);
        Assert.Contains("A-2 (200)", multi.InvoiceText);
        Assert.Equal("B-1", groups.Single(g => g.CheckNumber == "555").InvoiceText);   // یک فاکتور: فقط شماره
    }

    [Fact]
    public void Same_Number_For_Other_Company_Or_Other_Date_Or_No_Number_Is_Not_Merged()
    {
        var d1 = new DateTime(2026, 11, 1); var d2 = new DateTime(2026, 12, 1);
        var groups = CheckGrouping.Group(new[]
        {
            Check(1, 10, "A-1", 1, 100m, "900", d1),
            Check(2, 11, "B-1", 2, 100m, "900", d1),   // شرکت دیگر
            Check(3, 12, "A-2", 1, 100m, "900", d2),   // تاریخ دیگر
            Check(4, 13, "A-3", 1, 100m, null, d1),    // بدون شماره
            Check(5, 14, "A-4", 1, 100m, " ", d1)      // شماره‌ی خالی
        });
        Assert.Equal(5, groups.Count);
    }

    [Fact]
    public void Status_Of_A_Mixed_Group_Prefers_Returned_Then_Pending()
    {
        var d = new DateTime(2026, 11, 1);
        var mixed = CheckGrouping.Group(new[]
        {
            Check(1, 10, "A-1", 1, 100m, "1", d, "وصول\u200cشده"),
            Check(2, 11, "A-2", 1, 100m, "1", d, "برگشتی")
        }).Single();
        Assert.Equal("برگشتی", mixed.Status);

        var pending = CheckGrouping.Group(new[]
        {
            Check(3, 10, "A-1", 1, 100m, "2", d, "وصول\u200cشده"),
            Check(4, 11, "A-2", 1, 100m, "2", d, "در انتظار وصول")
        }).Single();
        Assert.Equal("در انتظار وصول", pending.Status);
    }

    [Fact]
    public void Groups_Are_Ordered_By_Nearest_Check_Date()
    {
        var groups = CheckGrouping.Group(new[]
        {
            Check(1, 10, "A-1", 1, 100m, "late", new DateTime(2026, 12, 1)),
            Check(2, 11, "A-2", 1, 100m, "soon", new DateTime(2026, 11, 1)),
            Check(3, 12, "A-3", 1, 100m, "none", null)
        });
        Assert.Equal(new[] { "soon", "late", "none" }, groups.Select(g => g.CheckNumber));
    }

    [Fact]
    public async Task A_Real_Split_Payment_Shows_Up_As_One_Check_For_Both_Invoices()
    {
        var s = new AccountingService();
        var company = new Company { Name = "شرکت چک مشترک" };
        await s.AddCompanyAsync(company);
        var i1 = new Invoice { CompanyId = company.Id, Number = "S-1", Amount = 1000m, InvoiceDate = DateTime.Today.AddDays(-10), DueDate = DateTime.Today.AddDays(5) };
        var i2 = new Invoice { CompanyId = company.Id, Number = "S-2", Amount = 500m, InvoiceDate = DateTime.Today.AddDays(-5), DueDate = DateTime.Today.AddDays(10) };
        await s.AddInvoiceAsync(i1); await s.AddInvoiceAsync(i2);

        await s.AddSplitPaymentAsync(new List<int> { i1.Id, i2.Id }, 1300m, DateTime.Today, "چک", "4455", DateTime.Today.AddDays(20), "در انتظار وصول", null);

        var checks = (await s.GetPaymentsAsync(company.Id)).Where(p => p.PaymentMethod == "چک").ToList();
        Assert.True(checks.Count >= 2);                        // در دیتابیس برای هر فاکتور یک رکورد وصول
        var groups = CheckGrouping.Group(checks);
        var one = Assert.Single(groups);                       // ولی در گزارش فقط یک چک
        Assert.Equal(1300m, one.Amount);
        Assert.Contains("S-1", one.InvoiceText);
        Assert.Contains("S-2", one.InvoiceText);
    }
}
