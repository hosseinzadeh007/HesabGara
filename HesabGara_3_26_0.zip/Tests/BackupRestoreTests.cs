using HesabGara.Data;
using HesabGara.Models;
using HesabGara.Services;
using Microsoft.Data.Sqlite;
using Xunit;

namespace HesabGara.Tests;

public class BackupRestoreTests : DatabaseTestBase
{
    static readonly AccountingService S = new();
    static readonly BackupService Backup = new();

    static string NewTempDir()
    {
        var dir = Path.Combine(Path.GetTempPath(), $"HesabGara-tests-backup-{Guid.NewGuid():N}");
        Directory.CreateDirectory(dir);
        return dir;
    }

    [Fact]
    public async Task Restore_Returns_Database_To_Backup_State_And_Keeps_Safety_Copy()
    {
        var dir = NewTempDir();
        try
        {
            await S.AddCompanyAsync(new Company { Name = "قبل از پشتیبان" });
            var backupFile = await Backup.CreateBackupAsync(dir);

            // تغییرات بعد از پشتیبان (باید با بازیابی برگردند).
            await S.AddCompanyAsync(new Company { Name = "بعد از پشتیبان" });
            Assert.Equal(2, (await S.GetCompaniesAsync()).Count);

            var safety = await Backup.RestoreBackupAsync(backupFile);

            var companies = await S.GetCompaniesAsync();
            Assert.Equal("قبل از پشتیبان", Assert.Single(companies).Name);

            // نسخه‌ی ایمنی باید وضعیت قبل از بازیابی (هر دو شرکت) را داشته باشد.
            Assert.True(File.Exists(safety));
            await using var conn = new SqliteConnection($"Data Source={safety};Mode=ReadOnly");
            await conn.OpenAsync();
            await using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM Companies;";
            Assert.Equal(2L, Convert.ToInt64(await cmd.ExecuteScalarAsync()));
            SqliteConnection.ClearAllPools();
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    [Fact]
    public async Task Restore_Rejects_Foreign_Sqlite_File_And_Leaves_Data_Untouched()
    {
        var dir = NewTempDir();
        try
        {
            await S.AddCompanyAsync(new Company { Name = "شرکت اصلی" });

            var foreign = Path.Combine(dir, "other.db");
            await using (var conn = new SqliteConnection($"Data Source={foreign}"))
            {
                await conn.OpenAsync();
                await using var cmd = conn.CreateCommand();
                cmd.CommandText = "CREATE TABLE Notes(Id INTEGER PRIMARY KEY, Text TEXT);";
                await cmd.ExecuteNonQueryAsync();
            }
            SqliteConnection.ClearAllPools();

            await Assert.ThrowsAsync<InvalidOperationException>(() => Backup.RestoreBackupAsync(foreign));
            Assert.Equal("شرکت اصلی", Assert.Single(await S.GetCompaniesAsync()).Name);
        }
        finally { try { Directory.Delete(dir, true); } catch { } }
    }

    [Fact]
    public async Task Restore_Rejects_The_Live_Database_File_Itself()
    {
        await S.AddCompanyAsync(new Company { Name = "شرکت" });
        await Assert.ThrowsAsync<InvalidOperationException>(() => Backup.RestoreBackupAsync(AppDbContext.DatabasePath));
        Assert.Single(await S.GetCompaniesAsync());
    }
}
