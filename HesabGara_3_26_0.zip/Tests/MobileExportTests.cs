using System.Text.Json;
using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

public class MobileExportTests : DatabaseTestBase
{
    [Fact]
    public async Task Export_Contains_All_Entities_With_Persian_Dates()
    {
        var s = new AccountingService();
        var company = new Company { Name = "شرکت موبایل" };
        await s.AddCompanyAsync(company);
        var invoice = new Invoice { CompanyId = company.Id, Number = "M-1", Amount = 1000m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(10) };
        await s.AddInvoiceAsync(invoice);
        await s.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 300m, PayDate = DateTime.Today, PaymentMethod = "چک", CheckNumber = "77", CheckDate = DateTime.Today.AddDays(5), CheckStatus = "در انتظار وصول" });

        var path = Path.Combine(Path.GetTempPath(), $"HesabGara-tests-mobile-{Guid.NewGuid():N}.json");
        try
        {
            await new MobileExportService().ExportAsync(path);
            using var doc = JsonDocument.Parse(await File.ReadAllTextAsync(path));
            var root = doc.RootElement;
            Assert.Equal("HesabGara", root.GetProperty("app").GetString());
            Assert.Equal("شرکت موبایل", root.GetProperty("companies")[0].GetProperty("name").GetString());
            var inv = root.GetProperty("invoices")[0];
            Assert.Equal(1000m, inv.GetProperty("amount").GetDecimal());
            Assert.Equal(300m, inv.GetProperty("paid").GetDecimal());
            Assert.Equal(PersianDateService.ToPersian(DateTime.Today), inv.GetProperty("dateFa").GetString());
            var pay = root.GetProperty("payments")[0];
            Assert.Equal("77", pay.GetProperty("checkNumber").GetString());
            Assert.Equal(inv.GetProperty("id").GetInt32(), pay.GetProperty("invoiceId").GetInt32());
        }
        finally { try { File.Delete(path); } catch { } }
    }
}
