﻿using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Data;

public sealed class AppDbContext : DbContext
{
    public DbSet<Company> Companies => Set<Company>();
    public DbSet<Invoice> Invoices => Set<Invoice>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<AppSetting> Settings => Set<AppSetting>();

    public static string DatabaseDirectory => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AccountingPurchasePro");
    public static string DatabasePath => Path.Combine(DatabaseDirectory, "accounting.db");

    public AppDbContext() => Directory.CreateDirectory(DatabaseDirectory);
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) => Directory.CreateDirectory(DatabaseDirectory);

    protected override void OnConfiguring(DbContextOptionsBuilder options)
    {
        var cfg = DatabaseConfigurationStore.Load();
        if (cfg.Provider == DatabaseProvider.SqlServer && !string.IsNullOrWhiteSpace(cfg.ConnectionString))
            options.UseSqlServer(cfg.ConnectionString, sql => sql.EnableRetryOnFailure(5));
        else
            options.UseSqlite($"Data Source={DatabasePath};Cache=Shared;Foreign Keys=True");
    }

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Company>().HasIndex(x => x.Name).IsUnique();
        b.Entity<Company>().HasIndex(x => x.NationalId).IsUnique();
        b.Entity<Invoice>().HasIndex(x => new { x.CompanyId, x.Number }).IsUnique();
        b.Entity<Invoice>().HasIndex(x => new { x.CompanyId, x.DueDate });
        b.Entity<Payment>().HasIndex(x => new { x.InvoiceId, x.PayDate });
        b.Entity<Payment>().HasIndex(x => x.PaymentMethod);
        b.Entity<AuditLog>().HasIndex(x => x.TimestampUtc);
        b.Entity<AuditLog>().HasIndex(x => x.UserId);
        b.Entity<AuditLog>().HasIndex(x => x.IpAddress);
        b.Entity<AppUser>().HasIndex(x => x.UserName).IsUnique();
        b.Entity<AppSetting>().HasIndex(x => x.Key).IsUnique();
        b.Entity<Invoice>().Property(x => x.Amount).HasPrecision(18, 2);
        b.Entity<Invoice>().Property(x => x.Paid).HasPrecision(18, 2);
        b.Entity<Payment>().Property(x => x.Amount).HasPrecision(18, 2);
        b.Entity<Invoice>().HasOne(x => x.Company).WithMany(x => x.Invoices).HasForeignKey(x => x.CompanyId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<Payment>().HasOne(x => x.Invoice).WithMany(x => x.Payments).HasForeignKey(x => x.InvoiceId).OnDelete(DeleteBehavior.Cascade);
    }
}
