using System.Text.RegularExpressions;
using AccountingPurchasePro.Services;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Data;

public static class DatabaseInitializer
{
    public static void Initialize()
    {
        var cfg = DatabaseConfigurationStore.Load();
        if (cfg is null)
            throw new InvalidOperationException("تنظیمات پایگاه داده قابل بارگذاری نیست.");

        if (cfg.Provider == DatabaseProvider.SqlServer && string.IsNullOrWhiteSpace(cfg.ConnectionString))
            throw new InvalidOperationException("تنظیمات SQL Server ناقص است. برنامه را دوباره اجرا کنید تا حالت محلی انتخاب شود.");

        using var db = new AppDbContext();
        try
        {
            db.Database.EnsureCreated();
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"ایجاد/باز کردن پایگاه داده ناموفق بود. نوع پایگاه داده: {cfg.Provider}.", ex);
        }
        if (cfg.Provider == DatabaseProvider.Sqlite)
        {
            db.Database.ExecuteSqlRaw("PRAGMA foreign_keys = ON;");
            db.Database.ExecuteSqlRaw("PRAGMA journal_mode = WAL;");
            db.Database.ExecuteSqlRaw("PRAGMA synchronous = NORMAL;");
            EnsureColumn(db, "Users", "CanManageData", "INTEGER NOT NULL DEFAULT 1");
            EnsureColumn(db, "Users", "CanViewReports", "INTEGER NOT NULL DEFAULT 1");
            EnsureColumn(db, "Users", "CanImportExport", "INTEGER NOT NULL DEFAULT 1");
            EnsureColumn(db, "Users", "CanBackup", "INTEGER NOT NULL DEFAULT 1");
            EnsureColumn(db, "AuditLogs", "UserId", "INTEGER NULL");
            EnsureColumn(db, "AuditLogs", "UserName", "TEXT NULL");
            EnsureColumn(db, "AuditLogs", "IpAddress", "TEXT NULL");
            EnsureColumn(db, "Payments", "PaymentMethod", "TEXT NOT NULL DEFAULT 'نقد'");
            EnsureColumn(db, "Payments", "CheckNumber", "TEXT NULL");
            EnsureColumn(db, "Payments", "CheckDate", "TEXT NULL");
            EnsureColumn(db, "Payments", "CheckStatus", "TEXT NULL");
            db.Database.ExecuteSqlRaw("CREATE TABLE IF NOT EXISTS Settings (Id INTEGER NOT NULL CONSTRAINT PK_Settings PRIMARY KEY AUTOINCREMENT, Key TEXT NOT NULL, Value TEXT NOT NULL DEFAULT '')");
            db.Database.ExecuteSqlRaw("CREATE UNIQUE INDEX IF NOT EXISTS IX_Settings_Key ON Settings(Key)");
        }
        if (cfg.Provider == DatabaseProvider.SqlServer)
        {
            // Ensure additive schema changes for existing SQL Server databases.
            // EnsureCreated() does not migrate an already-existing database.
            EnsureSqlServerColumn(db, "Users", "CanManageData", "bit NOT NULL CONSTRAINT DF_Users_CanManageData DEFAULT 1");
            EnsureSqlServerColumn(db, "Users", "CanViewReports", "bit NOT NULL CONSTRAINT DF_Users_CanViewReports DEFAULT 1");
            EnsureSqlServerColumn(db, "Users", "CanImportExport", "bit NOT NULL CONSTRAINT DF_Users_CanImportExport DEFAULT 1");
            EnsureSqlServerColumn(db, "Users", "CanBackup", "bit NOT NULL CONSTRAINT DF_Users_CanBackup DEFAULT 1");
            EnsureSqlServerColumn(db, "AuditLogs", "UserId", "int NULL");
            EnsureSqlServerColumn(db, "AuditLogs", "UserName", "nvarchar(256) NULL");
            EnsureSqlServerColumn(db, "AuditLogs", "IpAddress", "nvarchar(64) NULL");
            EnsureSqlServerColumn(db, "Payments", "PaymentMethod", "nvarchar(32) NOT NULL CONSTRAINT DF_Payments_PaymentMethod DEFAULT N'نقد'");
            EnsureSqlServerColumn(db, "Payments", "CheckNumber", "nvarchar(128) NULL");
            EnsureSqlServerColumn(db, "Payments", "CheckDate", "datetime2 NULL");
            EnsureSqlServerColumn(db, "Payments", "CheckStatus", "nvarchar(32) NULL");
        }
    }

    static void EnsureSqlServerColumn(AppDbContext db, string table, string column, string definition)
    {
        var exists = db.Database.SqlQueryRaw<int>("SELECT COUNT(*) AS Value FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = {0} AND COLUMN_NAME = {1}", new object[] { table, column }).AsEnumerable().FirstOrDefault() > 0;
        if (!exists) db.Database.ExecuteSqlRaw("ALTER TABLE [" + table + "] ADD [" + column + "] " + definition);
    }

    static void EnsureColumn(AppDbContext db, string table, string column, string definition)
    {
        if (!IsSafeIdentifier(table) || !IsSafeIdentifier(column)) throw new ArgumentException("نام جدول یا ستون پایگاه‌داده معتبر نیست.");
        var exists = db.Database.SqlQueryRaw<int>("SELECT COUNT(*) AS Value FROM pragma_table_info({0}) WHERE name = {1}", new object[] { table, column }).AsEnumerable().FirstOrDefault() > 0;
        if (!exists) db.Database.ExecuteSqlRaw("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
        static bool IsSafeIdentifier(string value) => !string.IsNullOrWhiteSpace(value) && Regex.IsMatch(value, @"^[A-Za-z_][A-Za-z0-9_]*$");
    }
}
