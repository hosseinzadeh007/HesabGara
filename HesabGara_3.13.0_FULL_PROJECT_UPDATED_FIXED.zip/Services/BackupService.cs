using AccountingPurchasePro.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Services;

/// <summary>
/// پشتیبان‌گیری امن برای SQLite و SQL Server.
/// در SQL Server مسیر فایل باید روی خود سرور SQL قابل دسترس و قابل نوشتن باشد.
/// </summary>
public sealed class BackupService
{
    public async Task<string> CreateBackupAsync(string destinationFolder, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(destinationFolder))
            throw new ArgumentException("مسیر پشتیبان معتبر نیست.");

        Directory.CreateDirectory(destinationFolder);
        var cfg = DatabaseConfigurationStore.Load();

        if (cfg.Provider == DatabaseProvider.SqlServer)
        {
            var path = Path.Combine(destinationFolder,
                $"HesabYar_{DateTime.Now:yyyyMMdd_HHmmss}.bak");
            return await CreateSqlServerBackupAsync(path, ct);
        }

        var file = Path.Combine(destinationFolder,
            $"HesabYar_{DateTime.Now:yyyyMMdd_HHmmss}.db");

        await using var db = new AppDbContext();
        await db.Database.ExecuteSqlRawAsync("VACUUM INTO {0};", new object[] { file }, ct);
        if (!await IsValidSqliteDatabaseAsync(file, ct))
        {
            TryDelete(file);
            throw new InvalidOperationException("پشتیبان SQLite ایجاد شد ولی اعتبارسنجی آن موفق نبود.");
        }
        return file;
    }

    async Task<string> CreateSqlServerBackupAsync(string backupPath, CancellationToken ct)
    {
        var cfg = DatabaseConfigurationStore.Load();
        var cs = new SqlConnectionStringBuilder(cfg.ConnectionString);
        if (string.IsNullOrWhiteSpace(cs.InitialCatalog) ||
            string.Equals(cs.InitialCatalog, "master", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("نام دیتابیس SQL Server برای Backup معتبر نیست.");

        // BACKUP DATABASE writes on the SQL Server machine, not necessarily the client PC.
        await using var cn = new SqlConnection(cfg.ConnectionString);
        await cn.OpenAsync(ct);

        await using var cmd = cn.CreateCommand();
        cmd.CommandTimeout = 300;
        cmd.CommandText = """
            BACKUP DATABASE @db
            TO DISK = @path
            WITH INIT, CHECKSUM, COMPRESSION, STATS = 10;
            """;
        cmd.Parameters.AddWithValue("@db", cs.InitialCatalog);
        cmd.Parameters.AddWithValue("@path", backupPath);
        await cmd.ExecuteNonQueryAsync(ct);

        // Verify that SQL Server can see the backup and that the backup header is readable.
        await using var verify = cn.CreateCommand();
        verify.CommandTimeout = 60;
        verify.CommandText = "RESTORE VERIFYONLY FROM DISK = @path WITH CHECKSUM;";
        verify.Parameters.AddWithValue("@path", backupPath);
        await verify.ExecuteNonQueryAsync(ct);

        return backupPath;
    }

    public async Task<string> RestoreBackupAsync(string backupFile, CancellationToken ct = default)
    {
        if (!File.Exists(backupFile))
            throw new FileNotFoundException("فایل پشتیبان پیدا نشد.", backupFile);

        var cfg = DatabaseConfigurationStore.Load();
        if (cfg.Provider == DatabaseProvider.SqlServer)
            return await RestoreSqlServerBackupAsync(backupFile, ct);

        if (!await IsValidSqliteDatabaseAsync(backupFile, ct))
            throw new InvalidOperationException("فایل پشتیبان SQLite از نظر یکپارچگی معتبر نیست.");

        var current = AppDbContext.DatabasePath;
        var safety = current + ".before-restore-" +
                     DateTime.Now.ToString("yyyyMMdd_HHmmss");

        if (File.Exists(current)) File.Copy(current, safety, true);
        File.Copy(backupFile, current, true);
        return safety;
    }

    async Task<string> RestoreSqlServerBackupAsync(string backupFile, CancellationToken ct)
    {
        var cfg = DatabaseConfigurationStore.Load();
        var cs = new SqlConnectionStringBuilder(cfg.ConnectionString);
        if (string.IsNullOrWhiteSpace(cs.InitialCatalog) ||
            string.Equals(cs.InitialCatalog, "master", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("نام دیتابیس مقصد معتبر نیست.");

        // The .bak path is interpreted by SQL Server, so it must be accessible to SQL Server.
        await using var master = new SqlConnection(
            new SqlConnectionStringBuilder(cfg.ConnectionString) { InitialCatalog = "master" }.ConnectionString);
        await master.OpenAsync(ct);

        await using var verify = master.CreateCommand();
        verify.CommandTimeout = 120;
        verify.CommandText = "RESTORE VERIFYONLY FROM DISK = @path WITH CHECKSUM;";
        verify.Parameters.AddWithValue("@path", backupFile);
        await verify.ExecuteNonQueryAsync(ct);

        await using var restore = master.CreateCommand();
        restore.CommandTimeout = 600;
        restore.CommandText = $"""
            ALTER DATABASE [{EscapeIdentifier(cs.InitialCatalog)}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
            RESTORE DATABASE [{EscapeIdentifier(cs.InitialCatalog)}]
            FROM DISK = @path WITH REPLACE, RECOVERY, CHECKSUM, STATS = 10;
            ALTER DATABASE [{EscapeIdentifier(cs.InitialCatalog)}] SET MULTI_USER;
            """;
        restore.Parameters.AddWithValue("@path", backupFile);
        await restore.ExecuteNonQueryAsync(ct);
        return backupFile;
    }

    static string EscapeIdentifier(string value) => value.Replace("]", "]]");

    static async Task<bool> IsValidSqliteDatabaseAsync(string path, CancellationToken ct)
    {
        var cs = $"Data Source={path};Mode=ReadOnly;Foreign Keys=True";
        await using var conn = new SqliteConnection(cs);
        await conn.OpenAsync(ct);
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "PRAGMA integrity_check;";
        var result = Convert.ToString(await cmd.ExecuteScalarAsync(ct));
        if (!string.Equals(result, "ok", StringComparison.OrdinalIgnoreCase)) return false;

        cmd.CommandText = "PRAGMA foreign_key_check;";
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        return !await reader.ReadAsync(ct);
    }

    public static void TryDelete(string file)
    {
        try { if (File.Exists(file)) File.Delete(file); } catch { }
    }
}
