using System.Text.Json;
using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

/// <summary>وصول‌شدن چک از اپ موبایل: فقط «در انتظار وصول» تغییر می‌کند و ارسال تکراری بی‌اثر است.</summary>
public class CheckCollectTests : DatabaseTestBase
{
    static readonly AccountingService S = new();

    static async Task<Payment> SeedCheckAsync(string status = PaymentRules.DefaultCheckStatus, string number = "123456")
    {
        var company = new Company { Name = "شرکت چک " + Guid.NewGuid().ToString("N")[..6] };
        await S.AddCompanyAsync(company);
        var invoice = new Invoice { CompanyId = company.Id, Number = "C-1", Amount = 1000m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(30) };
        await S.AddInvoiceAsync(invoice);
        var payment = new Payment { InvoiceId = invoice.Id, Amount = 400m, PayDate = DateTime.Today, PaymentMethod = PaymentMethods.Check, CheckNumber = number, CheckDate = DateTime.Today.AddDays(10), CheckStatus = status };
        await S.AddPaymentAsync(payment);
        return payment;
    }

    [Fact]
    public async Task Pending_Check_Becomes_Collected_And_Balance_Is_Unchanged()
    {
        var p = await SeedCheckAsync();
        var r = await S.MarkChecksCollectedAsync(new[] { p.Id }, "123456", "test");
        Assert.Equal(1, r.Updated);
        var stored = await S.GetPaymentByIdAsync(p.Id);
        Assert.Equal(PaymentRules.CollectedCheckStatus, stored!.CheckStatus);
        var inv = (await S.GetInvoicesAsync()).Single(x => x.Id == p.InvoiceId);
        Assert.Equal(600m, AccountingService.Balance(inv));
    }

    [Fact]
    public async Task Repeating_The_Message_Is_Harmless()
    {
        var p = await SeedCheckAsync();
        await S.MarkChecksCollectedAsync(new[] { p.Id }, "123456", "test");
        var again = await S.MarkChecksCollectedAsync(new[] { p.Id }, "123456", "test");
        Assert.Equal(0, again.Updated);
        Assert.Equal(1, again.AlreadyDone);
    }

    [Fact]
    public async Task Returned_Check_Is_Never_Flipped_Back_To_Collected()
    {
        var p = await SeedCheckAsync("برگشتی");
        var r = await S.MarkChecksCollectedAsync(new[] { p.Id }, "123456", "test");
        Assert.Equal(1, r.Skipped);
        Assert.Equal("برگشتی", (await S.GetPaymentByIdAsync(p.Id))!.CheckStatus);
    }

    [Fact]
    public async Task Wrong_Check_Number_Is_Skipped()
    {
        var p = await SeedCheckAsync();
        var r = await S.MarkChecksCollectedAsync(new[] { p.Id }, "999999", "test");
        Assert.Equal(1, r.Skipped);
        Assert.Equal(PaymentRules.DefaultCheckStatus, (await S.GetPaymentByIdAsync(p.Id))!.CheckStatus);
    }

    [Fact]
    public async Task Inbox_Message_Is_Parsed_And_Applied()
    {
        var p = await SeedCheckAsync();
        var json = JsonSerializer.Serialize(new { t = "check-collected", id = "x", paymentIds = new[] { p.Id }, checkNumber = "123456" });
        var r = await CloudInboxService.ApplyAsync(S, json, CancellationToken.None);
        Assert.Equal(1, r!.Updated);
        Assert.Null(await CloudInboxService.ApplyAsync(S, "{\"t\":\"other\",\"paymentIds\":[1]}", CancellationToken.None));
        Assert.Null(await CloudInboxService.ApplyAsync(S, "{\"t\":\"check-collected\",\"paymentIds\":[\"a\"]}", CancellationToken.None));
    }
}
