using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using HesabGara.Data;
using HesabGara.Models;

namespace HesabGara.Services;

public sealed record InboxPullResult(int Received, int ChecksUpdated, int AlreadyDone, int Skipped, int Invalid)
{
    public static InboxPullResult None { get; } = new(0, 0, 0, 0, 0);

    public string Summary =>
        Received == 0 ? "پیام جدیدی از موبایل نبود."
        : $"{Received} پیام از موبایل: {ChecksUpdated} وصول چک ثبت شد"
          + (AlreadyDone > 0 ? $"، {AlreadyDone} قبلاً ثبت شده بود" : "")
          + (Skipped > 0 ? $"، {Skipped} رد شد (چک پیدا نشد یا وضعیتش «در انتظار وصول» نبود)" : "")
          + (Invalid > 0 ? $"، {Invalid} پیام نامعتبر (رمز یا قالب نادرست) حذف شد" : "") + ".";
}

/// <summary>
/// دریافت پیام‌های اپ موبایل (فعلاً: «وصول شدن چک») از صندوق ابری. پیام‌ها با همان رمز همگام‌سازی رمزگذاری‌اند؛
/// پیامی که با رمز درست باز نشود هرگز اعمال نمی‌شود. اعمال هر پیام تکرارپذیر است (ارسال دوباره ضرر ندارد).
/// </summary>
public sealed class CloudInboxService
{
    public const string CheckCollectedType = "check-collected";
    const int MaxPaymentIdsPerMessage = 200;
    readonly HttpClient _http;

    public CloudInboxService(HttpClient? http = null) => _http = http ?? new HttpClient { Timeout = TimeSpan.FromSeconds(60) };

    public static string InboxUrl(string serverUrl, string channelId) =>
        $"{serverUrl.TrimEnd('/')}/v1/inbox/{Uri.EscapeDataString(channelId)}";

    HttpRequestMessage Request(HttpMethod method, string url, string apiKey)
    {
        var r = new HttpRequestMessage(method, url);
        r.Headers.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
        return r;
    }

    public async Task<InboxPullResult> PullAsync(CloudSyncSettings s, CancellationToken ct = default)
    {
        if (!s.IsConfigured) throw new InvalidOperationException("همگام‌سازی ابری کامل تنظیم نشده است.");
        var server = CloudSyncService.NormalizeServerUrl(s.ServerUrl);
        var url = InboxUrl(server, s.ChannelId);

        string listJson;
        try
        {
            using var request = Request(HttpMethod.Get, url, s.ApiKey);
            using var response = await _http.SendAsync(request, ct);
            if (!response.IsSuccessStatusCode)
                throw new InvalidOperationException(response.StatusCode switch
                {
                    HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden => "کلید ارسال درست نیست.",
                    HttpStatusCode.NotFound => "سرور ابری هنوز صندوق پیام ندارد؛ فایل جدید cloud/worker.js را در Cloudflare منتشر کنید.",
                    _ => $"سرور ابری خطا داد ({(int)response.StatusCode})."
                });
            listJson = await response.Content.ReadAsStringAsync(ct);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { throw new InvalidOperationException("پاسخ سرور دیر رسید. دوباره تلاش کنید."); }
        catch (HttpRequestException) { throw new InvalidOperationException("اتصال به سرور ابری برقرار نشد (اینترنت یا فیلترینگ را بررسی کنید)."); }

        List<(string Key, string Data)> items = new();
        try
        {
            using var doc = JsonDocument.Parse(listJson);
            foreach (var it in doc.RootElement.GetProperty("items").EnumerateArray())
                items.Add((it.GetProperty("k").GetString() ?? "", it.GetProperty("data").GetString() ?? ""));
        }
        catch (Exception ex) when (ex is JsonException or KeyNotFoundException or InvalidOperationException)
        {
            throw new InvalidOperationException("پاسخ صندوق پیام سرور معتبر نیست.");
        }
        if (items.Count == 0) return InboxPullResult.None;

        var accounting = new AccountingService();
        int updated = 0, already = 0, skipped = 0, invalid = 0;
        foreach (var (key, data) in items)
        {
            bool processed = false;
            try
            {
                var plain = CloudCrypto.Decrypt(data, s.Password);
                var r = await ApplyAsync(accounting, plain, ct);
                if (r is null) invalid++;
                else { updated += r.Updated; already += r.AlreadyDone; skipped += r.Skipped; }
                processed = true;
            }
            catch (InvalidOperationException) { invalid++; processed = true; }   // رمز اشتباه/قالب خراب: هرگز قابل‌اعمال نیست
            catch (JsonException) { invalid++; processed = true; }
            // خطای دیتابیس و مانند آن: پیام را پاک نکن تا دفعه‌ی بعد دوباره امتحان شود.

            if (!processed || key.Length == 0) continue;
            try
            {
                using var del = Request(HttpMethod.Delete, $"{url}/{Uri.EscapeDataString(key)}", s.ApiKey);
                using var resp = await _http.SendAsync(del, ct);
            }
            catch (HttpRequestException) { /* پیام می‌ماند؛ اعمال دوباره بی‌اثر است */ }
        }

        var user = UserSession.CurrentUser;
        await using var db = new AppDbContext();
        db.AuditLogs.Add(new AuditLog { TimestampUtc = DateTime.UtcNow, UserId = user?.Id, UserName = user?.UserName, IpAddress = UserSession.IpAddress, Action = "CloudPull", Entity = "Cloud", Details = $"received={items.Count}; updated={updated}; already={already}; skipped={skipped}; invalid={invalid}" });
        await db.SaveChangesAsync(ct);
        return new InboxPullResult(items.Count, updated, already, skipped, invalid);
    }

    /// <summary>یک پیام رمزگشایی‌شده را اعمال می‌کند؛ پیام ناشناخته/ناقص = null.</summary>
    public static async Task<AccountingService.CheckCollectResult?> ApplyAsync(AccountingService accounting, string plainJson, CancellationToken ct)
    {
        using var doc = JsonDocument.Parse(plainJson);
        var root = doc.RootElement;
        if (root.ValueKind != JsonValueKind.Object) return null;
        if (!root.TryGetProperty("t", out var t) || t.GetString() != CheckCollectedType) return null;
        if (!root.TryGetProperty("paymentIds", out var idsEl) || idsEl.ValueKind != JsonValueKind.Array) return null;

        var ids = new List<int>();
        foreach (var e in idsEl.EnumerateArray())
        {
            if (e.ValueKind != JsonValueKind.Number || !e.TryGetInt32(out var id) || id <= 0) return null;
            ids.Add(id);
            if (ids.Count > MaxPaymentIdsPerMessage) return null;
        }
        if (ids.Count == 0) return null;
        var checkNumber = root.TryGetProperty("checkNumber", out var cn) && cn.ValueKind == JsonValueKind.String ? cn.GetString() : null;
        return await accounting.MarkChecksCollectedAsync(ids, checkNumber, "mobile", ct);
    }
}
