﻿namespace HesabGara.Models;

public class Company
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string? NationalId { get; set; }
    public string? Phone { get; set; }
    public string? Note { get; set; }
    public ICollection<Invoice> Invoices { get; set; } = new List<Invoice>();
}

public class Invoice
{
    public int Id { get; set; }
    public int CompanyId { get; set; }
    public Company? Company { get; set; }
    public string Number { get; set; } = "";
    public DateTime InvoiceDate { get; set; }
    public DateTime DueDate { get; set; }
    public decimal Amount { get; set; }
    public decimal Paid { get; set; }
    /// <summary>مرجوعی: بخشی از مبلغ کل فاکتور که کالایش برگشت خورده و از مبلغ کل کم می‌شود.</summary>
    public decimal ReturnedAmount { get; set; }
    /// <summary>مبلغ خالص فاکتور = مبلغ کل − مرجوعی؛ مانده و وصول بر اساس همین محاسبه می‌شود.</summary>
    public decimal NetAmount => Amount - ReturnedAmount;
    public string? Note { get; set; }
    public ICollection<Payment> Payments { get; set; } = new List<Payment>();
}

public class Payment
{
    public int Id { get; set; }
    public int InvoiceId { get; set; }
    public Invoice? Invoice { get; set; }
    public DateTime PayDate { get; set; }
    public decimal Amount { get; set; }

    // روش وصول: نقد، کارت‌به‌کارت، چک یا ترکیبی
    public string PaymentMethod { get; set; } = "نقد";

    // اطلاعات چک عمداً اختیاری است؛ چک ممکن است بعداً آماده شود.
    public string? CheckNumber { get; set; }
    public DateTime? CheckDate { get; set; }
    public string? CheckStatus { get; set; }

    public string? Note { get; set; }
}

/// <summary>
/// عکس فشرده‌ی چک/رسید یک وصول (JPEG). عمداً جدا از Payment است تا با هر بار خواندن وصول‌ها، عکس‌ها بارگذاری نشوند.
/// CloudKey = ۳۲ نویسه‌ی اول SHA-256 محتوای عکس؛ شناسه‌ی عکس در سرور ابری (عکس تکراری یک بار ارسال می‌شود).
/// </summary>
public class PaymentImage
{
    public int Id { get; set; }
    public int PaymentId { get; set; }
    public byte[] Data { get; set; } = Array.Empty<byte>();
    public DateTime CreatedAt { get; set; }
    public string CloudKey { get; set; } = "";
    public DateTime? CloudUploadedAt { get; set; }
}

public class AuditLog
{
    public long Id { get; set; }
    public DateTime TimestampUtc { get; set; }
    public int? UserId { get; set; }
    public string? UserName { get; set; }
    public string? IpAddress { get; set; }
    public string Action { get; set; } = "";
    public string Entity { get; set; } = "";
    public string? EntityId { get; set; }
    public string? Details { get; set; }
}
