using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using HesabGara.Data;
using HesabGara.Services;

namespace HesabGara.Views;

public sealed class SettingsView : Grid
{
    readonly SettingsService S = new();
    readonly TextBox CompanyName = new(), Phone = new(), AutoBackup = new(), BackupKeep = new(), Server = new(), Database = new(), User = new();
    readonly PasswordBox Password = new();
    readonly TextBlock StorageInfo = new() { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(3, 0, 3, 8) };
    readonly TextBox CloudUrl = new(), CloudPair = new() { IsReadOnly = true };
    readonly PasswordBox CloudKey = new(), CloudPassword = new();
    readonly CheckBox CloudAuto = new() { Content = "ارسال خودکار بعد از هر پشتیبان خودکار، و دریافت خودکار وصول چک‌ها از موبایل", Margin = new Thickness(3, 0, 3, 8) };
    readonly TextBlock CloudStatus = new() { Margin = new Thickness(3, 0, 3, 8), TextWrapping = TextWrapping.Wrap };
    readonly CheckBox Integrated = new() { Content = "احراز هویت Windows (Integrated Security)", Margin = new Thickness(3, 5, 3, 12) };
    readonly ComboBox Mode = new() { ItemsSource = new[] { "محلی (SQLite)", "شبکه‌ای (SQL Server)" }, Width = 260 };
    readonly TextBlock Status = new() { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(3, 8, 3, 12) };

    public SettingsView() { FlowDirection = FlowDirection.RightToLeft; Build(); Loaded += async (_, _) => await Load(); }

    void Build()
    {
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var p = new StackPanel { Margin = new Thickness(30), Width = 680, HorizontalAlignment = HorizontalAlignment.Center };
        p.Children.Add(H("تنظیمات حساب‌گرا"));
        p.Children.Add(L("نام مجموعه", CompanyName)); p.Children.Add(L("تلفن", Phone)); p.Children.Add(L("پشتیبان‌گیری خودکار (دقیقه؛ حداقل ۱۵، پیشنهاد ۶۰؛ فقط وقتی اطلاعات تغییر کرده باشد)", AutoBackup)); p.Children.Add(L("تعداد پشتیبان خودکار نگه‌داشته‌شده (۰ = همه)", BackupKeep));
        p.Children.Add(H2("فضای مصرفی برنامه"));
        p.Children.Add(StorageInfo);
        var storageBar = new WrapPanel { Margin = new Thickness(3, 0, 3, 8) };
        Button SB(string text, RoutedEventHandler handler) { var btn = new Button { Content = text, Height = 36, Padding = new Thickness(14, 0, 14, 0), Margin = new Thickness(0, 0, 8, 6) }; btn.Click += handler; return btn; }
        storageBar.Children.Add(SB("به‌روزرسانی عدد", (_, _) => RefreshStorageInfo()));
        storageBar.Children.Add(SB("باز کردن پوشه‌ی برنامه", (_, _) => OpenAppFolder()));
        storageBar.Children.Add(SB("حذف پشتیبان‌های خودکار قدیمی (۳ تای آخر بماند)", (_, _) => TrimBackups()));
        p.Children.Add(storageBar);
        RefreshStorageInfo();
        p.Children.Add(H2("انتقال به موبایل"));
        p.Children.Add(new TextBlock { Text = "یک فایل فقط‌خواندنی (JSON) می‌سازد که در اپ موبایل حساب‌گرا باز می‌شود. فایل رمزگذاری نمی‌شود؛ آن را فقط برای خودتان بفرستید.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(3, 0, 3, 8) });
        var mobile = new Button { Content = "ساخت فایل برای موبایل", Width = 190, Height = 38, Margin = new Thickness(3, 0, 3, 8), HorizontalAlignment = HorizontalAlignment.Left }; mobile.Click += ExportMobile;
        p.Children.Add(mobile);
        p.Children.Add(H2("همگام‌سازی ابری با موبایل"));
        p.Children.Add(new TextBlock { Text = "داده با رمزی که شما تعیین می‌کنید روی همین سیستم رمزگذاری و بعد ارسال می‌شود؛ سرور فقط داده‌ی غیرقابل‌خواندن می‌بیند. رمز را فراموش کنید، داده قابل بازیابی نیست.", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(3, 0, 3, 8) });
        p.Children.Add(L("آدرس سرور ابری (https://...)", CloudUrl));
        p.Children.Add(L("کلید ارسال (API Key)", CloudKey));
        p.Children.Add(L("رمز رمزگذاری (حداقل ۸ نویسه؛ روی گوشی هم همین را وارد می‌کنید)", CloudPassword));
        p.Children.Add(CloudAuto);
        p.Children.Add(L("کد اتصال برای گوشی (رمز داخل آن نیست)", CloudPair));
        var cloudSave = new Button { Content = "ذخیره", Width = 90, Height = 36, Margin = new Thickness(3, 0, 8, 8) }; cloudSave.Click += SaveCloudClick;
        var cloudSend = new Button { Content = "ارسال اکنون", Width = 120, Height = 36, Margin = new Thickness(3, 0, 3, 8) }; cloudSend.Click += SendCloudClick;
        var cloudPull = new Button { Content = "دریافت وصول چک از موبایل", Width = 190, Height = 36, Margin = new Thickness(3, 0, 3, 8) }; cloudPull.Click += PullCloudClick;
        p.Children.Add(new StackPanel { Orientation = Orientation.Horizontal, Children = { cloudSave, cloudSend, cloudPull } });
        p.Children.Add(CloudStatus);
        p.Children.Add(H2("اتصال شبکه‌ای"));
        p.Children.Add(L("نوع پایگاه‌داده", Mode)); Mode.SelectionChanged += (_, _) => UpdateNetworkVisibility();
        p.Children.Add(L("نام سرور / IP", Server)); p.Children.Add(L("نام پایگاه‌داده", Database)); p.Children.Add(L("نام کاربری SQL Server", User)); p.Children.Add(L("رمز عبور SQL Server", Password)); p.Children.Add(Integrated);
        var test = new Button { Content = "بررسی اتصال SQL Server", Width = 190, Height = 38, Margin = new Thickness(3), HorizontalAlignment = HorizontalAlignment.Left }; test.Click += TestConnection;
        p.Children.Add(test); p.Children.Add(Status);
        var save = new Button { Content = "ذخیره تنظیمات و اعمال", Width = 190, Height = 42, Margin = new Thickness(3), HorizontalAlignment = HorizontalAlignment.Left }; save.Click += Save; p.Children.Add(save);
        p.Children.Add(new TextBlock { Text = "نکته: پس از تغییر حالت پایگاه‌داده، حساب‌گرا باید مجدداً اجرا شود. برای استفاده چند سیستم، SQL Server روی سیستم سرور نصب و سایر سیستم‌ها با IP سرور متصل می‌شوند.", TextWrapping = TextWrapping.Wrap, Foreground = AppTheme.Ink500, Margin = new Thickness(3, 16, 3, 0) });
        scroll.Content = p; Children.Add(scroll);
    }
    static TextBlock H(string t) => new() { Text = t, FontSize = 22, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 0, 20) };
    static TextBlock H2(string t) => new() { Text = t, FontSize = 17, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 18, 0, 8) };
    static StackPanel L(string label, Control box) { box.Margin = new Thickness(3, 4, 3, 12); if (box is TextBox tb) tb.Height = 34; return new StackPanel { Children = { new TextBlock { Text = label, FontWeight = FontWeights.SemiBold }, box } }; }
    void LoadCloud()
    {
        var c = CloudSyncSettingsStore.Load();
        CloudUrl.Text = c.ServerUrl;
        CloudAuto.IsChecked = c.AutoSync;
        CloudPair.Text = c.ServerUrl.Length > 0 && c.ChannelId.Length > 0 ? CloudSyncService.BuildPairingCode(c.ServerUrl, c.ChannelId) : "";
        CloudStatus.Text = c.IsConfigured ? "تنظیم شده است. برای تغییر کلید یا رمز، مقدار جدید وارد کنید (خالی = بدون تغییر)." : "هنوز کامل تنظیم نشده است.";
    }

    CloudSyncSettings SaveCloud()
    {
        var old = CloudSyncSettingsStore.Load();
        var url = CloudSyncService.NormalizeServerUrl(CloudUrl.Text);
        var key = string.IsNullOrWhiteSpace(CloudKey.Password) ? old.ApiKey : CloudKey.Password.Trim();
        var password = string.IsNullOrEmpty(CloudPassword.Password) ? old.Password : CloudPassword.Password;
        if (key.Length == 0) throw new ArgumentException("کلید ارسال را وارد کنید.");
        if (password.Length < CloudSyncService.MinPasswordLength) throw new ArgumentException($"رمز رمزگذاری حداقل {CloudSyncService.MinPasswordLength} نویسه باشد.");
        var s = new CloudSyncSettings(url, old.ChannelId.Length > 0 ? old.ChannelId : CloudSyncService.NewChannelId(), key, password, CloudAuto.IsChecked == true);
        CloudSyncSettingsStore.Save(s);
        CloudKey.Clear(); CloudPassword.Clear();
        LoadCloud();
        return s;
    }

    void SaveCloudClick(object sender, RoutedEventArgs e)
    {
        try { SaveCloud(); CloudStatus.Text = "ذخیره شد. کد اتصال را برای گوشی بفرستید."; }
        catch (Exception ex) { MessageBox.Show(ex.Message, "همگام‌سازی ابری", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    async void SendCloudClick(object sender, RoutedEventArgs e)
    {
        var u = UserSession.CurrentUser;
        if (u is null || (!u.IsAdmin && !u.CanImportExport)) { MessageBox.Show("دسترسی Excel/خروجی لازم است."); return; }
        try
        {
            var s = SaveCloud();
            CloudStatus.Text = "در حال ارسال...";
            var cloudSvc = new CloudSyncService();
            var bytes = await cloudSvc.PushAsync(s);
            CloudStatus.Text = $"ارسال شد ({bytes / 1024 + 1} کیلوبایت رمزگذاری‌شده)"
                + (cloudSvc.LastImagesUploaded > 0 ? $"، {cloudSvc.LastImagesUploaded:N0} عکس چک" : "")
                + $" — {DateTime.Now:HH:mm}";
            if (cloudSvc.LastImageWarning is { } imgWarn) MessageBox.Show(imgWarn, "همگام‌سازی ابری", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        catch (Exception ex) { CloudStatus.Text = ""; MessageBox.Show(ex.Message, "همگام‌سازی ابری", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    async void PullCloudClick(object sender, RoutedEventArgs e)
    {
        var u = UserSession.CurrentUser;
        if (u is null || (!u.IsAdmin && !u.CanImportExport)) { MessageBox.Show("دسترسی Excel/خروجی لازم است."); return; }
        try
        {
            var s = SaveCloud();
            CloudStatus.Text = "در حال دریافت...";
            var r = await new CloudInboxService().PullAsync(s);
            CloudStatus.Text = $"{r.Summary} — {DateTime.Now:HH:mm}";
        }
        catch (Exception ex) { CloudStatus.Text = ""; MessageBox.Show(ex.Message, "همگام‌سازی ابری", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    async void ExportMobile(object sender, RoutedEventArgs e)
    {
        var u = UserSession.CurrentUser;
        if (u is null || (!u.IsAdmin && !u.CanImportExport)) { MessageBox.Show("دسترسی Excel/خروجی لازم است."); return; }
        try
        {
            var d = new Microsoft.Win32.SaveFileDialog { Filter = "HesabGara Mobile|*.json", FileName = $"hesabgara-mobile-{DateTime.Now:yyyyMMdd-HHmm}.json", Title = "ذخیره فایل موبایل" };
            if (d.ShowDialog() != true) return;
            await new MobileExportService().ExportAsync(d.FileName);
            MessageBox.Show("فایل ساخته شد. آن را به گوشی بفرستید و در اپ موبایل «انتخاب فایل» را بزنید.", "انتقال به موبایل", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "انتقال به موبایل", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }
    async Task Load()
    {
        LoadCloud();
        CompanyName.Text = await S.GetAsync("CompanyName") ?? ""; Phone.Text = await S.GetAsync("CompanyPhone") ?? ""; AutoBackup.Text = await S.GetAsync("AutoBackupMinutes") ?? "0"; BackupKeep.Text = await S.GetAsync(BackupService.KeepCountSettingKey) ?? BackupService.DefaultKeepCount.ToString();
        var cfg = DatabaseConfigurationStore.Load(); Mode.SelectedIndex = cfg.Provider == DatabaseProvider.SqlServer ? 1 : 0;
        ParseConnection(cfg.ConnectionString); UpdateNetworkVisibility(); Status.Text = cfg.Provider == DatabaseProvider.SqlServer ? "● حالت شبکه‌ای فعال است." : "● حالت محلی فعال است.";
    }
    void ParseConnection(string cs)
    {
        try
        {
            var b = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder(cs); Server.Text = b.DataSource; Database.Text = b.InitialCatalog; Integrated.IsChecked = b.IntegratedSecurity; User.Text = b.UserID; Password.Password = b.Password;
        }
        catch { }
    }
    void UpdateNetworkVisibility()
    {
        var visible = Mode.SelectedIndex == 1 ? Visibility.Visible : Visibility.Collapsed;
        Server.Visibility = Database.Visibility = User.Visibility = Password.Visibility = Integrated.Visibility = visible;
    }
    async void TestConnection(object? sender, RoutedEventArgs e)
    {
        var result = await new DatabaseConnectionService().TestSqlServerAsync(BuildConnectionString()); Status.Text = result.Success ? "● " + result.Message : "● " + result.Message; Status.Foreground = result.Success ? AppTheme.Success600 : AppTheme.Danger600;
    }
    string BuildConnectionString()
    {
        var b = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder { DataSource = Server.Text.Trim(), InitialCatalog = Database.Text.Trim(), TrustServerCertificate = true, ConnectTimeout = 8 };
        if (Integrated.IsChecked == true) b.IntegratedSecurity = true; else { b.UserID = User.Text.Trim(); b.Password = Password.Password; } return b.ConnectionString;
    }
    static long FileSize(string path)
    {
        try { return File.Exists(path) ? new FileInfo(path).Length : 0; }
        catch (IOException) { return 0; }
    }

    static (long Bytes, int Count) FolderSize(string dir)
    {
        try
        {
            if (!Directory.Exists(dir)) return (0, 0);
            var files = new DirectoryInfo(dir).EnumerateFiles("*", SearchOption.AllDirectories).ToList();
            return (files.Sum(f => f.Length), files.Count);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { return (0, 0); }
    }

    static string Mb(long bytes) => bytes >= 1024L * 1024 * 1024 ? $"{bytes / 1073741824.0:N2} گیگابایت" : $"{bytes / 1048576.0:N1} مگابایت";

    void RefreshStorageInfo()
    {
        var root = DatabaseConfigurationStore.DirectoryPath;
        var all = FolderSize(root);
        var db = FileSize(AppDbContext.DatabasePath) + FileSize(AppDbContext.DatabasePath + "-wal") + FileSize(AppDbContext.DatabasePath + "-shm");
        var backups = FolderSize(BackupService.AutoBackupFolder);
        var logs = FolderSize(AppFileLogger.DirectoryPath);
        var other = Math.Max(0, all.Bytes - db - backups.Bytes - logs.Bytes);
        StorageInfo.Text = $"کل پوشه‌ی برنامه: {Mb(all.Bytes)}\n• دیتابیس (با عکس چک‌ها): {Mb(db)}\n• پشتیبان‌های خودکار: {Mb(backups.Bytes)} ({backups.Count:N0} فایل)\n• لاگ‌ها: {Mb(logs.Bytes)}\n• سایر (مثلاً نسخه‌های ایمنی بازیابی): {Mb(other)}\nمسیر: {root}";
    }

    void OpenAppFolder()
    {
        try
        {
            Directory.CreateDirectory(DatabaseConfigurationStore.DirectoryPath);
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{DatabaseConfigurationStore.DirectoryPath}\"") { UseShellExecute = true });
        }
        catch (Exception ex) when (ex is IOException or System.ComponentModel.Win32Exception) { MessageBox.Show(ex.Message); }
    }

    void TrimBackups()
    {
        if (MessageBox.Show("پشتیبان‌های خودکار قدیمی حذف می‌شوند و فقط ۳ پشتیبان آخر می‌ماند. (پشتیبان‌های دستی که در پوشه‌ی دیگری گرفته‌اید دست نمی‌خورند.) ادامه می‌دهید؟", "حذف پشتیبان‌های قدیمی", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        var removed = BackupService.PruneOldBackups(BackupService.AutoBackupFolder, 3);
        RefreshStorageInfo();
        MessageBox.Show($"{removed:N0} پشتیبان قدیمی حذف شد.", "حذف پشتیبان‌های قدیمی", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    async void Save(object? s, RoutedEventArgs e)
    {
        if (!int.TryParse(AutoBackup.Text, out var n) || n < 0) { MessageBox.Show("فاصله پشتیبان‌گیری باید عدد صفر یا بزرگ‌تر باشد."); return; }
        if (n > 0 && n < BackupService.MinAutoBackupMinutes)
        {
            n = BackupService.MinAutoBackupMinutes; AutoBackup.Text = n.ToString();
            MessageBox.Show($"هر پشتیبان یک کپی کامل دیتابیس است؛ فاصله‌ی کمتر از {n} دقیقه دیسک را مدام درگیر می‌کند. روی {n} دقیقه تنظیم شد.", "پشتیبان‌گیری خودکار", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        if (!int.TryParse(BackupKeep.Text, out var keepCount) || keepCount < 0) { MessageBox.Show("تعداد پشتیبان نگه‌داشته‌شده باید عدد صفر یا بزرگ‌تر باشد."); return; }
        await S.SetAsync("CompanyName", CompanyName.Text.Trim()); await S.SetAsync("CompanyPhone", Phone.Text.Trim()); await S.SetAsync("AutoBackupMinutes", n.ToString()); await S.SetAsync(BackupService.KeepCountSettingKey, keepCount.ToString());
        if (Mode.SelectedIndex == 1)
        {
            if (string.IsNullOrWhiteSpace(Server.Text) || string.IsNullOrWhiteSpace(Database.Text)) { MessageBox.Show("نام سرور/IP و نام پایگاه‌داده الزامی است."); return; }
            DatabaseConfigurationStore.Save(new DatabaseConfiguration { Provider = DatabaseProvider.SqlServer, ConnectionString = BuildConnectionString() });
            MessageBox.Show("حالت شبکه‌ای ذخیره شد. برای اعمال اتصال جدید، حساب‌گرا را ببندید و دوباره اجرا کنید.", "حساب‌گرا", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        else
        {
            DatabaseConfigurationStore.Save(new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite }); MessageBox.Show("حالت محلی ذخیره شد. برای اعمال تغییر، حساب‌گرا را دوباره اجرا کنید.");
        }
    }
}
