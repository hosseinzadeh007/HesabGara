using System.Globalization;
using HesabGara.Data;
using HesabGara.Domain;
using HesabGara.Models;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

/// <summary>
/// خواندن فاکتورها برای تعداد زیاد: همه‌ی فیلترها (شرکت، بازه‌ی تاریخ، فقط مانده‌دار، جستجو) و محدودیت تعداد در خود دیتابیس اعمال می‌شود
/// و فقط همان صفحه‌ی لازم خوانده می‌شود، نه همه‌ی فاکتورها.
/// </summary>
public sealed partial class AccountingService
{
    public sealed record InvoiceFilter(int? CompanyId = null, string? Search = null, DateTime? From = null, DateTime? To = null, bool OnlyWithBalance = false);

    /// <summary>Rows = حداکثر <c>take</c> فاکتور؛ Total = تعداد همه‌ی فاکتورهای مطابق فیلتر.</summary>
    public sealed record InvoicePage(List<Invoice> Rows, int Total);

    /// <summary>
    /// جستجو: شماره‌ی فاکتور و نام شرکت (بخشی از متن) و مبلغ فاکتور/مبلغ خالص (عدد کامل). اگر ارائه‌دهنده‌ی دیتابیس یکی از عبارت‌ها را
    /// ترجمه نکند، به‌ترتیب با فیلتر ساده‌تر و در آخر در حافظه تکرار می‌شود؛ نتیجه (جز جستجوی بخشی از مبلغ) یکی است.
    /// </summary>
    public async Task<InvoicePage> GetInvoicePageAsync(InvoiceFilter filter, int take, bool orderByDueDate = false, CancellationToken ct = default)
    {
        if (take < 1) take = 1;
        for (var level = 0; level < 2; level++)
        {
            try { return await QueryInvoicePageAsync(filter, take, orderByDueDate, level, ct); }
            catch (InvalidOperationException) { /* ترجمه‌ی SQL ممکن نشد؛ سطح ساده‌تر */ }
        }
        return await QueryInvoicePageAsync(filter, take, orderByDueDate, 2, ct);
    }

    static decimal? ExactAmount(string search)
    {
        if (!search.All(c => char.IsDigit(c) || c == ',' || c == '٬' || c == ' ')) return null;
        var digits = new string(search.Where(char.IsDigit).ToArray());
        return digits.Length > 0 && digits.Length <= 18 && decimal.TryParse(digits, NumberStyles.None, CultureInfo.InvariantCulture, out var v) ? v : null;
    }

    async Task<InvoicePage> QueryInvoicePageAsync(InvoiceFilter f, int take, bool byDue, int level, CancellationToken ct)
    {
        await using var db = new AppDbContext();
        IQueryable<Invoice> q = db.Invoices.AsNoTracking().Include(x => x.Company);
        if (f.CompanyId.HasValue) q = q.Where(x => x.CompanyId == f.CompanyId.Value);
        if (f.From.HasValue) { var from = f.From.Value.Date; q = q.Where(x => x.InvoiceDate >= from); }
        if (f.To.HasValue) { var toExclusive = f.To.Value.Date.AddDays(1); q = q.Where(x => x.InvoiceDate < toExclusive); }
        var raw = (f.Search ?? "").Trim();
        var search = InvoiceSearch.NormalizeDigits(raw).Trim();

        if (level < 2)
        {
            if (f.OnlyWithBalance) q = q.Where(x => x.Amount - x.ReturnedAmount - x.Paid > 0m);
            if (search.Length > 0)
            {
                decimal? exact = level == 0 ? ExactAmount(search) : null;
                q = exact is decimal v
                    ? q.Where(x => x.Number.Contains(raw) || x.Number.Contains(search) || (x.Company != null && x.Company.Name.Contains(raw)) || x.Amount == v || x.Amount - x.ReturnedAmount == v)
                    : q.Where(x => x.Number.Contains(raw) || x.Number.Contains(search) || (x.Company != null && x.Company.Name.Contains(raw)));
            }
            var total = await q.CountAsync(ct);
            var ordered = byDue ? q.OrderBy(x => x.DueDate).ThenBy(x => x.Number) : q.OrderByDescending(x => x.InvoiceDate).ThenByDescending(x => x.Id);
            return new InvoicePage(await ordered.Take(take).ToListAsync(ct), total);
        }

        // آخرین راه: همه‌ی فیلترهای باقی‌مانده در حافظه.
        IEnumerable<Invoice> e = await q.ToListAsync(ct);
        if (f.OnlyWithBalance) e = e.Where(x => Balance(x) > 0);
        if (search.Length > 0) e = e.Where(x => InvoiceSearch.Matches(x, raw) || (x.Company?.Name ?? "").Contains(raw, StringComparison.OrdinalIgnoreCase));
        var list = (byDue ? e.OrderBy(x => x.DueDate).ThenBy(x => x.Number) : e.OrderByDescending(x => x.InvoiceDate).ThenByDescending(x => x.Id)).ToList();
        return new InvoicePage(list.Take(take).ToList(), list.Count);
    }

    /// <summary>
    /// فهرست سبک برای داشبورد و جمع‌های کلی: فقط ستون‌های لازم (بدون توضیحات و بدون سایر ستون‌های شرکت) و بدون وصول‌ها.
    /// </summary>
    public async Task<List<Invoice>> GetInvoicesLiteAsync(int? companyId = null, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        IQueryable<Invoice> q = db.Invoices.AsNoTracking();
        if (companyId.HasValue) q = q.Where(x => x.CompanyId == companyId.Value);
        return await q.OrderByDescending(x => x.InvoiceDate).ThenByDescending(x => x.Id)
            .Select(x => new Invoice
            {
                Id = x.Id, CompanyId = x.CompanyId, Number = x.Number, InvoiceDate = x.InvoiceDate, DueDate = x.DueDate,
                Amount = x.Amount, Paid = x.Paid, ReturnedAmount = x.ReturnedAmount,
                Company = x.Company == null ? null : new Company { Id = x.Company.Id, Name = x.Company.Name }
            })
            .ToListAsync(ct);
    }
}
