# ساخت گواهی امضای کد «خودامضا» برای حساب‌گرا (فقط یک بار، روی یک کامپیوتر اجرا شود)
# خروجی: HesabGara-signing.pfx (خصوصی؛ فقط پیش خودتان بماند) و HesabGara-publisher.cer (عمومی؛ روی کامپیوترهای دیگر نصب می‌شود)
param(
    [string]$Subject = "CN=Hossein Hosseinzadeh, O=HesabGara",
    [int]$Years = 5
)
$ErrorActionPreference = 'Stop'
$cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject $Subject -KeyAlgorithm RSA -KeyLength 3072 `
    -HashAlgorithm SHA256 -CertStoreLocation Cert:\CurrentUser\My -NotAfter (Get-Date).AddYears($Years)
$pwd = Read-Host "یک رمز برای فایل PFX بنویسید" -AsSecureString
Export-PfxCertificate -Cert $cert -FilePath (Join-Path $PSScriptRoot 'HesabGara-signing.pfx') -Password $pwd | Out-Null
Export-Certificate -Cert $cert -FilePath (Join-Path $PSScriptRoot 'HesabGara-publisher.cer') | Out-Null
Write-Host "انجام شد. فایل‌ها کنار همین اسکریپت ساخته شد: HesabGara-signing.pfx و HesabGara-publisher.cer" -ForegroundColor Green
