# امضای فایل HesabGara.exe (بعد از هر بار ساخت نسخه‌ی جدید)
# مثال:  .\Sign-Exe.ps1 -ExePath C:\Build\HesabGara.exe
param(
    [Parameter(Mandatory = $true)][string]$ExePath,
    [string]$PfxPath = (Join-Path $PSScriptRoot 'HesabGara-signing.pfx'),
    [string]$TimestampServer = 'http://timestamp.digicert.com'   # مهر زمان باعث می‌شود امضا بعد از پایان اعتبار گواهی هم معتبر بماند (نیاز به اینترنت)
)
$ErrorActionPreference = 'Stop'
$pwd = Read-Host "رمز فایل PFX" -AsSecureString
$cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($PfxPath, $pwd)
$result = Set-AuthenticodeSignature -FilePath $ExePath -Certificate $cert -HashAlgorithm SHA256 -TimestampServer $TimestampServer
if ($result.Status -eq 'Valid' -or $result.Status -eq 'UnknownError') {
    # روی کامپیوتری که گواهی در آن نصب نیست وضعیت «UnknownError / ناشناخته» عادی است؛ مهم این است که امضا ثبت شده باشد.
    Write-Host "امضا ثبت شد: $($result.SignerCertificate.Subject)" -ForegroundColor Green
} else {
    Write-Host "امضا ناموفق بود: $($result.Status) - $($result.StatusMessage)" -ForegroundColor Red
    exit 1
}
