# معرفی ناشر به ویندوز روی هر کامپیوتر (یک بار، با «Run as administrator»)
# بعد از این، فایل‌های امضاشده با گواهی حساب‌گرا روی همین کامپیوتر «ناشر ناشناس» حساب نمی‌شوند.
#Requires -RunAsAdministrator
param([string]$CerPath = (Join-Path $PSScriptRoot 'HesabGara-publisher.cer'))
$ErrorActionPreference = 'Stop'
Import-Certificate -FilePath $CerPath -CertStoreLocation Cert:\LocalMachine\TrustedPublisher | Out-Null
Import-Certificate -FilePath $CerPath -CertStoreLocation Cert:\LocalMachine\Root | Out-Null
Write-Host "ناشر حساب‌گرا روی این کامپیوتر مورد اعتماد شد." -ForegroundColor Green
