# برداشتن علامت «دانلودشده از اینترنت» از فایل‌های یک پوشه (جلوی هشدار SmartScreen را می‌گیرد)
# مثال:  .\Unblock-HesabGara.ps1 -Folder C:\HesabGara
param([Parameter(Mandatory = $true)][string]$Folder)
Get-ChildItem -Path $Folder -Recurse -File | Unblock-File
Write-Host "فایل‌های $Folder از حالت مسدود خارج شدند." -ForegroundColor Green
