﻿using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

public class InvoiceQueryTests : DatabaseTestBase
{
    static readonly AccountingService S = new();

    [Fact]
    public async Task OnlyWithBalance_Skips_Settled_Invoices()
    {
        var company = new Company { Name = "شرکت مانده " + Guid.NewGuid().ToString("N")[..6] };
        await S.AddCompanyAsync(company);
        var open = new Invoice { CompanyId = company.Id, Number = "OPEN", Amount = 1000m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(5) };
        var settled = new Invoice { CompanyId = company.Id, Number = "DONE", Amount = 500m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(5) };
        await S.AddInvoiceAsync(open);
        await S.AddInvoiceAsync(settled);
        await S.AddPaymentAsync(new Payment { InvoiceId = settled.Id, Amount = 500m, PayDate = DateTime.Today, PaymentMethod = PaymentMethods.Cash });

        var all = await S.GetInvoicesAsync(company.Id, includePayments: false);
        var onlyOpen = await S.GetInvoicesAsync(company.Id, includePayments: false, onlyWithBalance: true);
        Assert.Equal(2, all.Count);
        Assert.Equal(new[] { "OPEN" }, onlyOpen.Select(x => x.Number).ToArray());
    }

    static async Task<(Company company, List<Invoice> invoices)> SeedManyAsync(int count)
    {
        var company = new Company { Name = "شرکت صفحه‌بندی " + Guid.NewGuid().ToString("N")[..6] };
        await S.AddCompanyAsync(company);
        var list = new List<Invoice>();
        for (var i = 1; i <= count; i++)
        {
            var inv = new Invoice { CompanyId = company.Id, Number = $"P-{i:000}", Amount = 1000m * i, InvoiceDate = DateTime.Today.AddDays(-i), DueDate = DateTime.Today.AddDays(100 - i) };
            await S.AddInvoiceAsync(inv);
            list.Add(inv);
        }
        return (company, list);
    }

    [Fact]
    public async Task Page_Returns_Only_Take_But_Reports_The_Total()
    {
        var (company, _) = await SeedManyAsync(12);
        var page = await S.GetInvoicePageAsync(new AccountingService.InvoiceFilter(company.Id), 5);
        Assert.Equal(5, page.Rows.Count);
        Assert.Equal(12, page.Total);
        Assert.Equal("P-001", page.Rows[0].Number);   // جدیدترین تاریخ فاکتور اول (P-001 یک روز پیش)
    }

    [Fact]
    public async Task Page_Orders_By_Due_Date_When_Asked()
    {
        var (company, _) = await SeedManyAsync(6);
        var page = await S.GetInvoicePageAsync(new AccountingService.InvoiceFilter(company.Id, OnlyWithBalance: true), 3, orderByDueDate: true);
        Assert.Equal(new[] { "P-006", "P-005", "P-004" }, page.Rows.Select(x => x.Number).ToArray());   // نزدیک‌ترین سررسید اول
        Assert.Equal(6, page.Total);
    }

    [Fact]
    public async Task Page_Search_Finds_By_Number_And_By_Exact_Amount()
    {
        var (company, _) = await SeedManyAsync(8);
        var byNumber = await S.GetInvoicePageAsync(new AccountingService.InvoiceFilter(company.Id, "P-00"), 50);
        Assert.Equal(8, byNumber.Total);
        var byOne = await S.GetInvoicePageAsync(new AccountingService.InvoiceFilter(company.Id, "P-003"), 50);
        Assert.Equal(new[] { "P-003" }, byOne.Rows.Select(x => x.Number).ToArray());
        var byAmount = await S.GetInvoicePageAsync(new AccountingService.InvoiceFilter(company.Id, "5,000"), 50);
        Assert.Contains(byAmount.Rows, x => x.Number == "P-005");
    }

    [Fact]
    public async Task Page_Date_Range_Is_Inclusive()
    {
        var (company, _) = await SeedManyAsync(10);
        var page = await S.GetInvoicePageAsync(new AccountingService.InvoiceFilter(company.Id, From: DateTime.Today.AddDays(-5), To: DateTime.Today.AddDays(-3)), 50);
        Assert.Equal(new[] { "P-003", "P-004", "P-005" }, page.Rows.Select(x => x.Number).OrderBy(x => x).ToArray());
    }

    [Fact]
    public async Task Lite_List_Has_Company_Name_And_No_Payments()
    {
        var (company, _) = await SeedManyAsync(3);
        var lite = await S.GetInvoicesLiteAsync(company.Id);
        Assert.Equal(3, lite.Count);
        Assert.All(lite, x => { Assert.Equal(company.Name, x.Company?.Name); Assert.Empty(x.Payments); });
    }
}

