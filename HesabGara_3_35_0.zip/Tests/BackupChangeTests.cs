﻿using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

public class BackupChangeTests : DatabaseTestBase
{
    [Fact]
    public void Defaults_Are_Gentle_On_The_Disk()
    {
        Assert.True(BackupService.MinAutoBackupMinutes >= 15);
        Assert.True(BackupService.DefaultKeepCount <= 10);
    }

    [Fact]
    public async Task No_Changes_After_A_Backup_Means_No_New_Backup_Is_Needed()
    {
        var folder = Path.Combine(Path.GetTempPath(), "hg-backup-" + Guid.NewGuid().ToString("N"));
        try
        {
            Assert.True(BackupService.HasChangesSinceLastBackup(folder));   // هنوز پشتیبانی نیست
            await new BackupService().CreateBackupAsync(folder, quickCheck: true);
            await Task.Delay(50);
            Assert.False(BackupService.HasChangesSinceLastBackup(folder));  // چیزی تغییر نکرده
            var s = new AccountingService();
            await s.AddCompanyAsync(new HesabGara.Models.Company { Name = "تغییر " + Guid.NewGuid().ToString("N")[..6] });
            Assert.True(BackupService.HasChangesSinceLastBackup(folder));
        }
        finally { try { Directory.Delete(folder, true); } catch (IOException) { } }
    }
}
