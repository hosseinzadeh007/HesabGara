﻿using HesabGara.Domain;
using HesabGara.Models;
using Xunit;

namespace HesabGara.Tests;

public class InvoiceSearchTests
{
    static Invoice Make(string number, decimal amount) => new() { Number = number, Amount = amount };

    [Theory]
    [InlineData("A-1042", "1042", true)]
    [InlineData("A-1042", "a-10", true)]
    [InlineData("A-1042", "۱۰۴۲", true)]      // ارقام فارسی
    [InlineData("A-1042", "9999", false)]
    [InlineData("X", "", true)]
    public void Matches_By_Number(string number, string query, bool expected) =>
        Assert.Equal(expected, InvoiceSearch.Matches(Make(number, 5m), query));

    [Theory]
    [InlineData("1500000", true)]
    [InlineData("1,500,000", true)]
    [InlineData("۱٬۵۰۰٬۰۰۰", true)]
    [InlineData("1500", true)]               // بخشی از مبلغ
    [InlineData("2500000", false)]
    public void Matches_By_Amount(string query, bool expected) =>
        Assert.Equal(expected, InvoiceSearch.Matches(Make("Z-1", 1_500_000m), query));

    [Fact]
    public void Text_With_Letters_Does_Not_Match_Amount_Digits() =>
        Assert.False(InvoiceSearch.Matches(Make("Z-1", 1_500_000m), "abc1500"));
}
