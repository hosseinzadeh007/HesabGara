using System.Globalization;
using System.Text;
using HesabGara.Models;

namespace HesabGara.Domain;

/// <summary>جستجوی فاکتورها در صفحه‌ی فاکتورها: بر اساس شماره‌ی فاکتور یا مبلغ فاکتور (ارقام فارسی/عربی هم پذیرفته می‌شود).</summary>
public static class InvoiceSearch
{
    /// <summary>ارقام فارسی و عربی را به ارقام لاتین تبدیل می‌کند.</summary>
    public static string NormalizeDigits(string? text)
    {
        if (string.IsNullOrEmpty(text)) return "";
        var sb = new StringBuilder(text.Length);
        foreach (var ch in text)
        {
            if (ch >= '۰' && ch <= '۹') sb.Append((char)('0' + (ch - '۰')));
            else if (ch >= '٠' && ch <= '٩') sb.Append((char)('0' + (ch - '٠')));
            else sb.Append(ch);
        }
        return sb.ToString();
    }

    /// <summary>
    /// شماره‌ی فاکتور: وجود متن جستجو در شماره (بدون حساسیت به حروف). مبلغ: اگر متن فقط رقم و جداکننده باشد
    /// (مثل 1500000 یا 1,500,000 یا بخشی از آن)، با مبلغ فاکتور و مبلغ خالص مقایسه می‌شود.
    /// </summary>
    public static bool Matches(Invoice invoice, string? query)
    {
        var q = NormalizeDigits(query).Trim();
        if (q.Length == 0) return true;
        if (NormalizeDigits(invoice.Number).Contains(q, StringComparison.OrdinalIgnoreCase)) return true;
        if (!q.All(c => char.IsDigit(c) || c == ',' || c == '٬' || c == ' ')) return false;
        var digits = new string(q.Where(char.IsDigit).ToArray());
        if (digits.Length == 0) return false;
        return Amount(invoice.Amount).Contains(digits, StringComparison.Ordinal) || Amount(invoice.NetAmount).Contains(digits, StringComparison.Ordinal);
    }

    static string Amount(decimal value) => Math.Truncate(value).ToString("0", CultureInfo.InvariantCulture);
}
