using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using HesabGara.Data;
using HesabGara.Models;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

public sealed record CloudSyncSettings(string ServerUrl, string ChannelId, string ApiKey, string Password, bool AutoSync)
{
    public static CloudSyncSettings Empty { get; } = new("", "", "", "", false);
    public bool IsConfigured => ServerUrl.Length > 0 && ChannelId.Length > 0 && ApiKey.Length > 0 && Password.Length > 0;
}

/// <summary>تنظیمات همگام‌سازی ابری؛ کلید ارسال و رمز فقط برای همین کاربر ویندوز با DPAPI رمز می‌شوند.</summary>
public static class CloudSyncSettingsStore
{
    static readonly byte[] Entropy = Encoding.UTF8.GetBytes("HesabGara.CloudSync.v1");
    public static string FilePath => Path.Combine(DatabaseConfigurationStore.DirectoryPath, "cloud.json");

    sealed class Disk
    {
        public string? ServerUrl { get; set; }
        public string? ChannelId { get; set; }
        public string? ApiKey { get; set; }
        public string? Password { get; set; }
        public bool AutoSync { get; set; }
    }

    public static CloudSyncSettings Load()
    {
        try
        {
            if (!File.Exists(FilePath)) return CloudSyncSettings.Empty;
            var d = JsonSerializer.Deserialize<Disk>(File.ReadAllText(FilePath, Encoding.UTF8));
            return d is null ? CloudSyncSettings.Empty : new CloudSyncSettings(d.ServerUrl ?? "", d.ChannelId ?? "", Decrypt(d.ApiKey), Decrypt(d.Password), d.AutoSync);
        }
        catch { return CloudSyncSettings.Empty; }
    }

    public static void Save(CloudSyncSettings s)
    {
        Directory.CreateDirectory(DatabaseConfigurationStore.DirectoryPath);
        var disk = new Disk { ServerUrl = s.ServerUrl, ChannelId = s.ChannelId, ApiKey = Encrypt(s.ApiKey), Password = Encrypt(s.Password), AutoSync = s.AutoSync };
        var temp = FilePath + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(disk), new UTF8Encoding(false));
        File.Move(temp, FilePath, true);
    }

    static string Encrypt(string plain) =>
        string.IsNullOrEmpty(plain) ? "" : Convert.ToBase64String(ProtectedData.Protect(Encoding.UTF8.GetBytes(plain), Entropy, DataProtectionScope.CurrentUser));

    // رمزگشایی ناموفق (کاربر یا پروفایل ویندوز دیگر) = مقدار خالی؛ هرگز متن رمزشده به‌جای کلید استفاده نمی‌شود.
    static string Decrypt(string? encoded)
    {
        if (string.IsNullOrEmpty(encoded)) return "";
        try { return Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String(encoded), Entropy, DataProtectionScope.CurrentUser)); }
        catch { return ""; }
    }
}

/// <summary>ارسال داده‌ی رمزگذاری‌شده‌ی فقط‌خواندنی به سرور ابری برای نمایش در اپ موبایل.</summary>
public sealed class CloudSyncService
{
    public const int MinPasswordLength = 8;
    const string PairPrefix = "HG1.";
    readonly HttpClient _http;

    public CloudSyncService(HttpClient? http = null) => _http = http ?? new HttpClient { Timeout = TimeSpan.FromSeconds(60) };

    /// <summary>هشدار مرحله‌ی ارسال عکس‌های چک در آخرین PushAsync (داده‌ی اصلی در هر حال ارسال شده است).</summary>
    public string? LastImageWarning { get; private set; }
    public int LastImagesUploaded { get; private set; }
    const string ImageFingerprintKey = "CloudImagesFingerprint";

    public static string ImageUrl(string serverUrl, string channelId, string key) =>
        $"{serverUrl.TrimEnd('/')}/v1/img/{Uri.EscapeDataString(channelId)}/{Uri.EscapeDataString(key)}";

    public static string NewChannelId() => Convert.ToHexString(RandomNumberGenerator.GetBytes(16)).ToLowerInvariant();

    public static string BlobUrl(string serverUrl, string channelId) => $"{serverUrl.TrimEnd('/')}/v1/blob/{Uri.EscapeDataString(channelId)}";

    /// <summary>آدرس باید https باشد (به‌جز localhost برای آزمایش).</summary>
    public static string NormalizeServerUrl(string? url)
    {
        var t = (url ?? "").Trim().TrimEnd('/');
        if (!Uri.TryCreate(t, UriKind.Absolute, out var u) || (u.Scheme != Uri.UriSchemeHttps && !(u.Scheme == Uri.UriSchemeHttp && u.IsLoopback)))
            throw new ArgumentException("آدرس سرور باید با https:// شروع شود.");
        return t;
    }

    /// <summary>کد اتصال برای گوشی: فقط آدرس و شناسه‌ی کانال؛ رمز رمزگذاری هرگز داخل آن نیست.</summary>
    public static string BuildPairingCode(string serverUrl, string channelId)
    {
        var json = JsonSerializer.Serialize(new { u = serverUrl.TrimEnd('/'), i = channelId });
        return PairPrefix + Convert.ToBase64String(Encoding.UTF8.GetBytes(json)).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    }

    public static bool TryParsePairingCode(string? code, out string serverUrl, out string channelId)
    {
        serverUrl = channelId = "";
        try
        {
            var t = (code ?? "").Trim();
            if (!t.StartsWith(PairPrefix, StringComparison.Ordinal)) return false;
            var b = t[PairPrefix.Length..].Replace('-', '+').Replace('_', '/');
            b = b.PadRight(b.Length + (4 - b.Length % 4) % 4, '=');
            using var doc = JsonDocument.Parse(Convert.FromBase64String(b));
            serverUrl = doc.RootElement.GetProperty("u").GetString() ?? "";
            channelId = doc.RootElement.GetProperty("i").GetString() ?? "";
            return serverUrl.StartsWith("https://", StringComparison.Ordinal) && channelId.Length == 32;
        }
        catch { return false; }
    }

    /// <summary>داده را رمز می‌کند و روی سرور می‌گذارد. تعداد بایت ارسال‌شده را برمی‌گرداند.</summary>
    public async Task<int> PushAsync(CloudSyncSettings s, CancellationToken ct = default)
    {
        if (!s.IsConfigured) throw new InvalidOperationException("همگام‌سازی ابری کامل تنظیم نشده است.");
        if (s.Password.Length < MinPasswordLength) throw new InvalidOperationException($"رمز رمزگذاری حداقل {MinPasswordLength} نویسه باشد.");
        var server = NormalizeServerUrl(s.ServerUrl);

        // عکس‌های چک اول می‌روند تا وقتی داده‌ی اصلی در گوشی دیده شد، عکس‌ها هم آماده باشند. خطای عکس مانع ارسال داده‌ی اصلی نمی‌شود.
        LastImageWarning = null; LastImagesUploaded = 0;
        try { LastImagesUploaded = await PushImagesAsync(s, server, ct); }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
        catch (Exception ex)   // هر خطای عکس‌ها (شبکه، سرور قدیمی، دیتابیس) نباید ارسال داده‌ی اصلی را متوقف کند
        {
            LastImageWarning = "ارسال عکس چک‌ها ناقص ماند: " + ex.Message;
        }

        var envelope = CloudCrypto.Encrypt(await new MobileExportService().BuildJsonAsync(ct), s.Password);
        using var request = new HttpRequestMessage(HttpMethod.Put, BlobUrl(server, s.ChannelId))
        {
            Content = new StringContent(envelope, Encoding.UTF8, "application/json")
        };
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", s.ApiKey);

        HttpResponseMessage response;
        try { response = await _http.SendAsync(request, ct); }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { throw new InvalidOperationException("پاسخ سرور دیر رسید. دوباره تلاش کنید."); }
        catch (HttpRequestException) { throw new InvalidOperationException("اتصال به سرور ابری برقرار نشد (اینترنت یا فیلترینگ را بررسی کنید)."); }
        using (response)
        {
            if (!response.IsSuccessStatusCode)
                throw new InvalidOperationException(response.StatusCode switch
                {
                    HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden => "کلید ارسال درست نیست.",
                    HttpStatusCode.RequestEntityTooLarge => "حجم داده از حد مجاز سرور بیشتر است.",
                    _ => $"سرور ابری خطا داد ({(int)response.StatusCode})."
                });
        }

        var bytes = Encoding.UTF8.GetByteCount(envelope);
        var user = UserSession.CurrentUser;
        await using var db = new AppDbContext();
        db.AuditLogs.Add(new AuditLog { TimestampUtc = DateTime.UtcNow, UserId = user?.Id, UserName = user?.UserName, IpAddress = UserSession.IpAddress, Action = "CloudPush", Entity = "Cloud", Details = $"bytes={bytes}" });
        await db.SaveChangesAsync(ct);
        return bytes;
    }

    /// <summary>عکس‌های هنوز ارسال‌نشده (یا قدیمی‌تر از ۳۰۰ روز، چون سرور بعد از حدود ۴۰۰ روز پاکشان می‌کند) را رمز و ارسال می‌کند.</summary>
    async Task<int> PushImagesAsync(CloudSyncSettings s, string server, CancellationToken ct)
    {
        await using var db = new AppDbContext();
        if (!await db.PaymentImages.AnyAsync(ct)) return 0;

        // اگر سرور/کانال/رمز عوض شده باشد، همه‌ی عکس‌ها باید دوباره به مقصد جدید بروند.
        var settings = new SettingsService();
        var fingerprint = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes($"{server}|{s.ChannelId}|{s.Password}")))[..24];
        if (await settings.GetAsync(ImageFingerprintKey, ct) != fingerprint)
        {
            await db.PaymentImages.ExecuteUpdateAsync(x => x.SetProperty(i => i.CloudUploadedAt, (DateTime?)null), ct);
            await settings.SetAsync(ImageFingerprintKey, fingerprint, ct);
        }

        var stale = DateTime.UtcNow.AddDays(-300);
        var pending = await db.PaymentImages.AsNoTracking()
            .Where(x => x.CloudKey != "" && (x.CloudUploadedAt == null || x.CloudUploadedAt < stale))
            .Select(x => x.CloudKey).Distinct().ToListAsync(ct);
        if (pending.Count == 0) return 0;

        using var encryptor = new CloudCrypto.BatchEncryptor(s.Password);
        var uploaded = 0;
        foreach (var key in pending)
        {
            var data = await db.PaymentImages.AsNoTracking().Where(x => x.CloudKey == key).Select(x => x.Data).FirstAsync(ct);
            using var request = new HttpRequestMessage(HttpMethod.Put, ImageUrl(server, s.ChannelId, key))
            {
                Content = new StringContent(encryptor.EncryptBytes(data), Encoding.UTF8, "application/json")
            };
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", s.ApiKey);
            HttpResponseMessage response;
            try { response = await _http.SendAsync(request, ct); }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested) { throw new InvalidOperationException("پاسخ سرور دیر رسید."); }
            catch (HttpRequestException) { throw new InvalidOperationException("اتصال به سرور ابری برقرار نشد."); }
            using (response)
            {
                if (response.StatusCode is HttpStatusCode.NotFound or HttpStatusCode.MethodNotAllowed)
                    throw new InvalidOperationException("سرور ابری هنوز به‌روز نشده است؛ فایل جدید cloud/worker.js را در Cloudflare منتشر کنید.");
                if (!response.IsSuccessStatusCode)
                    throw new InvalidOperationException(response.StatusCode switch
                    {
                        HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden => "کلید ارسال درست نیست.",
                        HttpStatusCode.RequestEntityTooLarge => "حجم یکی از عکس‌ها از حد مجاز سرور بیشتر است.",
                        _ => $"سرور ابری خطا داد ({(int)response.StatusCode})."
                    });
            }
            await db.PaymentImages.Where(x => x.CloudKey == key).ExecuteUpdateAsync(x => x.SetProperty(i => i.CloudUploadedAt, (DateTime?)DateTime.UtcNow), ct);
            uploaded++;
        }
        return uploaded;
    }
}
