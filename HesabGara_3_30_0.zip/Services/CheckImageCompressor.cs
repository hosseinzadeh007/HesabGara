using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace HesabGara.Services;

/// <summary>
/// فشرده‌سازی عکس چک/رسید برای بایگانی: چرخش درست (EXIF)، کوچک‌کردن به حداکثر ۱۲۸۰ پیکسل و ذخیره‌ی JPEG؛
/// کیفیت و اندازه آن‌قدر پایین می‌آید تا حجم از حدود ۸۰ کیلوبایت کمتر شود (عکس ۴ تا ۶ مگابایتی گوشی معمولاً ۴۰ تا ۸۰ کیلوبایت می‌شود
/// و شماره/مبلغ چک همچنان خوانا می‌ماند). باید روی ریسمان رابط (UI) صدا زده شود.
/// </summary>
public static class CheckImageCompressor
{
    public const int TargetBytes = 80 * 1024;
    const long MaxSourceBytes = 60L * 1024 * 1024;
    static readonly int[] Sides = { 1280, 1120, 960, 820 };
    static readonly int[] Qualities = { 68, 58, 48, 40 };

    public static byte[] CompressFile(string path)
    {
        var info = new FileInfo(path);
        if (!info.Exists) throw new InvalidOperationException("فایل عکس پیدا نشد.");
        if (info.Length > MaxSourceBytes) throw new InvalidOperationException("حجم فایل عکس بیش از حد بزرگ است.");
        BitmapFrame frame;
        try
        {
            using var ms = new MemoryStream(File.ReadAllBytes(path));
            frame = BitmapFrame.Create(ms, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
        }
        catch (Exception ex) when (ex is NotSupportedException or FileFormatException or InvalidOperationException or IOException)
        {
            throw new InvalidOperationException("این فایل، عکس معتبری نیست.");
        }
        return Compress(frame, ReadRotation(frame));
    }

    public static byte[] Compress(BitmapSource source, int rotationDegrees = 0)
    {
        BitmapSource s = source;
        if (rotationDegrees != 0)
        {
            var t = new TransformedBitmap();
            t.BeginInit();
            t.Source = s;
            t.Transform = new RotateTransform(rotationDegrees);
            t.EndInit();
            t.Freeze();
            s = t;
        }
        byte[]? best = null;
        foreach (var side in Sides)
        {
            var scaled = RenderOnWhite(s, side);
            foreach (var q in Qualities)
            {
                var data = Encode(scaled, q);
                if (best is null || data.Length < best.Length) best = data;
                if (data.Length <= TargetBytes) return data;
            }
        }
        return best ?? throw new InvalidOperationException("فشرده‌سازی عکس ناموفق بود.");
    }

    static int ReadRotation(BitmapFrame frame)
    {
        try
        {
            if (frame.Metadata is BitmapMetadata m && m.ContainsQuery("System.Photo.Orientation") && m.GetQuery("System.Photo.Orientation") is ushort o)
                return o switch { 3 => 180, 6 => 90, 8 => 270, _ => 0 };
        }
        catch (Exception ex) when (ex is NotSupportedException or InvalidOperationException or ArgumentException) { /* عکس بدون EXIF */ }
        return 0;
    }

    // با کیفیت بالا کوچک می‌کند و روی زمینه‌ی سفید می‌گذارد (برای PNG شفاف).
    static BitmapSource RenderOnWhite(BitmapSource s, int maxSide)
    {
        var longSide = Math.Max(s.PixelWidth, s.PixelHeight);
        var f = longSide > maxSide ? (double)maxSide / longSide : 1.0;
        var w = Math.Max(1, (int)Math.Round(s.PixelWidth * f));
        var h = Math.Max(1, (int)Math.Round(s.PixelHeight * f));
        var dv = new DrawingVisual();
        RenderOptions.SetBitmapScalingMode(dv, BitmapScalingMode.HighQuality);
        using (var dc = dv.RenderOpen())
        {
            dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, w, h));
            dc.DrawImage(s, new Rect(0, 0, w, h));
        }
        var rtb = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Pbgra32);
        rtb.Render(dv);
        rtb.Freeze();
        return rtb;
    }

    static byte[] Encode(BitmapSource s, int quality)
    {
        var enc = new JpegBitmapEncoder { QualityLevel = quality };
        enc.Frames.Add(BitmapFrame.Create(s));
        using var ms = new MemoryStream();
        enc.Save(ms);
        return ms.ToArray();
    }
}
