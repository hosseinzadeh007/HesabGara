using HesabGara.Data;
using HesabGara.Domain;
using HesabGara.Models;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

public sealed partial class AccountingService
{
    public sealed record SplitPaymentAllocation(int InvoiceId, string InvoiceNumber, decimal Amount);
    public sealed record SplitPaymentResult(List<SplitPaymentAllocation> Allocations);

    // برای حالتی که یک چک/پرداخت واحد، مجموع چند فاکتور را پوشش می‌دهد. مبلغ کل بین
    // فاکتورهای انتخاب‌شده - به ترتیب نزدیک‌ترین سررسید اول - تقسیم می‌شود و برای هر کدام
    // یک رکورد Payment جداگانه (با همان مشخصات چک) ثبت می‌شود، همه در یک تراکنش واحد.
    public async Task<SplitPaymentResult> AddSplitPaymentAsync(List<int> invoiceIds, decimal totalAmount, DateTime payDate, string paymentMethod, string? checkNumber, DateTime? checkDate, string? checkStatus, string? note, CancellationToken ct = default, IReadOnlyList<byte[]>? images = null)
    {
        ValidateImages(images);
        if (invoiceIds is null || invoiceIds.Count < 2) throw new ArgumentException("برای پرداخت مشترک، حداقل دو فاکتور باید انتخاب شود.");
        if (totalAmount <= 0) throw new ArgumentException("مبلغ کل باید بزرگ‌تر از صفر باشد.");
        var method = PaymentMethods.Normalize(paymentMethod);

        SplitPaymentResult? splitResult = null;
        await using var db = new AppDbContext();
        await InTransactionAsync(db, async () =>
        {

        var invoices = await db.Invoices.Where(x => invoiceIds.Contains(x.Id)).OrderBy(x => x.DueDate).ToListAsync(ct);
        if (invoices.Count != invoiceIds.Distinct().Count()) throw new InvalidOperationException("برخی از فاکتورهای انتخاب‌شده پیدا نشدند.");

        var remaining = totalAmount;
        var allocations = new List<SplitPaymentAllocation>();
        var added = new List<Payment>();
        foreach (var inv in invoices)
        {
            if (remaining <= 0) break;
            var otherPaid = (await db.Payments.Where(x => x.InvoiceId == inv.Id).Select(x => x.Amount).ToListAsync(ct)).Sum();
            var balance = Math.Max(0m, inv.NetAmount - otherPaid);
            if (balance <= 0) continue;
            var portion = Math.Min(balance, remaining);

            var pay = new Payment
            {
                InvoiceId = inv.Id, Amount = portion, PayDate = payDate.Date, PaymentMethod = method,
                CheckNumber = method == "چک" ? (string.IsNullOrWhiteSpace(checkNumber) ? null : checkNumber.Trim()) : null,
                CheckDate = method == "چک" ? checkDate?.Date : null,
                CheckStatus = method == "چک" ? (string.IsNullOrWhiteSpace(checkStatus) ? "در انتظار وصول" : checkStatus) : null,
                Note = string.IsNullOrWhiteSpace(note) ? $"بخشی از یک پرداخت مشترک برای {invoices.Count} فاکتور" : note.Trim()
            };
            db.Payments.Add(pay); added.Add(pay);
            inv.Paid = otherPaid + portion;
            remaining -= portion;
            allocations.Add(new SplitPaymentAllocation(inv.Id, inv.Number, portion));
        }

        if (allocations.Count == 0) throw new InvalidOperationException("هیچ‌کدام از فاکتورهای انتخاب‌شده مانده‌ی قابل‌وصول ندارند.");
        if (remaining > 0.01m) throw new InvalidOperationException($"مبلغ واردشده {remaining:N0} ریال بیشتر از مجموع مانده‌ی فاکتورهای انتخاب‌شده است.");

        await db.SaveChangesAsync(ct);
        foreach (var p in added) AddImagesToContext(db, p.Id, images);   // همان عکس چک برای همه‌ی سهم‌ها
        foreach (var a in allocations)
            await AuditAsync("Create", "Payment(Split)", a.InvoiceId.ToString(), $"Invoice={a.InvoiceNumber}; Amount={a.Amount}; GroupTotal={totalAmount}", db, ct);
        await db.SaveChangesAsync(ct);
        splitResult = new SplitPaymentResult(allocations);
        }, ct);
        return splitResult!;
    }

    public async Task AddPaymentAsync(Payment payment, CancellationToken ct = default, IReadOnlyList<byte[]>? images = null)
    {
        ValidateImages(images);
        if (payment.Amount <= 0) throw new ArgumentException("مبلغ پرداخت باید بزرگ‌تر از صفر باشد.");
        await using var db = new AppDbContext();
        await InTransactionAsync(db, async () =>
        {
        var inv = await db.Invoices.SingleOrDefaultAsync(x => x.Id == payment.InvoiceId, ct) ?? throw new InvalidOperationException("فاکتور پیدا نشد.");
        var alreadyPaid = await PaidTotalAsync(db, inv.Id, null, ct);
        var balance = Math.Max(0m, inv.NetAmount - alreadyPaid);
        if (balance <= 0) throw new InvalidOperationException("فاکتور تسویه شده است.");
        if (payment.Amount > balance) throw new InvalidOperationException($"مبلغ پرداخت بیشتر از مانده فاکتور است. مانده: {balance:N0}");

        payment.PayDate = payment.PayDate.Date;
        payment.PaymentMethod = PaymentMethods.Normalize(payment.PaymentMethod);
        PaymentRules.NormalizeCheckFields(payment);

        inv.Paid = alreadyPaid + payment.Amount;
        db.Payments.Add(payment);
        await db.SaveChangesAsync(ct);
        AddImagesToContext(db, payment.Id, images);   // با SaveChanges بعد از ثبت لاگ ذخیره می‌شود
        await AuditAsync("Create", "Payment", payment.Id.ToString(), $"Invoice={inv.Number}; Amount={payment.Amount}; Method={payment.PaymentMethod}; Check={payment.CheckNumber}", db, ct);
        await db.SaveChangesAsync(ct);
        }, ct);
    }

    public async Task UpdatePaymentAsync(Payment payment, CancellationToken ct = default, IReadOnlyList<byte[]>? images = null, IReadOnlyList<int>? removeImageIds = null)
    {
        ValidateImages(images);
        if (payment.Amount <= 0) throw new ArgumentException("مبلغ پرداخت باید بزرگ‌تر از صفر باشد.");
        await using var db = new AppDbContext();
        await InTransactionAsync(db, async () =>
        {
        var entity = await db.Payments.SingleOrDefaultAsync(x => x.Id == payment.Id, ct) ?? throw new InvalidOperationException("وصول پیدا نشد.");
        var inv = await db.Invoices.SingleOrDefaultAsync(x => x.Id == entity.InvoiceId, ct) ?? throw new InvalidOperationException("فاکتور پیدا نشد.");

        // otherPaid وصول در حال ویرایش را شامل نمی‌شود؛ وگرنه هر ویرایش به اندازه‌ی مبلغ قبلی خودش بیش‌ازحد به نظر می‌رسید.
        var otherPaid = await PaidTotalAsync(db, entity.InvoiceId, entity.Id, ct);
        var maxAllowed = Math.Max(0m, inv.NetAmount - otherPaid);
        if (payment.Amount > maxAllowed) throw new InvalidOperationException($"مبلغ وصول بیشتر از مانده‌ی مجاز فاکتور است. حداکثر مجاز: {maxAllowed:N0}");

        entity.Amount = payment.Amount;
        entity.PayDate = payment.PayDate.Date;
        entity.PaymentMethod = PaymentMethods.Normalize(payment.PaymentMethod);
        entity.CheckNumber = payment.CheckNumber;
        entity.CheckDate = payment.CheckDate;
        entity.CheckStatus = payment.CheckStatus;
        PaymentRules.NormalizeCheckFields(entity);
        entity.Note = string.IsNullOrWhiteSpace(payment.Note) ? null : payment.Note.Trim();

        if (removeImageIds is { Count: > 0 })
        {
            var rm = removeImageIds.ToList();
            await db.PaymentImages.Where(x => x.PaymentId == entity.Id && rm.Contains(x.Id)).ExecuteDeleteAsync(ct);
        }
        if (images is { Count: > 0 })
        {
            var existing = await db.PaymentImages.CountAsync(x => x.PaymentId == entity.Id, ct);
            if (existing + images.Count > MaxImagesPerPayment) throw new InvalidOperationException($"برای هر وصول حداکثر {MaxImagesPerPayment} عکس مجاز است.");
            AddImagesToContext(db, entity.Id, images);
        }

        inv.Paid = Math.Min(inv.NetAmount, otherPaid + entity.Amount);
        await db.SaveChangesAsync(ct);
        await AuditAsync("Update", "Payment", entity.Id.ToString(), $"Invoice={inv.Number}; Amount={entity.Amount}; Method={entity.PaymentMethod}", db, ct);
        await db.SaveChangesAsync(ct);
        }, ct);
    }

    public sealed record CheckCollectResult(int Updated, int AlreadyDone, int Skipped);

    static string CheckKey(string? s) => (s ?? "").Trim().ToUpperInvariant();

    /// <summary>
    /// وصول‌شدن چک (مثلاً از اپ موبایل). فقط وصولِ «چک» با وضعیت «در انتظار وصول» که شماره‌ی چکش با پیام بخواند
    /// به «وصول‌شده» می‌رود. چک وصول‌شده‌ی قبلی بی‌اثر است (ارسال تکراری ضرر ندارد) و چک برگشتی/لغوشده هرگز
    /// با این مسیر تغییر نمی‌کند. مبلغ و مانده‌ی فاکتور عوض نمی‌شود (چک از لحظه‌ی ثبت جزو پرداختی حساب می‌شود).
    /// </summary>
    public async Task<CheckCollectResult> MarkChecksCollectedAsync(IReadOnlyCollection<int> paymentIds, string? checkNumber, string source, CancellationToken ct = default)
    {
        if (paymentIds is null || paymentIds.Count == 0) return new CheckCollectResult(0, 0, 0);
        var ids = paymentIds.Distinct().ToList();
        int updated = 0, already = 0, skipped = 0;
        await using var db = new AppDbContext();
        await InTransactionAsync(db, async () =>
        {
            updated = 0; already = 0; skipped = 0; // اگر strategy تراکنش را دوباره اجرا کند، از صفر شروع می‌شود
            var rows = await db.Payments.Where(x => ids.Contains(x.Id)).ToListAsync(ct);
            skipped = ids.Count - rows.Count;
            var wanted = CheckKey(checkNumber);
            foreach (var p in rows)
            {
                if (p.PaymentMethod != PaymentMethods.Check || (wanted.Length > 0 && CheckKey(p.CheckNumber) != wanted)) { skipped++; continue; }
                if (p.CheckStatus == PaymentRules.CollectedCheckStatus) { already++; continue; }
                if (p.CheckStatus != PaymentRules.DefaultCheckStatus) { skipped++; continue; }
                p.CheckStatus = PaymentRules.CollectedCheckStatus;
                updated++;
                await AuditAsync("Update", "Payment(CheckCollected)", p.Id.ToString(), $"Check={p.CheckNumber}; Source={source}", db, ct);
            }
            await db.SaveChangesAsync(ct);
        }, ct);
        return new CheckCollectResult(updated, already, skipped);
    }

    public async Task DeletePaymentAsync(int paymentId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext(); await InTransactionAsync(db, async () => {
        var entity = await db.Payments.Include(x => x.Invoice).SingleOrDefaultAsync(x => x.Id == paymentId, ct) ?? throw new InvalidOperationException("پرداخت پیدا نشد.");
        await db.PaymentImages.Where(x => x.PaymentId == paymentId).ExecuteDeleteAsync(ct);
        var invoiceId = entity.InvoiceId; db.Payments.Remove(entity); await db.SaveChangesAsync(ct);
        var paid = (await db.Payments.Where(x => x.InvoiceId == invoiceId).Select(x => x.Amount).ToListAsync(ct)).Sum();
        var inv = await db.Invoices.SingleOrDefaultAsync(x => x.Id == invoiceId, ct); if (inv != null) inv.Paid = Math.Min(inv.NetAmount, paid);
        await db.SaveChangesAsync(ct); await AuditAsync("Delete", "Payment", paymentId.ToString(), $"Invoice={invoiceId}; Amount={entity.Amount}", db, ct); await db.SaveChangesAsync(ct); }, ct);
    }

    public async Task ReconcilePaidAmountsAsync(CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var invoices = await db.Invoices.Include(x => x.Payments).ToListAsync(ct);
        foreach (var inv in invoices) inv.Paid = Math.Min(inv.NetAmount, inv.Payments.Sum(x => x.Amount));
        await db.SaveChangesAsync(ct);
    }

    public async Task<List<Payment>> GetPaymentsAsync(int? companyId = null, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var q = db.Payments.Include(x => x.Invoice!).ThenInclude(x => x.Company).AsNoTracking().AsQueryable();
        if (companyId.HasValue) q = q.Where(x => x.Invoice!.CompanyId == companyId.Value);
        return await q.OrderByDescending(x => x.PayDate).ThenByDescending(x => x.Id).ToListAsync(ct);
    }

    public async Task<Payment?> GetPaymentByIdAsync(int paymentId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        return await db.Payments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == paymentId, ct);
    }

    public async Task<List<Payment>> GetPaymentsForInvoiceAsync(int invoiceId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        return await db.Payments.AsNoTracking()
            .Where(x => x.InvoiceId == invoiceId)
            .OrderByDescending(x => x.PayDate).ThenByDescending(x => x.Id)
            .ToListAsync(ct);
    }
}
