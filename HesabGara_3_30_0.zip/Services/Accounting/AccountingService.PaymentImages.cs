﻿using System.Security.Cryptography;
using HesabGara.Data;
using HesabGara.Models;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

/// <summary>عکس چک/رسید وصول‌ها (بایگانی). عکس‌ها از قبل فشرده شده‌اند (CheckImageCompressor) و در همان دیتابیس می‌مانند؛
/// پس پشتیبان‌گیری و بازیابی خودکار آن‌ها را هم شامل می‌شود.</summary>
public sealed partial class AccountingService
{
    public const int MaxImagesPerPayment = 8;
    public const int MaxImageBytes = 400 * 1024;   // سقف هر عکس بعد از فشرده‌سازی

    public sealed record PaymentImageData(int Id, byte[] Data);

    /// <summary>شناسه‌ی عکس در ابر: ۳۲ نویسه‌ی اول SHA-256 محتوا (عکس یکسان = شناسه‌ی یکسان).</summary>
    public static string ImageCloudKey(byte[] data) => Convert.ToHexString(SHA256.HashData(data))[..32].ToLowerInvariant();

    static void ValidateImages(IReadOnlyList<byte[]>? images)
    {
        if (images is null) return;
        if (images.Count > MaxImagesPerPayment) throw new InvalidOperationException($"برای هر وصول حداکثر {MaxImagesPerPayment} عکس مجاز است.");
        foreach (var d in images)
            if (d is null || d.Length == 0 || d.Length > MaxImageBytes) throw new InvalidOperationException("عکس نامعتبر است یا حجمش بعد از فشرده‌سازی از حد مجاز بیشتر است.");
    }

    static void AddImagesToContext(AppDbContext db, int paymentId, IReadOnlyList<byte[]>? images)
    {
        if (images is null) return;
        foreach (var data in images)
            db.PaymentImages.Add(new PaymentImage { PaymentId = paymentId, Data = data, CreatedAt = DateTime.UtcNow, CloudKey = ImageCloudKey(data) });
    }

    public async Task<List<PaymentImageData>> GetPaymentImagesAsync(int paymentId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var rows = await db.PaymentImages.AsNoTracking().Where(x => x.PaymentId == paymentId).OrderBy(x => x.Id).Select(x => new { x.Id, x.Data }).ToListAsync(ct);
        return rows.Select(x => new PaymentImageData(x.Id, x.Data)).ToList();
    }

    /// <summary>تعداد عکس هر وصول (بدون بارگذاری خود عکس‌ها).</summary>
    public async Task<Dictionary<int, int>> GetPaymentImageCountsAsync(IReadOnlyCollection<int> paymentIds, CancellationToken ct = default)
    {
        if (paymentIds.Count == 0) return new Dictionary<int, int>();
        var ids = paymentIds.ToList();
        await using var db = new AppDbContext();
        var rows = await db.PaymentImages.AsNoTracking().Where(x => ids.Contains(x.PaymentId)).GroupBy(x => x.PaymentId).Select(g => new { Id = g.Key, N = g.Count() }).ToListAsync(ct);
        return rows.ToDictionary(x => x.Id, x => x.N);
    }
}
