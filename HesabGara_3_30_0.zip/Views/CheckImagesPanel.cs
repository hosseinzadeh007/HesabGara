using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using HesabGara.Services;
using Microsoft.Win32;

namespace HesabGara.Views;

/// <summary>
/// بخش «عکس چک / رسید» در فرم ثبت وصول: افزودن از فایل یا کلیپ‌بورد، فشرده‌سازی خودکار، نمایش بندانگشتی، حذف و دیدن عکس بزرگ.
/// فرم ثبت از NewImages و RemovedIds استفاده می‌کند.
/// </summary>
public sealed class CheckImagesPanel : Border
{
    sealed class Item { public int? Id; public byte[] Data = Array.Empty<byte>(); }

    readonly List<Item> _items = new();
    readonly List<int> _removed = new();
    readonly WrapPanel _thumbs = new() { Margin = new Thickness(0, 6, 0, 0) };
    readonly TextBlock _info = new() { Foreground = AppTheme.Ink500, FontSize = 11.5, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 0) };
    int _loadToken;

    public IReadOnlyList<byte[]> NewImages => _items.Where(x => x.Id is null).Select(x => x.Data).ToList();
    public IReadOnlyList<int> RemovedIds => _removed.ToList();

    public CheckImagesPanel()
    {
        Margin = new Thickness(0, 0, 0, 10);
        var stack = new StackPanel();
        stack.Children.Add(new TextBlock { Text = "عکس چک / رسید (اختیاری، برای بایگانی)", FontWeight = FontWeights.SemiBold, FontSize = 12.5, Foreground = AppTheme.Ink700, Margin = new Thickness(0, 0, 0, 3) });
        var buttons = new WrapPanel();
        buttons.Children.Add(MakeButton("افزودن عکس…", AddFromFiles));
        buttons.Children.Add(MakeButton("چسباندن از کلیپ‌بورد", AddFromClipboard));
        stack.Children.Add(buttons);
        stack.Children.Add(_thumbs);
        stack.Children.Add(_info);
        Child = stack;
        Refresh();
    }

    static Button MakeButton(string text, Action act)
    {
        var b = new Button { Content = text, Padding = new Thickness(10, 5, 10, 5), Margin = new Thickness(0, 0, 6, 0), Background = AppTheme.Surface100, Foreground = AppTheme.Ink700, BorderBrush = AppTheme.Line300, BorderThickness = new Thickness(1), Cursor = Cursors.Hand };
        b.Click += (_, _) => act();
        return b;
    }

    public void Reset()
    {
        _loadToken++;
        _items.Clear(); _removed.Clear();
        Refresh();
    }

    /// <summary>عکس‌های ذخیره‌شده‌ی یک وصول را برای ویرایش نشان می‌دهد.</summary>
    public async Task LoadExistingAsync(int paymentId)
    {
        Reset();
        var token = _loadToken;
        try
        {
            var list = await new AccountingService().GetPaymentImagesAsync(paymentId);
            if (token != _loadToken) return;   // در همین فاصله وصول دیگری انتخاب شده
            foreach (var i in list) _items.Add(new Item { Id = i.Id, Data = i.Data });
            Refresh();
        }
        catch (Exception ex) { _info.Text = "بارگذاری عکس‌ها ناموفق بود: " + ex.Message; }
    }

    int Room => AccountingService.MaxImagesPerPayment - _items.Count;

    void AddFromFiles()
    {
        if (Room <= 0) { MessageBox.Show($"برای هر وصول حداکثر {AccountingService.MaxImagesPerPayment} عکس مجاز است."); return; }
        var d = new OpenFileDialog { Filter = "عکس‌ها|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tif;*.tiff|همه‌ی فایل‌ها|*.*", Multiselect = true, Title = "انتخاب عکس چک" };
        if (d.ShowDialog() != true) return;
        var skipped = 0;
        Mouse.OverrideCursor = Cursors.Wait;
        try
        {
            foreach (var path in d.FileNames)
            {
                if (Room <= 0) { skipped++; continue; }
                try { _items.Add(new Item { Data = CheckImageCompressor.CompressFile(path) }); }
                catch (InvalidOperationException ex) { MessageBox.Show($"{Path.GetFileName(path)}: {ex.Message}", "عکس چک", MessageBoxButton.OK, MessageBoxImage.Warning); }
            }
        }
        finally { Mouse.OverrideCursor = null; }
        if (skipped > 0) MessageBox.Show($"فقط {AccountingService.MaxImagesPerPayment} عکس برای هر وصول پذیرفته می‌شود؛ {skipped} عکس اضافه نادیده گرفته شد.");
        Refresh();
    }

    void AddFromClipboard()
    {
        if (Room <= 0) { MessageBox.Show($"برای هر وصول حداکثر {AccountingService.MaxImagesPerPayment} عکس مجاز است."); return; }
        BitmapSource? src = null;
        try { if (Clipboard.ContainsImage()) src = Clipboard.GetImage(); }
        catch (System.Runtime.InteropServices.ExternalException) { /* کلیپ‌بورد در دست برنامه‌ی دیگر است */ }
        if (src is null) { MessageBox.Show("در کلیپ‌بورد عکسی نیست. عکس را کپی کنید (یا با Win+Shift+S از صفحه بگیرید) و دوباره امتحان کنید."); return; }
        Mouse.OverrideCursor = Cursors.Wait;
        try { _items.Add(new Item { Data = CheckImageCompressor.Compress(src) }); }
        catch (InvalidOperationException ex) { MessageBox.Show(ex.Message, "عکس چک", MessageBoxButton.OK, MessageBoxImage.Warning); }
        finally { Mouse.OverrideCursor = null; }
        Refresh();
    }

    static BitmapImage Decode(byte[] data, int pixelWidth)
    {
        var bi = new BitmapImage();
        using var ms = new MemoryStream(data);
        bi.BeginInit(); bi.CacheOption = BitmapCacheOption.OnLoad; bi.DecodePixelWidth = pixelWidth; bi.StreamSource = ms; bi.EndInit();
        bi.Freeze();
        return bi;
    }

    void Refresh()
    {
        _thumbs.Children.Clear();
        for (var n = 0; n < _items.Count; n++)
        {
            var item = _items[n]; var index = n;
            var img = new Image { Source = Decode(item.Data, 180), Width = 84, Height = 84, Stretch = Stretch.UniformToFill, Cursor = Cursors.Hand, ToolTip = "برای دیدن عکس بزرگ کلیک کنید" };
            img.MouseLeftButtonUp += (_, _) => ImageViewerWindow.ShowImages(Window.GetWindow(this), _items.Select(x => x.Data).ToList(), index);
            var remove = new Button { Content = "✕", Width = 20, Height = 20, Padding = new Thickness(0), FontSize = 11, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(2), Background = AppTheme.Danger100, Foreground = AppTheme.Danger600, BorderThickness = new Thickness(0), Cursor = Cursors.Hand, ToolTip = "حذف این عکس" };
            remove.Click += (_, _) =>
            {
                if (item.Id is int id) _removed.Add(id);
                _items.Remove(item);
                Refresh();
            };
            var cell = new Grid { Margin = new Thickness(0, 0, 6, 6) };
            cell.Children.Add(new Border { BorderBrush = AppTheme.Line300, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(6), ClipToBounds = true, Child = img });
            cell.Children.Add(remove);
            _thumbs.Children.Add(cell);
        }
        var kb = _items.Sum(x => x.Data.Length) / 1024;
        _info.Text = _items.Count == 0
            ? "عکس هر چک پیش از ذخیره خودکار فشرده می‌شود (معمولاً کمتر از ۱۰۰ کیلوبایت) و در اپ موبایل هم قابل دیدن است."
            : $"{_items.Count:N0} عکس — حدود {kb + 1:N0} کیلوبایت" + (_removed.Count > 0 ? $"  |  {_removed.Count:N0} عکس با ذخیره حذف می‌شود" : "");
    }
}
