﻿using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace HesabGara.Views;

/// <summary>نمایش بزرگ عکس چک/رسید: پیکان‌ها یا دکمه‌ها برای عکس بعدی/قبلی، کلیک روی عکس برای اندازه‌ی واقعی، ذخیره‌ی عکس.</summary>
public sealed class ImageViewerWindow : Window
{
    readonly IReadOnlyList<byte[]> _images;
    int _index;
    readonly Image _img = new() { Stretch = Stretch.Uniform, Cursor = Cursors.Hand };
    readonly TextBlock _counter = new() { Foreground = Brushes.White, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(10, 0, 10, 0) };
    readonly ScrollViewer _scroll = new() { HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };

    public static void ShowImages(Window? owner, IReadOnlyList<byte[]> images, int index = 0)
    {
        if (images.Count == 0) return;
        var w = new ImageViewerWindow(images, Math.Clamp(index, 0, images.Count - 1));
        if (owner is not null) w.Owner = owner;
        w.Show();
    }

    ImageViewerWindow(IReadOnlyList<byte[]> images, int index)
    {
        _images = images; _index = index;
        Title = "عکس چک / رسید"; Width = 900; Height = 720;
        FlowDirection = FlowDirection.RightToLeft; WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Background = new SolidColorBrush(Color.FromRgb(0x1b, 0x1f, 0x24));

        var bar = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(8) };
        Button Make(string text, Action act)
        {
            var b = new Button { Content = text, Padding = new Thickness(12, 5, 12, 5), Margin = new Thickness(0, 0, 6, 0), Cursor = Cursors.Hand };
            b.Click += (_, _) => act();
            return b;
        }
        bar.Children.Add(Make("‹ قبلی", () => Go(-1)));
        bar.Children.Add(_counter);
        bar.Children.Add(Make("بعدی ›", () => Go(1)));
        bar.Children.Add(Make("ذخیره‌ی عکس…", Save));
        bar.Children.Add(new TextBlock { Text = "(کلیک روی عکس: اندازه‌ی واقعی)", Foreground = Brushes.Gainsboro, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 0, 0, 0), FontSize = 11.5 });

        var dock = new DockPanel();
        DockPanel.SetDock(bar, Dock.Top);
        dock.Children.Add(bar);
        _scroll.Content = _img;
        dock.Children.Add(_scroll);
        Content = dock;

        _img.MouseLeftButtonUp += (_, _) => ToggleZoom();
        KeyDown += (_, e) =>
        {
            if (e.Key == Key.Escape) Close();
            else if (e.Key == Key.Right) Go(-1);   // در چیدمان راست‌به‌چپ، پیکان راست = قبلی
            else if (e.Key == Key.Left) Go(1);
        };
        ShowAt(_index);
    }

    void ShowAt(int index)
    {
        _index = index;
        var bi = new BitmapImage();
        using (var ms = new MemoryStream(_images[index]))
        {
            bi.BeginInit(); bi.CacheOption = BitmapCacheOption.OnLoad; bi.StreamSource = ms; bi.EndInit();
        }
        bi.Freeze();
        _img.Source = bi;
        _img.Stretch = Stretch.Uniform;
        _counter.Text = $"{index + 1} از {_images.Count}   ({_images[index].Length / 1024 + 1} کیلوبایت)";
    }

    void Go(int delta) { if (_images.Count > 1) ShowAt((_index + delta + _images.Count) % _images.Count); }

    void ToggleZoom() => _img.Stretch = _img.Stretch == Stretch.Uniform ? Stretch.None : Stretch.Uniform;

    void Save()
    {
        var d = new SaveFileDialog { Filter = "JPEG|*.jpg", FileName = $"check-image-{_index + 1}.jpg" };
        if (d.ShowDialog(this) != true) return;
        try { File.WriteAllBytes(d.FileName, _images[_index]); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { MessageBox.Show(ex.Message, "ذخیره‌ی عکس", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }
}
