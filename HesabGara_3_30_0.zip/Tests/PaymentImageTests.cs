using System.Text.Json;
using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

/// <summary>عکس چک/رسید وصول‌ها: ذخیره همراه وصول، ویرایش، حذف و ورود شناسه‌ی عکس‌ها به خروجی موبایل.</summary>
public class PaymentImageTests : DatabaseTestBase
{
    static readonly AccountingService S = new();

    static async Task<Payment> SeedAsync(byte[][]? images = null)
    {
        var company = new Company { Name = "شرکت عکس " + Guid.NewGuid().ToString("N")[..6] };
        await S.AddCompanyAsync(company);
        var invoice = new Invoice { CompanyId = company.Id, Number = "I-1", Amount = 1000m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(30) };
        await S.AddInvoiceAsync(invoice);
        var payment = new Payment { InvoiceId = invoice.Id, Amount = 400m, PayDate = DateTime.Today, PaymentMethod = PaymentMethods.Check, CheckNumber = "555", CheckDate = DateTime.Today.AddDays(10), CheckStatus = PaymentRules.DefaultCheckStatus };
        await S.AddPaymentAsync(payment, images: images);
        return payment;
    }

    [Fact]
    public async Task Images_Are_Saved_With_The_Payment_And_Counted()
    {
        var p = await SeedAsync(new[] { new byte[] { 1, 2, 3 }, new byte[] { 9, 9 } });
        var list = await S.GetPaymentImagesAsync(p.Id);
        Assert.Equal(2, list.Count);
        var counts = await S.GetPaymentImageCountsAsync(new[] { p.Id });
        Assert.Equal(2, counts[p.Id]);
    }

    [Fact]
    public async Task Update_Can_Add_And_Remove_Images()
    {
        var p = await SeedAsync(new[] { new byte[] { 1, 2, 3 } });
        var first = (await S.GetPaymentImagesAsync(p.Id)).Single();
        await S.UpdatePaymentAsync(new Payment { Id = p.Id, Amount = 400m, PayDate = DateTime.Today, PaymentMethod = PaymentMethods.Check, CheckNumber = "555", CheckStatus = PaymentRules.DefaultCheckStatus },
            images: new[] { new byte[] { 7, 7, 7 } }, removeImageIds: new[] { first.Id });
        var after = await S.GetPaymentImagesAsync(p.Id);
        Assert.Single(after);
        Assert.Equal(new byte[] { 7, 7, 7 }, after[0].Data);
    }

    [Fact]
    public async Task Deleting_The_Payment_Deletes_Its_Images()
    {
        var p = await SeedAsync(new[] { new byte[] { 1, 2, 3 } });
        await S.DeletePaymentAsync(p.Id);
        Assert.Empty(await S.GetPaymentImagesAsync(p.Id));
    }

    [Fact]
    public async Task Too_Many_Or_Empty_Images_Are_Rejected()
    {
        var tooMany = Enumerable.Range(0, AccountingService.MaxImagesPerPayment + 1).Select(i => new byte[] { (byte)(i + 1) }).ToArray();
        await Assert.ThrowsAsync<InvalidOperationException>(() => SeedAsync(tooMany));
        await Assert.ThrowsAsync<InvalidOperationException>(() => SeedAsync(new[] { Array.Empty<byte>() }));
    }

    [Fact]
    public async Task Mobile_Export_Lists_Image_Keys_But_Not_The_Images()
    {
        var data = new byte[] { 5, 6, 7, 8 };
        var p = await SeedAsync(new[] { data });
        using var doc = JsonDocument.Parse(await new MobileExportService().BuildJsonAsync());
        var pay = doc.RootElement.GetProperty("payments").EnumerateArray().Single(x => x.GetProperty("id").GetInt32() == p.Id);
        var keys = pay.GetProperty("images").EnumerateArray().Select(x => x.GetString()).ToList();
        Assert.Equal(new[] { AccountingService.ImageCloudKey(data) }, keys);
    }
}
