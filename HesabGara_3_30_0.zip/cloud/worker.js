// حساب‌گرا — واسط ابری (Cloudflare Worker + KV)
// فقط داده‌ی رمزگذاری‌شده‌ی بی‌معنی را نگه می‌دارد؛ رمز هرگز به این‌جا نمی‌رسد.
// نسخه‌ی ۲: علاوه بر blob (ویندوز ← موبایل)، صندوق پیام /v1/inbox (موبایل ← ویندوز) برای ثبت وصول چک.
// نسخه‌ی ۳: عکس چک‌ها /v1/img/<کانال>/<شناسه‌ی عکس> (رمزگذاری‌شده؛ ارسال با کلید API، دریافت فقط با دانستن شناسه‌ی کانال و عکس).
// ارسال (PUT) فقط با کلید API؛ دریافت (GET) فقط با شناسه‌ی ۱۲۸ بیتی غیرقابل‌حدس کانال.
const MAX_BYTES = 8 * 1024 * 1024;
const TTL_SECONDS = 60 * 60 * 24 * 60; // ۶۰ روز بعد از آخرین ارسال پاک می‌شود
const MAX_INBOX_BYTES = 16 * 1024;      // هر پیام موبایل (مثلاً «وصول شدن یک چک») کوچک است
const MAX_INBOX_ITEMS = 40;             // سقف پیام‌های دریافت‌نشده؛ هر بار خواندن ≤ ۴۰ KV (محدودیت پلن رایگان)
const INBOX_TTL_SECONDS = 60 * 60 * 24 * 14; // پیامی که ویندوز ۱۴ روز نگیرد پاک می‌شود
const MAX_IMG_BYTES = 600 * 1024;           // هر عکس چک (فشرده و رمزشده) معمولاً کمتر از ۲۰۰ کیلوبایت است
const IMG_TTL_SECONDS = 60 * 60 * 24 * 400; // ویندوز عکس‌های قدیمی‌تر از ۳۰۰ روز را دوباره می‌فرستد
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, PUT, POST, DELETE, OPTIONS', 'Access-Control-Allow-Headers': 'Authorization, Content-Type' };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...CORS } });

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const path = new URL(req.url).pathname;

    // ---- صندوق پیام موبایل ← ویندوز (مثلاً ثبت وصول چک) ----
    // ارسال (POST) بدون کلید API: شناسه‌ی غیرقابل‌حدس کانال خودش مجوز است و پیام باید با رمز رمزگذاری‌شده باشد
    // (ویندوز پیامی را که با رمز درست رمز نشده باشد دور می‌ریزد). خواندن و پاک‌کردن فقط با کلید API.
    const im = path.match(/^\/v1\/inbox\/([0-9a-f]{32})(?:\/(\d{13}-[0-9a-f]{12}))?$/);
    if (im) {
      const prefix = 'inbox:' + im[1] + ':';
      if (req.method === 'POST' && !im[2]) {
        const body = await req.text();
        if (body.length > MAX_INBOX_BYTES) return json({ error: 'too_large' }, 413);
        try { const e = JSON.parse(body); if (e.v !== 1 || !e.salt || !e.iv || !e.ct) throw 0; } catch { return json({ error: 'bad_envelope' }, 400); }
        const pending = await env.STORE.list({ prefix, limit: MAX_INBOX_ITEMS });
        if (pending.keys.length >= MAX_INBOX_ITEMS) return json({ error: 'inbox_full' }, 429);
        const id = Date.now() + '-' + Array.from(crypto.getRandomValues(new Uint8Array(6)), b => b.toString(16).padStart(2, '0')).join('');
        await env.STORE.put(prefix + id, body, { expirationTtl: INBOX_TTL_SECONDS });
        return json({ ok: true, id });
      }
      if (!env.API_KEY || !safeEqual(req.headers.get('Authorization') || '', 'Bearer ' + env.API_KEY)) return json({ error: 'unauthorized' }, 401);
      if (req.method === 'GET' && !im[2]) {
        const list = await env.STORE.list({ prefix, limit: MAX_INBOX_ITEMS });
        const items = [];
        for (const k of list.keys) {
          const data = await env.STORE.get(k.name);
          if (data) items.push({ k: k.name.slice(prefix.length), data });
        }
        return json({ items });
      }
      if (req.method === 'DELETE' && im[2]) { await env.STORE.delete(prefix + im[2]); return json({ ok: true }); }
      return json({ error: 'method_not_allowed' }, 405);
    }

    // ---- عکس چک‌ها: محتوا رمزگذاری‌شده و تغییرناپذیر است (شناسه = هش محتوا)، پس کش طولانی بی‌خطر است ----
    const gm = path.match(/^\/v1\/img\/([0-9a-f]{32})\/([0-9a-f]{32})$/);
    if (gm) {
      const ikey = 'img:' + gm[1] + ':' + gm[2];
      if (req.method === 'GET') {
        const v = await env.STORE.get(ikey);
        return v ? new Response(v, { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=31536000, immutable', ...CORS } }) : json({ error: 'empty' }, 404);
      }
      if (!env.API_KEY || !safeEqual(req.headers.get('Authorization') || '', 'Bearer ' + env.API_KEY)) return json({ error: 'unauthorized' }, 401);
      if (req.method === 'PUT') {
        if ((Number(req.headers.get('Content-Length')) || 0) > MAX_IMG_BYTES) return json({ error: 'too_large' }, 413);
        const body = await req.text();
        if (body.length > MAX_IMG_BYTES) return json({ error: 'too_large' }, 413);
        try { const e = JSON.parse(body); if (e.v !== 1 || !e.salt || !e.iv || !e.ct) throw 0; } catch { return json({ error: 'bad_envelope' }, 400); }
        await env.STORE.put(ikey, body, { expirationTtl: IMG_TTL_SECONDS });
        return json({ ok: true });
      }
      if (req.method === 'DELETE') { await env.STORE.delete(ikey); return json({ ok: true }); }
      return json({ error: 'method_not_allowed' }, 405);
    }

    const m = path.match(/^\/v1\/blob\/([0-9a-f]{32})$/);
    if (!m) return json({ error: 'not_found' }, 404);
    const key = 'blob:' + m[1];

    if (req.method === 'PUT') {
      if (!env.API_KEY || !safeEqual(req.headers.get('Authorization') || '', 'Bearer ' + env.API_KEY)) return json({ error: 'unauthorized' }, 401);
      if ((Number(req.headers.get('Content-Length')) || 0) > MAX_BYTES) return json({ error: 'too_large' }, 413);
      const body = await req.text();
      if (body.length > MAX_BYTES) return json({ error: 'too_large' }, 413);
      try { const e = JSON.parse(body); if (e.v !== 1 || !e.salt || !e.iv || !e.ct) throw 0; } catch { return json({ error: 'bad_envelope' }, 400); }
      const updatedAt = new Date().toISOString();
      await env.STORE.put(key, JSON.stringify({ updatedAt, data: body }), { expirationTtl: TTL_SECONDS });
      return json({ ok: true, updatedAt });
    }

    if (req.method === 'GET') {
      const v = await env.STORE.get(key);
      return v ? new Response(v, { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...CORS } }) : json({ error: 'empty' }, 404);
    }
    return json({ error: 'method_not_allowed' }, 405);
  }
};
