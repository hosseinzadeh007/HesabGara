using System.Windows;
using System.Windows.Controls;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public sealed class SettingsView : Grid
{
    readonly SettingsService S = new();
    readonly TextBox CompanyName = new(), Phone = new(), AutoBackup = new(), Server = new(), Database = new(), User = new(), Password = new();
    readonly CheckBox Integrated = new() { Content = "احراز هویت Windows (Integrated Security)", Margin = new Thickness(3, 5, 3, 12) };
    readonly ComboBox Mode = new() { ItemsSource = new[] { "محلی (SQLite)", "شبکه‌ای (SQL Server)" }, Width = 260 };
    readonly TextBlock Status = new() { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(3, 8, 3, 12) };

    public SettingsView() { FlowDirection = FlowDirection.RightToLeft; Build(); Loaded += async (_, _) => await Load(); }

    void Build()
    {
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        var p = new StackPanel { Margin = new Thickness(30), Width = 680, HorizontalAlignment = HorizontalAlignment.Center };
        p.Children.Add(H("تنظیمات حساب‌گرا"));
        p.Children.Add(L("نام مجموعه", CompanyName)); p.Children.Add(L("تلفن", Phone)); p.Children.Add(L("پشتیبان‌گیری خودکار (دقیقه)", AutoBackup));
        p.Children.Add(H2("اتصال شبکه‌ای"));
        p.Children.Add(L("نوع پایگاه‌داده", Mode)); Mode.SelectionChanged += (_, _) => UpdateNetworkVisibility();
        p.Children.Add(L("نام سرور / IP", Server)); p.Children.Add(L("نام پایگاه‌داده", Database)); p.Children.Add(L("نام کاربری SQL Server", User)); p.Children.Add(L("رمز عبور SQL Server", Password)); p.Children.Add(Integrated);
        var test = new Button { Content = "بررسی اتصال SQL Server", Width = 190, Height = 38, Margin = new Thickness(3), HorizontalAlignment = HorizontalAlignment.Left }; test.Click += TestConnection;
        p.Children.Add(test); p.Children.Add(Status);
        var save = new Button { Content = "ذخیره تنظیمات و اعمال", Width = 190, Height = 42, Margin = new Thickness(3), HorizontalAlignment = HorizontalAlignment.Left }; save.Click += Save; p.Children.Add(save);
        p.Children.Add(new TextBlock { Text = "نکته: پس از تغییر حالت پایگاه‌داده، حساب‌گرا باید مجدداً اجرا شود. برای استفاده چند سیستم، SQL Server روی سیستم سرور نصب و سایر سیستم‌ها با IP سرور متصل می‌شوند.", TextWrapping = TextWrapping.Wrap, Foreground = AppTheme.Ink500, Margin = new Thickness(3, 16, 3, 0) });
        scroll.Content = p; Children.Add(scroll);
    }
    static TextBlock H(string t) => new() { Text = t, FontSize = 22, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 0, 0, 20) };
    static TextBlock H2(string t) => new() { Text = t, FontSize = 17, FontWeight = FontWeights.Bold, Margin = new Thickness(0, 18, 0, 8) };
    static StackPanel L(string label, Control box) { box.Margin = new Thickness(3, 4, 3, 12); if (box is TextBox tb) tb.Height = 34; return new StackPanel { Children = { new TextBlock { Text = label, FontWeight = FontWeights.SemiBold }, box } }; }
    async Task Load()
    {
        CompanyName.Text = await S.GetAsync("CompanyName") ?? ""; Phone.Text = await S.GetAsync("CompanyPhone") ?? ""; AutoBackup.Text = await S.GetAsync("AutoBackupMinutes") ?? "0";
        var cfg = DatabaseConfigurationStore.Load(); Mode.SelectedIndex = cfg.Provider == DatabaseProvider.SqlServer ? 1 : 0;
        ParseConnection(cfg.ConnectionString); UpdateNetworkVisibility(); Status.Text = cfg.Provider == DatabaseProvider.SqlServer ? "● حالت شبکه‌ای فعال است." : "● حالت محلی فعال است.";
    }
    void ParseConnection(string cs)
    {
        try
        {
            var b = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder(cs); Server.Text = b.DataSource; Database.Text = b.InitialCatalog; Integrated.IsChecked = b.IntegratedSecurity; User.Text = b.UserID; Password.Text = b.Password;
        }
        catch { }
    }
    void UpdateNetworkVisibility()
    {
        var visible = Mode.SelectedIndex == 1 ? Visibility.Visible : Visibility.Collapsed;
        Server.Visibility = Database.Visibility = User.Visibility = Password.Visibility = Integrated.Visibility = visible;
    }
    async void TestConnection(object? sender, RoutedEventArgs e)
    {
        var result = await new DatabaseConnectionService().TestSqlServerAsync(BuildConnectionString()); Status.Text = result.Success ? "● " + result.Message : "● " + result.Message; Status.Foreground = result.Success ? AppTheme.Success600 : AppTheme.Danger600;
    }
    string BuildConnectionString()
    {
        var b = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder { DataSource = Server.Text.Trim(), InitialCatalog = Database.Text.Trim(), TrustServerCertificate = true, ConnectTimeout = 8 };
        if (Integrated.IsChecked == true) b.IntegratedSecurity = true; else { b.UserID = User.Text.Trim(); b.Password = Password.Text; } return b.ConnectionString;
    }
    async void Save(object? s, RoutedEventArgs e)
    {
        if (!int.TryParse(AutoBackup.Text, out var n) || n < 0) { MessageBox.Show("فاصله پشتیبان‌گیری باید عدد صفر یا بزرگ‌تر باشد."); return; }
        await S.SetAsync("CompanyName", CompanyName.Text.Trim()); await S.SetAsync("CompanyPhone", Phone.Text.Trim()); await S.SetAsync("AutoBackupMinutes", n.ToString());
        if (Mode.SelectedIndex == 1)
        {
            if (string.IsNullOrWhiteSpace(Server.Text) || string.IsNullOrWhiteSpace(Database.Text)) { MessageBox.Show("نام سرور/IP و نام پایگاه‌داده الزامی است."); return; }
            DatabaseConfigurationStore.Save(new DatabaseConfiguration { Provider = DatabaseProvider.SqlServer, ConnectionString = BuildConnectionString() });
            MessageBox.Show("حالت شبکه‌ای ذخیره شد. برای اعمال اتصال جدید، حساب‌گرا را ببندید و دوباره اجرا کنید.", "حساب‌گرا", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        else
        {
            DatabaseConfigurationStore.Save(new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite }); MessageBox.Show("حالت محلی ذخیره شد. برای اعمال تغییر، حساب‌گرا را دوباره اجرا کنید.");
        }
    }
}
