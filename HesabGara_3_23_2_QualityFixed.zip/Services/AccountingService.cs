﻿using AccountingPurchasePro.Data;
using AccountingPurchasePro.Domain;
using AccountingPurchasePro.Models;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Services;

public sealed record SelectionSummary(decimal TotalAmount, decimal TotalPaid, decimal TotalBalance, decimal WeightedDueDays, DateTime? WeightedDueDate);

public sealed class AccountingService
{
    public static decimal Balance(Invoice x) => FinanceRules.Balance(x.Amount, x.Paid);

    public static decimal WeightedDueDays(IEnumerable<Invoice> rows, DateTime? reference = null)
        => FinanceRules.Summarize(rows.Select(x => (x.Amount, x.Paid, x.DueDate)), reference).WeightedDays;

    public static SelectionSummary Summarize(IEnumerable<Invoice> rows)
    {
        var result = FinanceRules.Summarize(rows.Select(x => (x.Amount, x.Paid, x.DueDate)));
        return new(result.Total, result.Paid, result.Balance, result.WeightedDays, result.WeightedDate);
    }

    public async Task<List<Invoice>> GetInvoicesAsync(int? companyId = null, string? search = null, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var q = db.Invoices.Include(x => x.Company).Include(x => x.Payments).AsNoTracking().AsQueryable();
        if (companyId.HasValue) q = q.Where(x => x.CompanyId == companyId.Value);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            q = q.Where(x => x.Number.Contains(s) || (x.Company != null && x.Company.Name.Contains(s)));
        }
        return await q.OrderByDescending(x => x.InvoiceDate).ThenByDescending(x => x.Id).ToListAsync(ct);
    }

    public async Task<List<Company>> GetCompaniesAsync(CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        return await db.Companies.AsNoTracking().OrderBy(x => x.Name).ToListAsync(ct);
    }

    public async Task AddCompanyAsync(Company company, CancellationToken ct = default)
    {
        ValidateCompany(company);
        await using var db = new AppDbContext();
        if (await db.Companies.AnyAsync(x => x.Name == company.Name.Trim(), ct)) throw new InvalidOperationException("شرکتی با این نام قبلاً ثبت شده است.");
        company.Name = company.Name.Trim();
        db.Companies.Add(company);
        await db.SaveChangesAsync(ct);
        await AuditAsync("Create", "Company", company.Id.ToString(), company.Name, db, ct);
        await db.SaveChangesAsync(ct);
    }

    public async Task AddInvoiceAsync(Invoice invoice, CancellationToken ct = default)
    {
        if (invoice.CompanyId <= 0) throw new ArgumentException("شرکت فاکتور مشخص نشده است.");
        if (string.IsNullOrWhiteSpace(invoice.Number)) throw new ArgumentException("شماره فاکتور الزامی است.");
        if (invoice.Amount <= 0) throw new ArgumentException("مبلغ فاکتور باید بزرگ‌تر از صفر باشد.");
        if (invoice.DueDate.Date < invoice.InvoiceDate.Date) throw new ArgumentException("سررسید نمی‌تواند قبل از تاریخ فاکتور باشد.");
        invoice.Number = invoice.Number.Trim(); invoice.Paid = FinanceRules.ClampPaid(invoice.Amount, invoice.Paid);
        await using var db = new AppDbContext();
        if (!await db.Companies.AnyAsync(x => x.Id == invoice.CompanyId, ct)) throw new InvalidOperationException("شرکت پیدا نشد.");
        if (await db.Invoices.AnyAsync(x => x.CompanyId == invoice.CompanyId && x.Number == invoice.Number, ct)) throw new InvalidOperationException("این شماره فاکتور برای این شرکت قبلاً ثبت شده است.");
        db.Invoices.Add(invoice); await db.SaveChangesAsync(ct);
        await AuditAsync("Create", "Invoice", invoice.Id.ToString(), invoice.Number, db, ct); await db.SaveChangesAsync(ct);
    }

    public async Task AddPaymentAsync(Payment payment, CancellationToken ct = default)
    {
        if (payment.Amount <= 0) throw new ArgumentException("مبلغ پرداخت باید بزرگ‌تر از صفر باشد.");
        await using var db = new AppDbContext();
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var inv = await db.Invoices.SingleOrDefaultAsync(x => x.Id == payment.InvoiceId, ct) ?? throw new InvalidOperationException("فاکتور پیدا نشد.");
        var actualPaid = (await db.Payments.Where(x => x.InvoiceId == inv.Id).Select(x => x.Amount).ToListAsync(ct)).Sum();
        var existingLegacyPaid = Math.Max(0m, inv.Paid - actualPaid);
        var balance = Math.Max(0m, inv.Amount - actualPaid - existingLegacyPaid);
        if (balance <= 0) throw new InvalidOperationException("فاکتور تسویه شده است.");
        if (payment.Amount > balance) throw new InvalidOperationException($"مبلغ پرداخت بیشتر از مانده فاکتور است. مانده: {balance:N0}");
        payment.PayDate = payment.PayDate.Date;
        payment.PaymentMethod = string.IsNullOrWhiteSpace(payment.PaymentMethod) ? "نقد" : payment.PaymentMethod.Trim();
        var allowedMethods = new[] { "نقد", "کارت‌به‌کارت", "چک", "ترکیبی" };
        if (!allowedMethods.Contains(payment.PaymentMethod, StringComparer.Ordinal))
            throw new ArgumentException("روش وصول معتبر نیست.");

        if (payment.PaymentMethod == "چک")
        {
            if (!string.IsNullOrWhiteSpace(payment.CheckNumber))
                payment.CheckNumber = payment.CheckNumber.Trim();
            if (payment.CheckDate.HasValue)
                payment.CheckDate = payment.CheckDate.Value.Date;
            if (string.IsNullOrWhiteSpace(payment.CheckStatus))
                payment.CheckStatus = "در انتظار وصول";
        }
        else
        {
            // اطلاعات چک فقط برای روش چک نگهداری می‌شود.
            payment.CheckNumber = null;
            payment.CheckDate = null;
            payment.CheckStatus = null;
        }

        inv.Paid = actualPaid + existingLegacyPaid + payment.Amount;
        db.Payments.Add(payment);
        await db.SaveChangesAsync(ct);
        await AuditAsync("Create", "Payment", payment.Id.ToString(), $"Invoice={inv.Number}; Amount={payment.Amount}; Method={payment.PaymentMethod}; Check={payment.CheckNumber}", db, ct);
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
    }

    public async Task UpdatePaymentAsync(Payment payment, CancellationToken ct = default)
    {
        if (payment.Amount <= 0) throw new ArgumentException("مبلغ پرداخت باید بزرگ‌تر از صفر باشد.");
        await using var db = new AppDbContext();
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        var entity = await db.Payments.SingleOrDefaultAsync(x => x.Id == payment.Id, ct) ?? throw new InvalidOperationException("وصول پیدا نشد.");
        var inv = await db.Invoices.SingleOrDefaultAsync(x => x.Id == entity.InvoiceId, ct) ?? throw new InvalidOperationException("فاکتور پیدا نشد.");

        // "otherPaid" excludes the payment being edited, so its own current amount never
        // counts against the new amount being validated (otherwise every edit would look
        // like it exceeds the balance by its own old value).
        var otherPaid = (await db.Payments.Where(x => x.InvoiceId == entity.InvoiceId && x.Id != entity.Id).Select(x => x.Amount).ToListAsync(ct)).Sum();
        var existingLegacyPaid = Math.Max(0m, inv.Paid - (otherPaid + entity.Amount));
        var maxAllowed = Math.Max(0m, inv.Amount - otherPaid - existingLegacyPaid);
        if (payment.Amount > maxAllowed) throw new InvalidOperationException($"مبلغ وصول بیشتر از مانده‌ی مجاز فاکتور است. حداکثر مجاز: {maxAllowed:N0}");

        var method = string.IsNullOrWhiteSpace(payment.PaymentMethod) ? "نقد" : payment.PaymentMethod.Trim();
        var allowedMethods = new[] { "نقد", "کارت‌به‌کارت", "چک", "ترکیبی" };
        if (!allowedMethods.Contains(method, StringComparer.Ordinal))
            throw new ArgumentException("روش وصول معتبر نیست.");

        entity.Amount = payment.Amount;
        entity.PayDate = payment.PayDate.Date;
        entity.PaymentMethod = method;
        if (method == "چک")
        {
            entity.CheckNumber = string.IsNullOrWhiteSpace(payment.CheckNumber) ? null : payment.CheckNumber.Trim();
            entity.CheckDate = payment.CheckDate?.Date;
            entity.CheckStatus = string.IsNullOrWhiteSpace(payment.CheckStatus) ? "در انتظار وصول" : payment.CheckStatus;
        }
        else
        {
            entity.CheckNumber = null;
            entity.CheckDate = null;
            entity.CheckStatus = null;
        }
        entity.Note = string.IsNullOrWhiteSpace(payment.Note) ? null : payment.Note.Trim();

        inv.Paid = Math.Min(inv.Amount, otherPaid + existingLegacyPaid + entity.Amount);
        await db.SaveChangesAsync(ct);
        await AuditAsync("Update", "Payment", entity.Id.ToString(), $"Invoice={inv.Number}; Amount={entity.Amount}; Method={entity.PaymentMethod}", db, ct);
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
    }


    public async Task UpdateCompanyAsync(Company input, CancellationToken ct = default)
    {
        ValidateCompany(input);
        await using var db = new AppDbContext();
        var entity = await db.Companies.SingleOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new InvalidOperationException("شرکت پیدا نشد.");
        var name = input.Name.Trim();
        if (await db.Companies.AnyAsync(x => x.Id != input.Id && x.Name == name, ct)) throw new InvalidOperationException("شرکتی با این نام قبلاً ثبت شده است.");
        entity.Name = name; entity.NationalId = string.IsNullOrWhiteSpace(input.NationalId) ? null : input.NationalId.Trim(); entity.Phone = input.Phone?.Trim(); entity.Note = input.Note?.Trim();
        await db.SaveChangesAsync(ct);
        await AuditAsync("Update", "Company", entity.Id.ToString(), entity.Name, db, ct); await db.SaveChangesAsync(ct);
    }

    public async Task DeleteCompanyAsync(int companyId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var entity = await db.Companies.SingleOrDefaultAsync(x => x.Id == companyId, ct) ?? throw new InvalidOperationException("شرکت پیدا نشد.");
        if (await db.Invoices.AnyAsync(x => x.CompanyId == companyId, ct)) throw new InvalidOperationException("این شرکت دارای فاکتور است و برای حفظ سوابق مالی قابل حذف نیست. ابتدا فاکتورها را تعیین تکلیف کنید.");
        db.Companies.Remove(entity); await db.SaveChangesAsync(ct);
        await AuditAsync("Delete", "Company", companyId.ToString(), entity.Name, db, ct); await db.SaveChangesAsync(ct);
    }

    public async Task UpdateInvoiceAsync(Invoice input, CancellationToken ct = default)
    {
        if (input.CompanyId <= 0 || string.IsNullOrWhiteSpace(input.Number)) throw new ArgumentException("شرکت و شماره فاکتور الزامی است.");
        if (input.Amount <= 0) throw new ArgumentException("مبلغ فاکتور باید بزرگ‌تر از صفر باشد.");
        if (input.DueDate.Date < input.InvoiceDate.Date) throw new ArgumentException("سررسید نمی‌تواند قبل از تاریخ فاکتور باشد.");
        await using var db = new AppDbContext();
        var entity = await db.Invoices.Include(x => x.Payments).SingleOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new InvalidOperationException("فاکتور پیدا نشد.");
        if (await db.Invoices.AnyAsync(x => x.Id != input.Id && x.CompanyId == input.CompanyId && x.Number == input.Number.Trim(), ct)) throw new InvalidOperationException("این شماره فاکتور برای این شرکت قبلاً ثبت شده است.");
        var paid = entity.Payments.Sum(x => x.Amount);
        if (input.Amount < paid) throw new InvalidOperationException($"مبلغ فاکتور نمی‌تواند کمتر از پرداخت‌های ثبت‌شده ({paid:N0}) باشد.");
        entity.CompanyId = input.CompanyId; entity.Number = input.Number.Trim(); entity.InvoiceDate = input.InvoiceDate.Date; entity.DueDate = input.DueDate.Date; entity.Amount = input.Amount; entity.Paid = paid; entity.Note = input.Note?.Trim();
        await db.SaveChangesAsync(ct); await AuditAsync("Update", "Invoice", entity.Id.ToString(), entity.Number, db, ct); await db.SaveChangesAsync(ct);
    }

    public async Task DeleteInvoiceAsync(int invoiceId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext(); await using var tx = await db.Database.BeginTransactionAsync(ct);
        var entity = await db.Invoices.Include(x => x.Payments).SingleOrDefaultAsync(x => x.Id == invoiceId, ct) ?? throw new InvalidOperationException("فاکتور پیدا نشد.");
        if (entity.Payments.Count > 0) throw new InvalidOperationException("فاکتور دارای پرداخت است و برای حفظ سوابق مالی حذف نمی‌شود. ابتدا پرداخت‌های آن را حذف/اصلاح کنید.");
        db.Invoices.Remove(entity); await db.SaveChangesAsync(ct); await AuditAsync("Delete", "Invoice", invoiceId.ToString(), entity.Number, db, ct); await db.SaveChangesAsync(ct); await tx.CommitAsync(ct);
    }

    public async Task DeletePaymentAsync(int paymentId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext(); await using var tx = await db.Database.BeginTransactionAsync(ct);
        var entity = await db.Payments.Include(x => x.Invoice).SingleOrDefaultAsync(x => x.Id == paymentId, ct) ?? throw new InvalidOperationException("پرداخت پیدا نشد.");
        var invoiceId = entity.InvoiceId; db.Payments.Remove(entity); await db.SaveChangesAsync(ct);
        var paid = (await db.Payments.Where(x => x.InvoiceId == invoiceId).Select(x => x.Amount).ToListAsync(ct)).Sum();
        var inv = await db.Invoices.SingleOrDefaultAsync(x => x.Id == invoiceId, ct); if (inv != null) inv.Paid = Math.Min(inv.Amount, paid);
        await db.SaveChangesAsync(ct); await AuditAsync("Delete", "Payment", paymentId.ToString(), $"Invoice={invoiceId}; Amount={entity.Amount}", db, ct); await db.SaveChangesAsync(ct); await tx.CommitAsync(ct);
    }

    public async Task ReconcilePaidAmountsAsync(CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var invoices = await db.Invoices.Include(x => x.Payments).ToListAsync(ct);
        foreach (var inv in invoices) inv.Paid = Math.Min(inv.Amount, inv.Payments.Sum(x => x.Amount));
        await db.SaveChangesAsync(ct);
    }

    public async Task<List<Payment>> GetPaymentsAsync(int? companyId = null, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var q = db.Payments.Include(x => x.Invoice!).ThenInclude(x => x.Company).AsNoTracking().AsQueryable();
        if (companyId.HasValue) q = q.Where(x => x.Invoice!.CompanyId == companyId.Value);
        return await q.OrderByDescending(x => x.PayDate).ThenByDescending(x => x.Id).ToListAsync(ct);
    }

    public async Task<Payment?> GetPaymentByIdAsync(int paymentId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        return await db.Payments.AsNoTracking().FirstOrDefaultAsync(x => x.Id == paymentId, ct);
    }

    public async Task<List<Payment>> GetPaymentsForInvoiceAsync(int invoiceId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        return await db.Payments.AsNoTracking()
            .Where(x => x.InvoiceId == invoiceId)
            .OrderByDescending(x => x.PayDate).ThenByDescending(x => x.Id)
            .ToListAsync(ct);
    }

    static void ValidateCompany(Company c)
    {
        if (string.IsNullOrWhiteSpace(c.Name)) throw new ArgumentException("نام شرکت الزامی است.");
        if (c.Name.Trim().Length > 200) throw new ArgumentException("نام شرکت بیش از حد طولانی است.");
    }

    static Task AuditAsync(string action, string entity, string id, string? details, AppDbContext db, CancellationToken ct)
        => db.AuditLogs.AddAsync(new AuditLog { TimestampUtc = DateTime.UtcNow, Action = action, Entity = entity, EntityId = id, Details = details }, ct).AsTask();
}
