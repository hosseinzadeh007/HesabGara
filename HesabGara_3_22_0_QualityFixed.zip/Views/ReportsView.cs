using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using Microsoft.Win32;
using ClosedXML.Excel;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

// Full reports module: four report types (invoice summary, payments log, per-company
// summary, checks-in-progress) sharing one filter bar (company / date range / status),
// plus Excel export and print. The "open due dates" filter still lives in Invoices.
public class ReportsView : Grid
{
    readonly AccountingService S; readonly int? InitialCompanyId;
    readonly DataGrid G=new(); readonly TextBlock Summary=new(); readonly TextBlock TitleText=new();
    readonly ComboBox CompanyBox=new(), StatusBox=new(), PresetBox=new();
    readonly TextBox FromDateBox=new(), ToDateBox=new();
    readonly Button TabInvoices, TabPayments, TabByCompany, TabChecks, TabCombined, PrintBtn, EditPaymentBtn, DeletePaymentBtn;
    readonly ScrollViewer CombinedScroll=new(); readonly DataGrid CInvoices=new(), CPayments=new(), CChecks=new();
    readonly TextBlock CInvoicesHeader=new(), CPaymentsHeader=new(), CChecksHeader=new();
    ReportTab _tab = ReportTab.Invoices;
    enum ReportTab { Invoices, Payments, ByCompany, Checks, Combined }
    List<Invoice> _lastInvoiceRows = new();

    public ReportsView(AccountingService s,int? c)
    {
        S=s; InitialCompanyId=c; Margin=new Thickness(18); Background=AppTheme.Surface100;
        TabInvoices=TabButton("خلاصه فاکتورها"); TabPayments=TabButton("گزارش پرداخت‌ها"); TabByCompany=TabButton("خلاصه بر اساس شرکت"); TabChecks=TabButton("چک‌های در جریان"); TabCombined=TabButton("گزارش جامع شرکت");
        TabInvoices.Click+=async(_,_)=>{_tab=ReportTab.Invoices;UpdateTabs();await Load();};
        TabPayments.Click+=async(_,_)=>{_tab=ReportTab.Payments;UpdateTabs();await Load();};
        TabByCompany.Click+=async(_,_)=>{_tab=ReportTab.ByCompany;UpdateTabs();await Load();};
        TabChecks.Click+=async(_,_)=>{_tab=ReportTab.Checks;UpdateTabs();await Load();};
        TabCombined.Click+=async(_,_)=>{_tab=ReportTab.Combined;UpdateTabs();await Load();};
        PrintBtn=Btn("چاپ گزارش",AppTheme.Brand700); PrintBtn.Foreground=Brushes.White; PrintBtn.Click+=Print;
        EditPaymentBtn=Btn("ویرایش پرداخت",AppTheme.Brand600); EditPaymentBtn.Foreground=Brushes.White; EditPaymentBtn.Click+=EditSelectedPayment;
        DeletePaymentBtn=Btn("حذف پرداخت",AppTheme.Danger100); DeletePaymentBtn.Foreground=AppTheme.Danger600; DeletePaymentBtn.Click+=DeleteSelectedPayment;
        Build();
    }
    public static async Task<ReportsView>Create(AccountingService s,int? c){var v=new ReportsView(s,c);await v.LoadCompanies();await v.Load();return v;}

    void Build()
    {
        FlowDirection=FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});   // header + tabs
        RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});   // filter bar
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(58)}); // summary
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)}); // grid

        // --- Header + tabs ---
        var headerCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(14),Effect=AppTheme.CardShadow};
        var headerStack=new StackPanel();
        TitleText.Text="گزارش‌ها"; TitleText.FontSize=17; TitleText.FontWeight=FontWeights.Bold; TitleText.Foreground=AppTheme.Brand900;
        headerStack.Children.Add(TitleText);
        var tabsRow=new StackPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(0,10,0,0)};
        tabsRow.Children.Add(TabInvoices); tabsRow.Children.Add(TabPayments); tabsRow.Children.Add(TabByCompany); tabsRow.Children.Add(TabChecks); tabsRow.Children.Add(TabCombined);
        headerStack.Children.Add(tabsRow);
        headerCard.Child=headerStack; Grid.SetRow(headerCard,0); Children.Add(headerCard);
        UpdateTabs();

        // --- Filter bar ---
        var filterCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(14),Margin=new Thickness(0,8,0,0),Effect=AppTheme.CardShadow};
        var filters=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft};

        filters.Children.Add(LabeledField("شرکت", CompanyBox, 210));
        CompanyBox.Height=38;

        PresetBox.ItemsSource=new[]{"همه","امروز","۷ روز اخیر","این ماه (شمسی)","سه‌ماه اخیر","امسال (شمسی)","بازه‌ی دلخواه"};
        PresetBox.SelectedIndex=0; PresetBox.SelectionChanged+=(_,_)=>ApplyPreset();
        filters.Children.Add(LabeledField("بازه‌ی زمانی", PresetBox, 160));

        FromDateBox.ToolTip="مثال: 1405/01/01"; ToDateBox.ToolTip="مثال: 1405/06/25";
        filters.Children.Add(LabeledField("از تاریخ", FromDateBox, 120));
        filters.Children.Add(LabeledField("تا تاریخ", ToDateBox, 120));

        StatusBox.ItemsSource=new[]{"همه وضعیت‌ها","تسویه شده","بخشی پرداخت شده","پرداخت نشده"}; StatusBox.SelectedIndex=0;
        filters.Children.Add(LabeledField("وضعیت", StatusBox, 150));

        var showBtn=Btn("نمایش گزارش",AppTheme.Success600); showBtn.Foreground=Brushes.White; showBtn.VerticalAlignment=VerticalAlignment.Bottom; showBtn.Margin=new Thickness(4,0,4,4);
        showBtn.Click+=async(_,_)=>await Load();
        filters.Children.Add(showBtn);

        var expBtn=Btn("خروجی Excel",AppTheme.Brand600); expBtn.Foreground=Brushes.White; expBtn.VerticalAlignment=VerticalAlignment.Bottom; expBtn.Margin=new Thickness(4,0,4,4);
        expBtn.Click+=Export;
        filters.Children.Add(expBtn);

        PrintBtn.VerticalAlignment=VerticalAlignment.Bottom; PrintBtn.Margin=new Thickness(4,0,4,4);
        filters.Children.Add(PrintBtn);

        EditPaymentBtn.VerticalAlignment=VerticalAlignment.Bottom; EditPaymentBtn.Margin=new Thickness(4,0,4,4);
        DeletePaymentBtn.VerticalAlignment=VerticalAlignment.Bottom; DeletePaymentBtn.Margin=new Thickness(4,0,4,4);
        filters.Children.Add(EditPaymentBtn); filters.Children.Add(DeletePaymentBtn);

        filterCard.Child=filters; Grid.SetRow(filterCard,1); Children.Add(filterCard);

        // --- Summary ---
        var sumCard=new Border{Background=AppTheme.Brand100,CornerRadius=new CornerRadius(11),Padding=new Thickness(12),Margin=new Thickness(0,8,0,8)};
        Summary.FontSize=12.5; Summary.FontWeight=FontWeights.SemiBold; Summary.Foreground=AppTheme.Ink900;
        Summary.TextWrapping=TextWrapping.Wrap; Summary.VerticalAlignment=VerticalAlignment.Center;
        sumCard.Child=Summary; Grid.SetRow(sumCard,2); Children.Add(sumCard);

        // --- Grid (tabs 1-4) ---
        G.FlowDirection=FlowDirection.RightToLeft; G.AutoGenerateColumns=false; G.IsReadOnly=true; G.CanUserAddRows=false;
        G.RowHeight=40; G.ColumnHeaderHeight=38; G.FontSize=12.5; G.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; G.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        G.LoadingRow += G_LoadingRow;
        Grid.SetRow(G,3); Children.Add(G);

        // --- Combined report (tab 5): سه بخش پشت سر هم در یک قاب، بدون نیاز به جابه‌جایی تب ---
        var combinedStack=new StackPanel();
        combinedStack.Children.Add(BuildCombinedSection(CInvoicesHeader,"فاکتورهای خریداری‌شده", CInvoices,
            "شماره","شرکت","تاریخ فاکتور","سررسید","مبلغ","پرداختی","مانده","وضعیت"));
        combinedStack.Children.Add(BuildCombinedSection(CPaymentsHeader,"پرداخت‌ها", CPayments,
            "تاریخ وصول","فاکتور","مبلغ","روش","شماره چک","وضعیت چک"));
        combinedStack.Children.Add(BuildCombinedSection(CChecksHeader,"چک‌های داده‌شده", CChecks,
            "تاریخ چک","شماره چک","فاکتور","مبلغ","وضعیت چک"));
        CombinedScroll.Content=combinedStack; CombinedScroll.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        CombinedScroll.Visibility=Visibility.Collapsed;
        Grid.SetRow(CombinedScroll,3); Children.Add(CombinedScroll);
    }

    Border BuildCombinedSection(TextBlock header, string title, DataGrid grid, params string[] columnHeaders)
    {
        var card=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(12),Padding=new Thickness(12),Margin=new Thickness(0,0,0,10),Effect=AppTheme.CardShadow};
        var stack=new StackPanel();
        var titleRow=new StackPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(0,0,0,6)};
        titleRow.Children.Add(new TextBlock{Text=title,FontWeight=FontWeights.Bold,FontSize=13.5,Foreground=AppTheme.Brand900});
        header.FontSize=11.5; header.Foreground=AppTheme.Ink500; header.Margin=new Thickness(10,2,0,0); header.VerticalAlignment=VerticalAlignment.Center;
        titleRow.Children.Add(header);
        stack.Children.Add(titleRow);

        grid.FlowDirection=FlowDirection.RightToLeft; grid.AutoGenerateColumns=false; grid.IsReadOnly=true; grid.CanUserAddRows=false;
        grid.RowHeight=32; grid.ColumnHeaderHeight=32; grid.FontSize=11.5; grid.MaxHeight=220; grid.MinHeight=70;
        grid.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; grid.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        foreach (var h in columnHeaders) grid.Columns.Add(new DataGridTextColumn{Header=h,Binding=new Binding(SafeProp(h)),Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=80});
        stack.Children.Add(grid);
        card.Child=stack;
        return card;
    }
    // ستون‌های این سه‌گانه از رکوردهای موجود (Invoices row type / PayRow / CheckRow) استفاده می‌کنند؛
    // این متد فقط عنوان فارسی هر ستون را به نام Property مربوطه نگاشت می‌دهد.
    static string SafeProp(string header) => header switch
    {
        "شماره"=>"Number", "شرکت"=>"Company.Name", "تاریخ فاکتور"=>"InvoiceDate", "سررسید"=>"Due",
        "مبلغ"=>"Amount", "پرداختی"=>"Paid", "مانده"=>"Balance", "وضعیت"=>"Status",
        "تاریخ وصول"=>"PayDate", "فاکتور"=>"InvoiceNumber", "روش"=>"PaymentMethod",
        "شماره چک"=>"CheckNumber", "وضعیت چک"=>"CheckStatus", "تاریخ چک"=>"CheckDate",
        _=>header
    };

    static StackPanel LabeledField(string label, Control box, double width)
    {
        var p=new StackPanel{Margin=new Thickness(4,0,4,4)};
        p.Children.Add(new TextBlock{Text=label,FontSize=11,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink500,Margin=new Thickness(2,0,2,3)});
        box.Width=width; box.Height=36;
        if (box is TextBox tb){tb.Padding=new Thickness(8,6,8,6);tb.VerticalContentAlignment=VerticalAlignment.Center;}
        p.Children.Add(box);
        return p;
    }
    static Button TabButton(string text)=>new Button{Content=text,Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,0,8,0),BorderThickness=new Thickness(0),FontWeight=FontWeights.SemiBold,Cursor=System.Windows.Input.Cursors.Hand};
    void UpdateTabs()
    {
        SetTabState(TabInvoices,_tab==ReportTab.Invoices); SetTabState(TabPayments,_tab==ReportTab.Payments);
        SetTabState(TabByCompany,_tab==ReportTab.ByCompany); SetTabState(TabChecks,_tab==ReportTab.Checks);
        SetTabState(TabCombined,_tab==ReportTab.Combined);
        PrintBtn.Visibility = _tab==ReportTab.Invoices ? Visibility.Visible : Visibility.Collapsed;
        EditPaymentBtn.Visibility = DeletePaymentBtn.Visibility = _tab==ReportTab.Payments ? Visibility.Visible : Visibility.Collapsed;
        G.Visibility = _tab==ReportTab.Combined ? Visibility.Collapsed : Visibility.Visible;
        CombinedScroll.Visibility = _tab==ReportTab.Combined ? Visibility.Visible : Visibility.Collapsed;
    }
    static void SetTabState(Button b, bool active)
    {
        b.Background = active ? AppTheme.Brand600 : AppTheme.Surface100;
        b.Foreground = active ? Brushes.White : AppTheme.Ink700;
    }
    static Button Btn(string t,Brush bg)=>new Button{Content=t,Background=bg,BorderThickness=new Thickness(0),Padding=new Thickness(13,8,13,8),Margin=new Thickness(4),FontWeight=FontWeights.SemiBold};

    async Task LoadCompanies(){var list=await S.GetCompaniesAsync();var all=new List<Company>{new Company{Id=0,Name="همه شرکت‌ها"}};all.AddRange(list);CompanyBox.ItemsSource=all;CompanyBox.DisplayMemberPath="Name";CompanyBox.SelectedValuePath="Id";CompanyBox.SelectedValue=InitialCompanyId??0;}
    int? CompanyId=>CompanyBox.SelectedValue is int id&&id>0?id:null;

    void ApplyPreset()
    {
        var preset = PresetBox.SelectedItem as string;
        if (preset=="بازه‌ی دلخواه" || preset is null) return;
        var pc = new PersianCalendar(); var today = DateTime.Today;
        (DateTime from, DateTime to) range = preset switch
        {
            "امروز" => (today, today),
            "۷ روز اخیر" => (today.AddDays(-6), today),
            "این ماه (شمسی)" => MonthRange(pc, today),
            "سه‌ماه اخیر" => (today.AddDays(-90), today),
            "امسال (شمسی)" => (pc.ToDateTime(pc.GetYear(today),1,1,0,0,0,0), today),
            _ => (DateTime.MinValue, DateTime.MaxValue) // "همه"
        };
        FromDateBox.Text = range.from==DateTime.MinValue ? "" : PersianDateService.ToPersian(range.from);
        ToDateBox.Text = range.to==DateTime.MaxValue ? "" : PersianDateService.ToPersian(range.to);
    }
    static (DateTime,DateTime) MonthRange(PersianCalendar pc, DateTime today)
    {
        int y=pc.GetYear(today), m=pc.GetMonth(today);
        var from = pc.ToDateTime(y,m,1,0,0,0,0);
        var to = pc.ToDateTime(y,m,pc.GetDaysInMonth(y,m),0,0,0,0);
        return (from,to);
    }
    (DateTime? from, DateTime? to) ReadDateRange()
    {
        DateTime? from=null, to=null;
        if (!string.IsNullOrWhiteSpace(FromDateBox.Text)) { if (PersianDateService.TryParse(FromDateBox.Text, out var f)) from=f.Date; else MessageBox.Show("تاریخ «از» معتبر نیست. نمونه: 1405/01/01","فیلتر تاریخ",MessageBoxButton.OK,MessageBoxImage.Warning); }
        if (!string.IsNullOrWhiteSpace(ToDateBox.Text)) { if (PersianDateService.TryParse(ToDateBox.Text, out var t)) to=t.Date; else MessageBox.Show("تاریخ «تا» معتبر نیست. نمونه: 1405/06/25","فیلتر تاریخ",MessageBoxButton.OK,MessageBoxImage.Warning); }
        return (from,to);
    }
    static string StatusOf(Invoice x)
    {
        var balance = AccountingService.Balance(x);
        return balance<=0 ? "تسویه شده" : x.Paid>0 ? "بخشی پرداخت شده" : "پرداخت نشده";
    }

    async Task Load()
    {
        var (from,to) = ReadDateRange();
        if (_tab == ReportTab.Combined) { await LoadCombined(from,to); return; }
        G.Columns.Clear();
        switch(_tab)
        {
            case ReportTab.Invoices: await LoadInvoices(from,to); break;
            case ReportTab.Payments: await LoadPayments(from,to); break;
            case ReportTab.ByCompany: await LoadByCompany(from,to); break;
            case ReportTab.Checks: await LoadChecks(from,to); break;
        }
    }

    async Task LoadInvoices(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — خلاصه فاکتورها";
        var rows = await S.GetInvoicesAsync(CompanyId);
        if (from.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();
        var statusFilter = StatusBox.SelectedItem as string;
        if (!string.IsNullOrEmpty(statusFilter) && statusFilter!="همه وضعیت‌ها") rows = rows.Where(x=>StatusOf(x)==statusFilter).ToList();
        rows = rows.OrderByDescending(x=>x.InvoiceDate).ToList();
        _lastInvoiceRows = rows;

        var sum = AccountingService.Summarize(rows);
        Summary.Text = $"شرکت: {(CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها"}   |   تعداد: {rows.Count:N0}   |   جمع: {sum.TotalAmount:N0}   |   پرداختی: {sum.TotalPaid:N0}   |   مانده: {sum.TotalBalance:N0}   |   میانگین سررسید: {(sum.WeightedDueDate.HasValue?PersianDateService.ToPersian(sum.WeightedDueDate.Value):"—")}";

        G.Columns.Add(new DataGridTextColumn{Header="شماره",Binding=new Binding("Number"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("Company.Name"),Width=new DataGridLength(1.5,DataGridLengthUnitType.Star),MinWidth=140});
        G.Columns.Add(new DataGridTextColumn{Header="تاریخ فاکتور",Binding=new Binding("InvoiceDate"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="سررسید",Binding=new Binding("Due"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="پرداختی",Binding=new Binding("Paid"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="مانده",Binding=new Binding("Balance"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="وضعیت",Binding=new Binding("Status"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="تعداد پرداخت",Binding=new Binding("PaymentCount"),Width=95});
        G.Columns.Add(new DataGridTextColumn{Header="روش‌های پرداخت",Binding=new Binding("PaymentMethods"),Width=new DataGridLength(1.1,DataGridLengthUnitType.Star),MinWidth=130});
        G.Columns.Add(new DataGridTextColumn{Header="آخرین پرداخت",Binding=new Binding("LastPaymentDate"),Width=105});
        G.Columns.Add(new DataGridTextColumn{Header="توضیحات",Binding=new Binding("Note"),Width=new DataGridLength(1.2,DataGridLengthUnitType.Star),MinWidth=120});
        G.ItemsSource = rows.Select(x =>
        {
            var payments = x.Payments?.OrderBy(p => p.PayDate).ToList() ?? new List<Payment>();
            return new
            {
                x.Number, x.Company,
                InvoiceDate = PersianDateService.ToPersian(x.InvoiceDate),
                Due = PersianDateService.ToPersian(x.DueDate),
                x.Amount, x.Paid, Balance = AccountingService.Balance(x),
                Status = StatusOf(x),
                PaymentCount = payments.Count,
                PaymentMethods = payments.Count == 0 ? "—" : string.Join("، ", payments.Select(p => p.PaymentMethod).Distinct()),
                LastPaymentDate = payments.Count == 0 ? "—" : PersianDateService.ToPersian(payments.Last().PayDate),
                Note = string.IsNullOrWhiteSpace(x.Note) ? "—" : x.Note
            };
        }).ToList();
    }

    async Task LoadPayments(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — گزارش پرداخت‌ها";
        var payments = await S.GetPaymentsAsync(CompanyId);
        if (from.HasValue) payments = payments.Where(p=>p.PayDate.Date>=from.Value).ToList();
        if (to.HasValue) payments = payments.Where(p=>p.PayDate.Date<=to.Value).ToList();
        payments = payments.OrderByDescending(p=>p.PayDate).ToList();

        var total = payments.Sum(p=>p.Amount);
        var byMethod = payments.GroupBy(p=>p.PaymentMethod).Select(g=>$"{g.Key}: {g.Sum(x=>x.Amount):N0}");
        Summary.Text = $"تعداد وصول: {payments.Count:N0}   |   جمع مبالغ: {total:N0} ریال   |   {string.Join("   |   ", byMethod)}";

        G.Columns.Add(new DataGridTextColumn{Header="تاریخ وصول",Binding=new Binding("PayDate"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شماره فاکتور",Binding=new Binding("InvoiceNumber"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("CompanyName"),Width=new DataGridLength(1.4,DataGridLengthUnitType.Star),MinWidth=140});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="روش",Binding=new Binding("PaymentMethod"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شماره چک",Binding=new Binding("CheckNumber"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="وضعیت چک",Binding=new Binding("CheckStatus"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="توضیحات",Binding=new Binding("Note"),Width=new DataGridLength(1.2,DataGridLengthUnitType.Star),MinWidth=120});
        G.ItemsSource = payments.Select(p => new PayRow(
            p.Id, PersianDateService.ToPersian(p.PayDate), p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-",
            p.Amount, p.PaymentMethod, p.CheckNumber ?? "—", p.CheckStatus ?? "—", string.IsNullOrWhiteSpace(p.Note)?"—":p.Note
        )).ToList();
    }

    async Task LoadByCompany(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — خلاصه بر اساس شرکت";
        var rows = await S.GetInvoicesAsync(null); // company summary always covers all companies
        if (from.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();

        var groups = rows.Where(x=>x.Company!=null).GroupBy(x=>x.Company!.Name).Select(g=>
        {
            var bouncedCount = g.SelectMany(x=>x.Payments??new List<Payment>()).Count(p=>p.CheckStatus=="برگشتی");
            return new CompanyRow(g.Key, g.Count(), g.Sum(x=>x.Amount), g.Sum(x=>x.Paid), g.Sum(AccountingService.Balance), bouncedCount);
        }).OrderByDescending(c=>c.Balance).ToList();

        Summary.Text = $"تعداد شرکت: {groups.Count:N0}   |   جمع کل: {groups.Sum(x=>x.Amount):N0}   |   جمع پرداختی: {groups.Sum(x=>x.Paid):N0}   |   جمع مانده: {groups.Sum(x=>x.Balance):N0}";

        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("Name"),Width=new DataGridLength(1.6,DataGridLengthUnitType.Star),MinWidth=160});
        G.Columns.Add(new DataGridTextColumn{Header="تعداد فاکتور",Binding=new Binding("Count"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="جمع مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=120});
        G.Columns.Add(new DataGridTextColumn{Header="جمع پرداختی",Binding=new Binding("Paid"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=120});
        G.Columns.Add(new DataGridTextColumn{Header="جمع مانده",Binding=new Binding("Balance"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=120});
        G.Columns.Add(new DataGridTextColumn{Header="چک برگشتی",Binding=new Binding("BouncedChecks"),Width=100});
        G.ItemsSource = groups;
    }

    async Task LoadChecks(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — چک‌های در جریان";
        var payments = await S.GetPaymentsAsync(CompanyId);
        var checks = payments.Where(p=>p.PaymentMethod=="چک").ToList();
        if (from.HasValue) checks = checks.Where(p=>(p.CheckDate??p.PayDate).Date>=from.Value).ToList();
        if (to.HasValue) checks = checks.Where(p=>(p.CheckDate??p.PayDate).Date<=to.Value).ToList();
        // بحرانی‌ترین‌ها اول: برگشتی، بعد در انتظار وصول، بعد بقیه
        checks = checks.OrderBy(p=>p.CheckStatus=="برگشتی"?0:p.CheckStatus=="در انتظار وصول"?1:2).ThenByDescending(p=>p.PayDate).ToList();

        var bounced = checks.Count(p=>p.CheckStatus=="برگشتی");
        var pending = checks.Count(p=>p.CheckStatus=="در انتظار وصول");
        Summary.Text = $"تعداد کل چک: {checks.Count:N0}   |   برگشتی: {bounced:N0}   |   در انتظار وصول: {pending:N0}   |   جمع مبلغ چک‌ها: {checks.Sum(p=>p.Amount):N0} ریال";

        G.Columns.Add(new DataGridTextColumn{Header="تاریخ چک",Binding=new Binding("CheckDate"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شماره چک",Binding=new Binding("CheckNumber"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شماره فاکتور",Binding=new Binding("InvoiceNumber"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("CompanyName"),Width=new DataGridLength(1.4,DataGridLengthUnitType.Star),MinWidth=140});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="وضعیت",Binding=new Binding("CheckStatus"),Width=110});
        G.ItemsSource = checks.Select(p => new CheckRow(
            p.CheckDate.HasValue?PersianDateService.ToPersian(p.CheckDate.Value):"—", p.CheckNumber ?? "—",
            p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-", p.Amount, p.CheckStatus ?? "—"
        )).ToList();
    }

    async Task LoadCombined(DateTime? from, DateTime? to)
    {
        var companyName = (CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها";
        TitleText.Text = $"گزارش جامع — {companyName}";

        var invoices = await S.GetInvoicesAsync(CompanyId);
        if (from.HasValue) invoices = invoices.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) invoices = invoices.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();
        invoices = invoices.OrderByDescending(x=>x.InvoiceDate).ToList();
        _lastInvoiceRows = invoices;

        var payments = await S.GetPaymentsAsync(CompanyId);
        if (from.HasValue) payments = payments.Where(p=>p.PayDate.Date>=from.Value).ToList();
        if (to.HasValue) payments = payments.Where(p=>p.PayDate.Date<=to.Value).ToList();
        payments = payments.OrderByDescending(p=>p.PayDate).ToList();

        var checks = payments.Where(p=>p.PaymentMethod=="چک").ToList();

        var sum = AccountingService.Summarize(invoices);
        Summary.Text = $"شرکت: {companyName}   |   فاکتور: {invoices.Count:N0} ({sum.TotalAmount:N0} ریال)   |   پرداخت: {payments.Count:N0} ({payments.Sum(p=>p.Amount):N0} ریال)   |   چک: {checks.Count:N0} ({checks.Sum(p=>p.Amount):N0} ریال)   |   مانده‌ی کل: {sum.TotalBalance:N0}";

        CInvoicesHeader.Text = $"{invoices.Count:N0} فاکتور   |   جمع {invoices.Sum(x=>x.Amount):N0} ریال   |   مانده {invoices.Sum(AccountingService.Balance):N0} ریال";
        CInvoices.ItemsSource = invoices.Select(x => new
        {
            x.Number, x.Company,
            InvoiceDate = PersianDateService.ToPersian(x.InvoiceDate),
            Due = PersianDateService.ToPersian(x.DueDate),
            x.Amount, x.Paid, Balance = AccountingService.Balance(x),
            Status = StatusOf(x)
        }).ToList();

        CPaymentsHeader.Text = $"{payments.Count:N0} پرداخت   |   جمع {payments.Sum(p=>p.Amount):N0} ریال";
        CPayments.ItemsSource = payments.Select(p => new PayRow(
            p.Id, PersianDateService.ToPersian(p.PayDate), p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-",
            p.Amount, p.PaymentMethod, p.CheckNumber ?? "—", p.CheckStatus ?? "—", string.IsNullOrWhiteSpace(p.Note)?"—":p.Note
        )).ToList();

        CChecksHeader.Text = $"{checks.Count:N0} چک   |   جمع {checks.Sum(p=>p.Amount):N0} ریال   |   برگشتی: {checks.Count(p=>p.CheckStatus=="برگشتی"):N0}";
        CChecks.ItemsSource = checks.Select(p => new CheckRow(
            p.CheckDate.HasValue?PersianDateService.ToPersian(p.CheckDate.Value):"—", p.CheckNumber ?? "—",
            p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-", p.Amount, p.CheckStatus ?? "—"
        )).ToList();
    }

    void G_LoadingRow(object? sender, DataGridRowEventArgs e)
    {
        if (_tab != ReportTab.Checks || e.Row.Item is not CheckRow cr) { e.Row.Background = Brushes.White; return; }
        e.Row.Background = cr.CheckStatus switch
        {
            "برگشتی" => AppTheme.Danger100,
            "در انتظار وصول" => AppTheme.Warning100,
            _ => Brushes.White
        };
    }

    void Export(object? sender,RoutedEventArgs e)
    {
        var d=new SaveFileDialog{Filter="Excel Workbook|*.xlsx",FileName=$"گزارش-{DateTime.Now:yyyyMMdd-HHmm}.xlsx"};
        if(d.ShowDialog()!=true)return;
        try
        {
            using var wb = new XLWorkbook();
            if (_tab == ReportTab.Combined)
            {
                AddSheetFromGrid(wb, CInvoices, "فاکتورهای خریداری‌شده");
                AddSheetFromGrid(wb, CPayments, "پرداخت‌ها");
                AddSheetFromGrid(wb, CChecks, "چک‌های داده‌شده");
            }
            else
            {
                var sheetName = _tab switch
                {
                    ReportTab.Invoices => "خلاصه فاکتورها",
                    ReportTab.Payments => "گزارش پرداخت‌ها",
                    ReportTab.ByCompany => "خلاصه بر اساس شرکت",
                    ReportTab.Checks => "چک‌های در جریان",
                    _ => "گزارش"
                };
                AddSheetFromGrid(wb, G, sheetName);
            }
            wb.SaveAs(d.FileName);
            MessageBox.Show("خروجی Excel دقیقاً مطابق اطلاعات همین گزارش ذخیره شد.","خروجی Excel",MessageBoxButton.OK,MessageBoxImage.Information);
        }
        catch(Exception ex){MessageBox.Show(ex.Message,"خروجی",MessageBoxButton.OK,MessageBoxImage.Error);}
    }

    // خروجی Excel دقیقاً همان ستون‌ها و ردیف‌هایی را می‌نویسد که همین لحظه در جدول دیده می‌شود -
    // نه یک خروجی ثابت و جدا از فیلترها/تبی که کاربر واقعاً باز کرده.
    static void AddSheetFromGrid(XLWorkbook wb, DataGrid grid, string sheetName)
    {
        var ws = wb.Worksheets.Add(SafeSheetName(sheetName));
        var columns = grid.Columns.OfType<DataGridBoundColumn>().ToList();
        for (int c = 0; c < columns.Count; c++)
            ws.Cell(1, c + 1).Value = columns[c].Header?.ToString() ?? "";

        var items = grid.ItemsSource?.Cast<object>().ToList() ?? new List<object>();
        for (int r = 0; r < items.Count; r++)
            for (int c = 0; c < columns.Count; c++)
            {
                var path = (columns[c].Binding as Binding)?.Path?.Path;
                var val = path != null ? GetPropertyValue(items[r], path) : null;
                ws.Cell(r + 2, c + 1).Value = val?.ToString() ?? "";
            }

        ws.RightToLeft = true;
        ws.Row(1).Style.Font.Bold = true;
        ws.Row(1).Style.Fill.BackgroundColor = XLColor.LightBlue;
        ws.SheetView.FreezeRows(1);
        if (items.Count > 0) ws.Columns().AdjustToContents();
    }
    static string SafeSheetName(string s) => s.Length > 31 ? s.Substring(0, 31) : s; // محدودیت اکسل روی طول نام شیت

    static object? GetPropertyValue(object obj, string path)
    {
        object? current = obj;
        foreach (var part in path.Split('.'))
        {
            if (current is null) return null;
            var prop = current.GetType().GetProperty(part);
            if (prop is null) return null;
            current = prop.GetValue(current);
        }
        return current;
    }

    void Print(object? sender, RoutedEventArgs e)
    {
        if (_tab!=ReportTab.Invoices) return;
        new PrintService().PrintInvoices(_lastInvoiceRows, "گزارش فاکتورهای حساب‌گرا");
    }

    async void EditSelectedPayment(object? sender, RoutedEventArgs e)
    {
        if (G.SelectedItem is not PayRow row) { MessageBox.Show("یک پرداخت را از جدول انتخاب کنید."); return; }
        var payment = await S.GetPaymentByIdAsync(row.Id);
        if (payment is null) { MessageBox.Show("این پرداخت دیگر در سیستم موجود نیست."); await Load(); return; }
        if (ShowEditPaymentDialog(payment)) await Load();
    }

    async void DeleteSelectedPayment(object? sender, RoutedEventArgs e)
    {
        if (G.SelectedItem is not PayRow row) { MessageBox.Show("یک پرداخت را از جدول انتخاب کنید."); return; }
        if (MessageBox.Show($"پرداخت {row.Amount:N0} ریال برای فاکتور «{row.InvoiceNumber}» حذف شود؟","تأیید حذف",MessageBoxButton.YesNo,MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        try
        {
            await S.DeletePaymentAsync(row.Id);
            await Load();
            MessageBox.Show("پرداخت با موفقیت حذف شد.","حذف پرداخت",MessageBoxButton.OK,MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message,"حذف پرداخت",MessageBoxButton.OK,MessageBoxImage.Warning); }
    }

    // یک دیالوگ کوچک برای ویرایش پرداخت، مستقیماً از گزارش پرداخت‌ها - بدون نیاز به رفتن سراغ
    // فاکتور مربوطه. مقادیر ورودی همان قوانین AccountingService.UpdatePaymentAsync را دارند.
    bool ShowEditPaymentDialog(Payment payment)
    {
        var amountBox = new TextBox { Text = payment.Amount.ToString("0.##"), Height = 36, Margin = new Thickness(0,4,0,10) };
        var methodBox = new ComboBox { ItemsSource = new[]{"نقد","کارت‌به‌کارت","چک","ترکیبی"}, SelectedItem = payment.PaymentMethod, Height = 36, Margin = new Thickness(0,4,0,10) };
        var checkNumberBox = new TextBox { Text = payment.CheckNumber ?? "", Height = 36, Margin = new Thickness(0,4,0,10) };
        var checkDateBox = new DatePicker { SelectedDate = payment.CheckDate, Height = 36, Margin = new Thickness(0,4,0,10) };
        var checkStatusBox = new ComboBox { ItemsSource = new[]{"در انتظار وصول","وصول‌شده","برگشتی","لغوشده"}, SelectedItem = payment.CheckStatus ?? "در انتظار وصول", Height = 36, Margin = new Thickness(0,4,0,10) };
        var noteBox = new TextBox { Text = payment.Note ?? "", Height = 36, Margin = new Thickness(0,4,0,10) };

        var form = new StackPanel { Margin = new Thickness(18) };
        void AddRow(string label, FrameworkElement box) { form.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink700}); form.Children.Add(box); }
        AddRow("مبلغ وصول (ریال)", amountBox);
        AddRow("روش وصول", methodBox);
        AddRow("شماره چک (اختیاری)", checkNumberBox);
        AddRow("تاریخ چک (اختیاری)", checkDateBox);
        AddRow("وضعیت چک", checkStatusBox);
        AddRow("توضیحات", noteBox);

        bool saved = false;
        var saveBtn = Btn("ذخیره تغییرات", AppTheme.Brand600); saveBtn.Foreground = Brushes.White;
        var cancelBtn = Btn("انصراف", AppTheme.Surface100); cancelBtn.Foreground = AppTheme.Ink700;
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0,8,0,0) };
        buttons.Children.Add(saveBtn); buttons.Children.Add(cancelBtn);
        form.Children.Add(buttons);

        var win = new Window
        {
            Title = "ویرایش وصول", Content = form, Width = 380, SizeToContent = SizeToContent.Height,
            FlowDirection = FlowDirection.RightToLeft, WindowStartupLocation = WindowStartupLocation.CenterScreen,
            ResizeMode = ResizeMode.NoResize, Background = AppTheme.Surface100
        };
        cancelBtn.Click += (_,_) => win.Close();
        saveBtn.Click += async (_,_) =>
        {
            if (!decimal.TryParse(amountBox.Text.Replace(",","").Replace("٬","").Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var amount) || amount <= 0)
            { MessageBox.Show("مبلغ را به‌درستی وارد کنید."); return; }
            var method = methodBox.SelectedItem?.ToString() ?? "نقد";
            try
            {
                await S.UpdatePaymentAsync(new Payment
                {
                    Id = payment.Id, Amount = amount, PayDate = payment.PayDate, PaymentMethod = method,
                    CheckNumber = method=="چک" ? (string.IsNullOrWhiteSpace(checkNumberBox.Text)?null:checkNumberBox.Text.Trim()) : null,
                    CheckDate = method=="چک" ? checkDateBox.SelectedDate : null,
                    CheckStatus = method=="چک" ? checkStatusBox.SelectedItem?.ToString() : null,
                    Note = string.IsNullOrWhiteSpace(noteBox.Text) ? null : noteBox.Text.Trim()
                });
                saved = true;
                MessageBox.Show("پرداخت با موفقیت ویرایش شد.","ویرایش وصول",MessageBoxButton.OK,MessageBoxImage.Information);
                win.Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message,"ویرایش وصول",MessageBoxButton.OK,MessageBoxImage.Warning); }
        };
        win.ShowDialog();
        return saved;
    }
}

sealed record PayRow(int Id, string PayDate, string InvoiceNumber, string CompanyName, decimal Amount, string PaymentMethod, string CheckNumber, string CheckStatus, string Note);
sealed record CompanyRow(string Name, int Count, decimal Amount, decimal Paid, decimal Balance, int BouncedChecks);
sealed record CheckRow(string CheckDate, string CheckNumber, string InvoiceNumber, string CompanyName, decimal Amount, string CheckStatus);
