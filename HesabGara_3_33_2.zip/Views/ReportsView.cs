﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using Microsoft.Win32;
using ClosedXML.Excel;
using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;

namespace HesabGara.Views;

// Reports module: three reports sharing one filter bar (company / date range / search):
// company-wide combined report, invoice grouping, and issued checks (filtered by check due date).
public class ReportsView : Grid
{
    readonly AccountingService S; readonly int? InitialCompanyId;
    readonly DataGrid G=new(); readonly TextBlock Summary=new(); readonly TextBlock TitleText=new();
    readonly ComboBox CompanyBox=new(), StatusBox=new(), PresetBox=new();
    readonly TextBox FromDateBox=new(), ToDateBox=new(), SearchBox=new();
    readonly Button TabCombined, TabStatement, TabGrouping, TabChecks, TabPayments;
    StatementResult? _stmt; Company? _stmtCompany; DateTime? _stmtFrom; string _stmtPeriod="";
    readonly TextBlock ReportInfo=new();
    StackPanel? FromField, ToField, StatusField, SearchField;
    bool _ready, _suppress; // فیلترها بعد از اولین بارگذاری بلافاصله اعمال می‌شوند
    // گروه‌بندی فاکتورها
    readonly TextBox GroupNameBox=new(); readonly TextBlock SelectionSummary=new(), GroupTotalsText=new();
    Button? AddGroupBtn;
    readonly CheckBox HideGroupedBox=new(){Content="فاکتورهای گروه‌بندی‌شده نمایش داده نشوند",IsChecked=false,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(8,0,8,0)};
    // داده‌ی آخرین گزارش برای چاپ
    List<CheckGroup> _checkList=new(); List<Invoice> _cInv=new(); List<Payment> _cPay=new(); List<CheckGroup> _cChk=new();
    readonly ScrollViewer CombinedScroll=new(); readonly DataGrid CInvoices=new(), CPayments=new(), CChecks=new();
    readonly TextBlock CInvoicesHeader=new(), CPaymentsHeader=new(), CChecksHeader=new();
    readonly ScrollViewer GroupingScroll=new(){VerticalScrollBarVisibility=ScrollBarVisibility.Auto,HorizontalScrollBarVisibility=ScrollBarVisibility.Disabled};
    const double GroupingMinHeight=420;
    readonly Grid GroupingPanel=new(); readonly DataGrid GroupPickerGrid=new();
    readonly TextBlock PickerInfo=new();
    readonly ComboBox ViewBox=new(){VerticalContentAlignment=VerticalAlignment.Center,FlowDirection=FlowDirection.RightToLeft};   // نمایش: همه / فقط انتخاب‌شده‌ها / هر گروه
    bool _viewLock;
    // پرداخت فاکتورها: فاکتورهای شرکت را تیک می‌زنیم و پرداخت‌های همان فاکتورها را می‌بینیم/چاپ می‌کنیم
    readonly Grid PayPanel=new(); readonly DataGrid PayPickerGrid=new(), PayDetailGrid=new();
    readonly TextBlock PayPickerInfo=new(), PayDetailInfo=new();
    readonly HashSet<int> _paySel=new();
    List<Invoice> _paySource=new(); List<GroupRow> _payRows=new(); Dictionary<int,List<Payment>> _payByInvoice=new();
    List<Invoice> _payShownInv=new(); List<PayDetailRow> _payShownRows=new();   // آخرین انتخاب (برای چاپ و Excel)
    string _payBase=""; bool _payBulk;
    readonly HashSet<int> _selIds=new();                            // شناسه‌ی فاکتورهای تیک‌خورده (با تغییر فیلتر حفظ می‌شود)
    List<Invoice> _pickerSource=new(); List<GroupRow> _pickerRows=new(); string _summaryBase=""; bool _bulk;
    readonly List<InvoiceGroupResult> Groups=new();
    ReportTab _tab = ReportTab.Combined;
    enum ReportTab { Combined, Statement, Grouping, Checks, Payments }
    const string AllStatuses = "همه وضعیت‌ها";
    static readonly string[] CheckStatusItems = new[]{AllStatuses}.Concat(PaymentRules.CheckStatuses).ToArray();

    public ReportsView(AccountingService s,int? c)
    {
        S=s; InitialCompanyId=c; Margin=new Thickness(18); Background=AppTheme.Surface100;
        TabCombined=TabButton("گزارش جامع شرکت"); TabStatement=TabButton("صورت‌حساب شرکت"); TabGrouping=TabButton("گروه‌بندی فاکتورها"); TabChecks=TabButton("چک‌های در جریان"); TabPayments=TabButton("پرداخت فاکتورها");
        TabCombined.Click+=async(_,_)=>{_tab=ReportTab.Combined;UpdateTabs();await Load();};
        TabStatement.Click+=async(_,_)=>{_tab=ReportTab.Statement;UpdateTabs();await Load();};
        TabGrouping.Click+=async(_,_)=>{_tab=ReportTab.Grouping;UpdateTabs();await Load();};
        TabChecks.Click+=async(_,_)=>{_tab=ReportTab.Checks;UpdateTabs();await Load();};
        TabPayments.Click+=async(_,_)=>{_tab=ReportTab.Payments;UpdateTabs();await Load();};
        Build();
    }
    public static async Task<ReportsView>Create(AccountingService s,int? c){var v=new ReportsView(s,c);await v.LoadCompanies();await v.Load();v._ready=true;return v;}

    void Build()
    {
        FlowDirection=FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});   // header + tabs
        RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});   // filter bar
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(58)}); // summary
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)}); // grid

        // --- Header + tabs ---
        var headerCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(12,8,12,8),Effect=AppTheme.CardShadow};
        var headerStack=new StackPanel();
        TitleText.Text="گزارش‌ها"; TitleText.FontSize=17; TitleText.FontWeight=FontWeights.Bold; TitleText.Foreground=AppTheme.Brand900;
        TitleText.VerticalAlignment=VerticalAlignment.Center; TitleText.Margin=new Thickness(0,0,0,0);
        var tabsRow=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft};   // عنوان و تب‌ها در یک ردیف
        var titleWrap=new Border{Child=TitleText,Margin=new Thickness(2,0,22,0),VerticalAlignment=VerticalAlignment.Center};
        tabsRow.Children.Add(titleWrap);
        tabsRow.Children.Add(TabCombined); tabsRow.Children.Add(TabStatement); tabsRow.Children.Add(TabGrouping); tabsRow.Children.Add(TabChecks); tabsRow.Children.Add(TabPayments);
        headerStack.Children.Add(tabsRow);
        ReportInfo.Margin=new Thickness(2,6,2,0); ReportInfo.FontSize=12; ReportInfo.Foreground=AppTheme.Ink500; ReportInfo.TextWrapping=TextWrapping.NoWrap; ReportInfo.TextTrimming=TextTrimming.CharacterEllipsis;
        ReportInfo.SetBinding(ToolTipProperty,new Binding("Text"){Source=ReportInfo});   // یک خط؛ متن کامل با نگه‌داشتن ماوس
        headerStack.Children.Add(ReportInfo);
        headerCard.Child=headerStack; Grid.SetRow(headerCard,0); Children.Add(headerCard);
        UpdateTabs();

        // --- Filter bar ---
        var filterCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(10,8,10,4),Margin=new Thickness(0,6,0,0),Effect=AppTheme.CardShadow};
        var filters=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft};

        filters.Children.Add(LabeledField("شرکت", CompanyBox, 190));
        CompanyBox.Height=38;
        CompanyBox.SelectionChanged+=async(_,_)=>{ if(_ready&&!_suppress) await Load(); };

        SearchField=LabeledField("جستجو (شماره چک/فاکتور/شرکت)", SearchBox, 180);
        SearchBox.ToolTip="با Enter جستجو می‌شود";
        SearchBox.KeyUp+=async(_,e)=>{ if(e.Key==System.Windows.Input.Key.Enter) await Load(); };
        filters.Children.Add(SearchField);

        PresetBox.ItemsSource=new[]{"همه","امروز","۷ روز اخیر","این ماه (شمسی)","سه‌ماه اخیر","امسال (شمسی)","۷ روز آینده","۳۰ روز آینده","بازه‌ی دلخواه"};
        PresetBox.SelectedIndex=0;
        PresetBox.SelectionChanged+=async(_,_)=>{ ApplyPreset(); if(_ready&&!_suppress&&(PresetBox.SelectedItem as string)!="بازه‌ی دلخواه") await Load(); };
        filters.Children.Add(LabeledField("بازه‌ی زمانی", PresetBox, 140));

        FromDateBox.ToolTip="مثال: 1405/01/01"; ToDateBox.ToolTip="مثال: 1405/06/25";
        FromDateBox.KeyUp+=async(_,e)=>{ if(e.Key==System.Windows.Input.Key.Enter) await Load(); };
        ToDateBox.KeyUp+=async(_,e)=>{ if(e.Key==System.Windows.Input.Key.Enter) await Load(); };
        FromField=LabeledField("از تاریخ", FromDateBox, 110); ToField=LabeledField("تا تاریخ", ToDateBox, 110);
        filters.Children.Add(FromField); filters.Children.Add(ToField);

        StatusBox.SelectionChanged+=async(_,_)=>{ if(_ready&&!_suppress&&StatusBox.SelectedItem!=null) await Load(); };
        StatusField=LabeledField("وضعیت چک", StatusBox, 130);
        filters.Children.Add(StatusField);

        var showBtn=Btn("نمایش گزارش",AppTheme.Success600); showBtn.Foreground=Brushes.White; showBtn.VerticalAlignment=VerticalAlignment.Bottom; showBtn.Margin=new Thickness(4,0,4,4);
        showBtn.Click+=async(_,_)=>await Load();
        filters.Children.Add(showBtn);

        var expBtn=Btn("خروجی Excel",AppTheme.Brand600); expBtn.Foreground=Brushes.White; expBtn.VerticalAlignment=VerticalAlignment.Bottom; expBtn.Margin=new Thickness(4,0,4,4);
        expBtn.Click+=Export;
        filters.Children.Add(expBtn);

        var printBtn=Btn("چاپ",AppTheme.Brand700); printBtn.Foreground=Brushes.White; printBtn.VerticalAlignment=VerticalAlignment.Bottom; printBtn.Margin=new Thickness(4,0,4,4);
        printBtn.Click+=Print;
        filters.Children.Add(printBtn);

        filterCard.Child=filters; Grid.SetRow(filterCard,1); Children.Add(filterCard);
        UpdateTabs();

        // --- Summary ---
        var sumCard=new Border{Background=AppTheme.Brand100,CornerRadius=new CornerRadius(11),Padding=new Thickness(12),Margin=new Thickness(0,8,0,8)};
        Summary.FontSize=12.5; Summary.FontWeight=FontWeights.SemiBold; Summary.Foreground=AppTheme.Ink900;
        Summary.TextWrapping=TextWrapping.Wrap; Summary.VerticalAlignment=VerticalAlignment.Center;
        sumCard.Child=Summary; Grid.SetRow(sumCard,2); Children.Add(sumCard);

        // --- Grid (tabs 1-4) ---
        G.FlowDirection=FlowDirection.RightToLeft; G.AutoGenerateColumns=false; G.IsReadOnly=true; G.CanUserAddRows=false;
        G.SelectionMode=DataGridSelectionMode.Single; G.SelectionUnit=DataGridSelectionUnit.FullRow;
        G.RowHeight=40; G.ColumnHeaderHeight=38; G.FontSize=12.5; G.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; G.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        G.LoadingRow += G_LoadingRow;

        Grid.SetRow(G,3); Children.Add(G);

        // --- Combined report (tab 5): سه بخش پشت سر هم در یک قاب، بدون نیاز به جابه‌جایی تب ---
        var combinedStack=new StackPanel();
        combinedStack.Children.Add(BuildCombinedSection(CInvoicesHeader,"فاکتورهای خریداری‌شده", CInvoices,
            "شماره","شرکت","تاریخ فاکتور","سررسید","مبلغ","مرجوعی","پرداختی","مانده","وضعیت"));
        combinedStack.Children.Add(BuildCombinedSection(CPaymentsHeader,"پرداخت‌ها", CPayments,
            "تاریخ وصول","فاکتور","مبلغ","روش","شماره چک","وضعیت چک"));
        combinedStack.Children.Add(BuildCombinedSection(CChecksHeader,"چک‌های داده‌شده (بر اساس سررسید چک)", CChecks,
            "تاریخ چک","شماره چک","فاکتورها","مبلغ","وضعیت چک"));
        CombinedScroll.Content=combinedStack; CombinedScroll.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        CombinedScroll.Visibility=Visibility.Collapsed;
        Grid.SetRow(CombinedScroll,3); Children.Add(CombinedScroll);

        // --- گروه‌بندی فاکتورها (جدول فاکتورها بالا؛ انتخاب فعلی، گروه‌ها و جزئیات گروه پایین) ---
        BuildGroupingPanel();

        // در صفحه‌ی کوچک (لپ‌تاپ) کل پنل گروه‌بندی اسکرول می‌خورد تا کادرهای ۲ و ۳ و ۴ بریده نشوند؛ در صفحه‌ی بزرگ دقیقاً پر می‌کند.
        GroupingScroll.Content=GroupingPanel;
        GroupingScroll.SizeChanged+=(_,_)=>GroupingPanel.Height=Math.Max(GroupingMinHeight,GroupingScroll.ActualHeight);
        Grid.SetRow(GroupingScroll,3); Children.Add(GroupingScroll);

        // --- پرداخت فاکتورها ---
        BuildPayReportPanel();
        Grid.SetRow(PayPanel,3); Children.Add(PayPanel);
        UpdateTabs(); // بعد از ساخته‌شدن همه‌ی پنل‌ها، تا پنل تب پیش‌فرض (گزارش جامع) واقعاً دیده شود
    }

    Border BuildCombinedSection(TextBlock header, string title, DataGrid grid, params string[] columnHeaders)
    {
        var card=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(12),Padding=new Thickness(12),Margin=new Thickness(0,0,0,10),Effect=AppTheme.CardShadow};
        var stack=new StackPanel();
        var titleRow=new StackPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(0,0,0,6)};
        titleRow.Children.Add(new TextBlock{Text=title,FontWeight=FontWeights.Bold,FontSize=13.5,Foreground=AppTheme.Brand900});
        header.FontSize=11.5; header.Foreground=AppTheme.Ink500; header.Margin=new Thickness(10,2,0,0); header.VerticalAlignment=VerticalAlignment.Center;
        titleRow.Children.Add(header);
        stack.Children.Add(titleRow);

        grid.FlowDirection=FlowDirection.RightToLeft; grid.AutoGenerateColumns=false; grid.IsReadOnly=true; grid.CanUserAddRows=false;
        grid.RowHeight=32; grid.ColumnHeaderHeight=32; grid.FontSize=11.5; grid.MaxHeight=220; grid.MinHeight=70;
        grid.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; grid.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        foreach (var h in columnHeaders) grid.Columns.Add(new DataGridTextColumn{Header=h,Binding=new Binding(SafeProp(h)),Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=80});
        stack.Children.Add(grid);
        card.Child=stack;
        return card;
    }
    // ستون‌های این سه‌گانه از رکوردهای موجود (Invoices row type / PayRow / CheckRow) استفاده می‌کنند؛
    // این متد فقط عنوان فارسی هر ستون را به نام Property مربوطه نگاشت می‌دهد.
    static string SafeProp(string header) => header switch
    {
        "شماره"=>"Number", "شرکت"=>"Company.Name", "تاریخ فاکتور"=>"InvoiceDate", "سررسید"=>"Due",
        "مبلغ"=>"Amount", "مرجوعی"=>"Returned", "پرداختی"=>"Paid", "مانده"=>"Balance", "وضعیت"=>"Status",
        "تاریخ وصول"=>"PayDate", "فاکتور"=>"InvoiceNumber", "روش"=>"PaymentMethod",
        "شماره چک"=>"CheckNumber", "فاکتورها"=>"InvoiceNumber", "وضعیت چک"=>"CheckStatus", "تاریخ چک"=>"CheckDate",
        _=>header
    };

    static StackPanel LabeledField(string label, Control box, double width)
    {
        var p=new StackPanel{Margin=new Thickness(4,0,4,4)};
        p.Children.Add(new TextBlock{Text=label,FontSize=11,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink500,Margin=new Thickness(2,0,2,3)});
        box.Width=width; box.Height=36;
        if (box is TextBox tb){tb.Padding=new Thickness(8,6,8,6);tb.VerticalContentAlignment=VerticalAlignment.Center;}
        p.Children.Add(box);
        return p;
    }
    static Button TabButton(string text)=>new Button{Content=text,Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,0,8,0),BorderThickness=new Thickness(0),FontWeight=FontWeights.SemiBold,Cursor=System.Windows.Input.Cursors.Hand};
    void UpdateTabs()
    {
        _suppress=true;
        SetTabState(TabCombined,_tab==ReportTab.Combined); SetTabState(TabStatement,_tab==ReportTab.Statement); SetTabState(TabGrouping,_tab==ReportTab.Grouping); SetTabState(TabChecks,_tab==ReportTab.Checks); SetTabState(TabPayments,_tab==ReportTab.Payments);
        G.Visibility = (_tab==ReportTab.Checks || _tab==ReportTab.Statement) ? Visibility.Visible : Visibility.Collapsed;
        CombinedScroll.Visibility = _tab==ReportTab.Combined ? Visibility.Visible : Visibility.Collapsed;
        GroupingScroll.Visibility = _tab==ReportTab.Grouping ? Visibility.Visible : Visibility.Collapsed;
        PayPanel.Visibility = _tab==ReportTab.Payments ? Visibility.Visible : Visibility.Collapsed;
        RowDefinitions[2].Height = _tab==ReportTab.Grouping ? new GridLength(34) : new GridLength(58);   // نوار خلاصه در گروه‌بندی یک خط است
        if (StatusField!=null) StatusField.Visibility = _tab==ReportTab.Checks ? Visibility.Visible : Visibility.Collapsed;
        if (SearchField!=null) SearchField.Visibility = (_tab==ReportTab.Grouping || _tab==ReportTab.Checks || _tab==ReportTab.Payments) ? Visibility.Visible : Visibility.Collapsed;
        StatusBox.ItemsSource = CheckStatusItems; StatusBox.SelectedIndex = 0;
        SetLabel(FromField, _tab==ReportTab.Checks ? "سررسید چک — از" : "از تاریخ");
        SetLabel(ToField, _tab==ReportTab.Checks ? "سررسید چک — تا" : "تا تاریخ");
        ReportInfo.Text = _tab switch
        {
            ReportTab.Combined => "فاکتورها، وصول‌ها و چک‌های یک شرکت در یک صفحه. فاکتورها بر اساس تاریخ فاکتور، وصول‌ها بر اساس تاریخ وصول و چک‌ها بر اساس سررسید چک فیلتر می‌شوند.",
            ReportTab.Statement => "گردش کامل حساب یک شرکت به ترتیب تاریخ: فاکتورها (بدهکار)، مرجوعی و وصول‌ها (بستانکار) با مانده‌ی هر ردیف. ابتدا شرکت را انتخاب کنید؛ اگر بازه‌ی زمانی بدهید، مانده‌ی قبل از آن به‌صورت «مانده‌ی از قبل» می‌آید.",
            ReportTab.Grouping => "فاکتورهای مانده‌دار را تیک بزنید و گروه بسازید تا جمع و میانگین سررسید هر گروه را ببینید. فیلتر تاریخ بر اساس تاریخ فاکتور است.",
            ReportTab.Payments => "فاکتورهای یک شرکت را تیک بزنید تا ببینید هر فاکتور با چه روشی (نقد/کارت/چک) پرداخت شده و شماره و سررسید چک‌ها چیست؛ قابل چاپ و خروجی Excel. فیلتر تاریخ بر اساس تاریخ فاکتور است.",
            _ => "چک‌های صادرشده برای شرکت انتخاب‌شده، بر اساس سررسید چک. بازه‌ی زمانی را عوض کنید (مثلاً «۳۰ روز آینده») تا ببینید در آن بازه چه چک‌هایی سررسید دارند."
        };
        _suppress=false;
    }
    static void SetLabel(StackPanel? field, string text) { if (field?.Children[0] is TextBlock tb) tb.Text = text; }
    static string Norm(string? s) => (s ?? "").Replace('ي','ی').Replace('ك','ک').Trim();
    static bool Has(string? s, string q) => Norm(s).Contains(Norm(q), StringComparison.OrdinalIgnoreCase);
    static void SetTabState(Button b, bool active)
    {
        b.Background = active ? AppTheme.Brand600 : AppTheme.Surface100;
        b.Foreground = active ? Brushes.White : AppTheme.Ink700;
    }
    static Button Btn(string t,Brush bg)=>new Button{Content=t,Background=bg,BorderThickness=new Thickness(0),Padding=new Thickness(13,8,13,8),Margin=new Thickness(4),FontWeight=FontWeights.SemiBold};

    async Task LoadCompanies(){var list=await S.GetCompaniesAsync();var all=new List<Company>{new Company{Id=0,Name="همه شرکت‌ها"}};all.AddRange(list);CompanyBox.ItemsSource=all;CompanyBox.DisplayMemberPath="Name";CompanyBox.SelectedValuePath="Id";CompanyBox.SelectedValue=InitialCompanyId??0;}
    int? CompanyId=>CompanyBox.SelectedValue is int id&&id>0?id:null;

    void ApplyPreset()
    {
        var preset = PresetBox.SelectedItem as string;
        if (preset=="بازه‌ی دلخواه" || preset is null) return;
        var pc = new PersianCalendar(); var today = DateTime.Today;
        (DateTime from, DateTime to) range = preset switch
        {
            "امروز" => (today, today),
            "۷ روز اخیر" => (today.AddDays(-6), today),
            "این ماه (شمسی)" => MonthRange(pc, today),
            "سه‌ماه اخیر" => (today.AddDays(-90), today),
            "امسال (شمسی)" => (pc.ToDateTime(pc.GetYear(today),1,1,0,0,0,0), today),
            "۷ روز آینده" => (today, today.AddDays(7)),
            "۳۰ روز آینده" => (today, today.AddDays(30)),
            _ => (DateTime.MinValue, DateTime.MaxValue) // "همه"
        };
        FromDateBox.Text = range.from==DateTime.MinValue ? "" : PersianDateService.ToPersian(range.from);
        ToDateBox.Text = range.to==DateTime.MaxValue ? "" : PersianDateService.ToPersian(range.to);
    }
    static (DateTime,DateTime) MonthRange(PersianCalendar pc, DateTime today)
    {
        int y=pc.GetYear(today), m=pc.GetMonth(today);
        var from = pc.ToDateTime(y,m,1,0,0,0,0);
        var to = pc.ToDateTime(y,m,pc.GetDaysInMonth(y,m),0,0,0,0);
        return (from,to);
    }
    (DateTime? from, DateTime? to) ReadDateRange()
    {
        DateTime? from=null, to=null;
        if (!string.IsNullOrWhiteSpace(FromDateBox.Text)) { if (PersianDateService.TryParse(FromDateBox.Text, out var f)) from=f.Date; else MessageBox.Show("تاریخ «از» معتبر نیست. نمونه: 1405/01/01","فیلتر تاریخ",MessageBoxButton.OK,MessageBoxImage.Warning); }
        if (!string.IsNullOrWhiteSpace(ToDateBox.Text)) { if (PersianDateService.TryParse(ToDateBox.Text, out var t)) to=t.Date; else MessageBox.Show("تاریخ «تا» معتبر نیست. نمونه: 1405/06/25","فیلتر تاریخ",MessageBoxButton.OK,MessageBoxImage.Warning); }
        return (from,to);
    }
    static string StatusOf(Invoice x)
    {
        var balance = AccountingService.Balance(x);
        return balance<=0 ? "تسویه شده" : x.Paid>0 ? "بخشی پرداخت شده" : "پرداخت نشده";
    }

    async Task Load()
    {
        var (from,to) = ReadDateRange();
        switch (_tab)
        {
            case ReportTab.Combined: await LoadCombined(from,to); break;
            case ReportTab.Statement: await LoadStatement(from,to); break;
            case ReportTab.Grouping: await LoadGroupingPicker(from,to); break;
            case ReportTab.Payments: await LoadPaymentsReport(from,to); break;
            default: G.Columns.Clear(); await LoadChecks(from,to); break;
        }
    }

    async Task LoadStatement(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — صورت‌حساب شرکت";
        _stmt = null; _stmtCompany = null; _stmtFrom = from;
        G.Columns.Clear(); G.ItemsSource = null;
        if (CompanyId is not int cid)
        {
            Summary.Text = "برای دیدن صورت‌حساب، یک شرکت را از فیلتر «شرکت» انتخاب کنید.";
            return;
        }
        var company = CompanyBox.SelectedItem as Company;
        var invoices = await S.GetInvoicesAsync(cid, includePayments: false);
        var payments = await S.GetPaymentsAsync(cid);
        var result = CompanyStatement.Build(invoices, payments, from, to);
        _stmt = result; _stmtCompany = company;
        _stmtPeriod = from.HasValue || to.HasValue
            ? $"از {(from.HasValue?PersianDateService.ToPersian(from.Value):"ابتدا")} تا {(to.HasValue?PersianDateService.ToPersian(to.Value):"امروز")}"
            : "همه‌ی تاریخ‌ها";
        var nid = string.IsNullOrWhiteSpace(company?.NationalId) ? "" : "  (شناسه ملی " + company!.NationalId + ")";
        Summary.Text = $"{company?.Name ?? "شرکت"}{nid}   |   {_stmtPeriod}   |   جمع بدهکار: {result.TotalDebit:N0}   |   جمع بستانکار: {result.TotalCredit:N0}   |   مانده‌ی نهایی: {result.Closing:N0} ریال";

        const string money = "{0:#,##0;-#,##0;—}";
        G.Columns.Add(new DataGridTextColumn{Header="تاریخ",Binding=new Binding("Date"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شرح",Binding=new Binding("Description"),Width=new DataGridLength(1.6,DataGridLengthUnitType.Star),MinWidth=180});
        G.Columns.Add(new DataGridTextColumn{Header="مرجع (فاکتور/چک)",Binding=new Binding("Reference"),Width=new DataGridLength(1.2,DataGridLengthUnitType.Star),MinWidth=130});
        G.Columns.Add(new DataGridTextColumn{Header="بدهکار",Binding=new Binding("Debit"){StringFormat=money},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=105});
        G.Columns.Add(new DataGridTextColumn{Header="بستانکار",Binding=new Binding("Credit"){StringFormat=money},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=105});
        G.Columns.Add(new DataGridTextColumn{Header="مانده",Binding=new Binding("Balance"){StringFormat="{0:#,##0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        var rows = new List<StatementRow>();
        if (from.HasValue) rows.Add(new StatementRow("", "مانده‌ی از قبل", "", 0m, 0m, result.Opening));
        rows.AddRange(result.Lines.Select(l => new StatementRow(PersianDateService.ToPersian(l.Date), l.Description, l.Reference, l.Debit, l.Credit, l.Balance)));
        G.ItemsSource = rows;
    }

    // ======================= گروه‌بندی فاکتورها =======================
    // چیدمان: بالا = همه‌ی فاکتورهای مانده‌دار با تمام ستون‌ها در تمام عرض صفحه (قابل کوچک/بزرگ‌کردن با جداکننده).
    // پایین (از راست به چپ): ۲) انتخاب فعلی  ۳) گروه‌های ساخته‌شده  ۴) فاکتورهای کامل گروه انتخاب‌شده.
    // ردیف تیک‌خورده سبز می‌شود، همان لحظه در «انتخاب فعلی» با جمع‌ها دیده می‌شود، و فاکتورهای گروه‌شده خاکستری‌اند.
    static DataGridLength StarW(double v) => new DataGridLength(v, DataGridLengthUnitType.Star);
    static Border GCard(UIElement child, Thickness margin) => new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(12),Padding=new Thickness(12),Margin=margin,Effect=AppTheme.CardShadow,Child=child};
    static TextBlock GTitle(string t) => new TextBlock{Text=t,FontWeight=FontWeights.Bold,FontSize=14,Foreground=AppTheme.Brand900,VerticalAlignment=VerticalAlignment.Center,TextWrapping=TextWrapping.Wrap};
    static DataGridTextColumn GCol(string header, string path, DataGridLength width, double min=0, string? fmt=null, bool trim=false, bool bold=false)
    {
        var b = new Binding(path); if (fmt != null) b.StringFormat = fmt;
        var st = new Style(typeof(TextBlock));
        st.Setters.Add(new Setter(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center));
        if (bold) st.Setters.Add(new Setter(TextBlock.FontWeightProperty, FontWeights.SemiBold));
        if (trim) { st.Setters.Add(new Setter(TextBlock.TextTrimmingProperty, TextTrimming.CharacterEllipsis)); st.Setters.Add(new Setter(FrameworkElement.ToolTipProperty, new Binding(path))); }
        return new DataGridTextColumn{Header=header,Binding=b,IsReadOnly=true,Width=width,MinWidth=min,ElementStyle=st};
    }
    static void ConfigGrid(DataGrid g)
    {
        g.FlowDirection=FlowDirection.RightToLeft; g.AutoGenerateColumns=false; g.CanUserAddRows=false; g.CanUserDeleteRows=false;
        g.SelectionMode=DataGridSelectionMode.Single; g.SelectionUnit=DataGridSelectionUnit.FullRow;
        g.RowHeight=34; g.ColumnHeaderHeight=34; g.FontSize=12.5;
        g.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; g.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        VirtualizingPanel.SetIsVirtualizing(g,true); VirtualizingPanel.SetVirtualizationMode(g,VirtualizationMode.Recycling);   // فقط ردیف‌های دیده‌شده ساخته می‌شوند
    }

    void BuildGroupingPanel()
    {
        // یک جدول بزرگ برای همه‌ی فاکتورها + یک نوار فشرده‌ی پایین (انتخاب، ساخت گروه، گروه‌ها).
        // گروه‌ها با فهرست «نمایش» دیده می‌شوند: هر گروه را انتخاب کنید تا همان فاکتورها با همه‌ی ستون‌ها در همین جدول بیایند.
        GroupingPanel.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star),MinHeight=250});
        GroupingPanel.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        GroupingScroll.Visibility=Visibility.Collapsed;

        var pickLayout=new Grid();
        pickLayout.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        pickLayout.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});

        var pickHeader=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft,Margin=new Thickness(0,0,0,6)};
        var pickTitle=GTitle("فاکتورها — روی هر ردیف بزنید تا انتخاب شود"); pickTitle.Margin=new Thickness(0,0,14,0);
        PickerInfo.VerticalAlignment=VerticalAlignment.Center; PickerInfo.Foreground=AppTheme.Ink500; PickerInfo.FontSize=12; PickerInfo.Margin=new Thickness(0,0,12,0);
        var viewLabel=new TextBlock{Text="نمایش:",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,6,0),Foreground=AppTheme.Ink700,FontSize=12};
        ViewBox.MinWidth=250; ViewBox.Height=32; ViewBox.Margin=new Thickness(0,0,10,0);
        ViewBox.SelectionChanged+=(_,_)=>{ if(!_viewLock) ApplyPickerFilter(); };
        var selAllBtn=Btn("انتخاب همه‌ی نمایش‌داده‌شده‌ها",AppTheme.Surface100); selAllBtn.Foreground=AppTheme.Ink700; selAllBtn.Click+=(_,_)=>SetAllPicked(true);
        var selNoneBtn=Btn("هیچ‌کدام",AppTheme.Surface100); selNoneBtn.Foreground=AppTheme.Ink700; selNoneBtn.Click+=(_,_)=>SetAllPicked(false);
        HideGroupedBox.Content="مخفی‌کردن گروه‌بندی‌شده‌ها";
        HideGroupedBox.Checked+=(_,_)=>ApplyPickerFilter(); HideGroupedBox.Unchecked+=(_,_)=>ApplyPickerFilter();
        pickHeader.Children.Add(pickTitle); pickHeader.Children.Add(PickerInfo); pickHeader.Children.Add(viewLabel); pickHeader.Children.Add(ViewBox);
        pickHeader.Children.Add(selAllBtn); pickHeader.Children.Add(selNoneBtn); pickHeader.Children.Add(HideGroupedBox);
        Grid.SetRow(pickHeader,0); pickLayout.Children.Add(pickHeader);

        ConfigGrid(GroupPickerGrid);
        // ردیف تیک‌خورده سبز و پررنگ؛ ردیف گروه‌شده خاکستری؛ رنگ آبیِ «ردیف انتخاب‌شده‌ی DataGrid» حذف شده تا با تیک اشتباه نشود.
        var baseRow=Application.Current?.TryFindResource(typeof(DataGridRow)) as Style;
        var rowStyle=new Style(typeof(DataGridRow),baseRow);
        var plainSel=new Trigger{Property=DataGridRow.IsSelectedProperty,Value=true}; plainSel.Setters.Add(new Setter(Control.BackgroundProperty,Brushes.Transparent));
        var groupedTrig=new DataTrigger{Binding=new Binding(nameof(GroupRow.IsGrouped)),Value=true}; groupedTrig.Setters.Add(new Setter(Control.BackgroundProperty,AppTheme.Surface100));
        var tickTrig=new DataTrigger{Binding=new Binding(nameof(GroupRow.Selected)),Value=true};
        tickTrig.Setters.Add(new Setter(Control.BackgroundProperty,AppTheme.Success100)); tickTrig.Setters.Add(new Setter(Control.FontWeightProperty,FontWeights.SemiBold));
        rowStyle.Triggers.Add(plainSel); rowStyle.Triggers.Add(groupedTrig); rowStyle.Triggers.Add(tickTrig);
        GroupPickerGrid.RowStyle=rowStyle;

        // کادر انتخاب با «یک» کلیک تغییر می‌کند (ستون چک‌باکس پیش‌فرض DataGrid دو کلیک می‌خواهد).
        var cbFactory=new FrameworkElementFactory(typeof(CheckBox));
        cbFactory.SetBinding(CheckBox.IsCheckedProperty,new Binding(nameof(GroupRow.Selected)){Mode=BindingMode.TwoWay,UpdateSourceTrigger=UpdateSourceTrigger.PropertyChanged});
        cbFactory.SetValue(FrameworkElement.HorizontalAlignmentProperty,HorizontalAlignment.Center);
        cbFactory.SetValue(FrameworkElement.VerticalAlignmentProperty,VerticalAlignment.Center);
        cbFactory.SetValue(FrameworkElement.LayoutTransformProperty,new ScaleTransform(1.2,1.2));
        GroupPickerGrid.Columns.Add(new DataGridTemplateColumn{Header="انتخاب",CellTemplate=new DataTemplate{VisualTree=cbFactory},Width=62});
        GroupPickerGrid.Columns.Add(GCol("شماره",nameof(GroupRow.Number),95,80,bold:true));
        GroupPickerGrid.Columns.Add(GCol("شرکت",nameof(GroupRow.CompanyName),StarW(1.6),150,trim:true));
        GroupPickerGrid.Columns.Add(GCol("تاریخ فاکتور",nameof(GroupRow.InvoiceDatePersian),105));
        var dueStyle=new Style(typeof(TextBlock));   // سررسیدِ گذشته قرمز
        dueStyle.Setters.Add(new Setter(FrameworkElement.VerticalAlignmentProperty,VerticalAlignment.Center));
        var overdue=new DataTrigger{Binding=new Binding(nameof(GroupRow.IsOverdue)),Value=true};
        overdue.Setters.Add(new Setter(TextBlock.ForegroundProperty,AppTheme.Danger600));
        dueStyle.Triggers.Add(overdue);
        GroupPickerGrid.Columns.Add(new DataGridTextColumn{Header="سررسید",Binding=new Binding(nameof(GroupRow.DueDatePersian)),IsReadOnly=true,Width=105,ElementStyle=dueStyle});
        GroupPickerGrid.Columns.Add(GCol("مبلغ (خالص)",nameof(GroupRow.Amount),StarW(1),110,"{0:N0}"));
        GroupPickerGrid.Columns.Add(GCol("پرداختی",nameof(GroupRow.Paid),StarW(1),100,"{0:N0}"));
        GroupPickerGrid.Columns.Add(GCol("مانده",nameof(GroupRow.Balance),StarW(1),110,"{0:N0}",bold:true));
        GroupPickerGrid.Columns.Add(GCol("توضیحات فاکتور",nameof(GroupRow.Note),StarW(1.6),150,trim:true));
        GroupPickerGrid.Columns.Add(GCol("گروه",nameof(GroupRow.GroupLabel),95,bold:true));
        // کلیک روی هر جای ردیف (به‌جز خود کادر) انتخاب را برعکس می‌کند؛ کلید Space هم همین کار را می‌کند.
        GroupPickerGrid.PreviewMouseLeftButtonUp+=(_,e)=>
        {
            var d=e.OriginalSource as DependencyObject;
            while (d!=null && d is not DataGridRow && d is not CheckBox && d is not System.Windows.Controls.Primitives.DataGridColumnHeader) d=ParentOf(d);
            if (d is DataGridRow row && row.Item is GroupRow gr) gr.Selected=!gr.Selected;
        };
        GroupPickerGrid.PreviewKeyDown+=(_,e)=>
        {
            if (e.Key==System.Windows.Input.Key.Space && GroupPickerGrid.SelectedItem is GroupRow gr) { gr.Selected=!gr.Selected; e.Handled=true; }
        };
        Grid.SetRow(GroupPickerGrid,1); pickLayout.Children.Add(GroupPickerGrid);
        var pickCard=GCard(pickLayout,new Thickness(0)); Grid.SetRow(pickCard,0); GroupingPanel.Children.Add(pickCard);

        // ---- نوار پایین: انتخاب فعلی + ساخت گروه + گروه‌ها ----
        var barStack=new StackPanel();
        var selRow=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft};
        SelectionSummary.FontWeight=FontWeights.SemiBold; SelectionSummary.FontSize=12.5; SelectionSummary.Foreground=AppTheme.Brand700; SelectionSummary.VerticalAlignment=VerticalAlignment.Center; SelectionSummary.Margin=new Thickness(0,0,16,0);
        var nameLabel=new TextBlock{Text="نام گروه (اختیاری):",VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,6,0),Foreground=AppTheme.Ink700,FontSize=12};
        GroupNameBox.Width=190; GroupNameBox.Height=34; GroupNameBox.Padding=new Thickness(8,5,8,5); GroupNameBox.VerticalContentAlignment=VerticalAlignment.Center; GroupNameBox.Margin=new Thickness(0,0,8,0);
        GroupNameBox.ToolTip="نام گروه (اختیاری)، مثلاً «چک‌های مهر». با Enter گروه ساخته می‌شود.";
        GroupNameBox.KeyUp+=(_,e)=>{ if(e.Key==System.Windows.Input.Key.Enter && AddGroupBtn?.IsEnabled==true) AddInvoiceGroup(null,new RoutedEventArgs()); };
        AddGroupBtn=Btn("＋ ساخت گروه",AppTheme.Success600); AddGroupBtn.Foreground=Brushes.White; AddGroupBtn.FontSize=13.5; AddGroupBtn.IsEnabled=false;
        AddGroupBtn.Click+=AddInvoiceGroup;
        var clearSelBtn=Btn("پاک‌کردن انتخاب",AppTheme.Surface100); clearSelBtn.Foreground=AppTheme.Ink700; clearSelBtn.Click+=(_,_)=>SetAllPicked(false);
        selRow.Children.Add(SelectionSummary); selRow.Children.Add(nameLabel); selRow.Children.Add(GroupNameBox); selRow.Children.Add(AddGroupBtn); selRow.Children.Add(clearSelBtn);
        barStack.Children.Add(selRow);

        var grpRow=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft,Margin=new Thickness(0,8,0,0)};
        GroupTotalsText.FontWeight=FontWeights.SemiBold; GroupTotalsText.FontSize=12; GroupTotalsText.Foreground=AppTheme.Ink700; GroupTotalsText.VerticalAlignment=VerticalAlignment.Center; GroupTotalsText.Margin=new Thickness(0,0,16,0);
        var gPrintBtn=Btn("چاپ گروه‌ها",AppTheme.Brand700); gPrintBtn.Foreground=Brushes.White; gPrintBtn.Click+=Print;
        var gExcelBtn=Btn("خروجی Excel",AppTheme.Brand600); gExcelBtn.Foreground=Brushes.White; gExcelBtn.Click+=Export;
        var removeGroupBtn=Btn("حذف گروهِ انتخاب‌شده در «نمایش»",AppTheme.Danger100); removeGroupBtn.Foreground=AppTheme.Danger600; removeGroupBtn.Click+=RemoveSelectedGroup;
        var clearGroupsBtn=Btn("پاک کردن همه‌ی گروه‌ها",AppTheme.Surface100); clearGroupsBtn.Foreground=AppTheme.Ink700;
        clearGroupsBtn.Click+=(_,_)=>{ if(Groups.Count==0) return; Groups.Clear(); RefreshGroups(0); ApplyPickerFilter(); };
        grpRow.Children.Add(GroupTotalsText); grpRow.Children.Add(gPrintBtn); grpRow.Children.Add(gExcelBtn); grpRow.Children.Add(removeGroupBtn); grpRow.Children.Add(clearGroupsBtn);
        barStack.Children.Add(grpRow);
        var barCard=GCard(barStack,new Thickness(0,10,0,0)); Grid.SetRow(barCard,1); GroupingPanel.Children.Add(barCard);

        RefreshGroups();
        UpdateSelectionSummary();
    }

    async Task LoadGroupingPicker(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — گروه‌بندی فاکتورها";
        var rows = await S.GetInvoicesAsync(CompanyId, includePayments: false);   // فقط همین‌جا به دیتابیس می‌رود؛ بقیه‌ی فیلترها در حافظه انجام می‌شوند
        if (from.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();
        rows = rows.Where(x=>AccountingService.Balance(x)>0).OrderBy(x=>x.DueDate).ThenBy(x=>x.Number).ToList();
        var gq = SearchBox.Text.Trim();
        if (gq.Length>0) rows = rows.Where(x=>Has(x.Number,gq) || Has(x.Company?.Name,gq)).ToList();
        _pickerSource = rows;
        _selIds.IntersectWith(_pickerSource.Select(x=>x.Id));
        ApplyPickerFilter();
    }

    // جدول را از روی داده‌ی بارگذاری‌شده می‌سازد (بدون دیتابیس). حالت‌های «نمایش»: همه | فقط انتخاب‌شده‌ها | یک گروه.
    // تیک‌ها با شناسه‌ی فاکتور بین حالت‌ها حفظ می‌شوند.
    void ApplyPickerFilter()
    {
        var groupOf = new Dictionary<int,int>();
        foreach (var g in Groups) foreach (var id in g.InvoiceIds) groupOf[id] = g.GroupNumber;
        var view = ViewBox.SelectedIndex;
        IEnumerable<Invoice> q = _pickerSource;
        if (view==1) q = q.Where(x=>_selIds.Contains(x.Id));
        else if (view>=2 && view-2<Groups.Count) { var ids = Groups[view-2].InvoiceIds.ToHashSet(); q = q.Where(x=>ids.Contains(x.Id)); }
        else if (HideGroupedBox.IsChecked==true) { q = q.Where(x=>!groupOf.ContainsKey(x.Id)); _selIds.ExceptWith(groupOf.Keys); }
        var shown = q.ToList();

        _pickerRows = shown.Select(x =>
        {
            var r = new GroupRow(x, groupOf.TryGetValue(x.Id, out var gn) ? $"گروه {gn}" : "");
            r.Selected = _selIds.Contains(x.Id);          // قبل از وصل‌کردن رویداد
            r.PropertyChanged += OnRowSelectionChanged;
            return r;
        }).ToList();
        GroupPickerGrid.ItemsSource = _pickerRows;         // یک بار انتساب (نه افزودن تک‌تک)

        PickerInfo.Text = $"{shown.Count:N0} فاکتور از {_pickerSource.Count:N0}";
        _summaryBase = $"شرکت: {(CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها"}   |   فاکتور مانده‌دار: {_pickerSource.Count:N0}   |   مانده‌ی آن‌ها: {_pickerSource.Sum(AccountingService.Balance):N0}   |   گروه‌های ثبت‌شده: {Groups.Count:N0}";
        UpdateSelectionSummary();
    }

    void OnRowSelectionChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName!=nameof(GroupRow.Selected) || sender is not GroupRow r) return;
        if (r.Selected) _selIds.Add(r.Invoice.Id); else _selIds.Remove(r.Invoice.Id);
        if (!_bulk) UpdateSelectionSummary();
    }

    void SetAllPicked(bool value)
    {
        _bulk = true;
        foreach (var r in _pickerRows) r.Selected = value;
        _bulk = false;
        if (!value && ViewBox.SelectedIndex==1) { ApplyPickerFilter(); return; }   // در نمای «فقط انتخاب‌شده‌ها» لیست خالی شود
        UpdateSelectionSummary();
    }

    List<Invoice> SelectedInvoices() => _pickerSource.Where(x=>_selIds.Contains(x.Id)).ToList();

    void UpdateSelectionSummary()
    {
        var sel = SelectedInvoices();
        if (AddGroupBtn!=null) AddGroupBtn.IsEnabled = sel.Count>0;
        if (sel.Count==0)
        {
            SelectionSummary.Text = "انتخاب‌شده: هیچ";
            if (_summaryBase.Length>0) Summary.Text = _summaryBase;
            return;
        }
        var sum = AccountingService.Summarize(sel);
        var avg = sum.WeightedDueDate.HasValue ? PersianDateService.ToPersian(sum.WeightedDueDate.Value) : "—";
        SelectionSummary.Text = $"انتخاب‌شده: {sel.Count:N0} فاکتور   |   جمع مبلغ: {sum.TotalAmount:N0}   |   مانده: {sum.TotalBalance:N0}   |   میانگین سررسید: {avg}";
        if (_summaryBase.Length>0) Summary.Text = $"{_summaryBase}   |   انتخاب‌شده: {sel.Count:N0} فاکتور، مانده {sum.TotalBalance:N0}";
    }

    void RefreshGroups(int? select = null)
    {
        GroupTotalsText.Text = Groups.Count==0 ? "هنوز گروهی ثبت نشده است."
            : $"{Groups.Count:N0} گروه   |   جمع کل: {Groups.Sum(g=>g.TotalAmount):N0}   |   مانده‌ی کل: {Groups.Sum(g=>g.Balance):N0}";
        var prev = ViewBox.SelectedIndex;
        _viewLock = true;
        ViewBox.Items.Clear();
        ViewBox.Items.Add("همه‌ی فاکتورها");
        ViewBox.Items.Add("فقط انتخاب‌شده‌ها");
        foreach (var g in Groups) ViewBox.Items.Add($"{g.Name} — {g.Count:N0} فاکتور — مانده {g.Balance:N0}");
        ViewBox.SelectedIndex = select ?? (prev>=0 && prev<ViewBox.Items.Count ? prev : 0);
        _viewLock = false;
    }

    static DependencyObject? ParentOf(DependencyObject d) =>
        d is System.Windows.Media.Visual || d is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);

    void AddInvoiceGroup(object? sender, RoutedEventArgs e)
    {
        var invoices = SelectedInvoices();
        if (invoices.Count == 0) { MessageBox.Show("حداقل یک فاکتور را انتخاب کنید (روی ردیف بزنید)."); return; }

        var grouped = Groups.SelectMany(g=>g.InvoiceIds).ToHashSet();
        var already = invoices.Count(x=>grouped.Contains(x.Id));
        if (already>0 && MessageBox.Show($"{already:N0} فاکتور از انتخاب‌شده‌ها قبلاً در یک گروه دیگر هستند. باز هم در این گروه هم بیایند؟","گروه‌بندی",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes) return;

        var sum = AccountingService.Summarize(invoices);
        var companies = invoices.Where(x=>x.Company!=null).Select(x=>x.Company!).GroupBy(c=>c.Id).Select(g=>g.First()).ToList();
        var number = Groups.Count + 1;
        var group = new InvoiceGroupResult
        {
            GroupNumber = number,
            Name = string.IsNullOrWhiteSpace(GroupNameBox.Text) ? $"گروه {number}" : GroupNameBox.Text.Trim(),
            InvoiceNumbers = string.Join("، ", invoices.Select(x=>x.Number)),
            CompanyNames = companies.Count>0 ? string.Join("، ", companies.Select(c=>c.Name)) : "-",
            NationalIds = companies.Count>0 ? string.Join("، ", companies.Select(c=>string.IsNullOrWhiteSpace(c.NationalId) ? "—" : c.NationalId!.Trim())) : "—",
            CompanyNotes = CompanyNotesText(companies),
            Count = invoices.Count,
            TotalAmount = sum.TotalAmount,
            Balance = sum.TotalBalance,
            AvgDueDate = sum.WeightedDueDate.HasValue ? PersianDateService.ToPersian(sum.WeightedDueDate.Value) : "—",
            InvoiceIds = invoices.Select(x=>x.Id).ToList(),
            Lines = invoices.Select(x=>new GroupInvoiceLine(
                x.Number, x.Company?.Name ?? "-",
                string.IsNullOrWhiteSpace(x.Company?.NationalId) ? "—" : x.Company!.NationalId!.Trim(),
                PersianDateService.ToPersian(x.DueDate), AccountingService.Balance(x))).ToList()
        };
        Groups.Add(group);
        GroupNameBox.Clear();
        _selIds.Clear();
        RefreshGroups(Groups.Count + 1);   // فهرست «نمایش» روی گروه تازه می‌رود
        ApplyPickerFilter();               // همان فاکتورها با همه‌ی ستون‌ها در جدول اصلی دیده می‌شوند
    }

    // توضیحات شرکت‌های گروه؛ اگر چند شرکت باشد، نام شرکت هم کنار توضیحش می‌آید.
    static string CompanyNotesText(List<Company> companies)
    {
        var withNote = companies.Where(c=>!string.IsNullOrWhiteSpace(c.Note)).ToList();
        if (withNote.Count==0) return "—";
        string Clean(string t)=>t.Replace("\r"," ").Replace("\n"," ").Trim();
        return companies.Count>1
            ? string.Join(" | ", withNote.Select(c=>$"{c.Name}: {Clean(c.Note!)}"))
            : Clean(withNote[0].Note!);
    }

    void RemoveSelectedGroup(object? sender, RoutedEventArgs e)
    {
        var idx = ViewBox.SelectedIndex - 2;
        if (idx < 0 || idx >= Groups.Count) { MessageBox.Show("از فهرست «نمایش» بالای جدول، گروهی را که می‌خواهید حذف کنید انتخاب کنید."); return; }
        Groups.RemoveAt(idx);
        for (int i=0;i<Groups.Count;i++) { Groups[i].GroupNumber = i+1; if (Groups[i].Name.StartsWith("گروه ")) Groups[i].Name = $"گروه {i+1}"; }
        RefreshGroups(0);
        ApplyPickerFilter();
    }

    // چک‌های صادرشده (همه‌ی وضعیت‌ها یا یک وضعیت مشخص). فیلتر تاریخ همیشه روی «سررسید چک» است.
    // چک بدون تاریخ سررسید فقط وقتی فیلتر تاریخی نباشد نمایش داده می‌شود و در غیر این صورت در خلاصه گزارش می‌شود.
    async Task LoadChecks(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — چک‌های در جریان";
        var companyName = (CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها";
        var payments = await S.GetPaymentsAsync(CompanyId);
        // یک چک برای چند فاکتور = چند رکورد وصول با همان شماره/تاریخ چک؛ اینجا فقط «یک» ردیف نشان داده می‌شود.
        var all = CheckGrouping.Group(payments.Where(p=>p.PaymentMethod=="چک"));

        var hasRange = from.HasValue || to.HasValue;
        var undated = all.Count(g=>!g.CheckDate.HasValue);
        var checks = all.Where(g=>!hasRange || g.CheckDate.HasValue).ToList();
        if (from.HasValue) checks = checks.Where(g=>g.CheckDate!.Value.Date>=from.Value).ToList();
        if (to.HasValue) checks = checks.Where(g=>g.CheckDate!.Value.Date<=to.Value).ToList();

        var statusFilter = StatusBox.SelectedItem as string;
        if (!string.IsNullOrEmpty(statusFilter) && statusFilter!=AllStatuses) checks = checks.Where(g=>g.Status==statusFilter).ToList();

        var q = SearchBox.Text.Trim();
        if (q.Length>0) checks = checks.Where(g=>Has(g.CheckNumber,q) || Has(g.CompanyName,q) || g.Payments.Any(p=>Has(p.Invoice?.Number,q))).ToList();
        _checkList = checks;

        string Part(string status)
        {
            var part = checks.Where(g=>g.Status==status).ToList();
            return $"{status}: {part.Count:N0} ({part.Sum(g=>g.Amount):N0})";
        }
        var rangeText = hasRange
            ? $"سررسید از {(from.HasValue?PersianDateService.ToPersian(from.Value):"…")} تا {(to.HasValue?PersianDateService.ToPersian(to.Value):"…")}"
            : "همه‌ی سررسیدها";
        Summary.Text = $"شرکت: {companyName}   |   {rangeText}   |   تعداد چک: {checks.Count:N0}   |   جمع: {checks.Sum(g=>g.Amount):N0} ریال   |   {Part(PaymentRules.DefaultCheckStatus)}   |   {Part(PaymentRules.CheckStatuses[2])}   |   {Part(PaymentRules.CheckStatuses[1])}"
            + (hasRange && undated>0 ? $"   |   ({undated:N0} چک بدون تاریخ سررسید در این فیلتر نیامد)" : "");

        G.Columns.Add(new DataGridTextColumn{Header="سررسید چک",Binding=new Binding("CheckDate"),Width=105});
        G.Columns.Add(new DataGridTextColumn{Header="تا سررسید",Binding=new Binding("DueInfo"),Width=105});
        G.Columns.Add(new DataGridTextColumn{Header="شماره چک",Binding=new Binding("CheckNumber"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="فاکتورها (جهت)",Binding=new Binding("InvoiceNumber"),Width=new DataGridLength(1.8,DataGridLengthUnitType.Star),MinWidth=150});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("CompanyName"),Width=new DataGridLength(1.3,DataGridLengthUnitType.Star),MinWidth=130});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ چک",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="وضعیت",Binding=new Binding("CheckStatus"),Width=110});
        var today = DateTime.Today;
        G.ItemsSource = checks.Select(g => new CheckRow(
            g.CheckDate.HasValue?PersianDateService.ToPersian(g.CheckDate.Value):"—", g.CheckNumber ?? "—",
            g.InvoiceText, g.CompanyName, g.Amount, g.Status.Length>0?g.Status:"—", DueInfo(g.Status, g.CheckDate, today)
        )).ToList();
    }

    // «۳ روز دیگر / امروز / ۲ روز گذشته» فقط برای چک‌های در انتظار وصول.
    static string DueInfo(string status, DateTime? checkDate, DateTime today)
    {
        if (status != PaymentRules.DefaultCheckStatus || !checkDate.HasValue) return "—";
        var d = (checkDate.Value.Date - today.Date).Days;
        return d>0 ? $"{d:N0} روز دیگر" : d==0 ? "امروز" : $"{-d:N0} روز گذشته";
    }

    async Task LoadCombined(DateTime? from, DateTime? to)
    {
        var companyName = (CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها";
        TitleText.Text = $"گزارش جامع — {companyName}";

        var invoices = await S.GetInvoicesAsync(CompanyId, includePayments: false);
        if (from.HasValue) invoices = invoices.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) invoices = invoices.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();
        invoices = invoices.OrderByDescending(x=>x.InvoiceDate).ToList();

        var allPayments = await S.GetPaymentsAsync(CompanyId);
        // وصول‌ها بر اساس «تاریخ وصول» فیلتر می‌شوند، ولی چک‌ها بر اساس «سررسید چک».
        var payments = allPayments.ToList();
        if (from.HasValue) payments = payments.Where(p=>p.PayDate.Date>=from.Value).ToList();
        if (to.HasValue) payments = payments.Where(p=>p.PayDate.Date<=to.Value).ToList();
        payments = payments.OrderByDescending(p=>p.PayDate).ToList();

        var hasRange = from.HasValue || to.HasValue;
        // یک چک برای چند فاکتور فقط یک بار می‌آید (فاکتورهایش در ستون «فاکتورها» نوشته می‌شود).
        var checks = CheckGrouping.Group(allPayments.Where(p=>p.PaymentMethod=="چک")).Where(g=>!hasRange || g.CheckDate.HasValue).ToList();
        if (from.HasValue) checks = checks.Where(g=>g.CheckDate!.Value.Date>=from.Value).ToList();
        if (to.HasValue) checks = checks.Where(g=>g.CheckDate!.Value.Date<=to.Value).ToList();
        _cInv = invoices; _cPay = payments; _cChk = checks;

        var sum = AccountingService.Summarize(invoices);
        Summary.Text = $"شرکت: {companyName}   |   فاکتور: {invoices.Count:N0} ({sum.TotalAmount:N0} ریال)   |   پرداخت: {payments.Count:N0} ({payments.Sum(p=>p.Amount):N0} ریال)   |   چک: {checks.Count:N0} ({checks.Sum(p=>p.Amount):N0} ریال)   |   مانده‌ی کل: {sum.TotalBalance:N0}";

        CInvoicesHeader.Text = $"{invoices.Count:N0} فاکتور   |   جمع {invoices.Sum(x=>x.Amount):N0} ریال   |   مرجوعی {invoices.Sum(x=>x.ReturnedAmount):N0}   |   مانده {invoices.Sum(AccountingService.Balance):N0} ریال";
        CInvoices.ItemsSource = invoices.Select(x => new
        {
            x.Number, x.Company,
            InvoiceDate = PersianDateService.ToPersian(x.InvoiceDate),
            Due = PersianDateService.ToPersian(x.DueDate),
            x.Amount, Returned = x.ReturnedAmount, x.Paid, Balance = AccountingService.Balance(x),
            Status = StatusOf(x)
        }).ToList();

        CPaymentsHeader.Text = $"{payments.Count:N0} پرداخت   |   جمع {payments.Sum(p=>p.Amount):N0} ریال";
        CPayments.ItemsSource = payments.Select(p => new PayRow(
            p.Id, PersianDateService.ToPersian(p.PayDate), p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-",
            p.Amount, p.PaymentMethod, p.CheckNumber ?? "—", p.CheckStatus ?? "—", string.IsNullOrWhiteSpace(p.Note)?"—":p.Note
        )).ToList();

        CChecksHeader.Text = $"{checks.Count:N0} چک   |   جمع {checks.Sum(p=>p.Amount):N0} ریال   |   برگشتی: {checks.Count(g=>g.Status=="برگشتی"):N0}";
        CChecks.ItemsSource = checks.Select(g => new CheckRow(
            g.CheckDate.HasValue?PersianDateService.ToPersian(g.CheckDate.Value):"—", g.CheckNumber ?? "—",
            g.InvoiceText, g.CompanyName, g.Amount, g.Status.Length>0?g.Status:"—"
        )).ToList();
    }

    // ---------- پرداخت فاکتورها ----------
    void BuildPayReportPanel()
    {
        PayPanel.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star),MinHeight=160});
        PayPanel.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1.4,GridUnitType.Star),MinHeight=190});
        PayPanel.Visibility=Visibility.Collapsed;

        // ---- بالا: فاکتورها با کادر انتخاب ----
        var topLayout=new Grid();
        topLayout.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        topLayout.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});
        var head=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft,Margin=new Thickness(0,0,0,6)};
        var title=GTitle("فاکتورها — روی هر ردیف بزنید تا انتخاب شود"); title.Margin=new Thickness(0,0,14,0);
        PayPickerInfo.VerticalAlignment=VerticalAlignment.Center; PayPickerInfo.Foreground=AppTheme.Ink500; PayPickerInfo.FontSize=12; PayPickerInfo.Margin=new Thickness(0,0,12,0);
        var allBtn=Btn("انتخاب همه‌ی فاکتورها",AppTheme.Surface100); allBtn.Foreground=AppTheme.Ink700; allBtn.Click+=(_,_)=>SetAllPayPicked(true);
        var noneBtn=Btn("هیچ‌کدام",AppTheme.Surface100); noneBtn.Foreground=AppTheme.Ink700; noneBtn.Click+=(_,_)=>SetAllPayPicked(false);
        head.Children.Add(title); head.Children.Add(PayPickerInfo); head.Children.Add(allBtn); head.Children.Add(noneBtn);
        Grid.SetRow(head,0); topLayout.Children.Add(head);

        ConfigGrid(PayPickerGrid);
                var baseRow=Application.Current?.TryFindResource(typeof(DataGridRow)) as Style;
        var rowStyle=new Style(typeof(DataGridRow),baseRow);
        var plainSel=new Trigger{Property=DataGridRow.IsSelectedProperty,Value=true}; plainSel.Setters.Add(new Setter(Control.BackgroundProperty,Brushes.Transparent));
        var tickTrig=new DataTrigger{Binding=new Binding(nameof(GroupRow.Selected)),Value=true};
        tickTrig.Setters.Add(new Setter(Control.BackgroundProperty,AppTheme.Success100)); tickTrig.Setters.Add(new Setter(Control.FontWeightProperty,FontWeights.SemiBold));
        rowStyle.Triggers.Add(plainSel); rowStyle.Triggers.Add(tickTrig);
        PayPickerGrid.RowStyle=rowStyle;

        var cbFactory=new FrameworkElementFactory(typeof(CheckBox));
        cbFactory.SetBinding(CheckBox.IsCheckedProperty,new Binding(nameof(GroupRow.Selected)){Mode=BindingMode.TwoWay,UpdateSourceTrigger=UpdateSourceTrigger.PropertyChanged});
        cbFactory.SetValue(FrameworkElement.HorizontalAlignmentProperty,HorizontalAlignment.Center);
        cbFactory.SetValue(FrameworkElement.VerticalAlignmentProperty,VerticalAlignment.Center);
        cbFactory.SetValue(FrameworkElement.LayoutTransformProperty,new ScaleTransform(1.2,1.2));
        PayPickerGrid.Columns.Add(new DataGridTemplateColumn{Header="انتخاب",CellTemplate=new DataTemplate{VisualTree=cbFactory},Width=62});
        PayPickerGrid.Columns.Add(GCol("شماره",nameof(GroupRow.Number),95,80,bold:true));
        PayPickerGrid.Columns.Add(GCol("شرکت",nameof(GroupRow.CompanyName),StarW(1.5),140,trim:true));
        PayPickerGrid.Columns.Add(GCol("تاریخ فاکتور",nameof(GroupRow.InvoiceDatePersian),105));
        PayPickerGrid.Columns.Add(GCol("مبلغ (خالص)",nameof(GroupRow.Amount),StarW(1),110,"{0:N0}"));
        PayPickerGrid.Columns.Add(GCol("پرداختی",nameof(GroupRow.Paid),StarW(1),100,"{0:N0}"));
        PayPickerGrid.Columns.Add(GCol("مانده",nameof(GroupRow.Balance),StarW(1),110,"{0:N0}",bold:true));
        PayPickerGrid.PreviewMouseLeftButtonUp+=(_,e)=>
        {
            var d=e.OriginalSource as DependencyObject;
            while (d!=null && d is not DataGridRow && d is not CheckBox && d is not System.Windows.Controls.Primitives.DataGridColumnHeader) d=ParentOf(d);
            if (d is DataGridRow row && row.Item is GroupRow gr) gr.Selected=!gr.Selected;
        };
        PayPickerGrid.PreviewKeyDown+=(_,e)=>
        {
            if (e.Key==System.Windows.Input.Key.Space && PayPickerGrid.SelectedItem is GroupRow gr) { gr.Selected=!gr.Selected; e.Handled=true; }
        };
        Grid.SetRow(PayPickerGrid,1); topLayout.Children.Add(PayPickerGrid);
        var topCard=GCard(topLayout,new Thickness(0)); Grid.SetRow(topCard,0); PayPanel.Children.Add(topCard);

        // ---- پایین: پرداخت‌های فاکتورهای انتخاب‌شده ----
        var botLayout=new Grid();
        botLayout.RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});
        botLayout.RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});
        var botHead=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft,Margin=new Thickness(0,0,0,6)};
        var botTitle=GTitle("روش و اطلاعات پرداخت فاکتورهای انتخاب‌شده"); botTitle.Margin=new Thickness(0,0,14,0);
        PayDetailInfo.VerticalAlignment=VerticalAlignment.Center; PayDetailInfo.Foreground=AppTheme.Brand700; PayDetailInfo.FontWeight=FontWeights.SemiBold; PayDetailInfo.FontSize=12; PayDetailInfo.Margin=new Thickness(0,0,14,0);
        var payPrintBtn=Btn("چاپ",AppTheme.Brand700); payPrintBtn.Foreground=Brushes.White; payPrintBtn.Click+=Print;
        var payExcelBtn=Btn("خروجی Excel",AppTheme.Brand600); payExcelBtn.Foreground=Brushes.White; payExcelBtn.Click+=Export;
        botHead.Children.Add(botTitle); botHead.Children.Add(PayDetailInfo); botHead.Children.Add(payPrintBtn); botHead.Children.Add(payExcelBtn);
        Grid.SetRow(botHead,0); botLayout.Children.Add(botHead);

        ConfigGrid(PayDetailGrid);
        PayDetailGrid.IsReadOnly=true;
        PayDetailGrid.Columns.Add(GCol("فاکتور",nameof(PayDetailRow.InvoiceNumber),StarW(1.3),110,bold:true,trim:true));
        PayDetailGrid.Columns.Add(GCol("روش پرداخت",nameof(PayDetailRow.Method),StarW(1),110,bold:true));
        PayDetailGrid.Columns.Add(GCol("شماره چک",nameof(PayDetailRow.CheckNumber),StarW(1),100));
        PayDetailGrid.Columns.Add(GCol("سررسید چک",nameof(PayDetailRow.CheckDate),StarW(1),105));
        PayDetailGrid.Columns.Add(GCol("مبلغ",nameof(PayDetailRow.Amount),StarW(1),110,"{0:N0}"));
        PayDetailGrid.Columns.Add(GCol("تاریخ پرداخت",nameof(PayDetailRow.PayDate),StarW(1),105));
        Grid.SetRow(PayDetailGrid,1); botLayout.Children.Add(PayDetailGrid);
        var botCard=GCard(botLayout,new Thickness(0,10,0,0)); Grid.SetRow(botCard,1); PayPanel.Children.Add(botCard);

        UpdatePayDetails();
    }

    async Task LoadPaymentsReport(DateTime? from, DateTime? to)
    {
        var companyName = (CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها";
        TitleText.Text = $"گزارش‌ها — پرداخت فاکتورها ({companyName})";
        var rows = await S.GetInvoicesAsync(CompanyId, includePayments: false);   // فقط همین‌جا به دیتابیس می‌رود؛ تیک زدن‌ها در حافظه انجام می‌شود
        if (from.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();
        var q = SearchBox.Text.Trim();
        if (q.Length>0) rows = rows.Where(x=>Has(x.Number,q) || Has(x.Company?.Name,q) || Has(x.Note,q)).ToList();
        rows = rows.OrderBy(x=>x.InvoiceDate).ThenBy(x=>x.Number).ToList();
        var pays = await S.GetPaymentsAsync(CompanyId);
        _payByInvoice = pays.GroupBy(p=>p.InvoiceId).ToDictionary(g=>g.Key, g=>g.OrderBy(p=>p.PayDate).ThenBy(p=>p.Id).ToList());
        _paySource = rows;
        _paySel.IntersectWith(_paySource.Select(x=>x.Id));
        _payBase = $"شرکت: {companyName}   |   فاکتور: {_paySource.Count:N0}   |   جمع خالص: {_paySource.Sum(x=>x.NetAmount):N0}   |   پرداختی: {_paySource.Sum(x=>x.Paid):N0}   |   مانده: {_paySource.Sum(AccountingService.Balance):N0}";
        _payRows = _paySource.Select(x =>
        {
            var r = new GroupRow(x);
            r.Selected = _paySel.Contains(x.Id);          // قبل از وصل‌کردن رویداد
            r.PropertyChanged += OnPayRowSelectionChanged;
            return r;
        }).ToList();
        PayPickerGrid.ItemsSource = _payRows;             // یک بار انتساب
        PayPickerInfo.Text = $"{_paySource.Count:N0} فاکتور";
        UpdatePayDetails();
    }

    void OnPayRowSelectionChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName!=nameof(GroupRow.Selected) || sender is not GroupRow r) return;
        if (r.Selected) _paySel.Add(r.Invoice.Id); else _paySel.Remove(r.Invoice.Id);
        if (!_payBulk) UpdatePayDetails();
    }

    void SetAllPayPicked(bool value)
    {
        _payBulk = true;
        foreach (var r in _payRows) r.Selected = value;
        _payBulk = false;
        UpdatePayDetails();
    }

    const string PayUnpaidText = "پرداخت نشده";

    // جدول پایین: برای هر فاکتورِ تیک‌خورده یک ردیف به ازای هر پرداخت (روش، شماره چک، سررسید چک)؛
    // فاکتوری که هنوز چیزی پرداخت نشده یک ردیف «پرداخت نشده» دارد.
    List<PayDetailRow> BuildPayDetailRows(List<Invoice> sel)
    {
        var withCompany = CompanyId == null;
        var list = new List<PayDetailRow>();
        foreach (var inv in sel)
        {
            var label = withCompany && inv.Company != null ? $"{inv.Number} ({inv.Company.Name})" : inv.Number;
            if (_payByInvoice.TryGetValue(inv.Id, out var pays) && pays.Count > 0)
            {
                foreach (var p in pays)
                    list.Add(new PayDetailRow(label, PersianDateService.ToPersian(p.PayDate), p.Amount, p.PaymentMethod,
                        string.IsNullOrWhiteSpace(p.CheckNumber) ? "—" : p.CheckNumber,
                        p.CheckDate.HasValue ? PersianDateService.ToPersian(p.CheckDate.Value) : "—"));
            }
            else list.Add(new PayDetailRow(label, "—", 0, PayUnpaidText, "—", "—"));
        }
        return list;
    }

    void UpdatePayDetails()
    {
        var sel = _paySource.Where(x=>_paySel.Contains(x.Id)).ToList();
        _payShownInv = sel;
        _payShownRows = BuildPayDetailRows(sel);
        PayDetailGrid.ItemsSource = _payShownRows;

        if (sel.Count==0)
        {
            PayDetailInfo.Text = "فاکتورهای بالا را تیک بزنید تا روش و اطلاعات پرداختشان این‌جا بیاید.";
            if (_payBase.Length>0) Summary.Text = _payBase;
            return;
        }
        var paid = sel.Sum(x=>x.Paid); var bal = sel.Sum(AccountingService.Balance);
        PayDetailInfo.Text = $"{sel.Count:N0} فاکتور   |   پرداختی: {paid:N0}   |   مانده: {bal:N0}";
        if (_payBase.Length>0) Summary.Text = $"{_payBase}   |   انتخاب‌شده: {sel.Count:N0} فاکتور، پرداختی {paid:N0}، مانده {bal:N0}";
    }

    static string[] PayDetailHeaders => new[]{"فاکتور","روش پرداخت","شماره چک","سررسید چک","مبلغ","تاریخ پرداخت"};

    List<string[]> PayDetailRows() => _payShownRows.Select(r=>new[]{r.InvoiceNumber,r.Method,r.CheckNumber,r.CheckDate,r.Method==PayUnpaidText?"—":r.Amount.ToString("N0"),r.PayDate}).ToList();

    string PayFooterText() => $"{_payShownInv.Count:N0} فاکتور   |   جمع پرداختی: {_payShownInv.Sum(x=>x.Paid):N0}   |   مانده: {_payShownInv.Sum(AccountingService.Balance):N0} ریال";

    void AddPaySheets(XLWorkbook wb)
    {
        var ws = wb.Worksheets.Add(SafeSheetName("پرداخت فاکتورها"));
        var headers = PayDetailHeaders; var rows = PayDetailRows();
        for (int c=0;c<headers.Length;c++) ws.Cell(1,c+1).Value = headers[c];
        for (int r=0;r<rows.Count;r++)
            for (int c=0;c<headers.Length;c++)
            {
                var cell = ws.Cell(r+2,c+1);
                if (c==4 && decimal.TryParse(rows[r][c], NumberStyles.Number, CultureInfo.CurrentCulture, out var num)) cell.Value = num;
                else cell.Value = rows[r][c];
            }
        ws.RightToLeft = true;
        ws.Row(1).Style.Font.Bold = true;
        ws.Row(1).Style.Fill.BackgroundColor = XLColor.LightBlue;
        ws.SheetView.FreezeRows(1);
        if (rows.Count > 0) ws.Columns().AdjustToContents();
    }

    void G_LoadingRow(object? sender, DataGridRowEventArgs e)
    {
        if (_tab != ReportTab.Checks || e.Row.Item is not CheckRow cr) { e.Row.Background = Brushes.White; return; }
        e.Row.Background = cr.CheckStatus switch
        {
            "برگشتی" => AppTheme.Danger100,
            "در انتظار وصول" => AppTheme.Warning100,
            _ => Brushes.White
        };
    }

    void Export(object? sender,RoutedEventArgs e)
    {
        if (_tab == ReportTab.Statement && (_stmt is null || _stmtCompany is null)) { MessageBox.Show("ابتدا یک شرکت را از فیلتر «شرکت» انتخاب کنید و گزارش را نمایش دهید.", "خروجی", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        if (_tab == ReportTab.Grouping && Groups.Count == 0) { MessageBox.Show("هنوز گروهی ثبت نشده است. ابتدا چند فاکتور را تیک بزنید و «افزودن گروه» را بزنید.", "خروجی", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        if (_tab == ReportTab.Payments && _payShownInv.Count == 0) { MessageBox.Show("ابتدا چند فاکتور را تیک بزنید تا پرداخت‌هایشان در خروجی بیاید.", "خروجی", MessageBoxButton.OK, MessageBoxImage.Information); return; }
        var d=new SaveFileDialog{Filter="Excel Workbook|*.xlsx",FileName=$"گزارش-{DateTime.Now:yyyyMMdd-HHmm}.xlsx"};
        if(d.ShowDialog()!=true)return;
        try
        {
            using var wb = new XLWorkbook();
            if (_tab == ReportTab.Combined)
            {
                AddSheetFromGrid(wb, CInvoices, "فاکتورهای خریداری‌شده");
                AddSheetFromGrid(wb, CPayments, "پرداخت‌ها");
                AddSheetFromGrid(wb, CChecks, "چک‌های داده‌شده");
            }
            else if (_tab == ReportTab.Statement)
            {
                AddStatementSheet(wb);
            }
            else if (_tab == ReportTab.Grouping)
            {
                AddGroupSheet(wb);
            }
            else if (_tab == ReportTab.Payments)
            {
                AddPaySheets(wb);
            }
            else
            {
                AddSheetFromGrid(wb, G, "چک‌های در جریان");
            }
            wb.SaveAs(d.FileName);
            MessageBox.Show("خروجی Excel دقیقاً مطابق اطلاعات همین گزارش ذخیره شد.","خروجی Excel",MessageBoxButton.OK,MessageBoxImage.Information);
        }
        catch(Exception ex){MessageBox.Show(ex.Message,"خروجی",MessageBoxButton.OK,MessageBoxImage.Error);}
    }

    // ---------- چاپ (هر سه گزارش) ----------
    async void Print(object? sender, RoutedEventArgs e)
    {
        try
        {
            var ps = new PrintService();
            var today = DateTime.Today;
            switch (_tab)
            {
                case ReportTab.Checks:
                    await ps.PrintReportAsync("گزارش چک‌های در جریان", Summary.Text, new[]{ CheckTable("", _checkList, today) });
                    break;
                case ReportTab.Statement:
                {
                    if (_stmt is null || _stmtCompany is null) { MessageBox.Show("ابتدا یک شرکت را از فیلتر «شرکت» انتخاب کنید و گزارش را نمایش دهید.", "چاپ", MessageBoxButton.OK, MessageBoxImage.Information); return; }
                    var stRows = new List<string[]>();
                    if (_stmtFrom.HasValue) stRows.Add(new[]{"","مانده‌ی از قبل","","","",_stmt.Opening.ToString("N0")});
                    stRows.AddRange(_stmt.Lines.Select(l => new[]{PersianDateService.ToPersian(l.Date), l.Description, l.Reference, l.Debit==0?"—":l.Debit.ToString("N0"), l.Credit==0?"—":l.Credit.ToString("N0"), l.Balance.ToString("N0")}));
                    var stTable = new PrintTable("", new[]{"تاریخ","شرح","مرجع","بدهکار","بستانکار","مانده"}, stRows,
                        $"جمع بدهکار: {_stmt.TotalDebit:N0}   |   جمع بستانکار: {_stmt.TotalCredit:N0}   |   مانده‌ی نهایی: {_stmt.Closing:N0} ریال",
                        new[]{1,2.4,2,1.1,1.1,1.2});
                    var stSub = $"شناسه ملی: {(string.IsNullOrWhiteSpace(_stmtCompany.NationalId) ? "—" : _stmtCompany.NationalId)}   |   بازه: {_stmtPeriod}   |   بدهکار = فاکتور، بستانکار = وصول و مرجوعی";
                    await ps.PrintReportAsync($"صورت‌حساب شرکت {_stmtCompany.Name}", stSub, new[]{ stTable });
                    break;
                }
                case ReportTab.Combined:
                {
                    var company = (CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها";
                    var invTable = new PrintTable("فاکتورها",
                        new[]{"شماره","شرکت","تاریخ فاکتور","سررسید","مبلغ","مرجوعی","پرداختی","مانده","وضعیت"},
                        _cInv.Select(x=>new[]{x.Number,x.Company?.Name ?? "-",PersianDateService.ToPersian(x.InvoiceDate),PersianDateService.ToPersian(x.DueDate),x.Amount.ToString("N0"),x.ReturnedAmount.ToString("N0"),x.Paid.ToString("N0"),AccountingService.Balance(x).ToString("N0"),StatusOf(x)}).ToList(),
                        $"جمع: {_cInv.Sum(x=>x.Amount):N0}   |   مرجوعی: {_cInv.Sum(x=>x.ReturnedAmount):N0}   |   پرداختی: {_cInv.Sum(x=>x.Paid):N0}   |   مانده: {_cInv.Sum(AccountingService.Balance):N0} ریال");
                    var payTable = new PrintTable("وصول‌ها",
                        new[]{"تاریخ وصول","فاکتور","مبلغ","روش","شماره چک","وضعیت چک"},
                        _cPay.Select(p=>new[]{PersianDateService.ToPersian(p.PayDate),p.Invoice?.Number ?? "-",p.Amount.ToString("N0"),p.PaymentMethod,p.CheckNumber ?? "—",p.CheckStatus ?? "—"}).ToList(),
                        $"جمع وصول‌ها: {_cPay.Sum(p=>p.Amount):N0} ریال");
                    await ps.PrintReportAsync($"گزارش جامع — {company}", Summary.Text, new[]{ invTable, payTable, CheckTable("چک‌ها (بر اساس سررسید چک)", _cChk, today) });
                    break;
                }
                case ReportTab.Payments:
                {
                    if (_payShownInv.Count==0) { MessageBox.Show("ابتدا چند فاکتور را تیک بزنید تا پرداخت‌هایشان چاپ شود.", "چاپ", MessageBoxButton.OK, MessageBoxImage.Information); return; }
                    var payCompany = (CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها";
                    var payTable = new PrintTable("روش و اطلاعات پرداخت فاکتورها", PayDetailHeaders, PayDetailRows(), PayFooterText(), new[]{1.6,1.1,1.1,1.2,1.2,1.2});
                    await ps.PrintReportAsync($"پرداخت فاکتورها — {payCompany}", $"{_payShownInv.Count:N0} فاکتور   |   تاریخ تهیه: {PersianDateService.ToPersian(DateTime.Now)}", new[]{ payTable });
                    break;
                }
                default:
                {
                    if (Groups.Count==0) { MessageBox.Show("هنوز گروهی ثبت نشده است. ابتدا چند فاکتور را انتخاب کنید و «افزودن گروه» را بزنید.","چاپ",MessageBoxButton.OK,MessageBoxImage.Information); return; }
                    var table = new PrintTable("",
                        new[]{"#","شماره فاکتورها","شرکت","شناسه ملی","تعداد","توضیحات شرکت","مانده","میانگین سررسید"},
                        Groups.Select(g=>new[]{g.GroupNumber.ToString(),g.InvoiceNumbers,g.CompanyNames,g.NationalIds,g.Count.ToString("N0"),g.CompanyNotes,g.Balance.ToString("N0"),g.AvgDueDate}).ToList(),
                        GroupTotalsText.Text,
                        new[]{0.4,2.2,1.4,1.2,0.6,1.8,1.1,1.1});
                    await ps.PrintReportAsync("", "", new[]{ table });
                    break;
                }
            }
        }
        catch (Exception ex) { MessageBox.Show(ex.Message,"چاپ",MessageBoxButton.OK,MessageBoxImage.Warning); }
    }

    static PrintTable CheckTable(string heading, IReadOnlyList<CheckGroup> checks, DateTime today) => new(heading,
        new[]{"سررسید چک","تا سررسید","شماره چک","فاکتورها","شرکت","مبلغ چک","وضعیت"},
        checks.Select(g=>new[]{g.CheckDate.HasValue?PersianDateService.ToPersian(g.CheckDate.Value):"—",DueInfo(g.Status,g.CheckDate,today),g.CheckNumber ?? "—",g.InvoiceText,g.CompanyName,g.Amount.ToString("N0"),g.Status.Length>0?g.Status:"—"}).ToList(),
        $"تعداد: {checks.Count:N0}   |   جمع مبلغ: {checks.Sum(g=>g.Amount):N0} ریال",
        new[]{1,1,1,2.2,1.5,1.2,1});

    // خروجی Excel دقیقاً همان ستون‌ها و ردیف‌هایی را می‌نویسد که همین لحظه در جدول دیده می‌شود -
    // نه یک خروجی ثابت و جدا از فیلترها/تبی که کاربر واقعاً باز کرده.
    // خروجی Excel صورت‌حساب: سرتیتر شرکت (با شناسه ملی)، «مانده‌ی از قبل»، ردیف‌ها و جمع‌ها.
    void AddStatementSheet(XLWorkbook wb)
    {
        var st = _stmt!; var c = _stmtCompany;
        var ws = wb.Worksheets.Add(SafeSheetName("صورت‌حساب"));
        ws.RightToLeft = true;
        ws.Cell(1,1).Value = "صورت‌حساب شرکت " + (c?.Name ?? "");
        ws.Cell(1,1).Style.Font.Bold = true; ws.Cell(1,1).Style.Font.FontSize = 14;
        ws.Cell(2,1).Value = "شناسه ملی";
        var idCell = ws.Cell(2,2); idCell.Style.NumberFormat.Format = "@"; idCell.SetValue(c?.NationalId ?? "");
        ws.Cell(3,1).Value = "بازه"; ws.Cell(3,2).Value = _stmtPeriod;
        ws.Cell(4,1).Value = "تاریخ تهیه"; ws.Cell(4,2).Value = PersianDateService.ToPersian(DateTime.Now);
        var headers = new[]{"تاریخ","شرح","مرجع (فاکتور/چک)","بدهکار","بستانکار","مانده"};
        const int hr = 6;
        for (int i=0;i<headers.Length;i++) ws.Cell(hr,i+1).Value = headers[i];
        var hdr = ws.Range(hr,1,hr,headers.Length); hdr.Style.Font.Bold = true; hdr.Style.Fill.BackgroundColor = XLColor.LightBlue;
        var r = hr + 1;
        if (_stmtFrom.HasValue) { ws.Cell(r,2).Value = "مانده‌ی از قبل"; ws.Cell(r,6).Value = st.Opening; r++; }
        foreach (var l in st.Lines)
        {
            ws.Cell(r,1).Value = PersianDateService.ToPersian(l.Date);
            ws.Cell(r,2).Value = l.Description;
            ws.Cell(r,3).Value = l.Reference;
            if (l.Debit != 0) ws.Cell(r,4).Value = l.Debit;
            if (l.Credit != 0) ws.Cell(r,5).Value = l.Credit;
            ws.Cell(r,6).Value = l.Balance;
            r++;
        }
        ws.Cell(r,2).Value = "جمع / مانده‌ی نهایی";
        ws.Cell(r,4).Value = st.TotalDebit; ws.Cell(r,5).Value = st.TotalCredit; ws.Cell(r,6).Value = st.Closing;
        ws.Range(r,1,r,headers.Length).Style.Font.Bold = true;
        for (int col=4; col<=6; col++) ws.Column(col).Style.NumberFormat.Format = "#,##0";
        ws.SheetView.FreezeRows(hr);
        ws.Columns().AdjustToContents();
    }

    // خروجی Excel گروه‌بندی: بدون نام گروه، با شناسه ملی شرکت‌ها (به‌صورت متن تا صفر ابتدایی حذف نشود).
    void AddGroupSheet(XLWorkbook wb)
    {
        var ws = wb.Worksheets.Add(SafeSheetName("گروه‌بندی فاکتورها"));
        var headers = new[]{"#","شماره فاکتورها","شرکت","شناسه ملی","تعداد","جمع کل","مانده","میانگین سررسید"};
        for (int c=0;c<headers.Length;c++) ws.Cell(1,c+1).Value = headers[c];
        for (int r=0;r<Groups.Count;r++)
        {
            var g = Groups[r];
            ws.Cell(r+2,1).Value = g.GroupNumber;
            ws.Cell(r+2,2).Value = g.InvoiceNumbers;
            ws.Cell(r+2,3).Value = g.CompanyNames;
            var idCell = ws.Cell(r+2,4);
            idCell.Style.NumberFormat.Format = "@";
            idCell.SetValue(g.NationalIds);
            ws.Cell(r+2,5).Value = g.Count;
            ws.Cell(r+2,6).Value = g.TotalAmount;
            ws.Cell(r+2,7).Value = g.Balance;
            ws.Cell(r+2,8).Value = g.AvgDueDate;
        }
        var last = Groups.Count + 2;
        ws.Cell(last,5).Value = "جمع";
        ws.Cell(last,6).Value = Groups.Sum(g=>g.TotalAmount);
        ws.Cell(last,7).Value = Groups.Sum(g=>g.Balance);
        ws.Range(last,5,last,7).Style.Font.Bold = true;
        ws.Column(6).Style.NumberFormat.Format = "#,##0";
        ws.Column(7).Style.NumberFormat.Format = "#,##0";
        ws.RightToLeft = true;
        ws.Row(1).Style.Font.Bold = true;
        ws.Row(1).Style.Fill.BackgroundColor = XLColor.LightBlue;
        ws.SheetView.FreezeRows(1);
        ws.Columns().AdjustToContents();
    }

    static void AddSheetFromGrid(XLWorkbook wb, DataGrid grid, string sheetName)
    {
        var ws = wb.Worksheets.Add(SafeSheetName(sheetName));
        var columns = grid.Columns.OfType<DataGridBoundColumn>().ToList();
        for (int c = 0; c < columns.Count; c++)
            ws.Cell(1, c + 1).Value = columns[c].Header?.ToString() ?? "";

        var items = grid.ItemsSource?.Cast<object>().ToList() ?? new List<object>();
        for (int r = 0; r < items.Count; r++)
            for (int c = 0; c < columns.Count; c++)
            {
                var path = (columns[c].Binding as Binding)?.Path?.Path;
                var val = path != null ? GetPropertyValue(items[r], path) : null;
                ws.Cell(r + 2, c + 1).Value = val?.ToString() ?? "";
            }

        ws.RightToLeft = true;
        ws.Row(1).Style.Font.Bold = true;
        ws.Row(1).Style.Fill.BackgroundColor = XLColor.LightBlue;
        ws.SheetView.FreezeRows(1);
        if (items.Count > 0) ws.Columns().AdjustToContents();
    }
    static string SafeSheetName(string s) => s.Length > 31 ? s.Substring(0, 31) : s; // محدودیت اکسل روی طول نام شیت

    static object? GetPropertyValue(object obj, string path)
    {
        object? current = obj;
        foreach (var part in path.Split('.'))
        {
            if (current is null) return null;
            var prop = current.GetType().GetProperty(part);
            if (prop is null) return null;
            current = prop.GetValue(current);
        }
        return current;
    }

}

sealed record PayRow(int Id, string PayDate, string InvoiceNumber, string CompanyName, decimal Amount, string PaymentMethod, string CheckNumber, string CheckStatus, string Note);
sealed record StatementRow(string Date, string Description, string Reference, decimal Debit, decimal Credit, decimal Balance);
sealed record CheckRow(string CheckDate, string CheckNumber, string InvoiceNumber, string CompanyName, decimal Amount, string CheckStatus, string DueInfo = "—");
sealed record PayDetailRow(string InvoiceNumber, string PayDate, decimal Amount, string Method, string CheckNumber, string CheckDate);

public sealed class GroupRow : INotifyPropertyChanged
{
    public Invoice Invoice { get; }
    public GroupRow(Invoice invoice, string groupLabel = "") { Invoice = invoice; GroupLabel = groupLabel; }
    public string Number => Invoice.Number;
    public string CompanyName => Invoice.Company?.Name ?? "-";
    public string Note => (Invoice.Note ?? "").Replace("\r"," ").Replace("\n"," ").Trim();   // توضیحات فاکتور
    public string InvoiceDatePersian => PersianDateService.ToPersian(Invoice.InvoiceDate);
    public string DueDatePersian => PersianDateService.ToPersian(Invoice.DueDate);
    public decimal Amount => Invoice.NetAmount;   // مبلغ خالص = مبلغ کل − مرجوعی
    public decimal Balance => AccountingService.Balance(Invoice);
    public decimal Paid => Invoice.Paid;
    public string StatusText => Balance<=0 ? "تسویه شده" : Paid>0 ? "بخشی پرداخت شده" : "پرداخت نشده";
    public bool IsOverdue => Invoice.DueDate.Date < DateTime.Today;
    public bool IsGrouped => GroupLabel.Length > 0;
    public string GroupLabel { get; }
    bool _selected;
    public bool Selected
    {
        get => _selected;
        set { if (_selected==value) return; _selected = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Selected))); }
    }
    public event PropertyChangedEventHandler? PropertyChanged;
}

public sealed class InvoiceGroupResult
{
    public int GroupNumber { get; set; }
    public string Name { get; set; } = "";
    public string InvoiceNumbers { get; set; } = "";
    public string CompanyNames { get; set; } = "";
    public string NationalIds { get; set; } = "";   // به ترتیب همان شرکت‌ها
    public string CompanyNotes { get; set; } = "";   // توضیحات شرکت‌ها (برای چاپ)
    public int Count { get; set; }
    public decimal TotalAmount { get; set; }
    public decimal Balance { get; set; }
    public string AvgDueDate { get; set; } = "";
    public List<int> InvoiceIds { get; set; } = new();
    public List<GroupInvoiceLine> Lines { get; set; } = new();   // جزئیات کامل هر فاکتور برای نمایش گروه
}

public sealed record GroupInvoiceLine(string Number, string CompanyName, string NationalId, string DueDate, decimal Balance);
