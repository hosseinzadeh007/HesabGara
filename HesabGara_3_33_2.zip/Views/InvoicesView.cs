using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;

namespace HesabGara.Views;

public partial class InvoicesView : Grid
{
    readonly AccountingService S; readonly int? InitialCompanyId; readonly DataGrid G=new(); readonly TextBlock Summary=new();
    ComboBox CompanyBox=new(); TextBox NumberBox=new(), AmountBox=new(), ReturnedBox=new(), NetBox=new(), DateBox=new(), DueBox=new(), NoteBox=new();
    readonly ObservableCollection<Row> Rows=new(); bool loading; bool suppressCompanyChange;
    readonly CheckBox DueOnlyBox = new(){ Content="فقط سررسیدهای باز" };
    readonly TextBox SearchBox = new();   // جستجو بر اساس شماره‌ی فاکتور یا مبلغ
    readonly System.Windows.Threading.DispatcherTimer _searchTimer = new() { Interval = TimeSpan.FromMilliseconds(250) };
    List<Invoice> _loaded = new();

    // --- Payments / check-collection panel for the currently selected invoice ---
    int? SelectedInvoiceId;
    int? EditingPaymentId; decimal? EditingOriginalAmount;
    int? EditingInvoiceId;   // فاکتوری که در فرم بالا در حال ویرایش است (مستقل از انتخاب ردیف در جدول)
    Button SaveInvoiceButton=new();
    readonly CheckImagesPanel PayImages = new();   // عکس چک/رسید وصول
    readonly TextBlock PaySubtitle=new();
    readonly TextBox PayAmount=new(), PayCheckNumberBox=new(), PayNoteBox=new();
    readonly ComboBox PayMethodBox=new(), PayCheckStatusBox=new();
    readonly PersianDateBox PayCheckDateBox=new(), PayDateBox=new();
    readonly CheckBox PayFullSettleBox=new(){ Content="تسویه کامل (کل مانده)" };
    readonly DataGrid PayGrid=new();
    Button PayAddButton=new(), PayDeleteButton=new(), PayCancelEditButton=new();

    public InvoicesView(AccountingService s,int? companyId){S=s;InitialCompanyId=companyId;Margin=new Thickness(18);Background=AppTheme.Surface100;Build();Loaded+=async(_,_)=>{await InitCompanies();await Load();};}

    void Build()
    {
        FlowDirection = FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });   // نوار ابزار: با کم‌عرض شدن پنجره ارتفاعش بزرگ می‌شود و دکمه‌ها به خط بعد می‌روند
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });   // نوار خلاصه‌ی فاکتورهای انتخاب‌شده، پایین صفحه

        var card = new Border
        {
            Background = Brushes.White,
            BorderBrush = AppTheme.Line200,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(14),
            Padding = new Thickness(16),
            Margin = new Thickness(0,0,0,10),
            Effect = AppTheme.CardShadow
        };

        var g = new Grid { FlowDirection = FlowDirection.RightToLeft };
        for (int i=0;i<4;i++) g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var title = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        title.Children.Add(new TextBlock { Text="مشخصات فاکتور", FontSize=17, FontWeight=FontWeights.Bold,
            Foreground=AppTheme.Brand900 });
        title.Children.Add(new TextBlock { Text="  ثبت و ویرایش اطلاعات فاکتور", Foreground=AppTheme.Ink500,
            FontSize=12.5, VerticalAlignment=VerticalAlignment.Center, Margin=new Thickness(8,0,0,0) });
        Grid.SetColumnSpan(title,4); Grid.SetRow(title,0); g.Children.Add(title);

        AddField(g,"شماره فاکتور *",NumberBox,0,1);
        AddCombo(g,"شرکت *",CompanyBox,1,1);
        AddField(g,"تاریخ فاکتور",DateBox,2,1);
        AddField(g,"سررسید",DueBox,3,1);

        AddField(g,"مبلغ کل (ریال) *",AmountBox,0,2);
        ReturnedBox.ToolTip="اگر بخشی از کالای این فاکتور مرجوع شده، مبلغ آن را اینجا بنویسید؛ از مبلغ کل کم می‌شود.";
        AddField(g,"مرجوعی (ریال)",ReturnedBox,1,2);
        NetBox.IsReadOnly=true; NetBox.ToolTip="مبلغ کل − مرجوعی؛ مانده و وصول بر اساس همین مبلغ است.";
        AddField(g,"مبلغ خالص (کل − مرجوعی)",NetBox,2,2);
        AddField(g,"توضیحات",NoteBox,3,2);
        AmountBox.TextChanged+=(_,_)=>UpdateNet(); ReturnedBox.TextChanged+=(_,_)=>UpdateNet();

        var buttons = new StackPanel { Orientation=Orientation.Horizontal, HorizontalAlignment=HorizontalAlignment.Left,
            VerticalAlignment=VerticalAlignment.Center, FlowDirection=FlowDirection.RightToLeft };
        var save=SaveInvoiceButton=Btn("＋ ثبت / ذخیره",AppTheme.Success600); save.Click+=AddInvoice;
        var clear=Btn("پاک کردن",AppTheme.Surface100); clear.Foreground=AppTheme.Ink900; clear.Click+=(_,_)=>ClearForm();
        var del=Btn("حذف",AppTheme.Danger100); del.Foreground=AppTheme.Danger600; del.Click+=DeleteInvoice;
        buttons.Children.Add(save); buttons.Children.Add(clear); buttons.Children.Add(del);
        Grid.SetColumn(buttons,2); Grid.SetColumnSpan(buttons,2); Grid.SetRow(buttons,3); g.Children.Add(buttons);

        card.Child=g; Grid.SetRow(card,0); Children.Add(card);

        var sumCard = new Border
        {
            Background=AppTheme.Brand100,
            CornerRadius=new CornerRadius(11), Padding=new Thickness(12,8,12,6),
            Margin=new Thickness(0,0,0,8),
            BorderBrush=AppTheme.Line300, BorderThickness=new Thickness(1)
        };
        Summary.FontSize=13; Summary.FontWeight=FontWeights.SemiBold; Summary.Foreground=AppTheme.Ink900;
        Summary.Text="هیچ فاکتوری انتخاب نشده است"; Summary.TextWrapping=TextWrapping.Wrap; Summary.VerticalAlignment=VerticalAlignment.Center;

        // نوار ابزار مرتب: راست = جستجو و فیلتر و انتخاب همه/هیچ‌کدام (با خط‌شکستن خودکار)، چپ = دکمه‌ی اصلی «ثبت وصول»
        var bar=new Grid { FlowDirection=FlowDirection.RightToLeft };
        bar.ColumnDefinitions.Add(new ColumnDefinition { Width=new GridLength(1,GridUnitType.Star) });
        bar.ColumnDefinitions.Add(new ColumnDefinition { Width=GridLength.Auto });
        var tools=new WrapPanel { Orientation=Orientation.Horizontal, VerticalAlignment=VerticalAlignment.Center, FlowDirection=FlowDirection.RightToLeft };

        Button Tool(string text){var t=Btn(text,Brushes.White);t.Foreground=AppTheme.Brand700;t.Height=34;t.Padding=new Thickness(14,0,14,0);t.Margin=new Thickness(0,0,8,6);t.BorderThickness=new Thickness(1);t.BorderBrush=AppTheme.Line300;t.VerticalContentAlignment=VerticalAlignment.Center;return t;}

        tools.Children.Add(new TextBlock { Text = "جستجو:", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 6), Foreground = AppTheme.Ink700, FontWeight = FontWeights.SemiBold });
        SearchBox.Width = 210; SearchBox.Height = 34; SearchBox.VerticalContentAlignment = VerticalAlignment.Center; SearchBox.Margin = new Thickness(0, 0, 16, 6);
        SearchBox.ToolTip = "شماره‌ی فاکتور یا مبلغ فاکتور (مثلاً 1500000 یا بخشی از آن). با Esc پاک می‌شود.";
        _searchTimer.Tick += (_, _) => { _searchTimer.Stop(); Rebuild(); };
        SearchBox.TextChanged += (_, _) => { _searchTimer.Stop(); _searchTimer.Start(); };
        SearchBox.KeyDown += (_, e) => { if (e.Key == System.Windows.Input.Key.Escape) SearchBox.Clear(); };
        tools.Children.Add(SearchBox);

        DueOnlyBox.VerticalAlignment=VerticalAlignment.Center; DueOnlyBox.Margin=new Thickness(0,0,16,6); DueOnlyBox.Foreground=AppTheme.Ink700; DueOnlyBox.FontWeight=FontWeights.SemiBold;
        DueOnlyBox.Checked+=async(_,_)=>await Load(); DueOnlyBox.Unchecked+=async(_,_)=>await Load();
        tools.Children.Add(DueOnlyBox);

        var all=Tool("انتخاب همه"); all.Click+=(_,_)=>{foreach(var r in Rows)r.Selected=true;UpdateSummary();};
        var none=Tool("لغو انتخاب"); none.Click+=(_,_)=>{foreach(var r in Rows)r.Selected=false;UpdateSummary();};
        tools.Children.Add(all); tools.Children.Add(none);
        Grid.SetColumn(tools,0); bar.Children.Add(tools);

        var multiPay=Btn("＋ ثبت وصول چند فاکتور / چند چک",AppTheme.Success600); multiPay.Foreground=Brushes.White; multiPay.Click+=RegisterMultiPayment;
        multiPay.Height=38; multiPay.Padding=new Thickness(18,0,18,0); multiPay.Margin=new Thickness(12,0,0,6); multiPay.VerticalAlignment=VerticalAlignment.Top; multiPay.VerticalContentAlignment=VerticalAlignment.Center;
        multiPay.ToolTip="فاکتورهای تیک‌خورده (یا فاکتور انتخاب‌شده) را با یک یا چند پرداخت (نقد، کارت، چک با شماره و سررسید و مبلغ متفاوت) تسویه می‌کند.";
        Grid.SetColumn(multiPay,1); bar.Children.Add(multiPay);

        sumCard.Child=bar; Grid.SetRow(sumCard,1); Children.Add(sumCard);

        G.FlowDirection=FlowDirection.RightToLeft; G.AutoGenerateColumns=false; G.CanUserAddRows=false; G.IsReadOnly=false;
        G.SelectionUnit=DataGridSelectionUnit.FullRow; G.RowHeight=40; G.ColumnHeaderHeight=38; G.FontSize=12.5;
        G.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; G.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        G.Columns.Add(new DataGridCheckBoxColumn{Header="انتخاب",Binding=new System.Windows.Data.Binding(nameof(Row.Selected)){Mode=System.Windows.Data.BindingMode.TwoWay,UpdateSourceTrigger=System.Windows.Data.UpdateSourceTrigger.PropertyChanged},Width=55});
        G.Columns.Add(new DataGridTextColumn{Header="شماره",Binding=new System.Windows.Data.Binding(nameof(Row.Number)),IsReadOnly=true,Width=85});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new System.Windows.Data.Binding("Company.Name"),IsReadOnly=true,Width=new DataGridLength(1.3,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="تاریخ",Binding=new System.Windows.Data.Binding(nameof(Row.InvoiceDatePersian)),IsReadOnly=true,Width=95});
        G.Columns.Add(new DataGridTextColumn{Header="سررسید",Binding=new System.Windows.Data.Binding(nameof(Row.DueDatePersian)),IsReadOnly=true,Width=95});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ کل",Binding=new System.Windows.Data.Binding(nameof(Row.Amount)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=95});
        G.Columns.Add(new DataGridTextColumn{Header="مرجوعی",Binding=new System.Windows.Data.Binding(nameof(Row.Returned)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(0.8,DataGridLengthUnitType.Star),MinWidth=80});
        G.Columns.Add(new DataGridTextColumn{Header="خالص",Binding=new System.Windows.Data.Binding(nameof(Row.NetAmount)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=90});
        G.Columns.Add(new DataGridTextColumn{Header="پرداختی",Binding=new System.Windows.Data.Binding(nameof(Row.Paid)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=95});
        G.Columns.Add(new DataGridTextColumn{Header="مانده",Binding=new System.Windows.Data.Binding(nameof(Row.Balance)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=95});
        G.Columns.Add(new DataGridTextColumn{Header="توضیحات",Binding=new System.Windows.Data.Binding(nameof(Row.Note)),IsReadOnly=true,Width=new DataGridLength(1.3,DataGridLengthUnitType.Star),MinWidth=90});
        CompanyBox.SelectionChanged+=async(_,_)=>{if(!loading&&!suppressCompanyChange)await Load();};
        G.SelectionChanged+=async(_,_)=>{if(G.SelectedItem is Row r){Populate(r);SelectedInvoiceId=r.Id;await LoadPaymentsForSelected();}else{SelectedInvoiceId=null;await LoadPaymentsForSelected();}};
        G.CurrentCellChanged+=(_,_)=>Dispatcher.BeginInvoke(UpdateSummary);
        G.CellEditEnding+=(_,_)=>Dispatcher.BeginInvoke(UpdateSummary); G.MouseLeftButtonUp+=(_,_)=>Dispatcher.BeginInvoke(UpdateSummary);

        // وصول‌های هر فاکتور در یک پنجره‌ی جداگانه باز می‌شود (دکمه‌ی «وصول‌ها» یا Enter؛ دوبار کلیک روی فاکتور پنجره‌ی وصول را باز نمی‌کند)
        // تا خود جدول فاکتورها کل عرض صفحه را داشته باشد.
        _payCard = BuildPaymentsPanel();
        var payBtn = new FrameworkElementFactory(typeof(Button));
        payBtn.SetValue(Button.ContentProperty, "وصول‌ها");
        payBtn.SetValue(Button.PaddingProperty, new Thickness(10, 2, 10, 2));
        payBtn.SetValue(Button.MarginProperty, new Thickness(2));
        payBtn.SetValue(FrameworkElement.CursorProperty, System.Windows.Input.Cursors.Hand);
        payBtn.AddHandler(Button.ClickEvent, new RoutedEventHandler(async (sender, e) =>
        {
            if ((sender as FrameworkElement)?.DataContext is Row r) { G.SelectedItem = r; await OpenPayments(); }
        }));
        G.Columns.Insert(0, new DataGridTemplateColumn { Header = "", CellTemplate = new DataTemplate { VisualTree = payBtn }, Width = 88 });
        G.ToolTip = "وصول‌های یک فاکتور: روی دکمه‌ی «وصول‌ها» بزنید (یا فاکتور را انتخاب و Enter بزنید).";
        G.PreviewKeyDown += async (_, e) =>
        {
            if (e.Key == System.Windows.Input.Key.Enter && G.SelectedItem != null && System.Windows.Input.Keyboard.FocusedElement is not TextBox)
            { e.Handled = true; await OpenPayments(); }
        };
        Grid.SetRow(G, 2); Children.Add(G);

        // خلاصه‌ی فاکتورهای تیک‌خورده (تعداد، جمع، پرداختی، مانده، سررسید وزنی) پایین صفحه؛ دکمه‌ها بالا می‌مانند
        var summaryBar = new Border
        {
            Background = AppTheme.Brand100, BorderBrush = AppTheme.Line300, BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(11), Padding = new Thickness(14, 10, 14, 10), Margin = new Thickness(0, 8, 0, 0),
            Child = Summary
        };
        Grid.SetRow(summaryBar, 3); Children.Add(summaryBar);
    }

    Border BuildPaymentsPanel()
    {
        var card = new Border
        {
            Background = Brushes.White,
            BorderBrush = AppTheme.Line200,
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(14),
            Padding = new Thickness(14),
            Margin = new Thickness(12),
            Effect = AppTheme.CardShadow
        };

        // Everything (header, form, buttons, history) lives in one scrollable stack instead
        // of a fixed set of Auto/Star grid rows. That earlier approach silently compressed
        // and clipped content - most visibly the submit button, since it sat at the very
        // bottom of the form - whenever the panel didn't have enough vertical room. A
        // ScrollViewer guarantees every control stays reachable no matter the window size.
        var outer = new StackPanel();

        var header = new StackPanel { Margin = new Thickness(0,0,0,10) };
        header.Children.Add(new TextBlock { Text="پرداخت‌ها و وصول چک", FontSize=16, FontWeight=FontWeights.Bold, Foreground=AppTheme.Brand900 });
        PaySubtitle.Text = "یک فاکتور را انتخاب کنید"; PaySubtitle.Foreground=AppTheme.Ink500; PaySubtitle.FontSize=12; PaySubtitle.Margin=new Thickness(0,3,0,0); PaySubtitle.TextWrapping=TextWrapping.Wrap;
        header.Children.Add(PaySubtitle);
        outer.Children.Add(header);

        var form = new StackPanel();
        PayDateBox.SelectedDate=DateTime.Today; PayMethodBox.ItemsSource=new[]{"نقد","کارت‌به‌کارت","چک","ترکیبی"}; PayMethodBox.SelectedIndex=0; PayMethodBox.SelectionChanged+=(_,_)=>UpdateCheckFieldsEnabled();
        PayCheckStatusBox.ItemsSource=new[]{"در انتظار وصول","وصول‌شده","برگشتی","لغوشده"}; PayCheckStatusBox.SelectedIndex=0;
        PayCheckNumberBox.ToolTip="اختیاری؛ می‌توانید شماره چک را بعداً تکمیل کنید.";
        AddStackedField(form,"تاریخ وصول",PayDateBox);
        AddStackedField(form,"مبلغ وصول (ریال)",PayAmount);
        PayFullSettleBox.Foreground=AppTheme.Ink700; PayFullSettleBox.Margin=new Thickness(0,-4,0,10); PayFullSettleBox.FontSize=12.5;
        PayFullSettleBox.Checked+=(_,_)=>ApplyFullSettleAmount(); PayFullSettleBox.Unchecked+=(_,_)=>{ PayAmount.IsReadOnly=false; };
        form.Children.Add(PayFullSettleBox);
        AddStackedField(form,"روش وصول",PayMethodBox);
        AddStackedField(form,"شماره چک (اختیاری)",PayCheckNumberBox);
        AddStackedField(form,"تاریخ چک (اختیاری)",PayCheckDateBox);
        AddStackedField(form,"وضعیت چک",PayCheckStatusBox);
        AddStackedField(form,"توضیحات",PayNoteBox);
        form.Children.Add(PayImages);

        var payButtons = new StackPanel { Orientation=Orientation.Horizontal, Margin=new Thickness(0,4,0,10) };
        PayAddButton = Btn("＋ ثبت وصول",AppTheme.Success600); PayAddButton.Foreground=Brushes.White; PayAddButton.Click+=SubmitPayment;
        PayDeleteButton = Btn("حذف وصول انتخاب‌شده",AppTheme.Danger100); PayDeleteButton.Foreground=AppTheme.Danger600; PayDeleteButton.Click+=DeletePayment;
        PayCancelEditButton = Btn("انصراف از ویرایش",AppTheme.Surface100); PayCancelEditButton.Foreground=AppTheme.Ink700; PayCancelEditButton.Click+=(_,_)=>CancelPaymentEdit(); PayCancelEditButton.Visibility=Visibility.Collapsed;
        payButtons.Children.Add(PayAddButton); payButtons.Children.Add(PayDeleteButton); payButtons.Children.Add(PayCancelEditButton);
        form.Children.Add(payButtons);
        outer.Children.Add(form);

        var historyLabel = new TextBlock { Text="سوابق وصول این فاکتور (برای ویرایش، یک ردیف را انتخاب کنید)", FontWeight=FontWeights.SemiBold, FontSize=13, Foreground=AppTheme.Ink700, Margin=new Thickness(0,0,0,6), TextWrapping=TextWrapping.Wrap };
        outer.Children.Add(historyLabel);

        PayGrid.FlowDirection=FlowDirection.RightToLeft; PayGrid.AutoGenerateColumns=false; PayGrid.IsReadOnly=true; PayGrid.CanUserAddRows=false;
        PayGrid.SelectionMode=DataGridSelectionMode.Single; PayGrid.RowHeight=36; PayGrid.ColumnHeaderHeight=34; PayGrid.FontSize=12;
        PayGrid.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; PayGrid.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        PayGrid.MinHeight=180; PayGrid.MaxHeight=340;
        PayGrid.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new System.Windows.Data.Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=90});
        PayGrid.Columns.Add(new DataGridTextColumn{Header="تاریخ",Binding=new System.Windows.Data.Binding("PayDate"),Width=90});
        PayGrid.Columns.Add(new DataGridTextColumn{Header="روش",Binding=new System.Windows.Data.Binding("PaymentMethod"),Width=90});
        PayGrid.Columns.Add(new DataGridTextColumn{Header="وضعیت چک",Binding=new System.Windows.Data.Binding("CheckStatus"),Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=100});
        PayGrid.Columns.Add(new DataGridTextColumn{Header="عکس",Binding=new System.Windows.Data.Binding("Images"),Width=60});
        PayGrid.SelectionChanged += (_,_) => { if (PayGrid.SelectedItem is PaymentRow pr) PopulateForEdit(pr); };
        outer.Children.Add(PayGrid);

        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Content = outer };
        card.Child = scroll;
        UpdateCheckFieldsEnabled();
        SetPaymentsPanelEnabled(false);
        return card;
    }

    static void AddStackedField(StackPanel panel, string label, Control control)
    {
        var p = new StackPanel { Margin = new Thickness(0,0,0,8) };
        p.Children.Add(new TextBlock { Text=label, FontWeight=FontWeights.SemiBold, FontSize=12.5, Foreground=AppTheme.Ink700, Margin=new Thickness(0,0,0,3) });
        control.Height = 34;
        p.Children.Add(control);
        panel.Children.Add(p);
    }

    void UpdateCheckFieldsEnabled()
    {
        var isCheck = string.Equals(PayMethodBox.SelectedItem?.ToString(), "چک", StringComparison.Ordinal);
        PayCheckNumberBox.IsEnabled = isCheck; PayCheckDateBox.IsEnabled = isCheck; PayCheckStatusBox.IsEnabled = isCheck;
        if (!isCheck) { PayCheckNumberBox.Clear(); PayCheckDateBox.SelectedDate=null; PayCheckStatusBox.SelectedIndex=0; }
    }

    void SetPaymentsPanelEnabled(bool enabled)
    {
        // Adding a NEW payment only makes sense while there's a remaining balance, so these
        // stay gated by "enabled" (which callers pass as balance > 0). Deleting an EXISTING
        // payment must stay possible even on a fully-settled invoice - that's exactly how a
        // mistaken entry that caused it to look settled would get corrected - so it's gated
        // separately, by whether an invoice is selected at all, not by its balance.
        PayImages.IsEnabled=enabled; PayAmount.IsEnabled=enabled; PayMethodBox.IsEnabled=enabled; PayNoteBox.IsEnabled=enabled; PayAddButton.IsEnabled=enabled; PayFullSettleBox.IsEnabled=enabled;
        PayDeleteButton.IsEnabled = SelectedInvoiceId.HasValue;
        if (enabled) UpdateCheckFieldsEnabled();
        else { PayCheckNumberBox.IsEnabled=false; PayCheckDateBox.IsEnabled=false; PayCheckStatusBox.IsEnabled=false; }
    }

    // With the checkbox ticked, the amount field always fills with the invoice's remaining
    // balance - if a payment is currently being edited, its own old amount is added back in
    // first, since that amount is being freed up for reassignment as part of the edit.
    void ApplyFullSettleAmount()
    {
        if (SelectedInvoiceId is not int id) { PayFullSettleBox.IsChecked=false; return; }
        var row = Rows.FirstOrDefault(x => x.Id == id);
        if (row is null) { PayFullSettleBox.IsChecked=false; return; }
        var available = row.Balance + (EditingPaymentId.HasValue ? EditingOriginalAmount ?? 0 : 0);
        PayAmount.Text = available.ToString("0.##");
        PayAmount.IsReadOnly = true;
    }

    void PopulateForEdit(PaymentRow pr)
    {
        EditingPaymentId = pr.Payment.Id;
        EditingOriginalAmount = pr.Payment.Amount;
        PayFullSettleBox.IsChecked = false; PayAmount.IsReadOnly = false;
        PayDateBox.SelectedDate = pr.Payment.PayDate;
        PayAmount.Text = pr.Payment.Amount.ToString("0.##");
        PayMethodBox.SelectedItem = pr.Payment.PaymentMethod;
        PayCheckNumberBox.Text = pr.Payment.CheckNumber ?? "";
        PayCheckDateBox.SelectedDate = pr.Payment.CheckDate;
        PayCheckStatusBox.SelectedItem = pr.Payment.CheckStatus;
        PayNoteBox.Text = pr.Payment.Note ?? "";
        PayAddButton.Content = "ذخیره ویرایش وصول";
        PayAddButton.Background = AppTheme.Brand600;
        PayCancelEditButton.Visibility = Visibility.Visible;
        _ = PayImages.LoadExistingAsync(pr.Payment.Id);
    }

    void CancelPaymentEdit()
    {
        EditingPaymentId = null; EditingOriginalAmount = null;
        PayAmount.Clear(); PayDateBox.SelectedDate=DateTime.Today; PayCheckNumberBox.Clear(); PayCheckDateBox.SelectedDate=null; PayNoteBox.Clear(); PayMethodBox.SelectedIndex=0;
        PayFullSettleBox.IsChecked = false; PayAmount.IsReadOnly = false;
        PayAddButton.Content = "＋ ثبت وصول";
        PayAddButton.Background = AppTheme.Success600;
        PayCancelEditButton.Visibility = Visibility.Collapsed;
        PayGrid.SelectedItem = null;
        PayImages.Reset();
    }

    int _paymentsRequestToken;
    Border? _payCard; Window? _payWin;

    static T? Up<T>(DependencyObject? d) where T : DependencyObject
    {
        while (d != null && d is not T)
            d = d is System.Windows.Media.Visual || d is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
        return d as T;
    }

    /// <summary>پنجره‌ی وصول‌های فاکتور انتخاب‌شده (ثبت، ویرایش و حذف وصول، چک، وصول کامل).</summary>
    async Task OpenPayments()
    {
        if (G.SelectedItem is not Row r) { MessageBox.Show("یک فاکتور را انتخاب کنید."); return; }
        if (_payWin != null || _payCard is null) return;
        SelectedInvoiceId = r.Id;
        var owner = Window.GetWindow(this);
        var host = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, Content = _payCard };
        var win = new Window
        {
            Title = $"وصول‌ها — فاکتور {r.Number}",
            WindowStartupLocation = owner is null ? WindowStartupLocation.CenterScreen : WindowStartupLocation.CenterOwner,
            Width = 660, Height = 780, MinWidth = 560, MinHeight = 520,
            FlowDirection = FlowDirection.RightToLeft,
            Background = AppTheme.Surface100,
            Content = host
        };
        if (owner != null) win.Owner = owner;
        win.Closed += (_, _) => { host.Content = null; _payWin = null; };
        _payWin = win;
        await LoadPaymentsForSelected();
        win.ShowDialog();
    }

    async Task LoadPaymentsForSelected()
    {
        if (_payWin == null) return;   // پنجره‌ی وصول‌ها بسته است؛ هنگام باز شدن بارگذاری می‌شود
        var myToken = ++_paymentsRequestToken;
        PayAmount.Clear(); PayDateBox.SelectedDate=DateTime.Today; PayCheckNumberBox.Clear(); PayCheckDateBox.SelectedDate=null; PayNoteBox.Clear(); PayMethodBox.SelectedIndex=0;
        EditingPaymentId=null; EditingOriginalAmount=null; PayFullSettleBox.IsChecked=false; PayAmount.IsReadOnly=false;
        PayImages.Reset();
        PayAddButton.Content="＋ ثبت وصول"; PayAddButton.Background=AppTheme.Success600; PayCancelEditButton.Visibility=Visibility.Collapsed;
        if (SelectedInvoiceId is not int id)
        {
            if (myToken != _paymentsRequestToken) return; // a newer selection has already started
            PaySubtitle.Text = "یک فاکتور را انتخاب کنید";
            PayGrid.ItemsSource = null;
            SetPaymentsPanelEnabled(false);
            return;
        }
        var row = Rows.FirstOrDefault(x => x.Id == id);
        var balance = row?.Balance ?? 0;
        var payments = await S.GetPaymentsForInvoiceAsync(id);
        // If the user selected a different invoice while this fetch was in flight, this
        // result is stale - applying it now would show the wrong invoice's payment history.
        if (myToken != _paymentsRequestToken) return;
        PaySubtitle.Text = row is null ? "" : (balance > 0
            ? $"فاکتور {row.Number} — مانده قابل وصول: {balance:N0} ریال{(row.Returned > 0 ? $" (پس از کسر مرجوعی {row.Returned:N0})" : "")}"
            : $"فاکتور {row.Number} — تسویه شده است");
        SetPaymentsPanelEnabled(balance > 0);
        Dictionary<int, int> imgCounts;
        try { imgCounts = await S.GetPaymentImageCountsAsync(payments.Select(p => p.Id).ToList()); }
        catch (Exception) { imgCounts = new Dictionary<int, int>(); }   // نبودن شمارش عکس نباید نمایش وصول‌ها را خراب کند
        if (myToken != _paymentsRequestToken) return;
        PayGrid.ItemsSource = payments.Select(p => new PaymentRow(p) { ImageCount = imgCounts.GetValueOrDefault(p.Id) }).ToList();
    }

    async void SubmitPayment(object? sender, RoutedEventArgs e)
    {
        if (SelectedInvoiceId is not int id) { MessageBox.Show("یک فاکتور را انتخاب کنید."); return; }
        if (!decimal.TryParse(PayAmount.Text.Replace(",","").Replace("٬","").Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var amount) || amount <= 0)
        {
            MessageBox.Show("مبلغ وصول را به‌درستی وارد کنید.");
            return;
        }
        var method = PayMethodBox.SelectedItem?.ToString() ?? "نقد";
        var editingId = EditingPaymentId;
        try
        {
            if (editingId is int payId)
            {
                await S.UpdatePaymentAsync(new Payment
                {
                    Id = payId,
                    Amount = amount,
                    PayDate = PayDateBox.SelectedDate ?? DateTime.Today,
                    PaymentMethod = method,
                    CheckNumber = method=="چک" ? NullIfWhite(PayCheckNumberBox.Text) : null,
                    CheckDate = method=="چک" ? PayCheckDateBox.SelectedDate?.Date : null,
                    CheckStatus = method=="چک" ? PayCheckStatusBox.SelectedItem?.ToString() : null,
                    Note = NullIfWhite(PayNoteBox.Text)
                }, images: PayImages.NewImages, removeImageIds: PayImages.RemovedIds);
                PayImages.Reset();
                await ReloadKeepingSelection(id);
                MessageBox.Show("وصول با موفقیت ویرایش شد.", "ویرایش وصول", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                await S.AddPaymentAsync(new Payment
                {
                    InvoiceId = id,
                    Amount = amount,
                    PayDate = PayDateBox.SelectedDate ?? DateTime.Today,
                    PaymentMethod = method,
                    CheckNumber = method=="چک" ? NullIfWhite(PayCheckNumberBox.Text) : null,
                    CheckDate = method=="چک" ? PayCheckDateBox.SelectedDate?.Date : null,
                    CheckStatus = method=="چک" ? PayCheckStatusBox.SelectedItem?.ToString() : null,
                    Note = NullIfWhite(PayNoteBox.Text)
                }, images: PayImages.NewImages);
                PayImages.Reset();
                await ReloadKeepingSelection(id);
                MessageBox.Show("وصول با موفقیت ثبت و ذخیره شد.", "ثبت وصول", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, editingId.HasValue ? "ویرایش وصول" : "ثبت وصول", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    async void DeletePayment(object? sender, RoutedEventArgs e)
    {
        if (PayGrid.SelectedItem is not PaymentRow row) { MessageBox.Show("یک وصول را از جدول سوابق انتخاب کنید."); return; }
        if (MessageBox.Show($"وصول {row.Amount:N0} حذف شود؟","تأیید حذف",MessageBoxButton.YesNo,MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        try
        {
            var invoiceId = SelectedInvoiceId;
            await S.DeletePaymentAsync(row.Id);
            if (invoiceId is int id) await ReloadKeepingSelection(id);
            MessageBox.Show("وصول با موفقیت حذف شد.", "حذف وصول", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message,"حذف وصول",MessageBoxButton.OK,MessageBoxImage.Warning); }
    }

    // Reloads the invoices grid (so Paid/Balance reflect the new payment) while keeping the
    // same invoice selected and its payments panel refreshed.
    async Task ReloadKeepingSelection(int invoiceId)
    {
        await Load();
        var row = Rows.FirstOrDefault(x => x.Id == invoiceId);
        if (row != null) { G.SelectedItem = row; Populate(row); }
        SelectedInvoiceId = invoiceId;
        await LoadPaymentsForSelected();
    }

    static string? NullIfWhite(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    static Button Btn(string text,Brush bg){return new Button{Content=text,Background=bg,BorderThickness=new Thickness(0),Padding=new Thickness(13,8,13,8),Margin=new Thickness(4),FontWeight=FontWeights.SemiBold,Cursor=System.Windows.Input.Cursors.Hand};}
    static void AddField(Grid g,string label,TextBox box,int c,int r){var p=new StackPanel{Margin=new Thickness(5,0,5,8),MinWidth=90};p.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink700});box.Height=40;box.Margin=new Thickness(0,4,0,0);p.Children.Add(box);Grid.SetColumn(p,c);Grid.SetRow(p,r);g.Children.Add(p);}
    static void AddCombo(Grid g,string label,ComboBox box,int c,int r){var p=new StackPanel{Margin=new Thickness(5,0,5,8),MinWidth=90};p.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink700});box.Height=40;box.Margin=new Thickness(0,4,0,0);p.Children.Add(box);Grid.SetColumn(p,c);Grid.SetRow(p,r);g.Children.Add(p);}
    async Task InitCompanies(){loading=true;var list=await S.GetCompaniesAsync();var all=new List<Company>{new Company{Id=0,Name="همه شرکت‌ها"}};all.AddRange(list);CompanyBox.ItemsSource=all;CompanyBox.DisplayMemberPath="Name";CompanyBox.SelectedValuePath="Id";CompanyBox.SelectedValue=InitialCompanyId??0;DateBox.Text=PersianDateService.ToPersian(DateTime.Today);DueBox.Text=PersianDateService.ToPersian(DateTime.Today.AddDays(30));loading=false;}
    int? FilterCompanyId=>CompanyBox.SelectedValue is int id&&id>0?id:null;
    void Populate(Row r){EditingInvoiceId=r.Id;SaveInvoiceButton.Content="ذخیره‌ی ویرایش فاکتور";SaveInvoiceButton.Background=AppTheme.Brand600;suppressCompanyChange=true;NumberBox.Text=r.Number;CompanyBox.SelectedValue=r.Company?.Id??0;suppressCompanyChange=false;DateBox.Text=r.InvoiceDatePersian;DueBox.Text=r.DueDatePersian;AmountBox.Text=r.Amount.ToString("0.##");ReturnedBox.Text=r.Returned==0?"":r.Returned.ToString("0.##");NoteBox.Text=r.Note??"";}
    async Task Load()
    {
        _loaded = await S.GetInvoicesAsync(FilterCompanyId, includePayments: false);
        Rebuild();
    }

    // فیلتر «سررسیدهای باز» و جستجو روی فهرست بارگذاری‌شده (بدون رفتن به دیتابیس) اعمال می‌شود.
    void Rebuild()
    {
        Rows.Clear();
        IEnumerable<Invoice> list = _loaded;
        if (DueOnlyBox.IsChecked == true) list = list.Where(x => AccountingService.Balance(x) > 0).OrderBy(x => x.DueDate);
        var q = SearchBox.Text.Trim();
        if (q.Length > 0) list = list.Where(x => InvoiceSearch.Matches(x, q));
        foreach (var x in list)
        {
            var row = new Row(x);
            row.PropertyChanged += (s, e) => { if (e.PropertyName == nameof(Row.Selected)) Dispatcher.BeginInvoke(UpdateSummary); };
            Rows.Add(row);
        }
        G.ItemsSource = Rows;
        UpdateSummary();
    }
    void UpdateSummary(){
        var selected=Rows.Where(x=>x.Selected).ToList();
        if(selected.Count==0){Summary.Text="هیچ فاکتوری انتخاب نشده است";return;}
        var summary=HesabGara.Domain.FinanceRules.Summarize(selected.Select(x=>(x.NetAmount,x.Paid,x.DueDateValue)));
        var weighted=summary.WeightedDate.HasValue ? PersianDateService.ToPersian(summary.WeightedDate.Value) : "—";
        var days=summary.WeightedDate.HasValue ? $"{summary.WeightedDays:N1} روز" : "—";
        Summary.Text=$"انتخاب: {selected.Count:N0} فاکتور   |   جمع: {summary.Total:N0} ریال   |   پرداختی: {summary.Paid:N0} ریال   |   مانده: {summary.Balance:N0} ریال   |   سررسید وزنی: {weighted} ({days})";
    }
    async void AddInvoice(object? s,RoutedEventArgs e){try{if(CompanyBox.SelectedValue is not int cid||cid<=0)throw new ArgumentException("شرکت را انتخاب کنید.");var inv=new Invoice{CompanyId=cid,Number=NumberBox.Text.Trim(),InvoiceDate=ParseDate(DateBox.Text),DueDate=ParseDate(DueBox.Text),Amount=decimal.Parse(AmountBox.Text.Replace(",","")),ReturnedAmount=ParseMoney(ReturnedBox.Text),Note=NoteBox.Text};if(EditingInvoiceId is int eid)inv.Id=eid; if(inv.Id>0)await S.UpdateInvoiceAsync(inv);else await S.AddInvoiceAsync(inv);ClearForm();await Load();}catch(Exception ex){MessageBox.Show(ex.Message,"ثبت فاکتور",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    static DateTime ParseDate(string text){if(PersianDateService.TryParse(text,out var d))return d;throw new ArgumentException("تاریخ را به صورت ۱۴۰۵/۰۵/۲۳ وارد کنید.");}
    async void DeleteInvoice(object? s,RoutedEventArgs e){if(G.SelectedItem is not Row r){MessageBox.Show("یک فاکتور را انتخاب کنید.");return;}if(MessageBox.Show($"فاکتور «{r.Number}» حذف شود؟","تأیید حذف",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;try{await S.DeleteInvoiceAsync(r.Id);ClearForm();SelectedInvoiceId=null;await Load();await LoadPaymentsForSelected();}catch(Exception ex){MessageBox.Show(ex.Message,"حذف فاکتور",MessageBoxButton.OK,MessageBoxImage.Warning);}}

    // برای حالتی که یک چک/پرداخت واحد، مجموع چند فاکتور را پوشش می‌دهد: فاکتورهای انتخاب‌شده
    // (تیک‌خورده در ستون «انتخاب») را می‌گیرد، یک فرم پرداخت مشترک نشان می‌دهد و مبلغ کل را
    // بین آن‌ها (نزدیک‌ترین سررسید اول) تقسیم می‌کند.
    // ثبت وصول برای یک یا چند فاکتور (فاکتورهای تیک‌خورده، یا فاکتور انتخاب‌شده در جدول) با یک یا چند پرداخت
    async void RegisterMultiPayment(object? sender, RoutedEventArgs e)
    {
        var selected = Rows.Where(x=>x.Selected).ToList();
        if (selected.Count == 0 && G.SelectedItem is Row current) selected.Add(current);
        if (selected.Count == 0) { MessageBox.Show("ابتدا یک یا چند فاکتور را از ستون «انتخاب» تیک بزنید (یا یک فاکتور را در جدول انتخاب کنید)."); return; }
        var payable = selected.Where(x=>x.Balance > 0).ToList();
        if (payable.Count == 0) { MessageBox.Show("فاکتورهای انتخاب‌شده مانده‌ی قابل‌وصولی ندارند."); return; }
        var win = new MultiPaymentWindow(payable.Select(x => new MultiPaymentWindow.InvoiceInfo(x.Id, x.Number, x.Balance)).ToList()) { Owner = Window.GetWindow(this) };
        if (win.ShowDialog() != true) return;
        await Load(); await LoadPaymentsForSelected();
        var detail = string.Join("\n", win.Allocations.Select(a => $"• {a.InvoiceNumber}: {a.Amount:N0} ریال"));
        MessageBox.Show($"{win.PaymentCount:N0} پرداخت ثبت شد و روی فاکتورها این‌طور نشست:\n\n{detail}", "ثبت وصول", MessageBoxButton.OK, MessageBoxImage.Information);
    }

    // مبلغ خالص زنده‌ی فرم: مبلغ کل − مرجوعی (قرمز اگر مرجوعی از مبلغ کل بیشتر شود)
    void UpdateNet()
    {
        var total = ParseMoney(AmountBox.Text); var returned = ParseMoney(ReturnedBox.Text);
        NetBox.Text = total == 0 && returned == 0 ? "" : (total - returned).ToString("N0");
        NetBox.Foreground = returned > total ? Brushes.Firebrick : AppTheme.Ink900;
    }

    static decimal ParseMoney(string? text)
    {
        var t = (text ?? "").Replace(",", "").Replace("٬", "").Trim();
        return decimal.TryParse(t, NumberStyles.Number, CultureInfo.InvariantCulture, out var v) ? v : 0m;
    }

    void ClearForm(){NumberBox.Clear();AmountBox.Clear();ReturnedBox.Clear();NetBox.Clear();NoteBox.Clear();DateBox.Text=PersianDateService.ToPersian(DateTime.Today);DueBox.Text=PersianDateService.ToPersian(DateTime.Today.AddDays(30));EditingInvoiceId=null;SaveInvoiceButton.Content="＋ ثبت / ذخیره";SaveInvoiceButton.Background=AppTheme.Success600;G.UnselectAll();}


    sealed class PaymentRow
    {
        public Payment Payment { get; }
        public int Id => Payment.Id;
        public decimal Amount => Payment.Amount;
        public string PayDate => PersianDateService.ToPersian(Payment.PayDate);
        public string PaymentMethod => Payment.PaymentMethod;
        public string CheckStatus => Payment.PaymentMethod=="چک" ? (Payment.CheckStatus ?? "—") : "—";
        public int ImageCount { get; set; }
        public string Images => ImageCount > 0 ? $"📎 {ImageCount}" : "";
        public PaymentRow(Payment payment) => Payment = payment;
    }
}
