﻿using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public class PaymentsView : Grid
{
    readonly AccountingService S;
    readonly int? CompanyId;
    readonly ComboBox InvoiceBox = new();
    readonly TextBox Amount = new();
    readonly ComboBox MethodBox = new();
    readonly TextBox CheckNumberBox = new();
    readonly DatePicker CheckDateBox = new();
    readonly ComboBox CheckStatusBox = new();
    readonly TextBox NoteBox = new();
    readonly DataGrid G = new();

    public PaymentsView(AccountingService s, int? companyId = null)
    {
        S = s;
        CompanyId = companyId;
        Build();
        Loaded += async (_, _) => await Load();
    }

    void Build()
    {
        FlowDirection = FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(190) });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        var form = new Border
        {
            Background=Brushes.White, BorderBrush=new SolidColorBrush(Color.FromRgb(224,232,240)),
            BorderThickness=new Thickness(1), CornerRadius=new CornerRadius(14),
            Padding=new Thickness(14), Margin=new Thickness(0,0,0,10)
        };
        var g=new Grid { FlowDirection=FlowDirection.RightToLeft };
        for(int i=0;i<3;i++) g.ColumnDefinitions.Add(new ColumnDefinition { Width=new GridLength(1,GridUnitType.Star) });
        for(int i=0;i<3;i++) g.RowDefinitions.Add(new RowDefinition { Height=new GridLength(54) });

        InvoiceBox.Height=38; Amount.Height=38; MethodBox.Height=38; CheckNumberBox.Height=38; CheckDateBox.Height=38; CheckStatusBox.Height=38; NoteBox.Height=38;
        InvoiceBox.Margin=Amount.Margin=MethodBox.Margin=CheckNumberBox.Margin=CheckDateBox.Margin=CheckStatusBox.Margin=NoteBox.Margin=new Thickness(4);

        MethodBox.ItemsSource=new[]{"نقد","کارت‌به‌کارت","چک","ترکیبی"}; MethodBox.SelectedIndex=0; MethodBox.SelectionChanged+=(_,_)=>UpdateCheckFields();
        CheckNumberBox.ToolTip="اختیاری؛ می‌توانید شماره چک را بعداً تکمیل کنید.";
        CheckDateBox.SelectedDateFormat=DatePickerFormat.Short;
        CheckStatusBox.ItemsSource=new[]{"در انتظار وصول","وصول‌شده","برگشتی","لغوشده"}; CheckStatusBox.SelectedIndex=0;

        AddLabeled(g,"فاکتور",InvoiceBox,0,0);
        AddLabeled(g,"مبلغ (ریال)",Amount,0,1);
        AddLabeled(g,"روش وصول",MethodBox,0,2);
        AddLabeled(g,"شماره چک (اختیاری)",CheckNumberBox,1,0);
        AddLabeled(g,"تاریخ چک (اختیاری)",CheckDateBox,1,1);
        AddLabeled(g,"وضعیت چک",CheckStatusBox,1,2);
        AddLabeled(g,"توضیحات",NoteBox,2,0);

        var buttons=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Left,VerticalAlignment=VerticalAlignment.Center,FlowDirection=FlowDirection.RightToLeft};
        var add=new Button{Content="＋ ثبت وصول",Margin=new Thickness(4),Padding=new Thickness(16,8,16,8),Background=new SolidColorBrush(Color.FromRgb(18,168,90)),Foreground=Brushes.White,BorderThickness=new Thickness(0),FontWeight=FontWeights.SemiBold}; add.Click+=Add;
        var del=new Button{Content="حذف وصول",Margin=new Thickness(4),Padding=new Thickness(16,8,16,8),Background=new SolidColorBrush(Color.FromRgb(255,241,242)),Foreground=new SolidColorBrush(Color.FromRgb(190,45,65)),BorderThickness=new Thickness(0),FontWeight=FontWeights.SemiBold}; del.Click+=Delete;
        buttons.Children.Add(add); buttons.Children.Add(del);
        Grid.SetColumn(buttons,2); Grid.SetRow(buttons,2); g.Children.Add(buttons);

        form.Child=g; Grid.SetRow(form,0); Children.Add(form);

        G.FlowDirection=FlowDirection.RightToLeft; G.AutoGenerateColumns=false; G.IsReadOnly=true; G.CanUserAddRows=false;
        G.SelectionMode=DataGridSelectionMode.Single; G.RowHeight=40; G.ColumnHeaderHeight=38; G.FontSize=12.5;
        G.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; G.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        G.Columns.Add(new DataGridTextColumn{Header="شناسه",Binding=new Binding("Id"),Width=75});
        G.Columns.Add(new DataGridTextColumn{Header="فاکتور",Binding=new Binding("Invoice.Number"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("Invoice.Company.Name"),Width=new DataGridLength(1.6,DataGridLengthUnitType.Star),MinWidth=150});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1.15,DataGridLengthUnitType.Star),MinWidth=125});
        G.Columns.Add(new DataGridTextColumn{Header="تاریخ وصول",Binding=new Binding("PayDate"),Width=115});
        G.Columns.Add(new DataGridTextColumn{Header="روش وصول",Binding=new Binding("PaymentMethod"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="شماره چک",Binding=new Binding("CheckNumber"),Width=115});
        G.Columns.Add(new DataGridTextColumn{Header="تاریخ چک",Binding=new Binding("CheckDate"),Width=115});
        G.Columns.Add(new DataGridTextColumn{Header="وضعیت چک",Binding=new Binding("CheckStatus"),Width=120});
        G.Columns.Add(new DataGridTextColumn{Header="توضیحات",Binding=new Binding("Note"),Width=new DataGridLength(1.2,DataGridLengthUnitType.Star),MinWidth=130});
        Grid.SetRow(G,1); Children.Add(G);
        UpdateCheckFields();
    }
    static void AddLabeled(Grid grid,string label,Control control,int row,int col)
    {
        var panel=new StackPanel{FlowDirection=FlowDirection.RightToLeft,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(4,0)};
        panel.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,FontSize=12.5,Foreground=new SolidColorBrush(Color.FromRgb(52,64,84)),Margin=new Thickness(0,0,0,3),TextAlignment=TextAlignment.Right});
        control.HorizontalAlignment=HorizontalAlignment.Stretch;
        panel.Children.Add(control);
        Grid.SetRow(panel,row); Grid.SetColumn(panel,col); grid.Children.Add(panel);
    }

    void UpdateCheckFields()
    {
        var isCheck = string.Equals(MethodBox.SelectedItem?.ToString(), "چک", StringComparison.Ordinal);
        CheckNumberBox.IsEnabled = isCheck;
        CheckDateBox.IsEnabled = isCheck;
        CheckStatusBox.IsEnabled = isCheck;
        if (!isCheck)
        {
            CheckNumberBox.Clear();
            CheckDateBox.SelectedDate = null;
            CheckStatusBox.SelectedIndex = 0;
        }
    }

    async Task Load()
    {
        var invoices = await S.GetInvoicesAsync(CompanyId);
        InvoiceBox.ItemsSource = invoices.Where(x => AccountingService.Balance(x) > 0).ToList();
        InvoiceBox.DisplayMemberPath = "Number";
        InvoiceBox.SelectedValuePath = "Id";

        var payments = await S.GetPaymentsAsync(CompanyId);
        G.ItemsSource = payments.Select(p => new PaymentRow(p)).ToList();
    }

    async void Add(object? sender, RoutedEventArgs e)
    {
        if (InvoiceBox.SelectedValue is not int id ||
            !decimal.TryParse(Amount.Text.Replace(",", "").Replace("٬", "").Trim(), NumberStyles.Number, CultureInfo.InvariantCulture, out var a) || a <= 0)
        {
            MessageBox.Show("فاکتور و مبلغ معتبر را انتخاب کنید.");
            return;
        }

        var method = MethodBox.SelectedItem?.ToString() ?? "نقد";
        try
        {
            await S.AddPaymentAsync(new Payment
            {
                InvoiceId = id,
                Amount = a,
                PayDate = DateTime.Today,
                PaymentMethod = method,
                CheckNumber = method == "چک" ? NullIfWhite(CheckNumberBox.Text) : null,
                CheckDate = method == "چک" ? CheckDateBox.SelectedDate?.Date : null,
                CheckStatus = method == "چک" ? CheckStatusBox.SelectedItem?.ToString() : null,
                Note = NullIfWhite(NoteBox.Text)
            });

            Amount.Clear();
            CheckNumberBox.Clear();
            CheckDateBox.SelectedDate = null;
            NoteBox.Clear();
            MethodBox.SelectedIndex = 0;
            await Load();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "ثبت وصول", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    async void Delete(object? sender, RoutedEventArgs e)
    {
        if (G.SelectedItem is not PaymentRow row)
        {
            MessageBox.Show("یک وصول را انتخاب کنید.");
            return;
        }

        var p = row.Payment;
        if (MessageBox.Show($"وصول {p.Amount:N0} حذف شود؟", "تأیید حذف", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;

        try
        {
            await S.DeletePaymentAsync(p.Id);
            await Load();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "حذف وصول", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    static string? NullIfWhite(string? value) => string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    sealed class PaymentRow
    {
        public Payment Payment { get; }
        public int Id => Payment.Id;
        public Invoice? Invoice => Payment.Invoice;
        public decimal Amount => Payment.Amount;
        public string PayDate => PersianDateService.ToPersian(Payment.PayDate);
        public string PaymentMethod => Payment.PaymentMethod;
        public string CheckNumber => Payment.CheckNumber ?? "—";
        public string CheckDate => Payment.CheckDate.HasValue ? PersianDateService.ToPersian(Payment.CheckDate.Value) : "—";
        public string CheckStatus => Payment.CheckStatus ?? "—";
        public string Note => Payment.Note ?? "";

        public PaymentRow(Payment payment) => Payment = payment;
    }
}
