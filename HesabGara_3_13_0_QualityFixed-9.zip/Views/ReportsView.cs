using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using Microsoft.Win32;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

// Reports and Due Dates live in one screen: a toggle at the top switches between "all
// invoices" and "open due dates" without opening a second window, so the sidebar's single
// "گزارش‌ها و سررسیدها" entry point actually covers both, instead of due-dates mode being
// reachable only through a separate, unwired code path.
public class ReportsView : Grid
{
    readonly AccountingService S; readonly int? InitialCompanyId;
    readonly DataGrid G=new(); readonly TextBlock Summary=new(); readonly TextBlock TitleText=new(); readonly ComboBox CompanyBox=new();
    readonly Button TabInvoices, TabDue;
    bool Due;

    public ReportsView(AccountingService s,int? c,bool due){S=s;InitialCompanyId=c;Due=due;Margin=new Thickness(18);Background=AppTheme.Surface100;
        TabInvoices=Tab("همه فاکتورها"); TabDue=Tab("سررسیدهای باز");
        TabInvoices.Click+=async(_,_)=>{Due=false;UpdateTabs();await Load();};
        TabDue.Click+=async(_,_)=>{Due=true;UpdateTabs();await Load();};
        Build();}
    public static async Task<ReportsView>Create(AccountingService s,int? c,bool due){var v=new ReportsView(s,c,due);await v.LoadCompanies();await v.Load();return v;}

    void Build()
    {
        FlowDirection=FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(82)});
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(46)});
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(58)});
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});

        var card=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,
            BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(12)};
        var bar=new Grid{FlowDirection=FlowDirection.RightToLeft};
        bar.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
        bar.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(2,GridUnitType.Star)});
        bar.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});

        var title=new StackPanel{VerticalAlignment=VerticalAlignment.Center};
        TitleText.FontSize=17; TitleText.FontWeight=FontWeights.Bold; TitleText.Foreground=AppTheme.Brand900;
        title.Children.Add(TitleText);
        title.Children.Add(new TextBlock{Text="گزارش مستقل برای شرکت انتخاب‌شده",FontSize=11.5,Foreground=AppTheme.Ink500,Margin=new Thickness(0,3,0,0)});
        Grid.SetColumn(title,0); bar.Children.Add(title);

        var companyPanel=new StackPanel{Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Center,VerticalAlignment=VerticalAlignment.Center,FlowDirection=FlowDirection.RightToLeft};
        companyPanel.Children.Add(new TextBlock{Text="شرکت:",VerticalAlignment=VerticalAlignment.Center,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink700,Margin=new Thickness(0,0,6,0)});
        CompanyBox.Width=230; CompanyBox.Height=38; CompanyBox.Margin=new Thickness(4);
        companyPanel.Children.Add(CompanyBox);
        var refresh=Btn("نمایش گزارش",AppTheme.Success600); refresh.Foreground=Brushes.White; refresh.Click+=async(_,_)=>await Load(); companyPanel.Children.Add(refresh);
        Grid.SetColumn(companyPanel,1); bar.Children.Add(companyPanel);

        var exp=Btn("خروجی Excel",AppTheme.Brand600); exp.Foreground=Brushes.White; exp.Click+=Export; exp.HorizontalAlignment=HorizontalAlignment.Left; exp.VerticalAlignment=VerticalAlignment.Center;
        Grid.SetColumn(exp,2); bar.Children.Add(exp);

        card.Child=bar; Grid.SetRow(card,0); Children.Add(card);

        // Toggle between the two report modes in the same screen instead of two separate windows.
        var tabs=new StackPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft,Margin=new Thickness(0,10,0,4)};
        tabs.Children.Add(TabInvoices); tabs.Children.Add(TabDue);
        Grid.SetRow(tabs,1); Children.Add(tabs);
        UpdateTabs();

        var sumCard=new Border{Background=AppTheme.Brand100,CornerRadius=new CornerRadius(11),Padding=new Thickness(12),Margin=new Thickness(0,0,0,8)};
        Summary.FontSize=12.5; Summary.FontWeight=FontWeights.SemiBold; Summary.Foreground=AppTheme.Ink900;
        Summary.TextWrapping=TextWrapping.Wrap; Summary.VerticalAlignment=VerticalAlignment.Center;
        sumCard.Child=Summary; Grid.SetRow(sumCard,2); Children.Add(sumCard);

        G.FlowDirection=FlowDirection.RightToLeft; G.AutoGenerateColumns=false; G.IsReadOnly=true; G.CanUserAddRows=false;
        G.RowHeight=40; G.ColumnHeaderHeight=38; G.FontSize=12.5; G.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; G.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        G.Columns.Add(new DataGridTextColumn{Header="شماره",Binding=new Binding("Number"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("Company.Name"),Width=new DataGridLength(1.8,DataGridLengthUnitType.Star),MinWidth=150});
        G.Columns.Add(new DataGridTextColumn{Header="تاریخ",Binding=new Binding("InvoiceDate"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1.2,DataGridLengthUnitType.Star),MinWidth=130});
        G.Columns.Add(new DataGridTextColumn{Header="پرداختی",Binding=new Binding("Paid"){StringFormat="{0:N0}"},Width=new DataGridLength(1.2,DataGridLengthUnitType.Star),MinWidth=130});
        G.Columns.Add(new DataGridTextColumn{Header="مانده",Binding=new Binding("Balance"){StringFormat="{0:N0}"},Width=new DataGridLength(1.2,DataGridLengthUnitType.Star),MinWidth=130});
        G.Columns.Add(new DataGridTextColumn{Header="سررسید",Binding=new Binding("Due"),Width=110});
        Grid.SetRow(G,3); Children.Add(G);
    }

    static Button Tab(string text)=>new Button{Content=text,Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,0,8,0),BorderThickness=new Thickness(0),FontWeight=FontWeights.SemiBold,Cursor=System.Windows.Input.Cursors.Hand};
    void UpdateTabs()
    {
        TitleText.Text = Due ? "گزارش سررسیدها" : "گزارش فاکتورها";
        SetTabState(TabInvoices, !Due);
        SetTabState(TabDue, Due);
    }
    static void SetTabState(Button b, bool active)
    {
        b.Background = active ? AppTheme.Brand600 : AppTheme.Surface100;
        b.Foreground = active ? Brushes.White : AppTheme.Ink900;
    }

    static Button Btn(string t,Brush bg)=>new Button{Content=t,Background=bg,BorderThickness=new Thickness(0),Padding=new Thickness(13,8,13,8),Margin=new Thickness(4),FontWeight=FontWeights.SemiBold};
    async Task LoadCompanies(){var list=await S.GetCompaniesAsync();var all=new List<Company>{new Company{Id=0,Name="همه شرکت‌ها"}};all.AddRange(list);CompanyBox.ItemsSource=all;CompanyBox.DisplayMemberPath="Name";CompanyBox.SelectedValuePath="Id";CompanyBox.SelectedValue=InitialCompanyId??0;}
    int? CompanyId=>CompanyBox.SelectedValue is int id&&id>0?id:null;
    async Task Load(){var rows=await S.GetInvoicesAsync(CompanyId);if(Due)rows=rows.Where(x=>AccountingService.Balance(x)>0).OrderBy(x=>x.DueDate).ToList();else rows=rows.OrderByDescending(x=>x.InvoiceDate).ToList();var sum=AccountingService.Summarize(rows);Summary.Text=$"شرکت: {(CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها"}   |   تعداد: {rows.Count:N0}   |   جمع: {sum.TotalAmount:N0}   |   پرداختی: {sum.TotalPaid:N0}   |   مانده: {sum.TotalBalance:N0}   |   میانگین سررسید: {(sum.WeightedDueDate.HasValue?PersianDateService.ToPersian(sum.WeightedDueDate.Value):"—")}";G.ItemsSource=rows.Select(x=>new{x.Number,x.Company,InvoiceDate=PersianDateService.ToPersian(x.InvoiceDate),x.Amount,x.Paid,Balance=AccountingService.Balance(x),Due=PersianDateService.ToPersian(x.DueDate)}).ToList();}
    async void Export(object? sender,RoutedEventArgs e){var d=new SaveFileDialog{Filter="Excel Workbook|*.xlsx",FileName=$"report-{(CompanyId.HasValue?CompanyId.Value.ToString():"all")}-{DateTime.Now:yyyyMMdd-HHmm}.xlsx"};if(d.ShowDialog()!=true)return;try{await new ExcelService().ExportAsync(d.FileName,CompanyId);MessageBox.Show("گزارش شرکت انتخاب‌شده با موفقیت ذخیره شد.","خروجی Excel",MessageBoxButton.OK,MessageBoxImage.Information);}catch(Exception ex){MessageBox.Show(ex.Message,"خروجی",MessageBoxButton.OK,MessageBoxImage.Error);}}
}
