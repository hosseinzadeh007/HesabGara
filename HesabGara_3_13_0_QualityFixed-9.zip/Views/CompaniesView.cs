using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public class CompaniesView : Grid
{
    readonly AccountingService S;
    readonly Func<Task> Reload;
    readonly TextBox NameBox = new(), NidBox = new(), PhoneBox = new(), NoteBox = new();
    readonly DataGrid G = new();
    bool editing;

    public CompaniesView(AccountingService s, Func<Task> r)
    {
        S = s; Reload = r; Margin = new Thickness(18); Background = AppTheme.Surface100;
        Build(); Loaded += async (_, _) => await Load();
    }

    void Build()
    {
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(175) });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(58) });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        var form = new Border { Background = Brushes.White, BorderBrush = AppTheme.Line200, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(16), Padding = new Thickness(18), Margin = new Thickness(0,0,0,10) };
        var g = new Grid();
        for (int i=0;i<5;i++) g.ColumnDefinitions.Add(new ColumnDefinition());
        g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(42) });
        g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(72) });
        var title = new StackPanel { Orientation = Orientation.Horizontal };
        title.Children.Add(new TextBlock { Text = "مشخصات شرکت", FontSize = 18, FontWeight = FontWeights.Bold, Foreground = AppTheme.Brand900, VerticalAlignment = VerticalAlignment.Center });
        title.Children.Add(new TextBlock { Text = "   اطلاعاتی که در فاکتور و گزارش‌ها نمایش داده می‌شود", Foreground = AppTheme.Ink500, VerticalAlignment = VerticalAlignment.Center });
        Grid.SetColumnSpan(title,5); g.Children.Add(title);
        AddField(g, "نام شرکت *", NameBox, 0, 1); AddField(g, "شناسه ملی", NidBox, 1, 1); AddField(g, "تلفن", PhoneBox, 2, 1); AddField(g, "توضیحات", NoteBox, 3, 1);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center };
        var save = Button("＋ ثبت شرکت", AppTheme.Success600); save.Foreground = Brushes.White; save.Click += AddOrUpdate;
        var clear = Button("پاک کردن", AppTheme.Surface100); clear.Foreground = AppTheme.Ink900; clear.Click += (_,_) => Clear();
        var del = Button("حذف", AppTheme.Danger100); del.Foreground = AppTheme.Danger600; del.Click += Delete;
        buttons.Children.Add(save); buttons.Children.Add(clear); buttons.Children.Add(del); Grid.SetColumn(buttons,4); g.Children.Add(buttons);
        form.Child=g; Grid.SetRow(form,0); Children.Add(form);

        var hint = new Border { Background = AppTheme.Brand100, CornerRadius = new CornerRadius(10), Padding = new Thickness(14,8,14,8), Margin = new Thickness(0,0,0,8) };
        hint.Child = new TextBlock { Text = "راهنما: ابتدا نام شرکت را وارد کنید؛ شناسه ملی، تلفن و توضیحات در همین فرم ثبت می‌شوند. برای ویرایش، یک ردیف را انتخاب کنید.", Foreground = AppTheme.Brand700 };
        Grid.SetRow(hint,1); Children.Add(hint);

        G.AutoGenerateColumns=false; G.IsReadOnly=true; G.SelectionMode=DataGridSelectionMode.Single; G.SelectionUnit=DataGridSelectionUnit.FullRow; G.Margin=new Thickness(0,0,0,0);
        G.Columns.Add(new DataGridTextColumn{Header="شناسه",Binding=new System.Windows.Data.Binding("Id"),Width=70});
        G.Columns.Add(new DataGridTextColumn{Header="نام شرکت",Binding=new System.Windows.Data.Binding("Name"),Width=new DataGridLength(2,DataGridLengthUnitType.Star)});
        G.Columns.Add(new DataGridTextColumn{Header="شناسه ملی",Binding=new System.Windows.Data.Binding("NationalId"),Width=170});
        G.Columns.Add(new DataGridTextColumn{Header="تلفن",Binding=new System.Windows.Data.Binding("Phone"),Width=160});
        G.Columns.Add(new DataGridTextColumn{Header="توضیحات",Binding=new System.Windows.Data.Binding("Note"),Width=new DataGridLength(2,DataGridLengthUnitType.Star)});
        G.SelectionChanged += (_,_) => { if(G.SelectedItem is Company c){ editing=true; NameBox.Text=c.Name; NidBox.Text=c.NationalId??""; PhoneBox.Text=c.Phone??""; NoteBox.Text=c.Note??""; } };
        Grid.SetRow(G,2); Children.Add(G);
    }

    static void AddField(Grid g,string label,TextBox box,int col,int row)
    {
        var p=new StackPanel{Margin=new Thickness(5,0,5,0)}; p.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink700});
        box.Height=40; box.Margin=new Thickness(0,5,0,0); p.Children.Add(box); Grid.SetColumn(p,col); Grid.SetRow(p,row); g.Children.Add(p);
    }
    static Button Button(string text,Brush bg){return new Button{Content=text,Background=bg,BorderThickness=new Thickness(0),Padding=new Thickness(13,8,13,8),Margin=new Thickness(4),FontWeight=FontWeights.SemiBold,Cursor=System.Windows.Input.Cursors.Hand};}

    async void AddOrUpdate(object? s,RoutedEventArgs e)
    {
        if(string.IsNullOrWhiteSpace(NameBox.Text)){MessageBox.Show("نام شرکت را وارد کنید.","ثبت شرکت",MessageBoxButton.OK,MessageBoxImage.Information);return;}
        try{
            if(editing && G.SelectedItem is Company c) await S.UpdateCompanyAsync(new Company{Id=c.Id,Name=NameBox.Text,NationalId=NidBox.Text,Phone=PhoneBox.Text,Note=NoteBox.Text});
            else await S.AddCompanyAsync(new Company{Name=NameBox.Text.Trim(),NationalId=string.IsNullOrWhiteSpace(NidBox.Text)?null:NidBox.Text.Trim(),Phone=PhoneBox.Text.Trim(),Note=NoteBox.Text.Trim()});
            Clear(); await Load(); await Reload();
        }catch(Exception ex){MessageBox.Show(ex.Message,"ثبت شرکت",MessageBoxButton.OK,MessageBoxImage.Warning);}
    }
    async void Delete(object? s,RoutedEventArgs e){if(G.SelectedItem is not Company c){MessageBox.Show("یک شرکت را انتخاب کنید.");return;}if(MessageBox.Show($"شرکت «{c.Name}» حذف شود؟","تأیید حذف",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;try{await S.DeleteCompanyAsync(c.Id);Clear();await Load();await Reload();}catch(Exception ex){MessageBox.Show(ex.Message,"حذف شرکت",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    void Clear(){NameBox.Clear();NidBox.Clear();PhoneBox.Clear();NoteBox.Clear();G.UnselectAll();editing=false;}
    async Task Load(){G.ItemsSource=await S.GetCompaniesAsync();}
}
