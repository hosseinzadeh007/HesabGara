using System.Text.Json;

namespace AccountingPurchasePro.Services;

public enum DatabaseProvider { Sqlite, SqlServer }

public sealed class DatabaseConfiguration
{
    public DatabaseProvider Provider { get; set; } = DatabaseProvider.Sqlite;
    public string ConnectionString { get; set; } = "";
    public bool IsNetworkMode => Provider == DatabaseProvider.SqlServer;
}

public static class DatabaseConfigurationStore
{
    public static string DirectoryPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabYar");
    public static string FilePath => Path.Combine(DirectoryPath, "database.json");

    public static DatabaseConfiguration Load()
    {
        try
        {
            if (!File.Exists(FilePath)) return new();
            var json = File.ReadAllText(FilePath);
            return JsonSerializer.Deserialize<DatabaseConfiguration>(json) ?? new();
        }
        catch { return new(); }
    }

    public static void Save(DatabaseConfiguration config)
    {
        Directory.CreateDirectory(DirectoryPath);
        var json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
        var temp = FilePath + ".tmp";
        File.WriteAllText(temp, json);
        File.Move(temp, FilePath, true);
    }
}
