﻿using System.Windows;
using AccountingPurchasePro.Data;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        AppFileLogger.Info("شروع حساب‌گرا.");
        ShutdownMode = ShutdownMode.OnExplicitShutdown;
        base.OnStartup(e);
        DispatcherUnhandledException += (_, args) =>
        {
            AppFileLogger.Error("خطای UI مدیریت‌نشده.", args.Exception);
            MessageBox.Show($"خطای غیرمنتظره رخ داد:\n{args.Exception.Message}", "خطای نرم‌افزار", MessageBoxButton.OK, MessageBoxImage.Error);
            args.Handled = true;
        };
        try
        {
            AppFileLogger.Info($"نسخه {typeof(App).Assembly.GetName().Version?.ToString(3)}");
            // First-run deployment wizard: choose local SQLite or network SQL Server before database initialization.
            if (!File.Exists(DatabaseConfigurationStore.FilePath))
            {
                var setup = new Views.SetupWizardWindow();
                if (setup.ShowDialog() != true || !setup.Completed) { Shutdown(0); return; }
            }
            DatabaseInitializer.Initialize();
            new AccountingService().ReconcilePaidAmountsAsync().GetAwaiter().GetResult();
            var login = new Views.LoginWindow();
            if (login.ShowDialog() != true || login.AuthenticatedUser is null) { Shutdown(0); return; }
            UserSession.Start(login.AuthenticatedUser);
            var main = new Views.MainWindow(login.AuthenticatedUser);
            main.Closed += (_, _) => { UserSession.Clear(); Shutdown(0); };
            main.Show();
        }
        catch (Exception ex)
        {
            AppFileLogger.Error("خطا در راه‌اندازی برنامه.", ex);
            MessageBox.Show($"راه‌اندازی پایگاه داده انجام نشد:\n{ex.Message}", "خطای راه‌اندازی", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(-1);
        }
    }
}
