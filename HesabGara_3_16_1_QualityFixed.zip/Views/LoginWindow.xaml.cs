using System.Windows;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public partial class LoginWindow : Window
{
    readonly SecurityService Security = new();
    public AppUser? AuthenticatedUser { get; private set; }
    bool firstRun;

    public LoginWindow()
    {
        InitializeComponent();
        PreviewKeyDown += (_, e) => { if (e.Key == System.Windows.Input.Key.Enter) Action_Click(this, new RoutedEventArgs()); };
        Loaded += async (_, _) =>
        {
            firstRun = !await Security.HasUsersAsync();
            if (firstRun)
            {
                ModeText.Text = "برای راه‌اندازی، مدیر اولیه را ایجاد کنید.";
                ActionButton.Content = "ایجاد مدیر و ورود";
                DisplayPanel.Visibility = Visibility.Visible;
                ConfirmPanel.Visibility = Visibility.Visible;
                SecuritySetupPanel.Visibility = Visibility.Visible;
                ForgotPasswordLink.Visibility = Visibility.Collapsed; // nothing to recover yet
                HintText.Text = "برای امنیت، رمز عبور حداقل ۸ کاراکتر باشد و سؤال امنیتی را حتماً انتخاب کنید.";
            }
            UserNameBox.Focus();
        };
    }

    async void Action_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (firstRun)
            {
                if (PasswordBox.Password != ConfirmBox.Password) throw new InvalidOperationException("تکرار رمز عبور یکسان نیست.");
                var question = (SecurityQuestionBox.Text ?? "").Trim();
                AuthenticatedUser = await Security.CreateFirstAdminAsync(UserNameBox.Text, DisplayNameBox.Text, PasswordBox.Password, question, SecurityAnswerBox.Text);
            }
            else AuthenticatedUser = await Security.LoginAsync(UserNameBox.Text, PasswordBox.Password);
            if (AuthenticatedUser is null) { HintText.Text = "نام کاربری یا رمز عبور صحیح نیست."; return; }
            DialogResult = true;
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "ورود", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    // --- بازیابی رمز عبور با سؤال امنیتی ---

    void ForgotPassword_Click(object sender, RoutedEventArgs e)
    {
        LoginPanel.Visibility = Visibility.Collapsed;
        RecoveryPanel.Visibility = Visibility.Visible;
        RecoveryAnswerPanel.Visibility = Visibility.Collapsed;
        RecoveryUserNameBox.Text = UserNameBox.Text;
        ModeText.Text = "برای بازیابی رمز، ابتدا نام کاربری خود را وارد کنید.";
        HintText.Text = "";
        RecoveryUserNameBox.Focus();
    }

    void BackToLogin_Click(object sender, RoutedEventArgs e)
    {
        RecoveryPanel.Visibility = Visibility.Collapsed;
        LoginPanel.Visibility = Visibility.Visible;
        ModeText.Text = "برای ادامه، اطلاعات کاربری خود را وارد کنید.";
        HintText.Text = "";
        UserNameBox.Focus();
    }

    async void RecoveryFind_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var question = await Security.GetSecurityQuestionAsync(RecoveryUserNameBox.Text);
            if (question is null)
            {
                // Deliberately generic: doesn't reveal whether the account exists at all or
                // simply never set up a security question, and points to the one path that
                // always works (an admin resetting the password from User Management).
                MessageBox.Show("بازیابی رمز برای این حساب در دسترس نیست. لطفاً با مدیر سیستم تماس بگیرید تا رمز شما را از بخش «کاربران و دسترسی» بازنشانی کند.", "بازیابی رمز", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            RecoveryQuestionText.Text = question;
            RecoveryAnswerPanel.Visibility = Visibility.Visible;
            RecoveryAnswerBox.Focus();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "بازیابی رمز", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    async void RecoveryReset_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (RecoveryNewPasswordBox.Password != RecoveryConfirmPasswordBox.Password) throw new InvalidOperationException("تکرار رمز عبور جدید یکسان نیست.");
            await Security.ResetPasswordViaSecurityAnswerAsync(RecoveryUserNameBox.Text, RecoveryAnswerBox.Text, RecoveryNewPasswordBox.Password);
            MessageBox.Show("رمز عبور با موفقیت بازنشانی شد. اکنون می‌توانید با رمز جدید وارد شوید.", "بازیابی رمز", MessageBoxButton.OK, MessageBoxImage.Information);
            UserNameBox.Text = RecoveryUserNameBox.Text;
            PasswordBox.Password = "";
            RecoveryAnswerBox.Clear(); RecoveryNewPasswordBox.Password = ""; RecoveryConfirmPasswordBox.Password = "";
            BackToLogin_Click(sender, e);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "بازیابی رمز", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }
}
