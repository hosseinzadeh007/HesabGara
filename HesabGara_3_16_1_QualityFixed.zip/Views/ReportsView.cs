using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using Microsoft.Win32;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

// Full reports module: four report types (invoice summary, payments log, per-company
// summary, checks-in-progress) sharing one filter bar (company / date range / status),
// plus Excel export and print. The "open due dates" filter still lives in Invoices.
public class ReportsView : Grid
{
    readonly AccountingService S; readonly int? InitialCompanyId;
    readonly DataGrid G=new(); readonly TextBlock Summary=new(); readonly TextBlock TitleText=new();
    readonly ComboBox CompanyBox=new(), StatusBox=new(), PresetBox=new();
    readonly TextBox FromDateBox=new(), ToDateBox=new();
    readonly Button TabInvoices, TabPayments, TabByCompany, TabChecks, PrintBtn;
    ReportTab _tab = ReportTab.Invoices;
    enum ReportTab { Invoices, Payments, ByCompany, Checks }
    List<Invoice> _lastInvoiceRows = new();

    public ReportsView(AccountingService s,int? c)
    {
        S=s; InitialCompanyId=c; Margin=new Thickness(18); Background=AppTheme.Surface100;
        TabInvoices=TabButton("خلاصه فاکتورها"); TabPayments=TabButton("گزارش پرداخت‌ها"); TabByCompany=TabButton("خلاصه بر اساس شرکت"); TabChecks=TabButton("چک‌های در جریان");
        TabInvoices.Click+=async(_,_)=>{_tab=ReportTab.Invoices;UpdateTabs();await Load();};
        TabPayments.Click+=async(_,_)=>{_tab=ReportTab.Payments;UpdateTabs();await Load();};
        TabByCompany.Click+=async(_,_)=>{_tab=ReportTab.ByCompany;UpdateTabs();await Load();};
        TabChecks.Click+=async(_,_)=>{_tab=ReportTab.Checks;UpdateTabs();await Load();};
        PrintBtn=Btn("چاپ گزارش",AppTheme.Ink700); PrintBtn.Foreground=Brushes.White; PrintBtn.Click+=Print;
        Build();
    }
    public static async Task<ReportsView>Create(AccountingService s,int? c){var v=new ReportsView(s,c);await v.LoadCompanies();await v.Load();return v;}

    void Build()
    {
        FlowDirection=FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});   // header + tabs
        RowDefinitions.Add(new RowDefinition{Height=GridLength.Auto});   // filter bar
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(58)}); // summary
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)}); // grid

        // --- Header + tabs ---
        var headerCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(14)};
        var headerStack=new StackPanel();
        TitleText.Text="گزارش‌ها"; TitleText.FontSize=17; TitleText.FontWeight=FontWeights.Bold; TitleText.Foreground=AppTheme.Brand900;
        headerStack.Children.Add(TitleText);
        var tabsRow=new StackPanel{Orientation=Orientation.Horizontal,Margin=new Thickness(0,10,0,0)};
        tabsRow.Children.Add(TabInvoices); tabsRow.Children.Add(TabPayments); tabsRow.Children.Add(TabByCompany); tabsRow.Children.Add(TabChecks);
        headerStack.Children.Add(tabsRow);
        headerCard.Child=headerStack; Grid.SetRow(headerCard,0); Children.Add(headerCard);
        UpdateTabs();

        // --- Filter bar ---
        var filterCard=new Border{Background=Brushes.White,BorderBrush=AppTheme.Line200,BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(14),Padding=new Thickness(14),Margin=new Thickness(0,8,0,0)};
        var filters=new WrapPanel{Orientation=Orientation.Horizontal,FlowDirection=FlowDirection.RightToLeft};

        filters.Children.Add(LabeledField("شرکت", CompanyBox, 210));
        CompanyBox.Height=38;

        PresetBox.ItemsSource=new[]{"همه","امروز","۷ روز اخیر","این ماه (شمسی)","سه‌ماه اخیر","امسال (شمسی)","بازه‌ی دلخواه"};
        PresetBox.SelectedIndex=0; PresetBox.SelectionChanged+=(_,_)=>ApplyPreset();
        filters.Children.Add(LabeledField("بازه‌ی زمانی", PresetBox, 160));

        FromDateBox.ToolTip="مثال: 1405/01/01"; ToDateBox.ToolTip="مثال: 1405/06/25";
        filters.Children.Add(LabeledField("از تاریخ", FromDateBox, 120));
        filters.Children.Add(LabeledField("تا تاریخ", ToDateBox, 120));

        StatusBox.ItemsSource=new[]{"همه وضعیت‌ها","تسویه شده","بخشی پرداخت شده","پرداخت نشده"}; StatusBox.SelectedIndex=0;
        filters.Children.Add(LabeledField("وضعیت", StatusBox, 150));

        var showBtn=Btn("نمایش گزارش",AppTheme.Success600); showBtn.Foreground=Brushes.White; showBtn.VerticalAlignment=VerticalAlignment.Bottom; showBtn.Margin=new Thickness(4,0,4,4);
        showBtn.Click+=async(_,_)=>await Load();
        filters.Children.Add(showBtn);

        var expBtn=Btn("خروجی Excel",AppTheme.Brand600); expBtn.Foreground=Brushes.White; expBtn.VerticalAlignment=VerticalAlignment.Bottom; expBtn.Margin=new Thickness(4,0,4,4);
        expBtn.Click+=Export;
        filters.Children.Add(expBtn);

        PrintBtn.VerticalAlignment=VerticalAlignment.Bottom; PrintBtn.Margin=new Thickness(4,0,4,4);
        filters.Children.Add(PrintBtn);

        filterCard.Child=filters; Grid.SetRow(filterCard,1); Children.Add(filterCard);

        // --- Summary ---
        var sumCard=new Border{Background=AppTheme.Brand100,CornerRadius=new CornerRadius(11),Padding=new Thickness(12),Margin=new Thickness(0,8,0,8)};
        Summary.FontSize=12.5; Summary.FontWeight=FontWeights.SemiBold; Summary.Foreground=AppTheme.Ink900;
        Summary.TextWrapping=TextWrapping.Wrap; Summary.VerticalAlignment=VerticalAlignment.Center;
        sumCard.Child=Summary; Grid.SetRow(sumCard,2); Children.Add(sumCard);

        // --- Grid ---
        G.FlowDirection=FlowDirection.RightToLeft; G.AutoGenerateColumns=false; G.IsReadOnly=true; G.CanUserAddRows=false;
        G.RowHeight=40; G.ColumnHeaderHeight=38; G.FontSize=12.5; G.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; G.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        G.LoadingRow += G_LoadingRow;
        Grid.SetRow(G,3); Children.Add(G);
    }

    static StackPanel LabeledField(string label, Control box, double width)
    {
        var p=new StackPanel{Margin=new Thickness(4,0,4,4)};
        p.Children.Add(new TextBlock{Text=label,FontSize=11,FontWeight=FontWeights.SemiBold,Foreground=AppTheme.Ink500,Margin=new Thickness(2,0,2,3)});
        box.Width=width; box.Height=36;
        if (box is TextBox tb){tb.Padding=new Thickness(8,6,8,6);tb.VerticalContentAlignment=VerticalAlignment.Center;}
        p.Children.Add(box);
        return p;
    }
    static Button TabButton(string text)=>new Button{Content=text,Padding=new Thickness(16,8,16,8),Margin=new Thickness(0,0,8,0),BorderThickness=new Thickness(0),FontWeight=FontWeights.SemiBold,Cursor=System.Windows.Input.Cursors.Hand};
    void UpdateTabs()
    {
        SetTabState(TabInvoices,_tab==ReportTab.Invoices); SetTabState(TabPayments,_tab==ReportTab.Payments);
        SetTabState(TabByCompany,_tab==ReportTab.ByCompany); SetTabState(TabChecks,_tab==ReportTab.Checks);
        PrintBtn.Visibility = _tab==ReportTab.Invoices ? Visibility.Visible : Visibility.Collapsed;
    }
    static void SetTabState(Button b, bool active)
    {
        b.Background = active ? AppTheme.Brand600 : AppTheme.Surface100;
        b.Foreground = active ? Brushes.White : AppTheme.Ink700;
    }
    static Button Btn(string t,Brush bg)=>new Button{Content=t,Background=bg,BorderThickness=new Thickness(0),Padding=new Thickness(13,8,13,8),Margin=new Thickness(4),FontWeight=FontWeights.SemiBold};

    async Task LoadCompanies(){var list=await S.GetCompaniesAsync();var all=new List<Company>{new Company{Id=0,Name="همه شرکت‌ها"}};all.AddRange(list);CompanyBox.ItemsSource=all;CompanyBox.DisplayMemberPath="Name";CompanyBox.SelectedValuePath="Id";CompanyBox.SelectedValue=InitialCompanyId??0;}
    int? CompanyId=>CompanyBox.SelectedValue is int id&&id>0?id:null;

    void ApplyPreset()
    {
        var preset = PresetBox.SelectedItem as string;
        if (preset=="بازه‌ی دلخواه" || preset is null) return;
        var pc = new PersianCalendar(); var today = DateTime.Today;
        (DateTime from, DateTime to) range = preset switch
        {
            "امروز" => (today, today),
            "۷ روز اخیر" => (today.AddDays(-6), today),
            "این ماه (شمسی)" => MonthRange(pc, today),
            "سه‌ماه اخیر" => (today.AddDays(-90), today),
            "امسال (شمسی)" => (pc.ToDateTime(pc.GetYear(today),1,1,0,0,0,0), today),
            _ => (DateTime.MinValue, DateTime.MaxValue) // "همه"
        };
        FromDateBox.Text = range.from==DateTime.MinValue ? "" : PersianDateService.ToPersian(range.from);
        ToDateBox.Text = range.to==DateTime.MaxValue ? "" : PersianDateService.ToPersian(range.to);
    }
    static (DateTime,DateTime) MonthRange(PersianCalendar pc, DateTime today)
    {
        int y=pc.GetYear(today), m=pc.GetMonth(today);
        var from = pc.ToDateTime(y,m,1,0,0,0,0);
        var to = pc.ToDateTime(y,m,pc.GetDaysInMonth(y,m),0,0,0,0);
        return (from,to);
    }
    (DateTime? from, DateTime? to) ReadDateRange()
    {
        DateTime? from=null, to=null;
        if (!string.IsNullOrWhiteSpace(FromDateBox.Text)) { if (PersianDateService.TryParse(FromDateBox.Text, out var f)) from=f.Date; else MessageBox.Show("تاریخ «از» معتبر نیست. نمونه: 1405/01/01","فیلتر تاریخ",MessageBoxButton.OK,MessageBoxImage.Warning); }
        if (!string.IsNullOrWhiteSpace(ToDateBox.Text)) { if (PersianDateService.TryParse(ToDateBox.Text, out var t)) to=t.Date; else MessageBox.Show("تاریخ «تا» معتبر نیست. نمونه: 1405/06/25","فیلتر تاریخ",MessageBoxButton.OK,MessageBoxImage.Warning); }
        return (from,to);
    }
    static string StatusOf(Invoice x)
    {
        var balance = AccountingService.Balance(x);
        return balance<=0 ? "تسویه شده" : x.Paid>0 ? "بخشی پرداخت شده" : "پرداخت نشده";
    }

    async Task Load()
    {
        G.Columns.Clear();
        var (from,to) = ReadDateRange();
        switch(_tab)
        {
            case ReportTab.Invoices: await LoadInvoices(from,to); break;
            case ReportTab.Payments: await LoadPayments(from,to); break;
            case ReportTab.ByCompany: await LoadByCompany(from,to); break;
            case ReportTab.Checks: await LoadChecks(from,to); break;
        }
    }

    async Task LoadInvoices(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — خلاصه فاکتورها";
        var rows = await S.GetInvoicesAsync(CompanyId);
        if (from.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();
        var statusFilter = StatusBox.SelectedItem as string;
        if (!string.IsNullOrEmpty(statusFilter) && statusFilter!="همه وضعیت‌ها") rows = rows.Where(x=>StatusOf(x)==statusFilter).ToList();
        rows = rows.OrderByDescending(x=>x.InvoiceDate).ToList();
        _lastInvoiceRows = rows;

        var sum = AccountingService.Summarize(rows);
        Summary.Text = $"شرکت: {(CompanyBox.SelectedItem as Company)?.Name ?? "همه شرکت‌ها"}   |   تعداد: {rows.Count:N0}   |   جمع: {sum.TotalAmount:N0}   |   پرداختی: {sum.TotalPaid:N0}   |   مانده: {sum.TotalBalance:N0}   |   میانگین سررسید: {(sum.WeightedDueDate.HasValue?PersianDateService.ToPersian(sum.WeightedDueDate.Value):"—")}";

        G.Columns.Add(new DataGridTextColumn{Header="شماره",Binding=new Binding("Number"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("Company.Name"),Width=new DataGridLength(1.5,DataGridLengthUnitType.Star),MinWidth=140});
        G.Columns.Add(new DataGridTextColumn{Header="تاریخ فاکتور",Binding=new Binding("InvoiceDate"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="سررسید",Binding=new Binding("Due"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="پرداختی",Binding=new Binding("Paid"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="مانده",Binding=new Binding("Balance"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="وضعیت",Binding=new Binding("Status"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="تعداد پرداخت",Binding=new Binding("PaymentCount"),Width=95});
        G.Columns.Add(new DataGridTextColumn{Header="روش‌های پرداخت",Binding=new Binding("PaymentMethods"),Width=new DataGridLength(1.1,DataGridLengthUnitType.Star),MinWidth=130});
        G.Columns.Add(new DataGridTextColumn{Header="آخرین پرداخت",Binding=new Binding("LastPaymentDate"),Width=105});
        G.Columns.Add(new DataGridTextColumn{Header="توضیحات",Binding=new Binding("Note"),Width=new DataGridLength(1.2,DataGridLengthUnitType.Star),MinWidth=120});
        G.ItemsSource = rows.Select(x =>
        {
            var payments = x.Payments?.OrderBy(p => p.PayDate).ToList() ?? new List<Payment>();
            return new
            {
                x.Number, x.Company,
                InvoiceDate = PersianDateService.ToPersian(x.InvoiceDate),
                Due = PersianDateService.ToPersian(x.DueDate),
                x.Amount, x.Paid, Balance = AccountingService.Balance(x),
                Status = StatusOf(x),
                PaymentCount = payments.Count,
                PaymentMethods = payments.Count == 0 ? "—" : string.Join("، ", payments.Select(p => p.PaymentMethod).Distinct()),
                LastPaymentDate = payments.Count == 0 ? "—" : PersianDateService.ToPersian(payments.Last().PayDate),
                Note = string.IsNullOrWhiteSpace(x.Note) ? "—" : x.Note
            };
        }).ToList();
    }

    async Task LoadPayments(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — گزارش پرداخت‌ها";
        var payments = await S.GetPaymentsAsync(CompanyId);
        if (from.HasValue) payments = payments.Where(p=>p.PayDate.Date>=from.Value).ToList();
        if (to.HasValue) payments = payments.Where(p=>p.PayDate.Date<=to.Value).ToList();
        payments = payments.OrderByDescending(p=>p.PayDate).ToList();

        var total = payments.Sum(p=>p.Amount);
        var byMethod = payments.GroupBy(p=>p.PaymentMethod).Select(g=>$"{g.Key}: {g.Sum(x=>x.Amount):N0}");
        Summary.Text = $"تعداد وصول: {payments.Count:N0}   |   جمع مبالغ: {total:N0} ریال   |   {string.Join("   |   ", byMethod)}";

        G.Columns.Add(new DataGridTextColumn{Header="تاریخ وصول",Binding=new Binding("PayDate"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شماره فاکتور",Binding=new Binding("InvoiceNumber"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("CompanyName"),Width=new DataGridLength(1.4,DataGridLengthUnitType.Star),MinWidth=140});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="روش",Binding=new Binding("PaymentMethod"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شماره چک",Binding=new Binding("CheckNumber"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="وضعیت چک",Binding=new Binding("CheckStatus"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="توضیحات",Binding=new Binding("Note"),Width=new DataGridLength(1.2,DataGridLengthUnitType.Star),MinWidth=120});
        G.ItemsSource = payments.Select(p => new PayRow(
            PersianDateService.ToPersian(p.PayDate), p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-",
            p.Amount, p.PaymentMethod, p.CheckNumber ?? "—", p.CheckStatus ?? "—", string.IsNullOrWhiteSpace(p.Note)?"—":p.Note
        )).ToList();
    }

    async Task LoadByCompany(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — خلاصه بر اساس شرکت";
        var rows = await S.GetInvoicesAsync(null); // company summary always covers all companies
        if (from.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date>=from.Value).ToList();
        if (to.HasValue) rows = rows.Where(x=>x.InvoiceDate.Date<=to.Value).ToList();

        var groups = rows.Where(x=>x.Company!=null).GroupBy(x=>x.Company!.Name).Select(g=>
        {
            var bouncedCount = g.SelectMany(x=>x.Payments??new List<Payment>()).Count(p=>p.CheckStatus=="برگشتی");
            return new CompanyRow(g.Key, g.Count(), g.Sum(x=>x.Amount), g.Sum(x=>x.Paid), g.Sum(AccountingService.Balance), bouncedCount);
        }).OrderByDescending(c=>c.Balance).ToList();

        Summary.Text = $"تعداد شرکت: {groups.Count:N0}   |   جمع کل: {groups.Sum(x=>x.Amount):N0}   |   جمع پرداختی: {groups.Sum(x=>x.Paid):N0}   |   جمع مانده: {groups.Sum(x=>x.Balance):N0}";

        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("Name"),Width=new DataGridLength(1.6,DataGridLengthUnitType.Star),MinWidth=160});
        G.Columns.Add(new DataGridTextColumn{Header="تعداد فاکتور",Binding=new Binding("Count"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="جمع مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=120});
        G.Columns.Add(new DataGridTextColumn{Header="جمع پرداختی",Binding=new Binding("Paid"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=120});
        G.Columns.Add(new DataGridTextColumn{Header="جمع مانده",Binding=new Binding("Balance"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=120});
        G.Columns.Add(new DataGridTextColumn{Header="چک برگشتی",Binding=new Binding("BouncedChecks"),Width=100});
        G.ItemsSource = groups;
    }

    async Task LoadChecks(DateTime? from, DateTime? to)
    {
        TitleText.Text="گزارش‌ها — چک‌های در جریان";
        var payments = await S.GetPaymentsAsync(CompanyId);
        var checks = payments.Where(p=>p.PaymentMethod=="چک").ToList();
        if (from.HasValue) checks = checks.Where(p=>(p.CheckDate??p.PayDate).Date>=from.Value).ToList();
        if (to.HasValue) checks = checks.Where(p=>(p.CheckDate??p.PayDate).Date<=to.Value).ToList();
        // بحرانی‌ترین‌ها اول: برگشتی، بعد در انتظار وصول، بعد بقیه
        checks = checks.OrderBy(p=>p.CheckStatus=="برگشتی"?0:p.CheckStatus=="در انتظار وصول"?1:2).ThenByDescending(p=>p.PayDate).ToList();

        var bounced = checks.Count(p=>p.CheckStatus=="برگشتی");
        var pending = checks.Count(p=>p.CheckStatus=="در انتظار وصول");
        Summary.Text = $"تعداد کل چک: {checks.Count:N0}   |   برگشتی: {bounced:N0}   |   در انتظار وصول: {pending:N0}   |   جمع مبلغ چک‌ها: {checks.Sum(p=>p.Amount):N0} ریال";

        G.Columns.Add(new DataGridTextColumn{Header="تاریخ چک",Binding=new Binding("CheckDate"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شماره چک",Binding=new Binding("CheckNumber"),Width=100});
        G.Columns.Add(new DataGridTextColumn{Header="شماره فاکتور",Binding=new Binding("InvoiceNumber"),Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new Binding("CompanyName"),Width=new DataGridLength(1.4,DataGridLengthUnitType.Star),MinWidth=140});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new Binding("Amount"){StringFormat="{0:N0}"},Width=new DataGridLength(1,DataGridLengthUnitType.Star),MinWidth=110});
        G.Columns.Add(new DataGridTextColumn{Header="وضعیت",Binding=new Binding("CheckStatus"),Width=110});
        G.ItemsSource = checks.Select(p => new CheckRow(
            p.CheckDate.HasValue?PersianDateService.ToPersian(p.CheckDate.Value):"—", p.CheckNumber ?? "—",
            p.Invoice?.Number ?? "-", p.Invoice?.Company?.Name ?? "-", p.Amount, p.CheckStatus ?? "—"
        )).ToList();
    }

    void G_LoadingRow(object? sender, DataGridRowEventArgs e)
    {
        if (_tab != ReportTab.Checks || e.Row.Item is not CheckRow cr) { e.Row.Background = Brushes.White; return; }
        e.Row.Background = cr.CheckStatus switch
        {
            "برگشتی" => AppTheme.Danger100,
            "در انتظار وصول" => AppTheme.Warning100,
            _ => Brushes.White
        };
    }

    async void Export(object? sender,RoutedEventArgs e)
    {
        var d=new SaveFileDialog{Filter="Excel Workbook|*.xlsx",FileName=$"report-{(CompanyId.HasValue?CompanyId.Value.ToString():"all")}-{DateTime.Now:yyyyMMdd-HHmm}.xlsx"};
        if(d.ShowDialog()!=true)return;
        try{await new ExcelService().ExportAsync(d.FileName,CompanyId);MessageBox.Show("گزارش شرکت انتخاب‌شده با موفقیت ذخیره شد.","خروجی Excel",MessageBoxButton.OK,MessageBoxImage.Information);}
        catch(Exception ex){MessageBox.Show(ex.Message,"خروجی",MessageBoxButton.OK,MessageBoxImage.Error);}
    }

    void Print(object? sender, RoutedEventArgs e)
    {
        if (_tab!=ReportTab.Invoices) return;
        new PrintService().PrintInvoices(_lastInvoiceRows, "گزارش فاکتورهای حساب‌گرا");
    }
}

sealed record PayRow(string PayDate, string InvoiceNumber, string CompanyName, decimal Amount, string PaymentMethod, string CheckNumber, string CheckStatus, string Note);
sealed record CompanyRow(string Name, int Count, decimal Amount, decimal Paid, decimal Balance, int BouncedChecks);
sealed record CheckRow(string CheckDate, string CheckNumber, string InvoiceNumber, string CompanyName, decimal Amount, string CheckStatus);
