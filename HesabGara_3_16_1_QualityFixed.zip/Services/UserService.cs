using AccountingPurchasePro.Data;
using AccountingPurchasePro.Models;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Services;

public sealed class UserService
{
    public async Task<List<AppUser>> GetAllAsync(CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        return await db.Users.AsNoTracking().OrderBy(x => x.UserName).ToListAsync(ct);
    }

    public async Task<AppUser> CreateAsync(AppUser input, string password, string? securityQuestion = null, string? securityAnswer = null, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(input.UserName)) throw new ArgumentException("نام کاربری الزامی است.");
        if (string.IsNullOrWhiteSpace(password) || password.Length < 8) throw new ArgumentException("رمز عبور حداقل ۸ کاراکتر باشد.");
        await using var db = new AppDbContext();
        if (await db.Users.AnyAsync(x => x.UserName == input.UserName.Trim(), ct)) throw new InvalidOperationException("این نام کاربری قبلاً ثبت شده است.");
        var user = new AppUser
        {
            UserName = input.UserName.Trim(), DisplayName = string.IsNullOrWhiteSpace(input.DisplayName) ? input.UserName.Trim() : input.DisplayName.Trim(),
            PasswordHash = SecurityService.HashPassword(password), IsAdmin = input.IsAdmin, IsActive = input.IsActive,
            CanManageData = input.CanManageData, CanViewReports = input.CanViewReports, CanImportExport = input.CanImportExport, CanBackup = input.CanBackup,
            SecurityQuestion = string.IsNullOrWhiteSpace(securityQuestion) ? null : securityQuestion.Trim(),
            SecurityAnswerHash = string.IsNullOrWhiteSpace(securityAnswer) ? null : SecurityService.HashSecurityAnswer(securityAnswer)
        };
        db.Users.Add(user); await db.SaveChangesAsync(ct);
        db.AuditLogs.Add(new AuditLog { TimestampUtc = DateTime.UtcNow, UserId = UserSession.CurrentUser?.Id, UserName = UserSession.CurrentUser?.UserName, IpAddress = UserSession.IpAddress, Action = "Create", Entity = "User", EntityId = user.Id.ToString(), Details = user.UserName });
        await db.SaveChangesAsync(ct); return user;
    }

    public async Task UpdateAsync(AppUser input, string? newPassword, string? securityQuestion = null, string? securityAnswer = null, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var user = await db.Users.SingleOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new InvalidOperationException("کاربر پیدا نشد.");
        if (string.IsNullOrWhiteSpace(input.UserName)) throw new ArgumentException("نام کاربری الزامی است.");
        if (await db.Users.AnyAsync(x => x.Id != input.Id && x.UserName == input.UserName.Trim(), ct)) throw new InvalidOperationException("این نام کاربری قبلاً ثبت شده است.");
        if (user.IsAdmin && !input.IsAdmin && await db.Users.CountAsync(x => x.IsAdmin && x.IsActive, ct) <= 1) throw new InvalidOperationException("حداقل یک مدیر فعال باید وجود داشته باشد.");
        user.UserName = input.UserName.Trim(); user.DisplayName = input.DisplayName.Trim(); user.IsActive = input.IsActive; user.IsAdmin = input.IsAdmin;
        user.CanManageData = input.CanManageData; user.CanViewReports = input.CanViewReports; user.CanImportExport = input.CanImportExport; user.CanBackup = input.CanBackup;
        if (!string.IsNullOrWhiteSpace(newPassword)) user.PasswordHash = SecurityService.HashPassword(newPassword);
        // Only touched if BOTH a question and an answer are supplied together - a lone
        // question with no answer would leave recovery unusable, so it's all-or-nothing.
        if (!string.IsNullOrWhiteSpace(securityQuestion) && !string.IsNullOrWhiteSpace(securityAnswer))
        {
            user.SecurityQuestion = securityQuestion.Trim();
            user.SecurityAnswerHash = SecurityService.HashSecurityAnswer(securityAnswer);
        }
        await db.SaveChangesAsync(ct);
        db.AuditLogs.Add(new AuditLog { TimestampUtc = DateTime.UtcNow, UserId = UserSession.CurrentUser?.Id, UserName = UserSession.CurrentUser?.UserName, IpAddress = UserSession.IpAddress, Action = "Update", Entity = "User", EntityId = user.Id.ToString(), Details = user.UserName });
        await db.SaveChangesAsync(ct);
    }

    public async Task DeactivateAsync(int id, int currentUserId, CancellationToken ct = default)
    {
        if (id == currentUserId) throw new InvalidOperationException("کاربر جاری را نمی‌توان غیرفعال کرد.");
        await using var db = new AppDbContext();
        var user = await db.Users.SingleOrDefaultAsync(x => x.Id == id, ct) ?? throw new InvalidOperationException("کاربر پیدا نشد.");
        if (user.IsAdmin && await db.Users.CountAsync(x => x.IsAdmin && x.IsActive, ct) <= 1) throw new InvalidOperationException("حداقل یک مدیر فعال باید باقی بماند.");
        user.IsActive = false; await db.SaveChangesAsync(ct);
        db.AuditLogs.Add(new AuditLog { TimestampUtc = DateTime.UtcNow, UserId = UserSession.CurrentUser?.Id, UserName = UserSession.CurrentUser?.UserName, IpAddress = UserSession.IpAddress, Action = "Deactivate", Entity = "User", EntityId = id.ToString(), Details = user.UserName });
        await db.SaveChangesAsync(ct);
    }
}
