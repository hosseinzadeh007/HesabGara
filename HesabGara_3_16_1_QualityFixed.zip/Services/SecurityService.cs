using System.Security.Cryptography;
using System.Text;
using AccountingPurchasePro.Data;
using AccountingPurchasePro.Models;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Services;

public sealed class SecurityService
{
    public static string HashPassword(string password)
    {
        if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
            throw new ArgumentException("رمز عبور باید حداقل ۸ کاراکتر باشد.");
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, 120_000, HashAlgorithmName.SHA256, 32);
        return $"PBKDF2-SHA256$120000${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
    }

    public static bool VerifyPassword(string password, string encoded)
    {
        try
        {
            var parts = encoded.Split('$');
            if (parts.Length != 4 || parts[0] != "PBKDF2-SHA256") return false;
            var iterations = int.Parse(parts[1]);
            var salt = Convert.FromBase64String(parts[2]);
            var expected = Convert.FromBase64String(parts[3]);
            var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, iterations, HashAlgorithmName.SHA256, expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch { return false; }
    }

    // Security-answer hashing reuses the exact same PBKDF2 scheme as passwords, but without
    // the 8-character minimum (an answer like "Rex" is a completely normal answer) and with
    // the answer normalized (trimmed + lowercased) first, since "Blue" and "blue " should be
    // treated as the same answer for someone recovering their own account.
    static string NormalizeAnswer(string answer) => (answer ?? "").Trim().ToLowerInvariant();

    public static string HashSecurityAnswer(string answer)
    {
        var normalized = NormalizeAnswer(answer);
        if (string.IsNullOrWhiteSpace(normalized)) throw new ArgumentException("پاسخ سؤال امنیتی نمی‌تواند خالی باشد.");
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(normalized, salt, 120_000, HashAlgorithmName.SHA256, 32);
        return $"PBKDF2-SHA256$120000${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
    }

    public static bool VerifySecurityAnswer(string answer, string encoded) => VerifyPassword(NormalizeAnswer(answer), encoded);

    public async Task<bool> HasUsersAsync(CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        return await db.Users.AnyAsync(ct);
    }

    public async Task<AppUser> CreateFirstAdminAsync(string userName, string displayName, string password, string securityQuestion, string securityAnswer, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(userName)) throw new ArgumentException("نام کاربری الزامی است.");
        if (string.IsNullOrWhiteSpace(securityQuestion)) throw new ArgumentException("برای بازیابی رمز در آینده، انتخاب یک سؤال امنیتی الزامی است.");
        await using var db = new AppDbContext();
        if (await db.Users.AnyAsync(ct)) throw new InvalidOperationException("مدیر اولیه قبلاً ایجاد شده است.");
        var user = new AppUser
        {
            UserName = userName.Trim(), DisplayName = string.IsNullOrWhiteSpace(displayName) ? userName.Trim() : displayName.Trim(),
            PasswordHash = HashPassword(password), IsAdmin = true, IsActive = true,
            SecurityQuestion = securityQuestion.Trim(), SecurityAnswerHash = HashSecurityAnswer(securityAnswer)
        };
        db.Users.Add(user);
        await db.SaveChangesAsync(ct);
        db.AuditLogs.Add(new AuditLog
        {
            TimestampUtc = DateTime.UtcNow, UserId = user.Id, UserName = user.UserName,
            IpAddress = UserSession.IpAddress, Action = "Create", Entity = "User",
            EntityId = user.Id.ToString(), Details = "Initial administrator"
        });
        await db.SaveChangesAsync(ct);
        return user;
    }

    // Returns the account's recovery question, or null if the account doesn't exist or never
    // set one up (in which case the UI should point them to an admin-assisted reset instead).
    public async Task<string?> GetSecurityQuestionAsync(string userName, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var user = await db.Users.SingleOrDefaultAsync(x => x.UserName == userName.Trim() && x.IsActive, ct);
        return string.IsNullOrWhiteSpace(user?.SecurityQuestion) ? null : user.SecurityQuestion;
    }

    public async Task ResetPasswordViaSecurityAnswerAsync(string userName, string securityAnswer, string newPassword, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var user = await db.Users.SingleOrDefaultAsync(x => x.UserName == userName.Trim() && x.IsActive, ct)
            ?? throw new InvalidOperationException("کاربری با این مشخصات پیدا نشد.");
        if (string.IsNullOrWhiteSpace(user.SecurityAnswerHash) || !VerifySecurityAnswer(securityAnswer, user.SecurityAnswerHash))
            throw new InvalidOperationException("پاسخ سؤال امنیتی صحیح نیست.");
        user.PasswordHash = HashPassword(newPassword);
        db.AuditLogs.Add(new AuditLog
        {
            TimestampUtc = DateTime.UtcNow, UserId = user.Id, UserName = user.UserName,
            IpAddress = UserSession.IpAddress, Action = "PasswordResetViaSecurityQuestion",
            Entity = "User", EntityId = user.Id.ToString(), Details = user.UserName
        });
        await db.SaveChangesAsync(ct);
    }

    public async Task<AppUser?> LoginAsync(string userName, string password, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var user = await db.Users.SingleOrDefaultAsync(x => x.UserName == userName.Trim() && x.IsActive, ct);
        if (user is null || !VerifyPassword(password, user.PasswordHash))
        {
            db.AuditLogs.Add(new AuditLog
            {
                TimestampUtc = DateTime.UtcNow, UserName = userName.Trim(),
                IpAddress = UserSession.IpAddress, Action = "LoginFailed",
                Entity = "User", Details = "Invalid credentials"
            });
            await db.SaveChangesAsync(ct);
            return null;
        }
        user.LastLoginUtc = DateTime.UtcNow;
        db.AuditLogs.Add(new AuditLog
        {
            TimestampUtc = DateTime.UtcNow, UserId = user.Id, UserName = user.UserName,
            IpAddress = UserSession.IpAddress, Action = "Login",
            Entity = "User", EntityId = user.Id.ToString(), Details = user.UserName
        });
        await db.SaveChangesAsync(ct);
        UserSession.Start(user);
        return user;
    }
}
