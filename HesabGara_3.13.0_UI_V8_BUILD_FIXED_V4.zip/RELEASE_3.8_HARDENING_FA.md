# حساب‌یار 3.8.0 — Release Hardening

## تغییرات اصلی

### 1) سلامت پایگاه داده
- بررسی SQLite با `integrity_check` و `foreign_key_check`
- بررسی وضعیت ONLINE دیتابیس در SQL Server
- گزارش تعداد شرکت‌ها، فاکتورها و پرداخت‌ها
- خطاهای Health Check به جای متوقف کردن برنامه گزارش می‌شوند.

### 2) Backup حرفه‌ای
- SQLite: پشتیبان سازگار با WAL و اعتبارسنجی Integrity
- SQL Server: `BACKUP DATABASE` با `CHECKSUM` و `COMPRESSION`
- SQL Server Backup با `RESTORE VERIFYONLY` اعتبارسنجی می‌شود.
- Restore SQL Server با حالت SINGLE_USER و بازگشت به MULTI_USER انجام می‌شود.
- نکته: مسیر `.bak` در SQL Server باید روی خود سرور SQL قابل دسترسی باشد.

### 3) لاگ فنی
- ثبت خطاهای راه‌اندازی و خطاهای UI
- فایل‌های لاگ روزانه در:
  `%LOCALAPPDATA%\HesabYar\Logs`
- نگهداری حداکثر 14 فایل قدیمی
- Logger نباید خودش باعث Crash برنامه شود.

### 4) پایداری
- خطاهای غیرمنتظره دیگر فقط به MessageBox محدود نیستند و در فایل لاگ هم ذخیره می‌شوند.
- منطق شبکه و SQLite از هم تفکیک شده‌اند.

## محدودیت مهم
این بسته سورس/پروژه Release است. ساخت EXE و Installer نهایی باید روی Windows با .NET 8 SDK و ابزار Installer پروژه انجام و سپس تست شود.
