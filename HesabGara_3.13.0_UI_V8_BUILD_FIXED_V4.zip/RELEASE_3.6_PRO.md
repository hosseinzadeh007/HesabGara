# HesabYar 3.6.0 — Professional Deployment Release

## تغییرات
- اضافه شدن First-Run Setup Wizard
- انتخاب Local SQLite یا Network SQL Server بدون ویرایش فایل config
- تست اتصال SQL Server از Wizard
- پشتیبانی Windows Authentication و SQL Authentication
- پشتیبانی پورت اختیاری SQL Server
- جلوگیری از اجرای DatabaseInitializer قبل از انتخاب مسیر دیتابیس در اولین اجرا
- ارتقای نسخه به 3.6.0

## توجه
این بسته سورس پروژه است. Build نهایی Self-Contained Win-x64 و Installer باید روی Windows با .NET 8 SDK ساخته و روی Windows واقعی تست شود.
