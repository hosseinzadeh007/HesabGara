﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$ProjectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$Project = Join-Path $ProjectRoot 'AccountingPurchasePro.csproj'
$Out = Join-Path $ProjectRoot 'publish\win-x64'
$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { throw 'dotnet پیدا نشد. .NET 8 SDK را نصب کنید و PowerShell را دوباره باز کنید.' }
Write-Host 'Restoring HesabGara 3.4.0...' -ForegroundColor Cyan
& $dotnet.Source restore $Project --runtime win-x64
if ($LASTEXITCODE -ne 0) { throw "Restore failed: $LASTEXITCODE" }
if (Test-Path $Out) { Remove-Item $Out -Recurse -Force }
Write-Host 'Publishing self-contained win-x64...' -ForegroundColor Cyan
& $dotnet.Source publish $Project -c Release -r win-x64 --self-contained true -p:PublishReadyToRun=true -p:DebugType=None -p:DebugSymbols=false -o $Out
if ($LASTEXITCODE -ne 0) { throw "Publish failed: $LASTEXITCODE" }
$exe = Join-Path $Out 'HesabGara.exe'
if (-not (Test-Path $exe)) { throw "EXE ساخته نشد: $exe" }
Write-Host "موفق: $exe" -ForegroundColor Green
Start-Process explorer.exe $Out
