﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$Project = Join-Path $Root 'AccountingPurchasePro.csproj'
$Iss = Join-Path $Root 'Installer\AccountingPurchasePro.iss'
$VersionFile = Join-Path $Root 'VERSION.txt'
$Report = Join-Path $Root 'RELEASE_VALIDATION_3.10_REPORT.txt'

$checks = [System.Collections.Generic.List[string]]::new()
function Check($name, $ok, $detail) {
  $status = if ($ok) { 'PASS' } else { 'FAIL' }
  $checks.Add("[$status] $name - $detail")
  if (-not $ok) { throw "$name failed: $detail" }
}

Check 'Project exists' (Test-Path $Project) $Project
Check 'Installer script exists' (Test-Path $Iss) $Iss
Check 'Version file exists' (Test-Path $VersionFile) $VersionFile

$version = (Get-Content $VersionFile -Raw).Trim()
Check 'Release version' ($version -eq '3.13.0') "Expected 3.13.0, found $version"

$csproj = Get-Content $Project -Raw
$iss = Get-Content $Iss -Raw
Check 'csproj version synchronized' ($csproj -match '<Version>3\.10\.0</Version>' -and $csproj -match '<AssemblyVersion>3\.10\.0\.0</AssemblyVersion>' -and $csproj -match '<FileVersion>3\.10\.0\.0</FileVersion>') 'Version metadata is 3.13.0'
Check 'Installer version synchronized' ($iss -match '#define MyAppVersion "3\.10\.0"' -and $iss -match 'VersionInfoVersion=3\.10\.0\.0' -and $iss -match 'VersionInfoProductVersion=3\.10\.0') 'Inno Setup metadata is 3.13.0'
Check 'Self-contained win-x64' ($csproj -match '<RuntimeIdentifier>win-x64</RuntimeIdentifier>' -and $csproj -match '<SelfContained>true</SelfContained>') 'Project is configured for self-contained win-x64'

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if ($dotnet) {
  $sdkText = (& $dotnet.Source --list-sdks 2>$null) -join "`n"
  $has8 = $sdkText -match '(^|\n)8\.\d+\.\d+'
  Check '.NET 8 SDK installed' $has8 'A .NET 8 SDK is required for the Windows build'
} else {
  $checks.Add('[BLOCKED] .NET 8 SDK check - dotnet is not installed in the current environment')
}

$publish = Join-Path $Root 'publish\win-x64'
if (Test-Path $publish) {
  $exe = Join-Path $publish 'HesabGara.exe'
  if (Test-Path $exe) {
    $checks.Add('[PASS] Published EXE - HesabGara.exe exists')
  } else {
    $checks.Add('[BLOCKED] Published EXE - publish folder exists but HesabGara.exe is missing')
  }
} else {
  $checks.Add('[BLOCKED] Published EXE - no Windows publish output exists yet')
}

$checks | Set-Content -Path $Report -Encoding UTF8
Write-Host "Validation report: $Report" -ForegroundColor Green
$checks | ForEach-Object { Write-Host $_ }
