﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$Version = '3.13.0'
$Project = Join-Path $Root 'AccountingPurchasePro.csproj'
$Publish = Join-Path $Root 'publish\win-x64'
$InstallerOutput = Join-Path $Root 'installer-output'
$Manifest = Join-Path $Root 'RELEASE_MANIFEST_SHA256.txt'

function Require-Path($path, $label) {
    if (-not (Test-Path $path)) { throw "Missing $label`: $path" }
}

Require-Path $Project 'project'
Require-Path (Join-Path $Root 'VERSION.txt') 'VERSION.txt'
Require-Path (Join-Path $Root 'Installer\AccountingPurchasePro.iss') 'Inno Setup script'

$actual = (Get-Content (Join-Path $Root 'VERSION.txt') -Raw).Trim()
if ($actual -ne $Version) { throw "VERSION.txt is $actual; expected $Version." }

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { throw '.NET SDK is required. Install .NET 8 SDK and reopen PowerShell.' }
$sdks = (& $dotnet.Source --list-sdks 2>$null) -join "`n"
if ($sdks -notmatch '(^|\n)8\.\d+\.\d+') { throw '.NET 8 SDK was not found.' }

Write-Host 'Running unit tests...' -ForegroundColor Cyan
$testProject = Join-Path $Root 'Tests\AccountingPurchasePro.Tests.csproj'
& $dotnet.Source test $testProject -c Release
if ($LASTEXITCODE -ne 0) { throw "Unit tests failed: $LASTEXITCODE" }

Write-Host 'Publishing self-contained win-x64...' -ForegroundColor Cyan
if (Test-Path $Publish) { Remove-Item $Publish -Recurse -Force }
& $dotnet.Source restore $Project --runtime win-x64
if ($LASTEXITCODE -ne 0) { throw "Restore failed: $LASTEXITCODE" }
& $dotnet.Source publish $Project -c Release -r win-x64 --self-contained true -p:PublishReadyToRun=true -p:DebugType=None -p:DebugSymbols=false -o $Publish
if ($LASTEXITCODE -ne 0) { throw "Publish failed: $LASTEXITCODE" }

$exe = Join-Path $Publish 'HesabGara.exe'
Require-Path $exe 'published executable'
$info = [Diagnostics.FileVersionInfo]::GetVersionInfo($exe)
if ($info.FileVersion -notlike "$Version.*") { throw "EXE version mismatch: $($info.FileVersion)" }

Write-Host 'Generating SHA-256 manifest...' -ForegroundColor Cyan
Get-ChildItem $Publish -File -Recurse |
    Where-Object { $_.Name -ne 'RELEASE_MANIFEST_SHA256.txt' } |
    Sort-Object FullName |
    ForEach-Object {
        $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash.ToLowerInvariant()
        $relative = $_.FullName.Substring($Publish.Length).TrimStart('\','/')
        "$hash  $relative"
    } | Set-Content -Encoding UTF8 $Manifest

$paths = @(
 "$env:ProgramFiles(x86)\Inno Setup 7\ISCC.exe",
 "$env:ProgramFiles\Inno Setup 7\ISCC.exe",
 "$env:ProgramFiles(x86)\Inno Setup 6\ISCC.exe",
 "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)
$iscc = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { throw 'Inno Setup 6/7 was not found.' }

if (Test-Path $InstallerOutput) { Remove-Item $InstallerOutput -Recurse -Force }
New-Item -ItemType Directory $InstallerOutput | Out-Null
& $iscc (Join-Path $Root 'Installer\AccountingPurchasePro.iss')
if ($LASTEXITCODE -ne 0) { throw "Installer build failed: $LASTEXITCODE" }

$setup = Join-Path $InstallerOutput "HesabGara_Setup_${Version}_win-x64.exe"
Require-Path $setup 'installer'
Write-Host "Production release completed: $setup" -ForegroundColor Green
