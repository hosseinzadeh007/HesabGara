﻿$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path $PSScriptRoot -Parent
Set-Location $ProjectRoot

Write-Host "=== HesabGara 3.4.0 One-Click Build ===" -ForegroundColor Cyan

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw ".NET SDK was not found. Install the .NET SDK and reopen PowerShell."
}

dotnet restore ".\AccountingPurchasePro.csproj" --runtime win-x64
if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed." }

dotnet publish ".\AccountingPurchasePro.csproj" -c Release -r win-x64 --self-contained true -o ".\publish\win-x64" --no-restore
if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed." }

$exe = Get-ChildItem ".\publish\win-x64\*.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $exe) { throw "Publish finished but no EXE was produced." }

Write-Host ""
Write-Host "SUCCESS: $($exe.FullName)" -ForegroundColor Green
Write-Host "Output folder: $($exe.DirectoryName)" -ForegroundColor Green
Start-Process explorer.exe $exe.DirectoryName
