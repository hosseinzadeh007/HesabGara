﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$project = Join-Path $root 'AccountingPurchasePro.csproj'
$versionFile = Join-Path $root 'VERSION.txt'
$version = (Get-Content $versionFile -Raw).Trim()
$publish = Join-Path $root 'publish\local-update-win-x64'
$outDir = Join-Path $root 'Releases'
$zip = Join-Path $outDir "HesabGara-$version-LocalUpdate-win-x64.zip"

Write-Host "HesabGara local update package - v$version" -ForegroundColor Cyan
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'dotnet پیدا نشد. ابتدا .NET 8 SDK را نصب کنید.'
}

if (Test-Path $publish) { Remove-Item $publish -Recurse -Force }
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
if (Test-Path $zip) { Remove-Item $zip -Force }

dotnet publish $project -c Release -r win-x64 --self-contained true -o $publish
if ($LASTEXITCODE -ne 0) { throw "Publish failed. Exit code: $LASTEXITCODE" }

$marker = Join-Path $publish 'VERSION.txt'
Set-Content -Path $marker -Value $version -Encoding UTF8
Compress-Archive -Path (Join-Path $publish '*') -DestinationPath $zip -CompressionLevel Optimal

Write-Host ''
Write-Host "بسته به‌روزرسانی آماده شد:" -ForegroundColor Green
Write-Host $zip
