﻿$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$csproj = Join-Path $root 'AccountingPurchasePro.csproj'
$publish = Join-Path $root 'publish\win-x64'
$installer = Join-Path $root 'installer-output'

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) { throw '.NET SDK پیدا نشد. .NET 8 SDK را نصب کنید.' }
$sdks = dotnet --list-sdks
if (-not ($sdks -match '^8\.')) { throw '.NET 8 SDK لازم است.' }

Write-Host 'Running tests...' -ForegroundColor Cyan
$testProject = Join-Path $root 'Tests\AccountingPurchasePro.Tests.csproj'
dotnet test $testProject -c Release --no-restore

Write-Host 'Publishing self-contained win-x64...' -ForegroundColor Cyan
if (Test-Path $publish) { Remove-Item $publish -Recurse -Force }
dotnet restore $csproj --runtime win-x64
dotnet publish $csproj -c Release -r win-x64 --self-contained true -p:PublishReadyToRun=true -p:DebugType=None -p:DebugSymbols=false -o $publish

$exe = Join-Path $publish 'HesabGara.exe'
if (-not (Test-Path $exe)) { throw 'فایل اجرایی ساخته نشد.' }

if (-not (Get-Command iscc -ErrorAction SilentlyContinue)) { throw 'Inno Setup Compiler (iscc.exe) پیدا نشد؛ Release ناقص است.' }

if (Test-Path $installer) { Remove-Item $installer -Recurse -Force }
New-Item -ItemType Directory -Path $installer | Out-Null
$iss = Join-Path $PSScriptRoot 'AccountingPurchasePro.iss'
& iscc $iss
if ($LASTEXITCODE -ne 0) { throw 'ساخت Installer ناموفق بود.' }
Write-Host "Release complete: $installer" -ForegroundColor Green
