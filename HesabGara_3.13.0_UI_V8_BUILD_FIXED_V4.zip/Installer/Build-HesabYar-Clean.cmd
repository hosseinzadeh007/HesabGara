﻿@echo off
setlocal
cd /d "%~dp0.."
echo ==========================================
echo HesabGara 3.4.0 - Clean Build and Publish
echo ==========================================
where dotnet >nul 2>&1
if errorlevel 1 (
  echo ERROR: .NET SDK was not found in PATH.
  echo Install .NET 8 SDK, then reopen this window.
  pause
  exit /b 1
)
echo [1/4] Cleaning...
dotnet clean "AccountingPurchasePro.csproj" -c Release
if errorlevel 1 goto fail
echo [2/4] Restoring...
dotnet restore "AccountingPurchasePro.csproj" --runtime win-x64
if errorlevel 1 goto fail
echo [3/4] Building and publishing...
dotnet publish "AccountingPurchasePro.csproj" -c Release -r win-x64 --self-contained true -o "publish\win-x64" --no-restore
if errorlevel 1 goto fail
echo [4/4] Done.
echo.
echo PUBLISH SUCCESSFUL
echo Output: "%CD%\publish\win-x64"
pause
exit /b 0
:fail
echo.
echo ==========================================
echo BUILD/PUBLISH FAILED
echo ==========================================
pause
exit /b 1
