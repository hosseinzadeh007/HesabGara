﻿@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
title HesabGara 3.4.0 - Clean Build
echo ==========================================
echo HesabGara 3.4.0 - CLEAN ONE CLICK BUILD
echo ==========================================
echo Project: %CD%
echo.

where dotnet >nul 2>&1
if errorlevel 1 (
  echo [ERROR] .NET SDK not found.
  echo Install .NET 8 SDK and reopen this window.
  pause
  exit /b 1
)

echo [1/4] Cleaning old build folders...
if exist "bin" rmdir /s /q "bin"
if exist "obj" rmdir /s /q "obj"
if exist "publish\win-x64" rmdir /s /q "publish\win-x64"

echo.
echo [2/4] Restoring packages...
dotnet restore "AccountingPurchasePro.csproj" --runtime win-x64
if errorlevel 1 goto :fail

echo.
echo [3/4] Building and publishing...
dotnet publish "AccountingPurchasePro.csproj" -c Release -r win-x64 --self-contained true -o "publish\win-x64" --no-restore
if errorlevel 1 goto :fail

echo.
echo [4/4] Verifying EXE...
set "EXE="
for %%F in ("publish\win-x64\*.exe") do if not defined EXE set "EXE=%%~fF"
if not defined EXE (
  echo [ERROR] No EXE was produced.
  goto :fail
)

echo.
echo ==========================================
echo BUILD SUCCESSFUL
echo EXE: %EXE%
echo ==========================================
echo.
start "" "publish\win-x64"
pause
exit /b 0

:fail
echo.
echo ==========================================
echo BUILD FAILED
echo Read the compiler error shown above.
echo ==========================================
pause
exit /b 1
