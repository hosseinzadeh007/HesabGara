# ساخت نسخه نصب‌شونده

روی Windows:

1. Visual Studio 2022/2026 با workload «.NET Desktop Development» یا .NET 8 SDK نصب شود.
2. Inno Setup 6 نصب شود.
3. PowerShell را در پوشه پروژه باز کنید.
4. اجرا کنید:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Installer\test-and-publish.ps1
.\Installer\build-installer.ps1
```

خروجی در `installer-output` قرار می‌گیرد.

برنامه به صورت Self-Contained برای win-x64 منتشر می‌شود و روی سیستم مقصد به نصب .NET Runtime، Visual Studio یا SQL Server نیاز ندارد.
