﻿@echo off
setlocal
cd /d "%~dp0.."
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-HesabGara.ps1"
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  pause
  exit /b 1
)
echo.
echo BUILD SUCCESSFUL.
pause
