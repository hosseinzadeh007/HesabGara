﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Project = Join-Path $Root "..\AccountingPurchasePro.csproj"
$Out = Join-Path $Root "..\publish\win-x64"

$dotnet = $null
$candidates = @(
  "$env:ProgramFiles\dotnet\dotnet.exe",
  "$env:ProgramFiles(x86)\dotnet\dotnet.exe",
  "$env:DOTNET_ROOT\dotnet.exe",
  "$env:DOTNET_ROOT(x64)\dotnet.exe"
)
foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { $dotnet = $c; break } }
if (-not $dotnet) {
  $cmd = Get-Command dotnet.exe -ErrorAction SilentlyContinue
  if ($cmd) { $dotnet = $cmd.Source }
}
if (-not $dotnet) { throw ".NET SDK پیدا نشد." }

if (Test-Path $Out) { Remove-Item $Out -Recurse -Force }
New-Item -ItemType Directory -Path $Out -Force | Out-Null

& $dotnet restore $Project
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& $dotnet publish $Project -c Release -r win-x64 --self-contained true -p:PublishReadyToRun=false -p:DebugType=None -p:DebugSymbols=false -o $Out
exit $LASTEXITCODE
