﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$ProjectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$Project = Join-Path $ProjectRoot 'AccountingPurchasePro.csproj'

if (-not (Test-Path $Project)) { throw "Project file not found: $Project" }

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { throw "dotnet was not found. Install the .NET 8 SDK and reopen PowerShell." }

$sdks = & $dotnet.Source --list-sdks 2>$null
if ($LASTEXITCODE -ne 0 -or -not $sdks) { throw "No .NET SDK was found." }

Write-Host "Building only the WPF application project..." -ForegroundColor Cyan
& $dotnet.Source build $Project -c Release --no-restore
if ($LASTEXITCODE -ne 0) { throw "Build failed. Exit code: $LASTEXITCODE" }

Write-Host "Build succeeded." -ForegroundColor Green
