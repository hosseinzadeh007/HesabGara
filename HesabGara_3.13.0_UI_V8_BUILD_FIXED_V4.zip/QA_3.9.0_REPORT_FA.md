# گزارش QA نسخه 3.9.0 — حساب‌یار

## نتیجه کلی
**وضعیت: Release Candidate مشروط (Conditional RC)**

در این محیط Linux قرار داریم و .NET SDK / Windows / WPF runtime در دسترس نیست؛ بنابراین Build و اجرای واقعی Windows قابل تأیید نیست. با این حال، سورس نسخه 3.8.0 به‌صورت ایستا بررسی شد و چند ایراد مهم قبل از Release شناسایی و اصلاح شد.

## یافته‌های مهم و اصلاحات

| مورد | وضعیت | توضیح |
|---|---|---|
| نسخه پروژه | اصلاح شد | از 3.8.0 به 3.9.0 ارتقا یافت |
| Installer version | اصلاح شد | Installer قبلاً روی 3.7.0 مانده بود؛ اکنون 3.9.0 است |
| SQL Server schema | اصلاح شد | ستون‌های Permission در دیتابیس‌های موجود قبلاً Migration نمی‌شدند |
| SQLite schema | قابل قبول | EnsureCreated + ستون‌های افزوده بررسی شدند |
| Backup | قابل قبول | مسیرهای SQLite/SQL Server جدا هستند |
| Local Update | قابل قبول با تست Windows | نسخه از Assembly خوانده می‌شود |
| Password hashing | قابل قبول | PBKDF2-SHA256 + salt + fixed-time comparison |
| Audit Log | قابل قبول | Login/Failure و IP ثبت می‌شود |
| Network | نیازمند تست واقعی | SQL Server connection باید روی Windows/شبکه واقعی تست شود |
| Installer build | نیازمند تست واقعی | Inno Setup و publish واقعی باید روی Windows اجرا شوند |

## تست‌های انجام‌شده در محیط فعلی

- باز کردن ZIP و استخراج کامل: **PASS**
- شمارش و بررسی ساختار پروژه: **PASS**
- بررسی Target Framework: **PASS — net8.0-windows**
- بررسی Self-contained / win-x64: **PASS — تنظیم شده**
- بررسی TreatWarningsAsErrors: **PASS — فعال است**
- بررسی نسخه‌ها: **FAIL اولیه → FIXED در 3.9.0**
- بررسی SQL Server additive schema: **FAIL اولیه → FIXED در 3.9.0**
- بررسی وجود تست‌های FinanceRules: **PASS**
- اجرای dotnet build: **BLOCKED** چون dotnet SDK در محیط فعلی نصب نیست
- اجرای WPF: **BLOCKED** چون محیط Windows در دسترس نیست
- اجرای Installer: **BLOCKED** چون Inno Setup/Windows در دسترس نیست

## مواردی که قبل از Release نهایی باید روی Windows تست شوند

1. `dotnet restore`
2. `dotnet build -c Release`
3. اجرای تست‌های xUnit
4. `dotnet publish -c Release -r win-x64 --self-contained true`
5. اجرای EXE روی Windows 10/11 x64
6. نصب و حذف کامل Installer
7. First Run Wizard
8. SQLite: ایجاد مدیر، ورود، فاکتور، پرداخت، Backup/Restore
9. SQL Server: ایجاد/اتصال دیتابیس و Migration افزایشی
10. اتصال دو Client همزمان به یک Server
11. قطع شبکه هنگام ذخیره و بازیابی اتصال
12. Excel Import/Export و Duplicate Detection
13. Local Update و Rollback
14. بررسی نمایش کامل تاریخ‌های شمسی در تمام صفحات و چاپ

## هشدارهای Release

- برای SQL Server موجود، Migrationهای آینده بهتر است به سیستم Migration رسمی EF Core منتقل شوند؛ `EnsureCreated` برای چرخه تکامل طولانی‌مدت دیتابیس راهکار ایده‌آل نیست.
- برای محصول شبکه‌ای، Backup باید روی خود Server SQL و با مسیر قابل دسترس سرویس SQL انجام شود.
- قبل از عرضه عمومی، Rate limiting / lockout برای Login ناموفق و سیاست پیچیدگی رمز عبور می‌تواند تقویت شود.

## حکم QA

**3.9.0 برای مرحله Release Candidate آماده است، اما هنوز «نسخه نهایی تأییدشده» نیست.**
تأیید نهایی فقط بعد از Build، Install و تست عملی روی Windows امکان‌پذیر است.
