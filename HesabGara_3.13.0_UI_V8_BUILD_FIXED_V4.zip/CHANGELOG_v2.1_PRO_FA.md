# AccountingPurchasePro v2.1 Professional

## مرحله دوم ارتقا
- ورود امن با Login Window
- ایجاد مدیر اولیه در اولین اجرا؛ رمز عبور حداقل ۸ کاراکتر
- هش رمز عبور با PBKDF2-SHA256 و salt تصادفی
- ثبت Login در AuditLog
- کنترل اولیه دسترسی برای عملیات مدیریتی
- Backup با checkpoint کامل WAL و ایجاد نام زمان‌دار
- قبل از Restore یک کپی ایمنی از دیتابیس فعلی ایجاد می‌شود
- مدل کاربر به EF Core اضافه شد
- گزینه «کالاها و خدمات» همچنان حذف است
- ساختار Self-Contained/Installer حفظ شده است

## نکته انتشار
برای تولید Setup.exe واقعی باید روی Windows دارای .NET 8 SDK و Inno Setup اجرا شود. این محیط امکان Build واقعی WPF ویندوز را ندارد.
