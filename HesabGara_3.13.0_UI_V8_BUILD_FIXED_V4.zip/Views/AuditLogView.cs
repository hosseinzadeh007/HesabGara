using System.Windows;
using System.Windows.Controls;
using AccountingPurchasePro.Data;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Views;

public sealed class AuditLogView : Grid
{
    readonly DataGrid G = new() { AutoGenerateColumns = false, IsReadOnly = true, CanUserAddRows = false, Margin = new Thickness(12) };
    readonly TextBox Search = new() { Width = 260, Height = 32, Margin = new Thickness(4) };

    public AuditLogView()
    {
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(55) });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        var top = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(12, 8, 12, 0), FlowDirection = FlowDirection.RightToLeft };
        top.Children.Add(new TextBlock { Text = "جستجوی کاربر / عملیات / IP:", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(4) });
        top.Children.Add(Search);
        var btn = new Button { Content = "جستجو", Padding = new Thickness(14, 5, 14, 5), Margin = new Thickness(4) };
        btn.Click += async (_, _) => await LoadAsync();
        top.Children.Add(btn);
        Grid.SetRow(top, 0); Children.Add(top);

        G.Columns.Add(new DataGridTextColumn { Header = "زمان", Binding = new System.Windows.Data.Binding("Timestamp") });
        G.Columns.Add(new DataGridTextColumn { Header = "کاربر", Binding = new System.Windows.Data.Binding("UserName") });
        G.Columns.Add(new DataGridTextColumn { Header = "IP", Binding = new System.Windows.Data.Binding("IpAddress") });
        G.Columns.Add(new DataGridTextColumn { Header = "عملیات", Binding = new System.Windows.Data.Binding("Action") });
        G.Columns.Add(new DataGridTextColumn { Header = "بخش", Binding = new System.Windows.Data.Binding("Entity") });
        G.Columns.Add(new DataGridTextColumn { Header = "جزئیات", Binding = new System.Windows.Data.Binding("Details") });
        Grid.SetRow(G, 1); Children.Add(G);
        Loaded += async (_, _) => await LoadAsync();
    }

    async Task LoadAsync()
    {
        await using var db = new AppDbContext();
        var q = db.AuditLogs.AsNoTracking().OrderByDescending(x => x.TimestampUtc).Take(1000);
        var rows = await q.Select(x => new
        {
            Timestamp = x.TimestampUtc.ToLocalTime().ToString("yyyy/MM/dd HH:mm:ss"),
            UserName = x.UserName ?? "-",
            IpAddress = x.IpAddress ?? "-",
            Action = x.Action,
            Entity = x.Entity,
            Details = x.Details ?? ""
        }).ToListAsync();
        var s = Search.Text.Trim();
        if (!string.IsNullOrWhiteSpace(s))
            rows = rows.Where(x => x.UserName.Contains(s, StringComparison.OrdinalIgnoreCase) ||
                                    x.IpAddress.Contains(s, StringComparison.OrdinalIgnoreCase) ||
                                    x.Action.Contains(s, StringComparison.OrdinalIgnoreCase) ||
                                    x.Details.Contains(s, StringComparison.OrdinalIgnoreCase)).ToList();
        G.ItemsSource = rows;
    }
}
