using System.Windows;
using System.Windows.Controls;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public sealed class UserManagementView : Grid
{
    readonly UserService S = new(); readonly int CurrentUserId; readonly DataGrid G = new();
    readonly TextBox User = new(), Display = new(), Password = new(); readonly CheckBox Admin = new(), Active = new() { IsChecked = true }, Data = new() { IsChecked = true }, Reports = new() { IsChecked = true }, Excel = new() { IsChecked = true }, Backup = new() { IsChecked = true };
    public UserManagementView(int currentUserId) { CurrentUserId=currentUserId; Build(); Loaded += async (_,_)=>await Load(); }
    void Build()
    {
        RowDefinitions.Add(new RowDefinition{Height=new GridLength(190)}); RowDefinitions.Add(new RowDefinition{Height=new GridLength(1,GridUnitType.Star)});
        var panel=new StackPanel{Margin=new Thickness(12)};
        User.Placeholder("نام کاربری"); Display.Placeholder("نام نمایشی"); Password.Placeholder("رمز جدید (اختیاری برای ویرایش)");
        panel.Children.Add(new StackPanel{Orientation=Orientation.Horizontal,Children={L("نام کاربری"),User,L("نام نمایشی"),Display,L("رمز"),Password}});
        Admin.Content="مدیر"; Active.Content="فعال"; Data.Content="مدیریت داده"; Reports.Content="گزارش"; Excel.Content="Excel"; Backup.Content="پشتیبان"; panel.Children.Add(new StackPanel{Orientation=Orientation.Horizontal,Children={Admin,Active,Data,Reports,Excel,Backup}});
        var add=new Button{Content="＋ کاربر جدید",Margin=new Thickness(4),Padding=new Thickness(12,6,12,6)}; add.Click+=Add;
        var edit=new Button{Content="ویرایش",Margin=new Thickness(4),Padding=new Thickness(12,6,12,6)}; edit.Click+=Edit;
        var off=new Button{Content="غیرفعال‌سازی",Margin=new Thickness(4),Padding=new Thickness(12,6,12,6)}; off.Click+=Deactivate;
        var audit=new Button{Content="گزارش فعالیت‌ها",Margin=new Thickness(4),Padding=new Thickness(12,6,12,6)};
        audit.Click += (_,_) => { var w=new Window { Title="گزارش فعالیت‌های سیستم", Content=new AuditLogView(), Width=1100, Height=650, Owner=Window.GetWindow(this), FlowDirection=FlowDirection.RightToLeft, WindowStartupLocation=WindowStartupLocation.CenterOwner }; w.ShowDialog(); };
        panel.Children.Add(new StackPanel{Orientation=Orientation.Horizontal,Children={add,edit,off,audit}}); Children.Add(panel);
        G.AutoGenerateColumns=false; G.IsReadOnly=true; G.CanUserAddRows=false; G.Columns.Add(new DataGridTextColumn{Header="کاربری",Binding=new System.Windows.Data.Binding("UserName")}); G.Columns.Add(new DataGridTextColumn{Header="نام",Binding=new System.Windows.Data.Binding("DisplayName")}); G.Columns.Add(new DataGridCheckBoxColumn{Header="مدیر",Binding=new System.Windows.Data.Binding("IsAdmin")}); G.Columns.Add(new DataGridCheckBoxColumn{Header="فعال",Binding=new System.Windows.Data.Binding("IsActive")}); G.Columns.Add(new DataGridCheckBoxColumn{Header="داده",Binding=new System.Windows.Data.Binding("CanManageData")}); G.Columns.Add(new DataGridCheckBoxColumn{Header="گزارش",Binding=new System.Windows.Data.Binding("CanViewReports")}); G.Columns.Add(new DataGridCheckBoxColumn{Header="Excel",Binding=new System.Windows.Data.Binding("CanImportExport")}); G.Columns.Add(new DataGridCheckBoxColumn{Header="Backup",Binding=new System.Windows.Data.Binding("CanBackup")}); Grid.SetRow(G,1); Children.Add(G);
        G.SelectionChanged += (_,_)=>{if(G.SelectedItem is AppUser u){User.Text=u.UserName;Display.Text=u.DisplayName;Admin.IsChecked=u.IsAdmin;Active.IsChecked=u.IsActive;Data.IsChecked=u.CanManageData;Reports.IsChecked=u.CanViewReports;Excel.IsChecked=u.CanImportExport;Backup.IsChecked=u.CanBackup;Password.Clear();}};
    }
    static TextBox L(string text){return new TextBox{Text=text,IsReadOnly=true,BorderThickness=new Thickness(0),Width=65,Margin=new System.Windows.Thickness(4,0,4,0)};}
    async Task Load(){G.ItemsSource=await S.GetAllAsync();}
    AppUser Input(int id=0)=>new(){Id=id,UserName=User.Text.Trim(),DisplayName=Display.Text.Trim(),IsAdmin=Admin.IsChecked==true,IsActive=Active.IsChecked==true,CanManageData=Data.IsChecked==true,CanViewReports=Reports.IsChecked==true,CanImportExport=Excel.IsChecked==true,CanBackup=Backup.IsChecked==true};
    async void Add(object? s,RoutedEventArgs e){try{await S.CreateAsync(Input(),Password.Text);Password.Clear();await Load();MessageBox.Show("کاربر ایجاد شد.");}catch(Exception ex){MessageBox.Show(ex.Message,"کاربر",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    async void Edit(object? s,RoutedEventArgs e){if(G.SelectedItem is not AppUser u){MessageBox.Show("یک کاربر را انتخاب کنید.");return;}try{await S.UpdateAsync(Input(u.Id),Password.Text);Password.Clear();await Load();}catch(Exception ex){MessageBox.Show(ex.Message,"کاربر",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    async void Deactivate(object? s,RoutedEventArgs e){if(G.SelectedItem is not AppUser u)return;if(MessageBox.Show($"کاربر {u.UserName} غیرفعال شود؟","تأیید",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;try{await S.DeactivateAsync(u.Id,CurrentUserId);await Load();}catch(Exception ex){MessageBox.Show(ex.Message,"کاربر",MessageBoxButton.OK,MessageBoxImage.Warning);}}
}
static class TextBoxExt { public static void Placeholder(this TextBox box,string _){box.Width=150;box.Margin=new Thickness(4);box.Height=30;} }
