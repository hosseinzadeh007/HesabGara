using System.Windows;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public partial class LoginWindow : Window
{
    readonly SecurityService Security = new();
    public AppUser? AuthenticatedUser { get; private set; }
    bool firstRun;

    public LoginWindow()
    {
        InitializeComponent();
        PreviewKeyDown += (_, e) => { if (e.Key == System.Windows.Input.Key.Enter) Action_Click(this, new RoutedEventArgs()); };
        Loaded += async (_, _) =>
        {
            firstRun = !await Security.HasUsersAsync();
            if (firstRun)
            {
                ModeText.Text = "برای راه‌اندازی، مدیر اولیه را ایجاد کنید.";
                ActionButton.Content = "ایجاد مدیر و ورود";
                DisplayPanel.Visibility = Visibility.Visible;
                ConfirmPanel.Visibility = Visibility.Visible;
                HintText.Text = "برای امنیت، رمز عبور حداقل ۸ کاراکتر باشد.";
            }
            UserNameBox.Focus();
        };
    }

    async void Action_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (firstRun)
            {
                if (PasswordBox.Password != ConfirmBox.Password) throw new InvalidOperationException("تکرار رمز عبور یکسان نیست.");
                AuthenticatedUser = await Security.CreateFirstAdminAsync(UserNameBox.Text, DisplayNameBox.Text, PasswordBox.Password);
            }
            else AuthenticatedUser = await Security.LoginAsync(UserNameBox.Text, PasswordBox.Password);
            if (AuthenticatedUser is null) { HintText.Text = "نام کاربری یا رمز عبور صحیح نیست."; return; }
            DialogResult = true;
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "ورود", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }
}