using System.Windows;
using System.Windows.Controls;
using System.Text.RegularExpressions;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public partial class SetupWizardWindow : Window
{
    public bool Completed { get; private set; }
    public SetupWizardWindow()
    {
        InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        // XAML can raise SelectionChanged/Checked events while InitializeComponent()
        // is still creating named controls. Initialize dependent UI only after the
        // complete visual tree exists.
        Mode_Changed(null, null);
        Auth_Changed(null, null);
    }

    void Mode_Changed(object? s, SelectionChangedEventArgs? e)
    {
        if (Mode is null || NetworkPanel is null || AuthPanel is null || PasswordPanel is null)
            return;

        var network = Mode.SelectedIndex == 1;
        NetworkPanel.Visibility = AuthPanel.Visibility = PasswordPanel.Visibility =
            network ? Visibility.Visible : Visibility.Collapsed;
    }
    void Auth_Changed(object? s, RoutedEventArgs? e)
    {
        if (User is null || Password is null || Integrated is null)
            return;

        User.IsEnabled = Password.IsEnabled = Integrated.IsChecked != true;
    }
    string BuildConnectionString()
    {
        var server = Server.Text.Trim();
        if (!string.IsNullOrWhiteSpace(Port.Text)) server += "," + Port.Text.Trim();
        var b = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder
        {
            DataSource = server, InitialCatalog = Database.Text.Trim(), TrustServerCertificate = true, ConnectTimeout = 8
        };
        if (Integrated.IsChecked == true) b.IntegratedSecurity = true;
        else { b.UserID = User.Text.Trim(); b.Password = Password.Password; }
        return b.ConnectionString;
    }
    async void PrepareDb_Click(object sender, RoutedEventArgs e)
    {
        if (Mode.SelectedIndex == 0) { Status.Text = "● حالت محلی نیازی به آماده‌سازی SQL Server ندارد."; return; }
        if (!ValidateNetwork()) return;
        PrepareDb.IsEnabled = false;
        try
        {
            var r = await new DatabaseConnectionService().EnsureDatabaseAsync(BuildConnectionString());
            Status.Text = "● " + r.Message;
            Status.Foreground = r.Success ? System.Windows.Media.Brushes.Green : System.Windows.Media.Brushes.Firebrick;
        }
        finally { PrepareDb.IsEnabled = true; }
    }

    bool ValidateNetwork()
    {
        if (string.IsNullOrWhiteSpace(Server.Text) || string.IsNullOrWhiteSpace(Database.Text)) { Status.Text = "● سرور/IP و نام دیتابیس الزامی است."; return false; }
        if (!string.IsNullOrWhiteSpace(Port.Text) && (!int.TryParse(Port.Text, out var port) || port < 1 || port > 65535)) { Status.Text = "● پورت باید عددی بین 1 تا 65535 باشد."; return false; }
        if (!Regex.IsMatch(Database.Text.Trim(), @"^[A-Za-z0-9_\u0600-\u06FF -]{1,128}$")) { Status.Text = "● نام دیتابیس نامعتبر است."; return false; }
        if (Integrated.IsChecked != true && string.IsNullOrWhiteSpace(User.Text)) { Status.Text = "● نام کاربری SQL الزامی است."; return false; }
        return true;
    }

    async void Test_Click(object sender, RoutedEventArgs e)
    {
        if (Mode.SelectedIndex == 0) { Status.Text = "● حالت محلی آماده است؛ پایگاه‌داده در اولین اجرا ساخته می‌شود."; Status.Foreground = System.Windows.Media.Brushes.Green; return; }
        if (!ValidateNetwork()) return;
        Test.IsEnabled = false;
        try
        {
            var r = await new DatabaseConnectionService().TestSqlServerAsync(BuildConnectionString());
            Status.Text = (r.Success ? "● " : "● خطا: ") + r.Message;
            Status.Foreground = r.Success ? System.Windows.Media.Brushes.Green : System.Windows.Media.Brushes.Firebrick;
        }
        finally { Test.IsEnabled = true; }
    }
    async void Save_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (Mode.SelectedIndex == 0)
                DatabaseConfigurationStore.Save(new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite });
            else
            {
                if (!ValidateNetwork()) throw new InvalidOperationException(Status.Text.Replace("● ", ""));
                var service = new DatabaseConnectionService();
                var ready = await service.EnsureDatabaseAsync(BuildConnectionString());
                if (!ready.Success) throw new InvalidOperationException(ready.Message);
                DatabaseConfigurationStore.Save(new DatabaseConfiguration { Provider = DatabaseProvider.SqlServer, ConnectionString = BuildConnectionString() });
            }
            Completed = true; DialogResult = true; Close();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "راه‌اندازی حساب‌گرا", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }
}
