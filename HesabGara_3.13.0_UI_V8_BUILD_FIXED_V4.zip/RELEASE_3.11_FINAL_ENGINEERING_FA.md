# حساب‌یار 3.11.0 — Final Release Engineering

## تغییرات این مرحله

- رفع باگ مهم نام فایل Setup در اسکریپت build که هنوز 3.7.0 را جستجو می‌کرد.
- جلوگیری از استفاده تصادفی از Publish قدیمی با بررسی FileVersion واقعی EXE.
- هماهنگ‌سازی نسخه 3.11.0 در پروژه، Installer و VERSION.txt.
- اضافه شدن Release Preflight برای کنترل فایل‌ها، نسخه‌ها و SDK.
- تولید فایل SHA-256 برای تمام فایل‌های Publish جهت کنترل یکپارچگی Release.
- تست خودکار با شکست صریح در صورت خطا.

## وضعیت

این نسخه از نظر مهندسی Release آماده بررسی روی Windows است؛ Build واقعی، اجرای WPF، SQL Server و نصب Inno Setup باید روی Windows انجام شود و تا آن زمان PASS نهایی ادعا نمی‌شود.
