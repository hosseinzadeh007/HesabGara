# چک‌لیست Release تولیدی 3.12.0

- [ ] نصب .NET 8 SDK
- [ ] اجرای Unit Tests با نتیجه PASS
- [ ] Restore با runtime win-x64
- [ ] Publish self-contained
- [ ] کنترل FileVersion فایل HesabYar.exe
- [ ] تولید SHA-256 manifest
- [ ] ساخت Installer با Inno Setup
- [ ] نصب Clean روی Windows
- [ ] اجرای Login و ساخت کاربر مدیر
- [ ] تست SQLite
- [ ] تست SQL Server
- [ ] تست Backup / Restore
- [ ] تست Update / Rollback
- [ ] تست حذف نرم‌افزار
- [ ] تست Client/Server و قطع/وصل شبکه
- [ ] بررسی Audit Log
- [ ] تأیید نهایی Release
