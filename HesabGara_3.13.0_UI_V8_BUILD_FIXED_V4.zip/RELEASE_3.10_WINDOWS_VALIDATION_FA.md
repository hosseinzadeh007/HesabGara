# حساب‌یار 3.10.0 — Windows Release Validation

این نسخه مرحله آماده‌سازی برای Build و تست واقعی Windows است.

## هدف
- یکسان‌سازی نسخه پروژه، Installer و VERSION.txt روی 3.10.0
- بررسی Self-contained / win-x64
- جلوگیری از اعلام PASS جعلی وقتی Windows/.NET SDK در دسترس نیست
- ایجاد اسکریپت Preflight برای بررسی محیط واقعی قبل از Build

## دستور پیشنهادی روی Windows
1. .NET 8 SDK را نصب کنید.
2. PowerShell را باز کنید.
3. داخل پوشه پروژه اجرا کنید:
   `powershell -ExecutionPolicy Bypass -File .\Installer\Validate-Release-3.10.ps1`
4. سپس:
   `powershell -ExecutionPolicy Bypass -File .\Installer\publish-win-x64.ps1`
5. پس از ایجاد `publish\win-x64\HesabYar.exe`، Installer را با Inno Setup بسازید.

## معیارهای پذیرش
- Build با exit code صفر
- `HesabYar.exe` ایجاد شود
- اجرای EXE بدون نصب .NET Runtime اضافی
- نصب و حذف Installer موفق باشد
- Login، SQLite، SQL Server، Backup/Restore، Update و Audit تست شوند
- نسخه EXE و Installer هر دو 3.10.0 باشند

## محدودیت این محیط
Build واقعی WPF/Windows و اجرای Installer در محیط فعلی انجام نشده است؛ بنابراین این مرحله فقط آمادگی و کنترل‌های قابل اجرای خارج از Windows را فراهم می‌کند و نتیجه Build واقعی باید روی Windows ثبت شود.
