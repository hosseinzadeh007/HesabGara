# حساب‌یار 3.12.0 — Production Release Engineering

## هدف
این نسخه مسیر تحویل تولیدی را یکپارچه می‌کند: تست واحد، Restore، Publish خود-contained win-x64، کنترل نسخه EXE، ساخت SHA-256 manifest و ساخت Installer.

## اسکریپت اصلی
`Installer/Production-Release-3.12.ps1`

این اسکریپت در صورت نبود .NET 8 SDK یا Inno Setup، یا شکست تست/Publish/Installer، با خطا متوقف می‌شود و Release ناقص را موفق اعلام نمی‌کند.

## کنترل‌های نسخه
- Project: 3.12.0
- AssemblyVersion: 3.12.0.0
- FileVersion: 3.12.0.0
- Runtime: win-x64
- SelfContained: true

## وضعیت
این بسته، Release Engineering را آماده می‌کند. Build واقعی Windows و اجرای Installer باید روی Windows انجام شود؛ این محیط آن را ادعا نمی‌کند.
