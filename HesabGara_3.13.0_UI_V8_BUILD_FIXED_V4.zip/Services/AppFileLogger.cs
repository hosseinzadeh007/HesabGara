using System.Text;

namespace AccountingPurchasePro.Services;

public static class AppFileLogger
{
    static readonly object Sync = new();

    public static string DirectoryPath =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara", "Logs");

    public static string CurrentLogPath =>
        Path.Combine(DirectoryPath, $"HesabGara_{DateTime.Now:yyyyMMdd}.log");

    public static void Info(string message) => Write("INFO", message, null);

    public static void Error(string message, Exception? ex = null) =>
        Write("ERROR", message, ex);

    public static void Write(string level, string message, Exception? ex)
    {
        try
        {
            Directory.CreateDirectory(DirectoryPath);
            var sb = new StringBuilder()
                .Append('[').Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"))
                .Append("] [").Append(level).Append("] ")
                .AppendLine(message);

            if (ex is not null)
                sb.AppendLine(ex.ToString());

            lock (Sync)
            {
                File.AppendAllText(CurrentLogPath, sb.ToString(), Encoding.UTF8);
                RotateOldLogs();
            }
        }
        catch { /* logging must never crash the application */ }
    }

    static void RotateOldLogs()
    {
        try
        {
            var files = new DirectoryInfo(DirectoryPath)
                .GetFiles("HesabGara_*.log")
                .OrderByDescending(x => x.LastWriteTimeUtc)
                .Skip(14);

            foreach (var f in files) f.Delete();
        }
        catch { }
    }
}
