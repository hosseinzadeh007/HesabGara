using System.Net;
using System.Net.Sockets;
using AccountingPurchasePro.Models;

namespace AccountingPurchasePro.Services;

public static class UserSession
{
    public static AppUser? CurrentUser { get; private set; }
    public static string IpAddress { get; } = ResolveLocalIp();

    public static void Start(AppUser user) => CurrentUser = user;
    public static void Clear() => CurrentUser = null;

    public static bool IsAdmin => CurrentUser?.IsAdmin == true;
    public static bool CanManageData => IsAdmin || CurrentUser?.CanManageData == true;
    public static bool CanViewReports => IsAdmin || CurrentUser?.CanViewReports == true;
    public static bool CanImportExport => IsAdmin || CurrentUser?.CanImportExport == true;
    public static bool CanBackup => IsAdmin || CurrentUser?.CanBackup == true;

    static string ResolveLocalIp()
    {
        try
        {
            foreach (var ip in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
                if (ip.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(ip))
                    return ip.ToString();
        }
        catch { }
        return "LOCAL";
    }
}
