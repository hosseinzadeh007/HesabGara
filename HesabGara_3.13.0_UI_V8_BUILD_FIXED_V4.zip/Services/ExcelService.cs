using System.IO;
using System.Globalization;
using AccountingPurchasePro.Data;
using AccountingPurchasePro.Models;
using ClosedXML.Excel;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Services;

public sealed record ExcelImportResult(int CompaniesAdded, int CompaniesSkipped, int InvoicesAdded, int InvoicesSkipped, int PaymentsAdded, int PaymentsSkipped, List<string> Errors);

public sealed class ExcelService
{
    public async Task ExportAsync(string filePath, int? companyId = null)
    {
        using var db = new AppDbContext();
        var invoicesQ = db.Invoices.Include(x => x.Company).AsNoTracking().AsQueryable();
        if (companyId.HasValue) invoicesQ = invoicesQ.Where(x => x.CompanyId == companyId.Value);
        var invoices = await invoicesQ.OrderBy(x => x.InvoiceDate).ThenBy(x => x.Number).ToListAsync();
        var ids = invoices.Select(x => x.Id).ToHashSet();
        var paymentsQ = db.Payments.Include(x => x.Invoice!).ThenInclude(x => x.Company).AsNoTracking().AsQueryable();
        if (companyId.HasValue) paymentsQ = paymentsQ.Where(x => ids.Contains(x.InvoiceId));
        var payments = await paymentsQ.OrderBy(x => x.PayDate).ToListAsync();
        var companies = await db.Companies.AsNoTracking().Where(x => !companyId.HasValue || x.Id == companyId.Value).OrderBy(x => x.Name).ToListAsync();

        using var wb = new XLWorkbook();
        var wsC = wb.Worksheets.Add("شرکت ها");
        WriteHeaders(wsC, "شناسه", "نام شرکت", "شناسه ملی", "تلفن", "توضیحات");
        var r = 2;
        foreach (var c in companies) { wsC.Cell(r,1).Value=c.Id; wsC.Cell(r,2).Value=c.Name; wsC.Cell(r,3).Value=c.NationalId ?? ""; wsC.Cell(r,4).Value=c.Phone ?? ""; wsC.Cell(r,5).Value=c.Note ?? ""; r++; }

        var wsI = wb.Worksheets.Add("فاکتورها");
        WriteHeaders(wsI, "شناسه", "نام شرکت", "شماره فاکتور", "تاریخ فاکتور", "تاریخ سررسید", "مبلغ", "پرداختی", "مانده", "توضیحات");
        r = 2;
        foreach (var x in invoices) { wsI.Cell(r,1).Value=x.Id; wsI.Cell(r,2).Value=x.Company?.Name ?? ""; wsI.Cell(r,3).Value=x.Number; wsI.Cell(r,4).Value=PersianDateService.ToPersian(x.InvoiceDate); wsI.Cell(r,5).Value=PersianDateService.ToPersian(x.DueDate); wsI.Cell(r,6).Value=(double)x.Amount; wsI.Cell(r,7).Value=(double)x.Paid; wsI.Cell(r,8).FormulaA1=$"=MAX(0,F{r}-G{r})"; wsI.Cell(r,9).Value=x.Note ?? ""; r++; }

        var wsP = wb.Worksheets.Add("پرداخت ها");
        WriteHeaders(wsP, "شناسه", "نام شرکت", "شماره فاکتور", "تاریخ پرداخت", "مبلغ", "توضیحات");
        r = 2;
        foreach (var p in payments) { wsP.Cell(r,1).Value=p.Id; wsP.Cell(r,2).Value=p.Invoice?.Company?.Name ?? ""; wsP.Cell(r,3).Value=p.Invoice?.Number ?? ""; wsP.Cell(r,4).Value=PersianDateService.ToPersian(p.PayDate); wsP.Cell(r,5).Value=(double)p.Amount; wsP.Cell(r,6).Value=p.Note ?? ""; r++; }

        foreach (var ws in wb.Worksheets) { ws.RightToLeft = true; ws.Columns().AdjustToContents(); ws.SheetView.FreezeRows(1); ws.Row(1).Style.Font.Bold = true; ws.Row(1).Style.Fill.BackgroundColor = XLColor.LightBlue; }
        Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
        wb.SaveAs(filePath);
    }

    public async Task<ExcelImportResult> ImportAsync(string filePath)
    {
        var errors = new List<string>();
        int ca=0, cs=0, ia=0, ins=0, pa=0, ps=0;
        using var wb = new XLWorkbook(filePath);
        using var db = new AppDbContext();
        var companyMap = await db.Companies.ToDictionaryAsync(x => Normalize(x.Name), x => x);

        var companySheet = FindSheet(wb, "شرکت ها", "شرکت‌ها", "شرکت ها و فروشندگان", "Companies");
        if (companySheet != null)
        {
            foreach (var row in DataRows(companySheet))
            {
                var name = Text(row, "نام شرکت", "نام", "Company"); if (string.IsNullOrWhiteSpace(name)) { cs++; continue; }
                var key = Normalize(name);
                var nationalId = NullIfEmpty(Text(row,"شناسه ملی","کد ملی","NationalId"));
                if (companyMap.ContainsKey(key) || (!string.IsNullOrWhiteSpace(nationalId) && await db.Companies.AnyAsync(x => x.NationalId == nationalId))) { cs++; continue; }
                var c = new Company { Name=name.Trim(), NationalId=nationalId, Phone=NullIfEmpty(Text(row,"تلفن","شماره تماس","Phone")), Note=NullIfEmpty(Text(row,"توضیحات","یادداشت","Note")) };
                db.Companies.Add(c); await db.SaveChangesAsync(); companyMap[key]=c; ca++;
            }
        }

        var invoiceSheet = FindSheet(wb, "فاکتورها", "فاکتور", "Invoices");
        var paymentSheet = FindSheet(wb, "پرداخت ها", "پرداخت‌ها", "پرداخت", "Payments");
        var hasPaymentSheet = paymentSheet != null;
        if (invoiceSheet != null)
        {
            foreach (var row in DataRows(invoiceSheet))
            {
                try
                {
                    var companyName=Text(row,"نام شرکت","شرکت","فروشنده","Company"); var number=Text(row,"شماره فاکتور","شماره","Invoice Number");
                    if (string.IsNullOrWhiteSpace(companyName) || string.IsNullOrWhiteSpace(number)) { ins++; continue; }
                    if (!companyMap.TryGetValue(Normalize(companyName), out var c)) { errors.Add($"شرکت «{companyName}» برای فاکتور «{number}» پیدا نشد."); ins++; continue; }
                    if (await db.Invoices.AnyAsync(x=>x.CompanyId==c.Id && x.Number==number.Trim())) { ins++; continue; }
                    var amount=Decimal(row,"مبلغ","مبلغ کل","Amount"); var paid=Decimal(row,"پرداختی","پرداخت شده","Paid");
                    if (amount<=0) { errors.Add($"مبلغ فاکتور «{number}» معتبر نیست."); ins++; continue; }
                    var date=Date(row,"تاریخ فاکتور","تاریخ","Invoice Date") ?? DateTime.Today;
                    var due=Date(row,"تاریخ سررسید","سررسید","Due Date") ?? date;
                    db.Invoices.Add(new Invoice { CompanyId=c.Id, Number=number.Trim(), InvoiceDate=date, DueDate=due, Amount=amount, Paid=hasPaymentSheet ? 0 : Math.Min(Math.Max(0,paid),amount), Note=NullIfEmpty(Text(row,"توضیحات","یادداشت","Note")) });
                    await db.SaveChangesAsync(); ia++;
                }
                catch(Exception ex){ errors.Add("خطا در فاکتور: "+ex.Message); ins++; }
            }
        }

        var invoiceMap = await db.Invoices.Include(x=>x.Company).ToDictionaryAsync(x => Normalize(x.Company!.Name)+"|"+Normalize(x.Number), x=>x);
        if (paymentSheet != null)
        {
            foreach (var row in DataRows(paymentSheet))
            {
                try
                {
                    var companyName=Text(row,"نام شرکت","شرکت","فروشنده","Company"); var number=Text(row,"شماره فاکتور","شماره","Invoice Number"); var amount=Decimal(row,"مبلغ","مبلغ پرداخت","Amount");
                    if (string.IsNullOrWhiteSpace(companyName)||string.IsNullOrWhiteSpace(number)||amount<=0){ps++;continue;}
                    if(!invoiceMap.TryGetValue(Normalize(companyName)+"|"+Normalize(number),out var inv)){errors.Add($"فاکتور «{number}» برای پرداخت پیدا نشد.");ps++;continue;}
                    var date=Date(row,"تاریخ پرداخت","تاریخ","Pay Date")??DateTime.Today;
                    var existing=await db.Payments.AnyAsync(x=>x.InvoiceId==inv.Id && x.PayDate.Date==date.Date && x.Amount==amount);
                    if(existing){ps++;continue;}
                    var remaining=AccountingService.Balance(inv); if(remaining<=0){ps++;continue;}
                    amount=Math.Min(amount,remaining);
                    inv.Paid += amount;
                    db.Payments.Add(new Payment{InvoiceId=inv.Id,PayDate=date,Amount=amount,Note=NullIfEmpty(Text(row,"توضیحات","یادداشت","Note"))});
                    await db.SaveChangesAsync(); pa++;
                }
                catch(Exception ex){errors.Add("خطا در پرداخت: "+ex.Message);ps++;}
            }
        }
        return new ExcelImportResult(ca,cs,ia,ins,pa,ps,errors);
    }

    static void WriteHeaders(IXLWorksheet ws, params string[] headers){for(int i=0;i<headers.Length;i++)ws.Cell(1,i+1).Value=headers[i];}
    static IXLWorksheet? FindSheet(XLWorkbook wb, params string[] names){return wb.Worksheets.FirstOrDefault(s=>names.Any(n=>Normalize(s.Name)==Normalize(n)));}
    static IEnumerable<IXLRow> DataRows(IXLWorksheet ws)=>ws.RowsUsed().Skip(1).Where(r=>r.CellsUsed().Any(c=>!string.IsNullOrWhiteSpace(c.GetString())));
    static string Text(IXLRow r, params string[] names){foreach(var c in r.CellsUsed()){var header=r.Worksheet.Cell(1,c.Address.ColumnNumber).GetString();if(names.Any(n=>Normalize(header)==Normalize(n)))return c.GetString().Trim();}return "";}
    static decimal Decimal(IXLRow r, params string[] names){var s=Text(r,names).Replace(",","").Replace("٬","").Trim(); if(decimal.TryParse(s,NumberStyles.Any,CultureInfo.InvariantCulture,out var d))return d;if(decimal.TryParse(s,NumberStyles.Any,new CultureInfo("fa-IR"),out d))return d;return 0;}
    static DateTime? Date(IXLRow r, params string[] names){var cell=FindCell(r,names); if(cell==null)return null; if(cell.DataType==XLDataType.DateTime)return cell.GetDateTime(); var s=cell.GetString().Trim(); if(PersianDateService.TryParse(s,out var d))return d;if(DateTime.TryParse(s,new CultureInfo("fa-IR"),DateTimeStyles.None,out d))return d;if(DateTime.TryParse(s,out d))return d;return null;}
    static IXLCell? FindCell(IXLRow r,string[] names){foreach(var c in r.CellsUsed()){var h=r.Worksheet.Cell(1,c.Address.ColumnNumber).GetString();if(names.Any(n=>Normalize(h)==Normalize(n)))return c;}return null;}
    static string Normalize(string? s)=>string.Join(' ',(s??"").Trim().Replace('ي','ی').Replace('ك','ک').Split((char[])null!,StringSplitOptions.RemoveEmptyEntries)).ToLowerInvariant();
    static string? NullIfEmpty(string s)=>string.IsNullOrWhiteSpace(s)?null:s;
}
