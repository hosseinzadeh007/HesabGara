using AccountingPurchasePro.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace AccountingPurchasePro.Services;

public sealed class DatabaseConnectionService
{
    public async Task<(bool Success, string Message)> TestSqlServerAsync(string connectionString, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(connectionString)) return (false, "رشته اتصال خالی است.");
        try
        {
            await using var cn = new SqlConnection(connectionString);
            await cn.OpenAsync(ct);
            await cn.CloseAsync();
            return (true, "اتصال به SQL Server با موفقیت برقرار شد.");
        }
        catch (Exception ex) { return (false, "اتصال برقرار نشد: " + ex.Message); }
    }

    public async Task<(bool Success, string Message)> EnsureDatabaseAsync(string connectionString, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(connectionString)) return (false, "رشته اتصال خالی است.");
        try
        {
            var target = new SqlConnectionStringBuilder(connectionString);
            var dbName = target.InitialCatalog?.Trim() ?? "";
            if (!Regex.IsMatch(dbName, @"^[A-Za-z0-9_\u0600-\u06FF -]{1,128}$"))
                return (false, "نام دیتابیس نامعتبر است. از حروف، عدد، فاصله و _ استفاده کنید.");

            var master = new SqlConnectionStringBuilder(connectionString) { InitialCatalog = "master" };
            await using var cn = new SqlConnection(master.ConnectionString);
            await cn.OpenAsync(ct);
            await using var cmd = cn.CreateCommand();
            cmd.CommandText = "IF DB_ID(@db) IS NULL BEGIN DECLARE @sql nvarchar(max) = N'CREATE DATABASE ' + QUOTENAME(@db); EXEC(@sql); END";
            cmd.Parameters.AddWithValue("@db", dbName);
            await cmd.ExecuteNonQueryAsync(ct);
            return (true, $"دیتابیس «{dbName}» آماده است.");
        }
        catch (Exception ex) { return (false, "ایجاد/بررسی دیتابیس ناموفق بود: " + ex.Message); }
    }
}
