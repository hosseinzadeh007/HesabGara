using System.Globalization;
namespace AccountingPurchasePro.Services;
public static class PersianDateService
{
    static readonly PersianCalendar P=new();
    public static string ToPersian(DateTime d)=>$"{P.GetYear(d):0000}/{P.GetMonth(d):00}/{P.GetDayOfMonth(d):00}";
    public static bool TryParse(string text,out DateTime date)
    { date=default; var s=(text??"").Trim().Replace('-','/').Replace('۰','0').Replace('۱','1').Replace('۲','2').Replace('۳','3').Replace('۴','4').Replace('۵','5').Replace('۶','6').Replace('۷','7').Replace('۸','8').Replace('۹','9'); var p=s.Split('/'); if(p.Length!=3)return false; if(!int.TryParse(p[0],out var y)||!int.TryParse(p[1],out var m)||!int.TryParse(p[2],out var d))return false; try{date=P.ToDateTime(y,m,d,0,0,0,0);return true;}catch{return false;}}
}
