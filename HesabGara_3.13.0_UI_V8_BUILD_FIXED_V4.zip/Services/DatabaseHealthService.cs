using AccountingPurchasePro.Data;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Services;

public sealed record DatabaseHealthResult(
    bool IsHealthy, long IntegrityChecks, long CompanyCount, long InvoiceCount,
    long PaymentCount, string Message);

public sealed class DatabaseHealthService
{
    public async Task<DatabaseHealthResult> CheckAsync(CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var cfg = DatabaseConfigurationStore.Load();

        try
        {
            if (cfg.Provider == DatabaseProvider.SqlServer)
                return await CheckSqlServerAsync(db, ct);

            return await CheckSqliteAsync(db, ct);
        }
        catch (Exception ex)
        {
            return new DatabaseHealthResult(false, 0, 0, 0, 0,
                "بررسی پایگاه داده با خطا مواجه شد: " + ex.Message);
        }
    }

    static async Task<DatabaseHealthResult> CheckSqliteAsync(AppDbContext db, CancellationToken ct)
    {
        await db.Database.OpenConnectionAsync(ct);
        try
        {
            await using var cmd = db.Database.GetDbConnection().CreateCommand();
            cmd.CommandText = "PRAGMA integrity_check;";
            var result = Convert.ToString(await cmd.ExecuteScalarAsync(ct));
            var integrityOk = string.Equals(result, "ok", StringComparison.OrdinalIgnoreCase);

            cmd.CommandText = "PRAGMA foreign_key_check;";
            var fkCount = 0L;
            await using (var reader = await cmd.ExecuteReaderAsync(ct))
                while (await reader.ReadAsync(ct)) fkCount++;

            return await BuildResultAsync(db, integrityOk && fkCount == 0,
                integrityOk ? 1 : 0,
                integrityOk && fkCount == 0
                    ? "پایگاه داده SQLite سالم است."
                    : "یکپارچگی SQLite مشکل دارد.", ct);
        }
        finally { await db.Database.CloseConnectionAsync(); }
    }

    static async Task<DatabaseHealthResult> CheckSqlServerAsync(AppDbContext db, CancellationToken ct)
    {
        var connection = db.Database.GetDbConnection();
        await db.Database.OpenConnectionAsync(ct);
        try
        {
            await using var cmd = connection.CreateCommand();
            cmd.CommandText = """
                SELECT
                    CASE WHEN EXISTS (
                        SELECT 1 FROM sys.databases
                        WHERE database_id = DB_ID() AND state_desc = 'ONLINE'
                    ) THEN 1 ELSE 0 END,
                    COALESCE((SELECT SUM(CASE WHEN state_desc <> 'ONLINE' THEN 1 ELSE 0 END)
                              FROM sys.databases WHERE database_id = DB_ID()), 0);
                """;
            await using var reader = await cmd.ExecuteReaderAsync(ct);
            var online = 0;
            var badStates = 0L;
            if (await reader.ReadAsync(ct))
            {
                online = reader.GetInt32(0);
                badStates = reader.GetInt64(1);
            }
            await reader.DisposeAsync();

            var ok = online == 1 && badStates == 0;
            return await BuildResultAsync(db, ok, ok ? 1 : 0,
                ok ? "اتصال و وضعیت SQL Server سالم است."
                   : "وضعیت دیتابیس SQL Server سالم نیست.", ct);
        }
        finally { await db.Database.CloseConnectionAsync(); }
    }

    static async Task<DatabaseHealthResult> BuildResultAsync(
        AppDbContext db, bool healthy, long checks, string message, CancellationToken ct)
    {
        var companies = await db.Companies.CountAsync(ct);
        var invoices = await db.Invoices.CountAsync(ct);
        var payments = await db.Payments.CountAsync(ct);
        return new DatabaseHealthResult(healthy, checks, companies, invoices, payments, message);
    }
}
