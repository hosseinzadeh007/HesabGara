using AccountingPurchasePro.Data;
using AccountingPurchasePro.Models;
using Microsoft.EntityFrameworkCore;

namespace AccountingPurchasePro.Services;

public sealed class SettingsService
{
    public async Task<string?> GetAsync(string key, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        return await db.Settings.Where(x => x.Key == key).Select(x => x.Value).SingleOrDefaultAsync(ct);
    }

    public async Task SetAsync(string key, string value, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(key)) throw new ArgumentException("کلید تنظیمات الزامی است.");
        await using var db = new AppDbContext();
        var item = await db.Settings.SingleOrDefaultAsync(x => x.Key == key, ct);
        if (item is null) db.Settings.Add(new AppSetting { Key = key.Trim(), Value = value ?? "" });
        else item.Value = value ?? "";
        await db.SaveChangesAsync(ct);
    }
}
