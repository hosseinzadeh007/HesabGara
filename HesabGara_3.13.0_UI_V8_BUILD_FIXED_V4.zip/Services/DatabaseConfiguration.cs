using System.Text.Json;

namespace AccountingPurchasePro.Services;

public enum DatabaseProvider { Sqlite, SqlServer }

public sealed class DatabaseConfiguration
{
    public DatabaseProvider Provider { get; set; } = DatabaseProvider.Sqlite;
    public string ConnectionString { get; set; } = "";
    public bool IsNetworkMode => Provider == DatabaseProvider.SqlServer;
}

public static class DatabaseConfigurationStore
{
    public static string DirectoryPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara");
    public static string FilePath => Path.Combine(DirectoryPath, "database.json");
    static string LegacyDirectoryPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabYar");
    static string LegacyFilePath => Path.Combine(LegacyDirectoryPath, "database.json");

    public static DatabaseConfiguration Load()
    {
        try
        {
            var path = File.Exists(FilePath) ? FilePath :
                       File.Exists(LegacyFilePath) ? LegacyFilePath : null;
            if (path is null) return new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite };

            var json = File.ReadAllText(path);
            var cfg = JsonSerializer.Deserialize<DatabaseConfiguration>(json);
            if (cfg is null) return new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite };

            // Never allow an incomplete/invalid saved configuration to break startup.
            if (cfg.Provider == DatabaseProvider.SqlServer && string.IsNullOrWhiteSpace(cfg.ConnectionString))
                return new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite };

            return cfg;
        }
        catch
        {
            // A damaged configuration must not prevent the application from starting.
            return new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite };
        }
    }

    public static void Save(DatabaseConfiguration config)
    {
        Directory.CreateDirectory(DirectoryPath);
        var json = JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true });
        var temp = FilePath + ".tmp";
        File.WriteAllText(temp, json);
        File.Move(temp, FilePath, true);
    }
}
