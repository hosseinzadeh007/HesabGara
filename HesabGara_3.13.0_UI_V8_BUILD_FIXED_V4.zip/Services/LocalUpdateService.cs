using System.Diagnostics;
using System.IO.Compression;
using System.Text.RegularExpressions;
using System.Globalization;

namespace AccountingPurchasePro.Services;

/// <summary>
/// به‌روزرسانی آفلاین/محلی بسته‌های انتشار حساب‌یار.
/// بسته باید یک ZIP از خروجی Publish باشد و شامل HesabYar.exe باشد.
/// </summary>
public sealed class LocalUpdateService
{
    public sealed record UpdatePackage(string ZipPath, string ExtractedRoot, string Version, string ApplicationDirectory);

    public static string CurrentVersion => typeof(LocalUpdateService).Assembly.GetName().Version?.ToString(3) ?? "3.11.0";

    public static UpdatePackage Inspect(string zipPath)
    {
        if (string.IsNullOrWhiteSpace(zipPath) || !File.Exists(zipPath))
            throw new FileNotFoundException("فایل بسته به‌روزرسانی پیدا نشد.", zipPath);

        if (!string.Equals(Path.GetExtension(zipPath), ".zip", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("بسته به‌روزرسانی باید با فرمت ZIP باشد.");

        var root = Path.Combine(Path.GetTempPath(), "HesabYarUpdate", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(root);
        try
        {
            ZipFile.ExtractToDirectory(zipPath, root, overwriteFiles: true);
            var exe = Directory.EnumerateFiles(root, "HesabYar.exe", SearchOption.AllDirectories)
                .Concat(Directory.EnumerateFiles(root, "HesabGara.exe", SearchOption.AllDirectories))
                .FirstOrDefault();
            if (exe is null)
                throw new InvalidOperationException("این فایل ZIP بسته انتشار حساب‌یار نیست؛ فایل HesabYar.exe در آن پیدا نشد.");

            var payload = Path.GetDirectoryName(exe)!;
            var version = ReadVersion(payload) ?? ReadVersionFromFileName(zipPath) ?? "نامشخص";
            if (!Version.TryParse(version, out var candidate))
                throw new InvalidOperationException("شماره نسخه بسته به‌روزرسانی معتبر نیست. نمونه صحیح: ۳.۳.۰");
            var currentText = CurrentVersion;
            if (Version.TryParse(currentText, out var current) && candidate <= current)
                throw new InvalidOperationException($"این بسته قدیمی یا هم‌نسخه است. نسخه فعلی {currentText} و نسخه بسته {version} است.");
            return new UpdatePackage(zipPath, root, version, payload);
        }
        catch
        {
            TryDelete(root);
            throw;
        }
    }

    public static void StartUpdate(UpdatePackage package, string targetDirectory)
    {
        if (!Directory.Exists(package.ApplicationDirectory))
            throw new DirectoryNotFoundException("پوشه فایل‌های به‌روزرسانی پیدا نشد.");
        if (string.IsNullOrWhiteSpace(targetDirectory) || !Directory.Exists(targetDirectory))
            throw new DirectoryNotFoundException("پوشه نصب فعلی حساب‌یار پیدا نشد.");

        var currentPid = Environment.ProcessId;
        var currentExe = Process.GetCurrentProcess().MainModule?.FileName;
        if (string.IsNullOrWhiteSpace(currentExe) || !File.Exists(currentExe))
            throw new InvalidOperationException("مسیر اجرای فعلی حساب‌یار قابل تشخیص نیست.");

        var script = Path.Combine(Path.GetTempPath(), $"HesabYar-LocalUpdate-{Guid.NewGuid():N}.cmd");
        var source = package.ApplicationDirectory.TrimEnd('\\');
        var target = targetDirectory.TrimEnd('\\');
        var tempRoot = package.ExtractedRoot.TrimEnd('\\');
        var escapedSource = source.Replace("\"", "\"\"");
        var escapedTarget = target.Replace("\"", "\"\"");
        var escapedTemp = tempRoot.Replace("\"", "\"\"");
        var escapedExe = currentExe.Replace("\"", "\"\"");

        var lines = new[]
        {
            "@echo off",
            "setlocal",
            $"set PID={currentPid}",
            $"set SOURCE=\"{escapedSource}\"",
            $"set TARGET=\"{escapedTarget}\"",
            $"set TEMP_ROOT=\"{escapedTemp}\"",
            $"set EXE=\"{escapedExe}\"",
            ":WAIT_APP",
            "tasklist /FI \"PID eq %PID%\" | findstr /R /C:\" %PID% \" >nul",
            "if not errorlevel 1 (timeout /t 1 /nobreak >nul & goto WAIT_APP)",
            "echo Updating HesabYar...",
            "robocopy %SOURCE% %TARGET% /E /R:3 /W:1 /XF *.db *.db-shm *.db-wal /NFL /NDL /NJH /NJS >nul",
            "set RC=%ERRORLEVEL%",
            "if %RC% GEQ 8 goto FAIL",
            "start \"\" %EXE%",
            "rmdir /S /Q %TEMP_ROOT% >nul 2>&1",
            "del \"%~f0\" >nul 2>&1",
            "exit /b 0",
            ":FAIL",
            "echo Update failed. Error code: %RC%",
            "start \"\" %EXE%",
            "pause",
            "del \"%~f0\" >nul 2>&1",
            "exit /b %RC%"
        };
        File.WriteAllLines(script, lines, new System.Text.UTF8Encoding(false));

        var psi = new ProcessStartInfo
        {
            FileName = "cmd.exe",
            Arguments = $"/c \"{script}\"",
            UseShellExecute = true,
            Verb = "runas",
            WindowStyle = ProcessWindowStyle.Hidden,
            WorkingDirectory = targetDirectory
        };
        Process.Start(psi);
    }

    private static string? ReadVersion(string payload)
    {
        var candidates = new[] { "VERSION.txt", "version.txt", "HesabYar.version.txt" };
        foreach (var name in candidates)
        {
            var path = Path.Combine(payload, name);
            if (!File.Exists(path)) continue;
            var value = File.ReadAllText(path).Trim();
            if (!string.IsNullOrWhiteSpace(value)) return value;
        }
        return null;
    }

    private static string? ReadVersionFromFileName(string path)
    {
        var match = Regex.Match(Path.GetFileNameWithoutExtension(path), @"(?<!\d)(\d+\.\d+(?:\.\d+){0,2})(?!\d)");
        return match.Success ? match.Groups[1].Value : null;
    }

    private static void TryDelete(string path)
    {
        try { if (Directory.Exists(path)) Directory.Delete(path, true); } catch { }
    }
}
