using AccountingPurchasePro.Domain;
using Xunit;

namespace AccountingPurchasePro.Tests;

public class FinanceRulesTests
{
    [Fact]
    public void Balance_Never_Goes_Negative()
        => Assert.Equal(0m, FinanceRules.Balance(100m, 150m));

    [Fact]
    public void Weighted_Date_Uses_Remaining_Balance()
    {
        var today = new DateTime(2026, 8, 13);
        var result = FinanceRules.Summarize(new[]
        {
            (100m, 0m, today.AddDays(10)),
            (900m, 0m, today.AddDays(30))
        }, today);

        Assert.Equal(28m, result.WeightedDays);
        Assert.Equal(today.AddDays(28), result.WeightedDate);
    }

    [Fact]
    public void Paid_Is_Clamped_To_Invoice_Amount()
    {
        var r = FinanceRules.Summarize(new[] { (100m, 150m, DateTime.Today.AddDays(10)) });
        Assert.Equal(100m, r.Paid);
        Assert.Equal(0m, r.Balance);
        Assert.Null(r.WeightedDate);
    }

    [Fact]
    public void Weighted_Date_Uses_Net_Remaining_Balance_When_Partially_Paid()
    {
        var today = new DateTime(2026, 8, 13);
        var result = FinanceRules.Summarize(new[]
        {
            (1000m, 900m, today.AddDays(5)),
            (100m, 0m, today.AddDays(25))
        }, today);

        Assert.Equal(15m, result.WeightedDays);
        Assert.Equal(today.AddDays(15), result.WeightedDate);
        Assert.Equal(200m, result.Balance);
    }

    [Fact]
    public void Empty_Selection_Has_No_Weighted_Date()
    {
        var result = FinanceRules.Summarize(Array.Empty<(decimal Amount, decimal Paid, DateTime DueDate)>());
        Assert.Equal(0m, result.Total);
        Assert.Equal(0m, result.Balance);
        Assert.Null(result.WeightedDate);
    }
}
