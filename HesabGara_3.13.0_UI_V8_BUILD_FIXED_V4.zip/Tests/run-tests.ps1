$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { throw 'dotnet SDK not found. Install .NET 8 SDK on Windows.' }
& $dotnet.Source test .\AccountingPurchasePro.sln -c Release --no-restore
if ($LASTEXITCODE -ne 0) { throw "dotnet test failed with exit code $LASTEXITCODE" }
Write-Host 'All automated tests passed.' -ForegroundColor Green
