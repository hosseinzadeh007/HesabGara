# حسابداری خرید حرفه‌ای — نسخه 3.0 Release Candidate

این بسته، نسخه حرفه‌ای آماده انتشار پروژه C# / WPF است.

## ویژگی‌های اصلی
- C# / .NET 8 / WPF / Entity Framework Core / SQLite
- رابط فارسی و راست‌چین
- مدیریت شرکت‌ها، فاکتورها و پرداخت‌ها
- تفکیک کامل اطلاعات بر اساس شرکت
- انتخاب فاکتورها با CheckBox و محاسبه زنده جمع، پرداختی، مانده و میانگین وزنی سررسید
- میانگین وزنی بر مبنای مانده واقعی
- Import / Export Excel و تشخیص تکراری‌ها
- کاربران، ورود امن و سطح دسترسی
- Audit Log
- Backup و Restore اعتبارسنجی‌شده
- Backup خودکار قابل تنظیم
- بررسی سلامت دیتابیس
- گزارش و چاپ
- حذف کامل بخش کالاها و خدمات
- Self-contained win-x64
- Installer با Inno Setup

## انتشار روی Windows
1. Windows 10/11 x64 داشته باشید.
2. .NET 8 SDK و Inno Setup را روی ماشین Build نصب کنید.
3. PowerShell را با دسترسی مناسب باز کنید.
4. `Installer/test-and-publish.ps1` را اجرا کنید.
5. خروجی Setup در `installer-output` ساخته می‌شود.

## نکته داده‌ها
دیتابیس در `%LOCALAPPDATA%\AccountingPurchasePro\accounting.db` نگهداری می‌شود و حذف برنامه نباید اطلاعات را حذف کند.
قبل از Restore، نسخه ایمنی با پسوند `.before-restore-*` ساخته می‌شود.

## وضعیت تست
این محیط اجرای فعلی Linux است و Windows/.NET SDK در آن موجود نیست؛ بنابراین EXE/Setup در این محیط Build و اجرای واقعی نشده است. اسکریپت انتشار برای Build واقعی Windows آماده شده است.
