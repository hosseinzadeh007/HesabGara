using System.Windows;
using AccountingPurchasePro.Data;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        AppFileLogger.Info("شروع حساب‌گرا.");
        ShutdownMode = ShutdownMode.OnExplicitShutdown;
        base.OnStartup(e);
        DispatcherUnhandledException += (_, args) =>
        {
            AppFileLogger.Error("خطای UI مدیریت‌نشده.", args.Exception);
            MessageBox.Show($"خطای غیرمنتظره رخ داد:\n{args.Exception.Message}", "خطای نرم‌افزار", MessageBoxButton.OK, MessageBoxImage.Error);
            args.Handled = true;
        };
        string startupStage = "شروع برنامه";
        try
        {
            AppFileLogger.Info($"نسخه {typeof(App).Assembly.GetName().Version?.ToString(3)}");
            // First-run deployment wizard: choose local SQLite or network SQL Server before database initialization.
            startupStage = "بررسی تنظیمات پایگاه داده";
            if (!File.Exists(DatabaseConfigurationStore.FilePath))
            {
                var setup = new Views.SetupWizardWindow();
                if (setup.ShowDialog() != true || !setup.Completed) { Shutdown(0); return; }
            }
            startupStage = "ایجاد و بازکردن پایگاه داده";
            AppFileLogger.Info("شروع آماده‌سازی پایگاه داده...");
            DatabaseInitializer.Initialize();
            AppFileLogger.Info("پایگاه داده با موفقیت آماده شد.");

            startupStage = "همگام‌سازی مبالغ پرداخت‌شده";
            AppFileLogger.Info("شروع همگام‌سازی مبالغ پرداخت‌شده...");
            new AccountingService().ReconcilePaidAmountsAsync().GetAwaiter().GetResult();
            AppFileLogger.Info("همگام‌سازی مبالغ پرداخت‌شده انجام شد.");

            startupStage = "بازکردن صفحه ورود";
            AppFileLogger.Info("شروع صفحه ورود...");
            var login = new Views.LoginWindow();
            if (login.ShowDialog() != true || login.AuthenticatedUser is null) { Shutdown(0); return; }
            UserSession.Start(login.AuthenticatedUser);
            var main = new Views.MainWindow(login.AuthenticatedUser);
            main.Closed += (_, _) => { UserSession.Clear(); Shutdown(0); };
            main.Show();
        }
        catch (Exception ex)
        {
            ex.Data["StartupStage"] = startupStage;
            AppFileLogger.Error($"خطا در راه‌اندازی برنامه در مرحله «{startupStage}».", ex);
            var stage = ex.Data["StartupStage"]?.ToString() ?? "نامشخص";
            var inner = ex.InnerException is null ? "" : $"\n\nجزئیات داخلی:\n{ex.InnerException}";
            MessageBox.Show($"راه‌اندازی حساب‌گرا انجام نشد.\n\nمرحله: {stage}\n\n{ex.Message}{inner}\n\nگزارش کامل خطا در:\n{AppFileLogger.CurrentLogPath}", "خطای راه‌اندازی", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(-1);
        }
    }
}
