namespace AccountingPurchasePro.Models;

public sealed class AppUser
{
    public int Id { get; set; }
    public string UserName { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public bool IsAdmin { get; set; }
    public bool IsActive { get; set; } = true;
    public bool CanManageData { get; set; } = true;
    public bool CanViewReports { get; set; } = true;
    public bool CanImportExport { get; set; } = true;
    public bool CanBackup { get; set; } = true;
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime? LastLoginUtc { get; set; }
}
