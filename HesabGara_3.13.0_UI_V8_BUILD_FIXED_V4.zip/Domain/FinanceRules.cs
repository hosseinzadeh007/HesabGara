namespace AccountingPurchasePro.Domain;

public static class FinanceRules
{
    public static decimal ClampPaid(decimal amount, decimal paid) => Math.Clamp(paid, 0m, Math.Max(0m, amount));
    public static decimal Balance(decimal amount, decimal paid) => Math.Max(0m, amount - ClampPaid(amount, paid));

    public static (decimal Total, decimal Paid, decimal Balance, decimal WeightedDays, DateTime? WeightedDate)
        Summarize(IEnumerable<(decimal Amount, decimal Paid, DateTime DueDate)> invoices, DateTime? reference = null)
    {
        var list = invoices.ToList();
        var total = list.Sum(x => x.Amount);
        var paid = list.Sum(x => ClampPaid(x.Amount, x.Paid));
        var balance = list.Sum(x => Balance(x.Amount, x.Paid));
        if (balance <= 0) return (total, paid, 0m, 0m, null);
        var refDate = (reference ?? DateTime.Today).Date;
        var weightedDays = list.Sum(x => Balance(x.Amount, x.Paid) * (decimal)(x.DueDate.Date - refDate).TotalDays) / balance;
        return (total, paid, balance, weightedDays, refDate.AddDays((double)weightedDays));
    }
}
