﻿@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-HesabGara-3.13.ps1"
if errorlevel 1 (
 echo.
 echo BUILD FAILED
 pause
 exit /b 1
)
echo.
echo BUILD SUCCESSFUL
pause
