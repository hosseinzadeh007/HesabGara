# چک‌لیست Release 3.11.0

- [ ] dotnet restore
- [ ] dotnet test
- [ ] dotnet publish win-x64 self-contained
- [ ] بررسی FileVersion EXE
- [ ] بررسی SHA-256 manifest
- [ ] ساخت Inno Setup
- [ ] نصب تمیز روی Windows 10/11 x64
- [ ] اجرای Login
- [ ] تست SQLite
- [ ] تست SQL Server Client/Server
- [ ] تست Backup/Restore
- [ ] تست Local Update و Rollback
- [ ] تست Uninstall
- [ ] تست اجرای مجدد بعد از Restart
