using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using AccountingPurchasePro.Models;
using AccountingPurchasePro.Services;

namespace AccountingPurchasePro.Views;

public class InvoicesView : Grid
{
    readonly AccountingService S; readonly int? InitialCompanyId; readonly DataGrid G=new(); readonly TextBlock Summary=new();
    ComboBox CompanyBox=new(); TextBox NumberBox=new(), AmountBox=new(), DateBox=new(), DueBox=new(), NoteBox=new();
    readonly ObservableCollection<Row> Rows=new(); bool loading; bool suppressCompanyChange;

    public InvoicesView(AccountingService s,int? companyId){S=s;InitialCompanyId=companyId;Margin=new Thickness(18);Background=new SolidColorBrush(Color.FromRgb(244,247,251));Build();Loaded+=async(_,_)=>{await InitCompanies();await Load();};}

    void Build()
    {
        FlowDirection = FlowDirection.RightToLeft;
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(202) });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(66) });
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        var card = new Border
        {
            Background = Brushes.White,
            BorderBrush = new SolidColorBrush(Color.FromRgb(224,232,240)),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(14),
            Padding = new Thickness(16),
            Margin = new Thickness(0,0,0,10)
        };

        var g = new Grid { FlowDirection = FlowDirection.RightToLeft };
        for (int i=0;i<4;i++) g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(34) });
        g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(62) });
        g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(62) });

        var title = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        title.Children.Add(new TextBlock { Text="مشخصات فاکتور", FontSize=17, FontWeight=FontWeights.Bold,
            Foreground=new SolidColorBrush(Color.FromRgb(11,58,122)) });
        title.Children.Add(new TextBlock { Text="  ثبت و ویرایش اطلاعات فاکتور", Foreground=new SolidColorBrush(Color.FromRgb(102,112,133)),
            FontSize=12.5, VerticalAlignment=VerticalAlignment.Center, Margin=new Thickness(8,0,0,0) });
        Grid.SetColumnSpan(title,4); Grid.SetRow(title,0); g.Children.Add(title);

        AddField(g,"شماره فاکتور *",NumberBox,0,1);
        AddCombo(g,"شرکت *",CompanyBox,1,1);
        AddField(g,"تاریخ فاکتور",DateBox,2,1);
        AddField(g,"سررسید",DueBox,3,1);

        AddField(g,"مبلغ (ریال) *",AmountBox,0,2);
        Grid.SetColumnSpan(NoteBox,1);
        AddField(g,"توضیحات",NoteBox,1,2);

        var buttons = new StackPanel { Orientation=Orientation.Horizontal, HorizontalAlignment=HorizontalAlignment.Left,
            VerticalAlignment=VerticalAlignment.Center, FlowDirection=FlowDirection.RightToLeft };
        var save=Btn("＋ ثبت / ذخیره","#12A85A"); save.Click+=AddInvoice;
        var clear=Btn("پاک کردن","#E9EEF4"); clear.Foreground=new SolidColorBrush(Color.FromRgb(30,55,80)); clear.Click+=(_,_)=>ClearForm();
        var del=Btn("حذف","#FFF1F2"); del.Foreground=new SolidColorBrush(Color.FromRgb(190,45,65)); del.Click+=DeleteInvoice;
        buttons.Children.Add(save); buttons.Children.Add(clear); buttons.Children.Add(del);
        Grid.SetColumn(buttons,2); Grid.SetColumnSpan(buttons,2); Grid.SetRow(buttons,2); g.Children.Add(buttons);

        card.Child=g; Grid.SetRow(card,0); Children.Add(card);

        var sumCard = new Border
        {
            Background=new SolidColorBrush(Color.FromRgb(236,244,252)),
            CornerRadius=new CornerRadius(11), Padding=new Thickness(10,8),
            Margin=new Thickness(0,0,0,8),
            BorderBrush=new SolidColorBrush(Color.FromRgb(210,224,238)), BorderThickness=new Thickness(1)
        };
        var sp=new DockPanel { LastChildFill=true, FlowDirection=FlowDirection.RightToLeft };
        Summary.FontSize=13; Summary.FontWeight=FontWeights.SemiBold; Summary.Foreground=new SolidColorBrush(Color.FromRgb(30,55,80));
        Summary.Text="هیچ فاکتوری انتخاب نشده است"; Summary.TextWrapping=TextWrapping.Wrap; Summary.VerticalAlignment=VerticalAlignment.Center;
        sp.Children.Add(Summary);
        var btns=new StackPanel { Orientation=Orientation.Horizontal, HorizontalAlignment=HorizontalAlignment.Left, FlowDirection=FlowDirection.RightToLeft };
        var all=Btn("انتخاب همه","#FFFFFF"); all.Foreground=new SolidColorBrush(Color.FromRgb(20,62,100)); all.Click+=(_,_)=>{foreach(var r in Rows)r.Selected=true;UpdateSummary();};
        var none=Btn("لغو انتخاب","#FFFFFF"); none.Foreground=new SolidColorBrush(Color.FromRgb(20,62,100)); none.Click+=(_,_)=>{foreach(var r in Rows)r.Selected=false;UpdateSummary();};
        btns.Children.Add(all); btns.Children.Add(none); DockPanel.SetDock(btns,Dock.Left); sp.Children.Add(btns);
        sumCard.Child=sp; Grid.SetRow(sumCard,1); Children.Add(sumCard);

        G.FlowDirection=FlowDirection.RightToLeft; G.AutoGenerateColumns=false; G.CanUserAddRows=false; G.IsReadOnly=false;
        G.SelectionUnit=DataGridSelectionUnit.FullRow; G.RowHeight=40; G.ColumnHeaderHeight=38; G.FontSize=12.5;
        G.HorizontalScrollBarVisibility=ScrollBarVisibility.Auto; G.VerticalScrollBarVisibility=ScrollBarVisibility.Auto;
        G.Columns.Add(new DataGridCheckBoxColumn{Header="انتخاب",Binding=new System.Windows.Data.Binding(nameof(Row.Selected)){Mode=System.Windows.Data.BindingMode.TwoWay,UpdateSourceTrigger=System.Windows.Data.UpdateSourceTrigger.PropertyChanged},Width=70});
        G.Columns.Add(new DataGridTextColumn{Header="شماره",Binding=new System.Windows.Data.Binding(nameof(Row.Number)),IsReadOnly=true,Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="شرکت",Binding=new System.Windows.Data.Binding("Company.Name"),IsReadOnly=true,Width=new DataGridLength(1.8,DataGridLengthUnitType.Star),MinWidth=150});
        G.Columns.Add(new DataGridTextColumn{Header="تاریخ",Binding=new System.Windows.Data.Binding(nameof(Row.InvoiceDatePersian)),IsReadOnly=true,Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="سررسید",Binding=new System.Windows.Data.Binding(nameof(Row.DueDatePersian)),IsReadOnly=true,Width=110});
        G.Columns.Add(new DataGridTextColumn{Header="مبلغ",Binding=new System.Windows.Data.Binding(nameof(Row.Amount)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1.15,DataGridLengthUnitType.Star),MinWidth=125});
        G.Columns.Add(new DataGridTextColumn{Header="پرداختی",Binding=new System.Windows.Data.Binding(nameof(Row.Paid)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1.15,DataGridLengthUnitType.Star),MinWidth=125});
        G.Columns.Add(new DataGridTextColumn{Header="مانده",Binding=new System.Windows.Data.Binding(nameof(Row.Balance)){StringFormat="{0:N0}"},IsReadOnly=true,Width=new DataGridLength(1.15,DataGridLengthUnitType.Star),MinWidth=125});
        CompanyBox.SelectionChanged+=async(_,_)=>{if(!loading&&!suppressCompanyChange)await Load();};
        G.SelectionChanged+=(_,_)=>{if(G.SelectedItem is Row r)Populate(r);}; G.CurrentCellChanged+=(_,_)=>Dispatcher.BeginInvoke(UpdateSummary);
        G.CellEditEnding+=(_,_)=>Dispatcher.BeginInvoke(UpdateSummary); G.MouseLeftButtonUp+=(_,_)=>Dispatcher.BeginInvoke(UpdateSummary);
        Grid.SetRow(G,2); Children.Add(G);
    }
    static Button Btn(string text,string bg){return new Button{Content=text,Background=new BrushConverter().ConvertFromString(bg) as Brush,BorderThickness=new Thickness(0),Padding=new Thickness(13,8,13,8),Margin=new Thickness(4),FontWeight=FontWeights.SemiBold,Cursor=System.Windows.Input.Cursors.Hand};}
    static void AddField(Grid g,string label,TextBox box,int c,int r){var p=new StackPanel{Margin=new Thickness(5,0,5,0)};p.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Foreground=new SolidColorBrush(Color.FromRgb(52,64,84))});box.Height=40;box.Margin=new Thickness(0,4,0,0);p.Children.Add(box);Grid.SetColumn(p,c);Grid.SetRow(p,r);g.Children.Add(p);}
    static void AddCombo(Grid g,string label,ComboBox box,int c,int r){var p=new StackPanel{Margin=new Thickness(5,0,5,0)};p.Children.Add(new TextBlock{Text=label,FontWeight=FontWeights.SemiBold,Foreground=new SolidColorBrush(Color.FromRgb(52,64,84))});box.Height=40;box.Margin=new Thickness(0,4,0,0);p.Children.Add(box);Grid.SetColumn(p,c);Grid.SetRow(p,r);g.Children.Add(p);}
    async Task InitCompanies(){loading=true;var list=await S.GetCompaniesAsync();var all=new List<Company>{new Company{Id=0,Name="همه شرکت‌ها"}};all.AddRange(list);CompanyBox.ItemsSource=all;CompanyBox.DisplayMemberPath="Name";CompanyBox.SelectedValuePath="Id";CompanyBox.SelectedValue=InitialCompanyId??0;DateBox.Text=PersianDateService.ToPersian(DateTime.Today);DueBox.Text=PersianDateService.ToPersian(DateTime.Today.AddDays(30));loading=false;}
    int? FilterCompanyId=>CompanyBox.SelectedValue is int id&&id>0?id:null;
    void Populate(Row r){suppressCompanyChange=true;NumberBox.Text=r.Number;CompanyBox.SelectedValue=r.Company?.Id??0;suppressCompanyChange=false;DateBox.Text=r.InvoiceDatePersian;DueBox.Text=r.DueDatePersian;AmountBox.Text=r.Amount.ToString("0.##");NoteBox.Text=r.Note??"";}
    async Task Load(){Rows.Clear();var list=await S.GetInvoicesAsync(FilterCompanyId);foreach(var x in list){var row=new Row(x);row.PropertyChanged+=(s,e)=>{if(e.PropertyName==nameof(Row.Selected))Dispatcher.BeginInvoke(UpdateSummary);};Rows.Add(row);}G.ItemsSource=Rows;UpdateSummary();}
    void UpdateSummary(){
        var selected=Rows.Where(x=>x.Selected).ToList();
        if(selected.Count==0){Summary.Text="هیچ فاکتوری انتخاب نشده است";return;}
        var summary=AccountingPurchasePro.Domain.FinanceRules.Summarize(selected.Select(x=>(x.Amount,x.Paid,x.DueDateValue)));
        var weighted=summary.WeightedDate.HasValue ? PersianDateService.ToPersian(summary.WeightedDate.Value) : "—";
        var days=summary.WeightedDate.HasValue ? $"{summary.WeightedDays:N1} روز" : "—";
        Summary.Text=$"انتخاب: {selected.Count:N0} فاکتور   |   جمع: {summary.Total:N0} ریال   |   پرداختی: {summary.Paid:N0} ریال   |   مانده: {summary.Balance:N0} ریال   |   سررسید وزنی: {weighted} ({days})";
    }
    async void AddInvoice(object? s,RoutedEventArgs e){try{if(CompanyBox.SelectedValue is not int cid||cid<=0)throw new ArgumentException("شرکت را انتخاب کنید.");var inv=new Invoice{CompanyId=cid,Number=NumberBox.Text.Trim(),InvoiceDate=ParseDate(DateBox.Text),DueDate=ParseDate(DueBox.Text),Amount=decimal.Parse(AmountBox.Text.Replace(",","")),Note=NoteBox.Text};if(G.SelectedItem is Row r)inv.Id=r.Id; if(inv.Id>0)await S.UpdateInvoiceAsync(inv);else await S.AddInvoiceAsync(inv);ClearForm();await Load();}catch(Exception ex){MessageBox.Show(ex.Message,"ثبت فاکتور",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    static DateTime ParseDate(string text){if(PersianDateService.TryParse(text,out var d))return d;throw new ArgumentException("تاریخ را به صورت ۱۴۰۵/۰۵/۲۳ وارد کنید.");}
    async void DeleteInvoice(object? s,RoutedEventArgs e){if(G.SelectedItem is not Row r){MessageBox.Show("یک فاکتور را انتخاب کنید.");return;}if(MessageBox.Show($"فاکتور «{r.Number}» حذف شود؟","تأیید حذف",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;try{await S.DeleteInvoiceAsync(r.Id);ClearForm();await Load();}catch(Exception ex){MessageBox.Show(ex.Message,"حذف فاکتور",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    void ClearForm(){NumberBox.Clear();AmountBox.Clear();NoteBox.Clear();DateBox.Text=PersianDateService.ToPersian(DateTime.Today);DueBox.Text=PersianDateService.ToPersian(DateTime.Today.AddDays(30));G.UnselectAll();}

    public class Row:INotifyPropertyChanged{readonly Invoice X;bool selected;public Row(Invoice x){X=x;}public int Id=>X.Id;public string Number=>X.Number;public Company? Company=>X.Company;public DateTime InvoiceDateValue=>X.InvoiceDate;public DateTime DueDateValue=>X.DueDate;public string InvoiceDatePersian=>PersianDateService.ToPersian(X.InvoiceDate);public string DueDatePersian=>PersianDateService.ToPersian(X.DueDate);public decimal Amount=>X.Amount;public decimal Paid=>X.Paid;public decimal Balance=>AccountingService.Balance(X);public string? Note=>X.Note;public bool Selected{get=>selected;set{if(selected==value)return;selected=value;PropertyChanged?.Invoke(this,new PropertyChangedEventArgs(nameof(Selected)));}}public event PropertyChangedEventHandler? PropertyChanged;}
}